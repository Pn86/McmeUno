package dev.craftwizard.pnwarehouseplugin.util;

import org.bukkit.ChatColor;

/**
 * 文本工具：颜色代码转换与占位符替换。
 */
public final class Text {

    private Text() {
    }

    public static String color(String text) {
        if (text == null) {
            return "";
        }
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public static String replace(String text, String key, String value) {
        if (text == null) {
            return "";
        }
        return text.replace("%" + key + "%", value == null ? "" : value);
    }
}
