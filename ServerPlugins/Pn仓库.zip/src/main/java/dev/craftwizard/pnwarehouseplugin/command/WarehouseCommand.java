package dev.craftwizard.pnwarehouseplugin.command;

import dev.craftwizard.pnwarehouseplugin.PnWarehousePlugin;
import dev.craftwizard.pnwarehouseplugin.warehouse.WarehouseManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * /warehouse 打开个人仓库。
 */
public final class WarehouseCommand implements TabExecutor {

    private final PnWarehousePlugin plugin;

    public WarehouseCommand(PnWarehousePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        WarehouseManager manager = plugin.getManager();
        if (!(sender instanceof Player player)) {
            manager.sendMessage(sender, "only-player");
            return true;
        }
        if (!player.hasPermission("pnwarehouse.use")) {
            manager.sendMessage(player, "no-permission");
            return true;
        }
        manager.openWarehouse(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
