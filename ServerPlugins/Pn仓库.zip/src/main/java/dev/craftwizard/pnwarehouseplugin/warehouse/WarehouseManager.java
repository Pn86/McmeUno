package dev.craftwizard.pnwarehouseplugin.warehouse;

import dev.craftwizard.pnwarehouseplugin.PnWarehousePlugin;
import dev.craftwizard.pnwarehouseplugin.config.PluginConfig;
import dev.craftwizard.pnwarehouseplugin.storage.StorageBackend;
import dev.craftwizard.pnwarehouseplugin.storage.StorageFactory;
import dev.craftwizard.pnwarehouseplugin.util.Text;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 仓库核心管理器：负责打开/保存/清空/热重载/关闭。
 * <p>
 * 使用 generation 计数器防止“加载中数据”在 clear/cleardata/reload 之后
 * 被旧数据覆盖（复活）的竞态问题。
 */
public final class WarehouseManager {

    private final PnWarehousePlugin plugin;
    private PluginConfig config;
    private StorageBackend backend;
    private final Map<UUID, WarehouseView> views = new ConcurrentHashMap<>();
    private final Set<UUID> loading = ConcurrentHashMap.newKeySet();
    private final AtomicLong generation = new AtomicLong();

    public WarehouseManager(PnWarehousePlugin plugin) {
        this.plugin = plugin;
        this.config = new PluginConfig(plugin);
        this.backend = StorageFactory.create(plugin, config);
    }

    public PluginConfig config() {
        return config;
    }

    public StorageBackend backend() {
        return backend;
    }

    public void openWarehouse(Player player) {
        UUID id = player.getUniqueId();
        if (views.containsKey(id) || !loading.add(id)) {
            return;
        }
        long gen = generation.get();
        StorageBackend backendAtOpen = backend;
        backendAtOpen.load(id.toString()).whenComplete((data, error) -> {
            player.getScheduler().run(plugin, t -> {
                loading.remove(id);
                if (!player.isOnline() || gen != generation.get() || backendAtOpen != backend) {
                    return;
                }
                if (error != null) {
                    plugin.getLogger().severe("读取玩家 " + player.getName() + " 的仓库数据失败: " + error.getMessage());
                    sendMessage(player, "database-error");
                    return;
                }
                String safeData = data;
                if (!WarehouseDataCodec.isSupported(safeData)) {
                    plugin.getLogger().warning("玩家 " + player.getName()
                            + " 的仓库数据格式版本不受支持，已按空仓库打开，请管理员检查。");
                    safeData = "";
                }
                WarehouseView view = new WarehouseView(plugin, backend, player, config,
                        WarehouseDataCodec.decode(safeData));
                views.put(id, view);
                player.openInventory(view.getInventory());
                sendMessage(player, "open");
            }, () -> loading.remove(id));
        });
    }

    public WarehouseView viewOf(UUID id) {
        return views.get(id);
    }

    /** 关闭界面时调用：移除视图并异步保存。 */
    public void onClose(Player player) {
        WarehouseView view = views.remove(player.getUniqueId());
        if (view != null) {
            view.saveAsync();
        }
    }

    /** 清空某个玩家的仓库（按 UUID）。 */
    public void clear(UUID uuid, String name) {
        WarehouseView view = views.get(uuid);
        if (view != null) {
            view.getPlayer().getScheduler().run(plugin, t -> {
                view.clearContents();
                view.saveAsync();
            }, null);
        } else {
            backend.clearByUuid(uuid.toString());
        }
        generation.incrementAndGet();
        plugin.getLogger().info("已清空玩家 " + name + " (" + uuid + ") 的仓库数据。");
    }

    /** 删除所有仓库数据（二次确认后调用）。 */
    public void clearAll() {
        generation.incrementAndGet();
        loading.clear();
        for (WarehouseView view : new ArrayList<>(views.values())) {
            views.remove(view.getOwnerId());
            view.discardAndClose();
        }
        backend.clearAll().exceptionally(t -> {
            plugin.getLogger().severe("删除全部仓库数据失败: " + t.getMessage());
            return null;
        });
        plugin.getLogger().info("已删除所有玩家的仓库数据。");
    }

    /** 热重载配置与数据库（支持 SQLite/MySQL 无重启切换）。 */
    public boolean reload() {
        generation.incrementAndGet();
        // 1. 保存并关闭所有已打开的仓库（写入旧存储）
        for (WarehouseView view : new ArrayList<>(views.values())) {
            views.remove(view.getOwnerId());
            view.saveSync();
            view.closeNow();
        }
        loading.clear();
        // 2. 重新读取配置文件
        plugin.reloadConfig();
        PluginConfig newConfig = new PluginConfig(plugin);
        // 3. 尝试创建新存储；失败则保留旧存储与旧配置
        StorageBackend newBackend;
        try {
            newBackend = StorageFactory.create(plugin, newConfig);
        } catch (Exception e) {
            plugin.getLogger().severe("数据库重载失败: " + e.getMessage());
            return false;
        }
        // 4. 切换存储与配置
        StorageBackend old = backend;
        this.config = newConfig;
        this.backend = newBackend;
        old.close();
        return true;
    }

    /** 插件禁用：同步保存所有打开的仓库并关闭数据库。 */
    public void disable() {
        for (WarehouseView view : new ArrayList<>(views.values())) {
            views.remove(view.getOwnerId());
            view.saveSync();
            view.closeNow();
        }
        views.clear();
        loading.clear();
        backend.close();
    }

    public void sendMessage(CommandSender sender, String key, String... replacements) {
        if (sender == null) {
            return;
        }
        String prefix = config.message("prefix");
        String msg = config.message(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = Text.replace(msg, replacements[i], replacements[i + 1]);
        }
        sender.sendMessage(Text.color(prefix + msg));
    }

    public void sendRawMessage(CommandSender sender, String key) {
        if (sender == null) {
            return;
        }
        sender.sendMessage(Text.color(config.message(key)));
    }
}
