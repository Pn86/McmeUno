package dev.craftwizard.pnwarehouseplugin.listener;

import dev.craftwizard.pnwarehouseplugin.warehouse.ItemCodec;
import dev.craftwizard.pnwarehouseplugin.warehouse.WarehouseManager;
import dev.craftwizard.pnwarehouseplugin.warehouse.WarehouseView;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

/**
 * 仓库界面交互监听：
 * - 无效物品槽位锁定（无法取出/放入）；
 * - 禁止把无效物品放入仓库；
 * - 关闭/退出时自动保存。
 */
public final class WarehouseListener implements Listener {

    private final WarehouseManager manager;

    public WarehouseListener(WarehouseManager manager) {
        this.manager = manager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        WarehouseView view = manager.viewOf(player.getUniqueId());
        if (view == null) {
            return;
        }
        int raw = event.getRawSlot();
        int size = view.getSize();

        // 点击仓库外区域：禁止丢弃
        if (raw == -999) {
            event.setCancelled(true);
            return;
        }

        if (raw >= 0 && raw < size) {
            // 点击仓库存储区
            if (view.isInvalidSlot(raw)) {
                event.setCancelled(true);
                manager.sendMessage(player, "invalid-item");
                return;
            }
            ItemStack current = event.getCurrentItem();
            if (current != null && !current.getType().isAir() && !ItemCodec.isUsable(current)) {
                event.setCancelled(true);
                manager.sendMessage(player, "invalid-item");
                return;
            }
            ItemStack cursor = event.getCursor();
            if (cursor != null && !cursor.getType().isAir() && !ItemCodec.isUsable(cursor)) {
                event.setCancelled(true);
                manager.sendMessage(player, "cannot-store");
                return;
            }
            if (event.getClick() == ClickType.NUMBER_KEY) {
                ItemStack hotbar = player.getInventory().getItem(event.getHotbarButton());
                if (hotbar != null && !hotbar.getType().isAir() && !ItemCodec.isUsable(hotbar)) {
                    event.setCancelled(true);
                    manager.sendMessage(player, "cannot-store");
                }
            }
        } else if (event.isShiftClick()) {
            // 从玩家背包 shift 点击移入仓库
            ItemStack current = event.getCurrentItem();
            if (current != null && !current.getType().isAir() && !ItemCodec.isUsable(current)) {
                event.setCancelled(true);
                manager.sendMessage(player, "cannot-store");
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        WarehouseView view = manager.viewOf(player.getUniqueId());
        if (view == null) {
            return;
        }
        for (int raw : event.getRawSlots()) {
            if (raw >= 0 && raw < view.getSize()) {
                ItemStack old = event.getOldCursor();
                if (old != null && !old.getType().isAir() && !ItemCodec.isUsable(old)) {
                    event.setCancelled(true);
                    manager.sendMessage(player, "cannot-store");
                }
                break;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }
        WarehouseView view = manager.viewOf(player.getUniqueId());
        if (view != null && view.getInventory() == event.getInventory()) {
            manager.onClose(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        manager.onClose(event.getPlayer());
    }
}
