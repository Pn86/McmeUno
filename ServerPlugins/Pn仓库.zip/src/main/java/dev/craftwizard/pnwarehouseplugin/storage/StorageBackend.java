package dev.craftwizard.pnwarehouseplugin.storage;

import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * 仓库数据存储后端（SQLite / MySQL 通用）。
 * <p>
 * 所有数据库操作通过内部单线程执行器串行执行，天然低占用且线程安全；
 * 连接由 HikariCP 池化，数据库断开后会自动重连。
 */
public abstract class StorageBackend implements AutoCloseable {

    protected final HikariDataSource dataSource;
    private final ExecutorService executor;

    protected StorageBackend(HikariDataSource dataSource) {
        this.dataSource = dataSource;
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "PnWarehouse-DB");
            t.setDaemon(true);
            return t;
        });
    }

    protected abstract String createTableSql();

    protected abstract String dbName();

    /** 建表并测试连接；失败抛出异常由工厂决定是否回退。 */
    public void init() {
        try (Connection conn = dataSource.getConnection();
             Statement st = conn.createStatement()) {
            st.execute(createTableSql());
        } catch (SQLException e) {
            throw new IllegalStateException("无法初始化 " + dbName() + " 数据库: " + e.getMessage(), e);
        }
    }

    // ---------- 异步接口（内部串行执行） ----------

    public CompletableFuture<String> load(String uuid) {
        return supplyAsync(() -> loadSync(uuid));
    }

    public CompletableFuture<Void> save(String uuid, String name, String data) {
        return runAsync(() -> saveSync(uuid, name, data));
    }

    public CompletableFuture<Void> clearByUuid(String uuid) {
        return runAsync(() -> clearByUuidSync(uuid));
    }

    public CompletableFuture<Void> clearAll() {
        return runAsync(this::clearAllSync);
    }

    public CompletableFuture<Optional<String>> findUuidByName(String name) {
        return supplyAsync(() -> findUuidByNameSync(name));
    }

    // ---------- 同步接口（关闭/热重载时使用） ----------

    public String loadSync(String uuid) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT data FROM pn_warehouse WHERE uuid = ?")) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("读取仓库数据失败", e);
        }
    }

    public void saveSync(String uuid, String name, String data) {
        try (Connection conn = dataSource.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE pn_warehouse SET name = ?, data = ?, updated_at = ? WHERE uuid = ?")) {
                ps.setString(1, name);
                ps.setString(2, data);
                ps.setLong(3, System.currentTimeMillis());
                ps.setString(4, uuid);
                if (ps.executeUpdate() == 0) {
                    try (PreparedStatement ins = conn.prepareStatement(
                            "INSERT INTO pn_warehouse (uuid, name, data, updated_at) VALUES (?, ?, ?, ?)")) {
                        ins.setString(1, uuid);
                        ins.setString(2, name);
                        ins.setString(3, data);
                        ins.setLong(4, System.currentTimeMillis());
                        ins.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("保存仓库数据失败", e);
        }
    }

    public void clearByUuidSync(String uuid) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM pn_warehouse WHERE uuid = ?")) {
            ps.setString(1, uuid);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("清空仓库数据失败", e);
        }
    }

    public void clearAllSync() {
        try (Connection conn = dataSource.getConnection();
             Statement st = conn.createStatement()) {
            st.executeUpdate("DELETE FROM pn_warehouse");
        } catch (SQLException e) {
            throw new IllegalStateException("删除全部仓库数据失败", e);
        }
    }

    public Optional<String> findUuidByNameSync(String name) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT uuid FROM pn_warehouse WHERE name = ? LIMIT 1")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(rs.getString(1)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("按玩家名查询仓库数据失败", e);
        }
    }

    private <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier) {
        CompletableFuture<T> future = new CompletableFuture<>();
        executor.execute(() -> {
            try {
                future.complete(supplier.get());
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        return future;
    }

    private CompletableFuture<Void> runAsync(Runnable runnable) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        executor.execute(() -> {
            try {
                runnable.run();
                future.complete(null);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        return future;
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        dataSource.close();
    }
}
