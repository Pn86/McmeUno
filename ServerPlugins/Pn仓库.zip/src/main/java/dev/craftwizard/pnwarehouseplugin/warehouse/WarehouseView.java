package dev.craftwizard.pnwarehouseplugin.warehouse;

import dev.craftwizard.pnwarehouseplugin.PnWarehousePlugin;
import dev.craftwizard.pnwarehouseplugin.config.PluginConfig;
import dev.craftwizard.pnwarehouseplugin.storage.StorageBackend;
import dev.craftwizard.pnwarehouseplugin.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * 一个玩家当前打开的仓库界面。
 * <p>
 * 无效槽位显示占位物品，且被锁定（不可取出、不可放入）。
 * 原始无效数据被保留，保存时原样写回，避免误删。
 */
public final class WarehouseView {

    private final PnWarehousePlugin plugin;
    private final StorageBackend backend;
    private final Player player;
    private final UUID ownerId;
    private final int size;
    private final Inventory inventory;
    private final Set<Integer> invalidSlots = new HashSet<>();
    private final Map<Integer, String> invalidRaw = new HashMap<>();
    private volatile boolean discarded;

    public WarehouseView(PnWarehousePlugin plugin, StorageBackend backend, Player player, PluginConfig config,
                         Map<Integer, String> rawSlots) {
        this.plugin = plugin;
        this.backend = backend;
        this.player = player;
        this.ownerId = player.getUniqueId();
        this.size = config.rows() * 9;
        String title = Text.color(Text.replace(config.title(), "player", player.getName()));
        this.inventory = Bukkit.createInventory(null, size, title);
        for (Map.Entry<Integer, String> entry : rawSlots.entrySet()) {
            int slot = entry.getKey();
            if (slot < 0 || slot >= size) {
                continue;
            }
            Optional<ItemStack> item = ItemCodec.deserialize(entry.getValue());
            if (item.isPresent()) {
                inventory.setItem(slot, item.get());
            } else {
                invalidSlots.add(slot);
                invalidRaw.put(slot, entry.getValue());
                inventory.setItem(slot, config.invalidItemStack());
            }
        }
    }

    public Inventory getInventory() {
        return inventory;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    public int getSize() {
        return size;
    }

    public Player getPlayer() {
        return player;
    }

    public boolean isInvalidSlot(int slot) {
        return invalidSlots.contains(slot);
    }

    /** 将当前界面内容编码为存储数据（需在玩家所属线程调用）。 */
    public String encodeCurrent() {
        Map<Integer, String> slots = new HashMap<>();
        for (int i = 0; i < size; i++) {
            if (invalidSlots.contains(i)) {
                String raw = invalidRaw.get(i);
                if (raw != null) {
                    slots.put(i, raw);
                }
                continue;
            }
            ItemStack item = inventory.getItem(i);
            if (item == null || item.getType().isAir()) {
                continue;
            }
            if (!ItemCodec.isUsable(item)) {
                continue;
            }
            String s = ItemCodec.serialize(item);
            if (s != null) {
                slots.put(i, s);
            }
        }
        return WarehouseDataCodec.encode(slots);
    }

    /** 异步保存（界面关闭时调用）。 */
    public void saveAsync() {
        if (discarded) {
            return;
        }
        String data = encodeCurrent();
        backend.save(ownerId.toString(), player.getName(), data)
                .exceptionally(t -> {
                    plugin.getLogger().severe("保存玩家 " + player.getName() + " 的仓库数据失败: " + t.getMessage());
                    return null;
                });
    }

    /** 同步保存（禁用/热重载时调用）。 */
    public void saveSync() {
        if (discarded) {
            return;
        }
        try {
            backend.saveSync(ownerId.toString(), player.getName(), encodeCurrent());
        } catch (Exception e) {
            plugin.getLogger().severe("保存玩家 " + player.getName() + " 的仓库数据失败: " + e.getMessage());
        }
    }

    /** 清空界面内容（/pnwh clear 使用）。 */
    public void clearContents() {
        invalidSlots.clear();
        invalidRaw.clear();
        for (int i = 0; i < size; i++) {
            inventory.clear(i);
        }
    }

    /** 标记丢弃并在实体线程关闭界面（/pnwh cleardata 使用，不保存）。 */
    public void discardAndClose() {
        discarded = true;
        closeNow();
    }

    /** 在玩家所属线程关闭界面。 */
    public void closeNow() {
        player.getScheduler().run(plugin, t -> {
            if (player.isOnline()) {
                player.closeInventory();
            }
        }, null);
    }
}
