package dev.craftwizard.pnwarehouseplugin.storage;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import dev.craftwizard.pnwarehouseplugin.config.PluginConfig;

/**
 * MySQL 跨服存储，多台服务器共享同一份仓库数据。
 */
public final class MySqlBackend extends StorageBackend {

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public MySqlBackend(PluginConfig config) {
        super(createDataSource(config));
    }

    private static HikariDataSource createDataSource(PluginConfig config) {
        String sslParam = config.mysqlUseSsl() ? "" : "&sslMode=DISABLED&allowPublicKeyRetrieval=true";
        HikariConfig hc = new HikariConfig();
        hc.setPoolName("PnWarehouse-MySQL");
        hc.setJdbcUrl("jdbc:mysql://" + config.mysqlHost() + ":" + config.mysqlPort()
                + "/" + config.mysqlDatabase()
                + "?useUnicode=true&characterEncoding=utf8" + sslParam);
        hc.setUsername(config.mysqlUsername());
        hc.setPassword(config.mysqlPassword());
        hc.setMaximumPoolSize(config.mysqlPoolSize());
        hc.setMinimumIdle(0);
        hc.setConnectionTimeout(5000);
        hc.setInitializationFailTimeout(3000);
        hc.setIdleTimeout(60000);
        hc.setMaxLifetime(1800000);
        return new HikariDataSource(hc);
    }

    @Override
    protected String createTableSql() {
        return "CREATE TABLE IF NOT EXISTS pn_warehouse ("
                + "uuid VARCHAR(36) PRIMARY KEY,"
                + "name VARCHAR(32) NOT NULL DEFAULT '',"
                + "data LONGTEXT NOT NULL,"
                + "updated_at BIGINT NOT NULL"
                + ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    }

    @Override
    protected String dbName() {
        return "MySQL";
    }
}
