package dev.craftwizard.pnwarehouseplugin.storage;

import dev.craftwizard.pnwarehouseplugin.config.PluginConfig;
import org.bukkit.plugin.Plugin;

/**
 * 存储工厂：按配置创建后端。
 * MySQL 连接失败时自动回退到 SQLite，保证插件始终可用（自动适配）。
 */
public final class StorageFactory {

    private StorageFactory() {
    }

    public static StorageBackend create(Plugin plugin, PluginConfig config) {
        if ("mysql".equalsIgnoreCase(config.storageType())) {
            try {
                MySqlBackend backend = new MySqlBackend(config);
                try {
                    backend.init();
                } catch (Exception e) {
                    backend.close();
                    throw e;
                }
                plugin.getLogger().info("已连接 MySQL 数据库: "
                        + config.mysqlHost() + ":" + config.mysqlPort() + "/" + config.mysqlDatabase());
                return backend;
            } catch (Exception e) {
                plugin.getLogger().severe("MySQL 连接失败: " + e.getMessage());
                plugin.getLogger().severe("已自动切换到 SQLite 本地存储 (database.db)，请检查 MySQL 配置后执行 /pnwh reload");
            }
        }
        SqliteBackend backend = new SqliteBackend(plugin);
        backend.init();
        plugin.getLogger().info("已连接 SQLite 数据库: database.db");
        return backend;
    }
}
