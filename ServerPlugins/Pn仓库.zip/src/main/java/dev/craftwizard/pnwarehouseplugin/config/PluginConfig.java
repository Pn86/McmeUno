package dev.craftwizard.pnwarehouseplugin.config;

import dev.craftwizard.pnwarehouseplugin.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 读取并缓存 config.yml 的配置与全部语言文本。
 * 所有字段在 reload() 时重新解析，支持 /pnwh reload 热重载。
 */
public final class PluginConfig {

    private static final Map<String, String> DEFAULT_MESSAGES = Map.ofEntries(
            Map.entry("prefix", "&8[&6PnWarehouse&8] &r"),
            Map.entry("reload-success", "&a配置与数据库已热重载完成！"),
            Map.entry("reload-fail", "&c数据库重载失败，已保留原存储，请查看控制台日志。"),
            Map.entry("no-permission", "&c你没有权限执行此操作。"),
            Map.entry("only-player", "&c该指令只能由玩家执行。"),
            Map.entry("open", "&a仓库已打开！"),
            Map.entry("player-not-found", "&c未找到玩家 %player%。"),
            Map.entry("warehouse-cleared", "&a玩家 %player% 的仓库已清空。"),
            Map.entry("data-cleared", "&c所有玩家的仓库数据已删除！"),
            Map.entry("cleardata-warning", "&c警告：此操作将删除所有玩家的仓库数据，且无法恢复！"),
            Map.entry("cleardata-confirm", "&c请再次输入 &6/pnwh cleardata &c以确认删除。"),
            Map.entry("invalid-item", "&c此物品已失效，无法取出。"),
            Map.entry("cannot-store", "&c此物品无法存入仓库。"),
            Map.entry("database-error", "&c数据库操作失败，请查看控制台日志。"),
            Map.entry("usage", "&e用法: &f/pnwh <reload|clear [玩家]|cleardata>")
    );

    private final Plugin plugin;
    private String storageType;
    private String mysqlHost;
    private int mysqlPort;
    private String mysqlDatabase;
    private String mysqlUsername;
    private String mysqlPassword;
    private int mysqlPoolSize;
    private boolean mysqlUseSsl;
    private int rows;
    private String title;
    private ItemStack invalidItemStack;
    private Map<String, String> messages;

    public PluginConfig(Plugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();

        storageType = c.getString("storage.type", "sqlite").toLowerCase(Locale.ROOT);
        if (!"mysql".equals(storageType)) {
            storageType = "sqlite";
        }
        mysqlHost = c.getString("storage.mysql.host", "localhost");
        mysqlPort = c.getInt("storage.mysql.port", 3306);
        mysqlDatabase = c.getString("storage.mysql.database", "pnwarehouse");
        mysqlUsername = c.getString("storage.mysql.username", "root");
        mysqlPassword = c.getString("storage.mysql.password", "");
        mysqlPoolSize = Math.max(1, c.getInt("storage.mysql.pool-size", 4));
        mysqlUseSsl = c.getBoolean("storage.mysql.use-ssl", false);

        rows = Math.max(1, Math.min(6, c.getInt("warehouse.rows", 3)));
        title = c.getString("warehouse.title", "&8仓库 - %player%");

        invalidItemStack = buildInvalidItem(c.getConfigurationSection("invalid-item"));
        messages = readMessages(c.getConfigurationSection("messages"));
    }

    public String storageType() {
        return storageType;
    }

    public String mysqlHost() {
        return mysqlHost;
    }

    public int mysqlPort() {
        return mysqlPort;
    }

    public String mysqlDatabase() {
        return mysqlDatabase;
    }

    public String mysqlUsername() {
        return mysqlUsername;
    }

    public String mysqlPassword() {
        return mysqlPassword;
    }

    public int mysqlPoolSize() {
        return mysqlPoolSize;
    }

    public boolean mysqlUseSsl() {
        return mysqlUseSsl;
    }

    public int rows() {
        return rows;
    }

    public String title() {
        return title;
    }

    public ItemStack invalidItemStack() {
        return invalidItemStack.clone();
    }

    public String message(String key) {
        return messages.getOrDefault(key, DEFAULT_MESSAGES.getOrDefault(key, ""));
    }

    private ItemStack buildInvalidItem(ConfigurationSection section) {
        String materialName = section == null ? "BARRIER" : section.getString("material", "BARRIER");
        Material material = Material.matchMaterial(materialName);
        if (material == null || material.isAir()) {
            material = Material.BARRIER;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(section == null ? "&c无效物品" : section.getString("name", "&c无效物品")));
            List<String> lore = section == null ? List.of() : section.getStringList("lore");
            List<String> colored = new ArrayList<>();
            for (String line : lore) {
                colored.add(Text.color(line));
            }
            if (colored.isEmpty()) {
                colored.add(Text.color("&7此物品在当前服务器版本中已失效"));
                colored.add(Text.color("&7无法取出，请联系管理员清理"));
            }
            meta.setLore(colored);
            item.setItemMeta(meta);
        }
        return item;
    }

    private Map<String, String> readMessages(ConfigurationSection section) {
        Map<String, String> result = new HashMap<>();
        for (Map.Entry<String, String> entry : DEFAULT_MESSAGES.entrySet()) {
            String value = section == null ? null : section.getString(entry.getKey());
            result.put(entry.getKey(), value == null ? entry.getValue() : value);
        }
        return result;
    }
}
