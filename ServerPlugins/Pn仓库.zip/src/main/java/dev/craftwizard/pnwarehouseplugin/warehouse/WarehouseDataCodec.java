package dev.craftwizard.pnwarehouseplugin.warehouse;

import java.util.HashMap;
import java.util.Map;

/**
 * 仓库整仓数据的编码/解码。
 * <p>
 * 格式: v1|槽位:Base64;槽位:Base64...
 * Base64 字符集不含 ':' 与 ';'，可安全作为分隔符。
 * 带版本前缀 v1，未来格式升级时可识别并标记旧数据为无效。
 */
public final class WarehouseDataCodec {

    private static final String PREFIX = "v1|";

    private WarehouseDataCodec() {
    }

    public static boolean isSupported(String data) {
        return data == null || data.isEmpty() || data.startsWith(PREFIX);
    }

    public static String encode(Map<Integer, String> slots) {
        StringBuilder sb = new StringBuilder(PREFIX);
        boolean first = true;
        for (Map.Entry<Integer, String> entry : slots.entrySet()) {
            if (!first) {
                sb.append(';');
            }
            first = false;
            sb.append(entry.getKey()).append(':').append(entry.getValue());
        }
        return sb.toString();
    }

    public static Map<Integer, String> decode(String data) {
        Map<Integer, String> result = new HashMap<>();
        if (data == null || data.isEmpty() || !data.startsWith(PREFIX)) {
            return result;
        }
        String body = data.substring(PREFIX.length());
        if (body.isEmpty()) {
            return result;
        }
        for (String entry : body.split(";")) {
            int idx = entry.indexOf(':');
            if (idx <= 0) {
                continue;
            }
            try {
                int slot = Integer.parseInt(entry.substring(0, idx));
                String item = entry.substring(idx + 1);
                if (!item.isEmpty()) {
                    result.put(slot, item);
                }
            } catch (NumberFormatException ignored) {
                // 单个槽位数据损坏时跳过
            }
        }
        return result;
    }
}
