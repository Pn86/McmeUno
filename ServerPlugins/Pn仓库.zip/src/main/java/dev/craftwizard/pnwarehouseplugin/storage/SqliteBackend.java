package dev.craftwizard.pnwarehouseplugin.storage;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.plugin.Plugin;

import java.io.File;

/**
 * SQLite 本地存储，数据文件为插件目录下的 database.db。
 */
public final class SqliteBackend extends StorageBackend {

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public SqliteBackend(Plugin plugin) {
        super(createDataSource(plugin));
    }

    private static HikariDataSource createDataSource(Plugin plugin) {
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists() && !dataFolder.mkdirs()) {
            throw new IllegalStateException("无法创建插件数据目录: " + dataFolder);
        }
        File dbFile = new File(dataFolder, "database.db");
        HikariConfig config = new HikariConfig();
        config.setPoolName("PnWarehouse-SQLite");
        config.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath()
                + "?journal_mode=WAL&synchronous=NORMAL&busy_timeout=5000");
        config.setMaximumPoolSize(2);
        config.setMinimumIdle(0);
        config.setConnectionTimeout(5000);
        config.setInitializationFailTimeout(3000);
        return new HikariDataSource(config);
    }

    @Override
    protected String createTableSql() {
        return "CREATE TABLE IF NOT EXISTS pn_warehouse ("
                + "uuid TEXT PRIMARY KEY,"
                + "name TEXT NOT NULL DEFAULT '',"
                + "data TEXT NOT NULL,"
                + "updated_at INTEGER NOT NULL"
                + ")";
    }

    @Override
    protected String dbName() {
        return "SQLite";
    }
}
