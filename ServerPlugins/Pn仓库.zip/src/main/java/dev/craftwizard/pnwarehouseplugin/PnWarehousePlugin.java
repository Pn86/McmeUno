package dev.craftwizard.pnwarehouseplugin;

import dev.craftwizard.pnwarehouseplugin.command.PnWhCommand;
import dev.craftwizard.pnwarehouseplugin.command.WarehouseCommand;
import dev.craftwizard.pnwarehouseplugin.listener.WarehouseListener;
import dev.craftwizard.pnwarehouseplugin.warehouse.WarehouseManager;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.java.JavaPlugin;

public final class PnWarehousePlugin extends JavaPlugin {

    private WarehouseManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new WarehouseManager(this);
        getServer().getPluginManager().registerEvents(new WarehouseListener(manager), this);
        registerCommand("pnwh", new PnWhCommand(this));
        registerCommand("warehouse", new WarehouseCommand(this));
        getLogger().info("PnWarehouse 已启用 (作者: Pn86) | 存储类型: " + manager.config().storageType());
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.disable();
        }
        getLogger().info("PnWarehouse 已禁用。");
    }

    public WarehouseManager getManager() {
        return manager;
    }

    private void registerCommand(String name, TabExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command != null) {
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }
    }
}
