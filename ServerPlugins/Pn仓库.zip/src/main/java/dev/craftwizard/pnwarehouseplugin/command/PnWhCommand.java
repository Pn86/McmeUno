package dev.craftwizard.pnwarehouseplugin.command;

import dev.craftwizard.pnwarehouseplugin.PnWarehousePlugin;
import dev.craftwizard.pnwarehouseplugin.warehouse.WarehouseManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * /pnwh 管理指令：reload / clear [玩家] / cleardata（二次确认）。
 */
public final class PnWhCommand implements TabExecutor {

    private static final long CONFIRM_TIMEOUT_MS = 15_000L;

    private final PnWarehousePlugin plugin;
    private final Map<String, Long> clearDataConfirmations = new ConcurrentHashMap<>();

    public PnWhCommand(PnWarehousePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        WarehouseManager manager = plugin.getManager();
        if (args.length == 0) {
            manager.sendRawMessage(sender, "usage");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (!sender.hasPermission("pnwarehouse.reload")) {
                    manager.sendMessage(sender, "no-permission");
                    return true;
                }
                if (manager.reload()) {
                    manager.sendMessage(sender, "reload-success");
                } else {
                    manager.sendMessage(sender, "reload-fail");
                }
            }
            case "clear" -> handleClear(sender, args);
            case "cleardata" -> handleClearData(sender);
            default -> manager.sendRawMessage(sender, "usage");
        }
        return true;
    }

    private void handleClear(CommandSender sender, String[] args) {
        WarehouseManager manager = plugin.getManager();
        if (!sender.hasPermission("pnwarehouse.clear")) {
            manager.sendMessage(sender, "no-permission");
            return;
        }
        String targetName;
        if (args.length >= 2) {
            targetName = args[1];
        } else if (sender instanceof Player player) {
            targetName = player.getName();
        } else {
            manager.sendRawMessage(sender, "usage");
            return;
        }
        resolveUuid(targetName, uuid -> {
            if (uuid == null) {
                manager.sendMessage(sender, "player-not-found", "player", targetName);
                return;
            }
            manager.clear(uuid, targetName);
            manager.sendMessage(sender, "warehouse-cleared", "player", targetName);
        });
    }

    private void handleClearData(CommandSender sender) {
        WarehouseManager manager = plugin.getManager();
        if (!sender.hasPermission("pnwarehouse.cleardata")) {
            manager.sendMessage(sender, "no-permission");
            return;
        }
        String key = sender.getName();
        long now = System.currentTimeMillis();
        Long pending = clearDataConfirmations.get(key);
        if (pending != null && now - pending < CONFIRM_TIMEOUT_MS) {
            clearDataConfirmations.remove(key);
            manager.clearAll();
            manager.sendMessage(sender, "data-cleared");
        } else {
            clearDataConfirmations.put(key, now);
            manager.sendRawMessage(sender, "cleardata-warning");
            manager.sendRawMessage(sender, "cleardata-confirm");
        }
    }

    /**
     * 解析玩家名 -> UUID：
     * 1) 在线玩家；2) 本服曾上线玩家；3) 数据库按 name 列查询（跨服场景）。
     */
    private void resolveUuid(String name, Consumer<UUID> callback) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            callback.accept(online.getUniqueId());
            return;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(name);
        if (offline != null && offline.hasPlayedBefore()) {
            callback.accept(offline.getUniqueId());
            return;
        }
        plugin.getManager().backend().findUuidByName(name).whenComplete((opt, error) -> {
            if (error != null || opt.isEmpty()) {
                callback.accept(null);
                return;
            }
            try {
                callback.accept(UUID.fromString(opt.get()));
            } catch (IllegalArgumentException e) {
                callback.accept(null);
            }
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = new ArrayList<>();
            if (sender.hasPermission("pnwarehouse.reload")) {
                subs.add("reload");
            }
            if (sender.hasPermission("pnwarehouse.clear")) {
                subs.add("clear");
            }
            if (sender.hasPermission("pnwarehouse.cleardata")) {
                subs.add("cleardata");
            }
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return subs.stream().filter(s -> s.startsWith(prefix)).toList();
        }
        if (args.length == 2 && "clear".equalsIgnoreCase(args[0])) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .toList();
        }
        return List.of();
    }
}
