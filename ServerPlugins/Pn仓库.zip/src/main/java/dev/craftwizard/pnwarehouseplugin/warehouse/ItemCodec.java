package dev.craftwizard.pnwarehouseplugin.warehouse;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Optional;

/**
 * 物品序列化 / 反序列化与有效性校验。
 * <p>
 * 无效物品定义：空物品、空气、数量越界、Base64/NBT 损坏、无法在当前
 * 服务器版本反序列化的物品。这类物品无法存入，也无法取出。
 */
public final class ItemCodec {

    private ItemCodec() {
    }

    /** 物品是否可以放入/取出仓库（有效性校验）。 */
    public static boolean isUsable(ItemStack item) {
        if (item == null) {
            return false;
        }
        if (item.getType().isAir()) {
            return false;
        }
        int amount = item.getAmount();
        return amount >= 1 && amount <= item.getMaxStackSize();
    }

    /** 序列化为 Base64 字符串；无效物品返回 null。 */
    public static String serialize(ItemStack item) {
        if (!isUsable(item)) {
            return null;
        }
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             BukkitObjectOutputStream dataOut = new BukkitObjectOutputStream(out)) {
            dataOut.writeObject(item);
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (IOException e) {
            throw new IllegalStateException("物品序列化失败", e);
        }
    }

    /** 反序列化；数据损坏或无效时返回空。 */
    public static Optional<ItemStack> deserialize(String data) {
        if (data == null || data.isEmpty()) {
            return Optional.empty();
        }
        try (ByteArrayInputStream in = new ByteArrayInputStream(Base64.getDecoder().decode(data));
             BukkitObjectInputStream dataIn = new BukkitObjectInputStream(in)) {
            Object obj = dataIn.readObject();
            if (obj instanceof ItemStack item && isUsable(item)) {
                return Optional.of(item);
            }
            return Optional.empty();
        } catch (Exception e) {
            return Optional.empty();
        }
    }
}
