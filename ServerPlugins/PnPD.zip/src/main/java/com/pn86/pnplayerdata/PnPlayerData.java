package com.pn86.pnplayerdata;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class PnPlayerData extends JavaPlugin {

    private static PnPlayerData instance;

    private Lang lang;
    private PlayerDataStore store;
    private PlayerListener listener;
    private ScheduledTask autoSaveTask;

    public static PnPlayerData get() {
        return instance;
    }

    public Lang getLang() {
        return lang;
    }

    public PlayerDataStore getStore() {
        return store;
    }

    public PlayerListener getListener() {
        return listener;
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        this.lang = new Lang(this);
        this.store = new PlayerDataStore(this);
        this.listener = new PlayerListener(this);

        getServer().getPluginManager().registerEvents(listener, this);
        registerCommand("pnpd", new PnpdCommand(this));
        registerCommand("seen", new SeenCommand(this));
        registerCommand("info", new InfoCommand(this));

        scheduleAutoSave();

        getLogger().info("PnPlayerData v" + getPluginMeta().getVersion()
                + " 已启用（Paper 1.21.1+ / Folia，无前置依赖）");
    }

    private void registerCommand(String name, CommandExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd != null) {
            cmd.setExecutor(executor);
        } else {
            getLogger().warning("命令 " + name + " 未在 plugin.yml 中注册");
        }
    }

    public void reload() {
        reloadConfig();
        if (lang != null) {
            lang.reload();
        }
        if (autoSaveTask != null) {
            autoSaveTask.cancel();
            autoSaveTask = null;
        }
        scheduleAutoSave();
    }

    private void scheduleAutoSave() {
        int minutes = Math.max(1, getConfig().getInt("auto-save-minutes", 5));
        long ticks = minutes * 60L * 20L;
        autoSaveTask = getServer().getGlobalRegionScheduler()
                .runAtFixedRate(this, t -> store.tickAutoSave(), ticks, ticks);
    }

    @Override
    public void onDisable() {
        if (autoSaveTask != null) {
            autoSaveTask.cancel();
            autoSaveTask = null;
        }
        if (store != null) {
            store.saveAllNow();
        }
        instance = null;
    }
}
