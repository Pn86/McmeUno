package com.pn86.pnplayerdata;

import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.UUID;

/**
 * 删除玩家的原始数据文件：
 * - 每个世界的 playerdata/&lt;uuid&gt;.dat 与 .dat_old（玩家数据）；
 * - 每个世界的 advancements/&lt;uuid&gt;.json（成就/进度）；
 * - 每个世界的 stats/&lt;uuid&gt;.json（统计）；
 * - 本插件的 player/&lt;uuid&gt;.yml 额外数据（可通过配置关闭）。
 * 必须在异步线程调用。
 */
public final class PlayerDataDeleter {

    private PlayerDataDeleter() {
    }

    public static void delete(PnPlayerData plugin, UUID uuid) {
        boolean includePluginData = plugin.getConfig().getBoolean("delete-includes-plugin-data", true);
        for (World world : Bukkit.getWorlds()) {
            File wf = world.getWorldFolder();
            deleteQuietly(new File(wf, "playerdata" + File.separator + uuid + ".dat"));
            deleteQuietly(new File(wf, "playerdata" + File.separator + uuid + ".dat_old"));
            deleteQuietly(new File(wf, "advancements" + File.separator + uuid + ".json"));
            deleteQuietly(new File(wf, "stats" + File.separator + uuid + ".json"));
        }
        if (includePluginData) {
            deleteQuietly(plugin.getStore().fileOf(uuid));
        }
        plugin.getStore().remove(uuid);
    }

    private static void deleteQuietly(File file) {
        try {
            Files.deleteIfExists(file.toPath());
        } catch (IOException ignored) {
            // 文件不存在或删除失败均静默处理
        }
    }
}
