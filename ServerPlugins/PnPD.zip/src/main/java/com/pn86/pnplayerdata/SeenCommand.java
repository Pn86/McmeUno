package com.pn86.pnplayerdata;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.regex.Pattern;

/**
 * /seen &lt;玩家名|UUID|IPv4&gt; —— 查看玩家 UUID、玩家名、成就、统计；
 * 输入 IPv4 时列出该 IP 下的所有账户。
 */
public final class SeenCommand implements CommandExecutor {

    private static final Pattern IPV4 = Pattern.compile(
            "^(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}$");

    private final PnPlayerData plugin;

    public SeenCommand(PnPlayerData plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("pnpd.seen")) {
            sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("seen-usage"));
            return true;
        }
        String input = args[0];
        if (IPV4.matcher(input).matches()) {
            DataViewer.showByIp(plugin, sender, input);
        } else {
            DataViewer.showPlayer(plugin, sender, input);
        }
        return true;
    }
}
