package com.pn86.pnplayerdata;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /info —— 查看自己的各项数据。
 */
public final class InfoCommand implements CommandExecutor {

    private final PnPlayerData plugin;

    public InfoCommand(PnPlayerData plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("player-only"));
            return true;
        }
        if (!player.hasPermission("pnpd.info")) {
            player.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("no-permission"));
            return true;
        }
        // 命令在玩家所属线程执行，可直接读取该玩家数据
        DataViewer.showInfo(plugin, player);
        return true;
    }
}
