package com.pn86.pnplayerdata;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 玩家额外数据存储：
 * - 内存 ConcurrentHashMap 实时读写，绝不在服务器线程做文件 IO；
 * - 玩家加入时异步合并磁盘历史、异步落盘（实时保存且不卡服）；
 * - 玩家退出后 10 分钟自动移出内存，降低内存占用；
 * - 周期性兜底保存 + 插件禁用时全量保存。
 */
public final class PlayerDataStore {

    private final PnPlayerData plugin;
    private final File dataDir;
    private final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();
    private final AtomicBoolean saving = new AtomicBoolean(false);

    public PlayerDataStore(PnPlayerData plugin) {
        this.plugin = plugin;
        this.dataDir = new File(plugin.getDataFolder(), "player");
        if (!dataDir.exists() && !dataDir.mkdirs()) {
            plugin.getLogger().warning("无法创建玩家数据目录: " + dataDir);
        }
    }

    public File dataDir() {
        return dataDir;
    }

    public File fileOf(UUID uuid) {
        return new File(dataDir, uuid + ".yml");
    }

    /** 获取或创建记录（仅修改内存，不做 IO）。 */
    public PlayerData getOrCreate(UUID uuid, String name, String ip) {
        return data.compute(uuid, (k, old) -> {
            if (old == null) {
                return new PlayerData(uuid, name, ip);
            }
            old.name(name);
            return old;
        });
    }

    public PlayerData get(UUID uuid) {
        return data.get(uuid);
    }

    public PlayerData get(String name) {
        for (PlayerData d : data.values()) {
            if (d.name() != null && d.name().equalsIgnoreCase(name)) {
                return d;
            }
        }
        return null;
    }

    /** 通过 IP 查找所有账户（内存记录 + 磁盘记录），按最后上线时间倒序。调用方需在异步线程。 */
    public List<PlayerData> findByIp(String ip) {
        List<PlayerData> result = new ArrayList<>();
        for (PlayerData d : data.values()) {
            if (d.ips().containsKey(ip)) {
                result.add(d);
            }
        }
        // 磁盘上的离线账户可能未加载进内存
        File[] files = dataDir.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                String base = f.getName().substring(0, f.getName().length() - 4);
                try {
                    UUID uuid = UUID.fromString(base);
                    if (!data.containsKey(uuid)) {
                        PlayerData d = load(uuid);
                        if (d != null && d.ips().containsKey(ip)) {
                            result.add(d);
                        }
                    }
                } catch (IllegalArgumentException ignored) {
                    // 非 UUID 文件名，忽略
                }
            }
        }
        result.sort(Comparator.comparingLong(PlayerData::lastSeen).reversed());
        return result;
    }

    /** 从磁盘加载（调用方需在异步线程）。 */
    public PlayerData load(UUID uuid) {
        File f = fileOf(uuid);
        if (!f.isFile()) {
            return null;
        }
        try {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(f);
            return PlayerData.fromYaml(uuid, yaml);
        } catch (Exception e) {
            plugin.getLogger().warning("读取玩家数据失败 " + uuid + ": " + e.getMessage());
            return null;
        }
    }

    /** 加入服务器时记录：实时更新内存 + 异步合并磁盘历史 + 异步落盘。 */
    public void onPlayerJoin(Player player) {
        UUID uuid = player.getUniqueId();
        String ip = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "";
        PlayerData d = getOrCreate(uuid, player.getName(), ip);
        d.recordIp(ip);
        d.onJoin();
        saveAsync(d);
        // 异步合并磁盘历史数据，避免在服务器线程做文件 IO
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            PlayerData disk = load(uuid);
            if (disk != null && d.mergeFromDisk(disk) && data.get(uuid) == d) {
                writeFile(d);
            }
        });
    }

    /** 退出服务器时记录：实时更新内存 + 异步落盘；10 分钟后移出内存。 */
    public void onPlayerQuit(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerData d = data.get(uuid);
        if (d != null) {
            d.onQuit();
            saveAsync(d);
            plugin.getServer().getAsyncScheduler().runDelayed(plugin, t -> {
                if (Bukkit.getPlayer(uuid) == null) {
                    data.remove(uuid, d);
                }
            }, 10, TimeUnit.MINUTES);
        }
    }

    /** 异步保存单条记录。 */
    public void saveAsync(PlayerData d) {
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> writeFile(d));
    }

    private void writeFile(PlayerData d) {
        File f = fileOf(d.uuid());
        try {
            YamlConfiguration yaml = new YamlConfiguration();
            d.toYaml(yaml);
            synchronized (this) {
                yaml.save(f);
            }
        } catch (IOException e) {
            plugin.getLogger().warning("保存玩家数据失败 " + d.uuid() + ": " + e.getMessage());
        }
    }

    /** 周期兜底保存（异步执行，避免卡服；同一时间只允许一轮保存）。 */
    public void tickAutoSave() {
        if (!saving.compareAndSet(false, true)) {
            return;
        }
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            try {
                for (PlayerData d : data.values()) {
                    writeFile(d);
                }
            } finally {
                saving.set(false);
            }
        });
    }

    /** 插件禁用时同步保存所有内存记录（禁用阶段执行，文件很小，开销可忽略）。 */
    public void saveAllNow() {
        for (PlayerData d : data.values()) {
            writeFile(d);
        }
    }

    /** 从内存中移除记录。 */
    public void remove(UUID uuid) {
        data.remove(uuid);
    }
}
