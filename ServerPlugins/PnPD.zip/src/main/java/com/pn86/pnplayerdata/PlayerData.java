package com.pn86.pnplayerdata;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 玩家的额外数据记录（内存中实时更新，异步落盘）。
 * 全部字段使用原子类型/并发容器，允许跨线程读写而不加锁。
 */
public final class PlayerData {

    private final UUID uuid;
    private volatile String name;
    private volatile String currentIp;
    private final Map<String, IpRecord> ips = new ConcurrentHashMap<>();

    private final AtomicLong firstSeen = new AtomicLong(0);
    private final AtomicLong lastSeen = new AtomicLong(0);
    private final AtomicLong lastQuit = new AtomicLong(0);
    private final AtomicLong totalPlaytime = new AtomicLong(0); // 毫秒
    private final AtomicLong joinCount = new AtomicLong(0);
    private final AtomicLong sessionStart = new AtomicLong(0);
    private final AtomicBoolean loadedFromDisk = new AtomicBoolean(false);

    public PlayerData(UUID uuid, String name, String ip) {
        this.uuid = uuid;
        this.name = name;
        this.currentIp = ip;
    }

    public UUID uuid() {
        return uuid;
    }

    public String name() {
        return name;
    }

    public void name(String name) {
        this.name = name;
    }

    public String currentIp() {
        return currentIp;
    }

    public Map<String, IpRecord> ips() {
        return ips;
    }

    public long firstSeen() {
        return firstSeen.get();
    }

    public long lastSeen() {
        return lastSeen.get();
    }

    public long lastQuit() {
        return lastQuit.get();
    }

    public long totalPlaytime() {
        return totalPlaytime.get();
    }

    public long joinCount() {
        return joinCount.get();
    }

    /** 记录一次上线：首次上线时间、最后上线时间、累计次数、会话开始时间。 */
    public void onJoin() {
        long now = System.currentTimeMillis();
        firstSeen.compareAndSet(0, now);
        lastSeen.set(now);
        joinCount.incrementAndGet();
        sessionStart.set(now);
    }

    /** 记录一次下线：累计在线时长、最后下线时间、清空会话开始时间。 */
    public void onQuit() {
        long now = System.currentTimeMillis();
        long start = sessionStart.getAndSet(0);
        if (start > 0) {
            totalPlaytime.addAndGet(Math.max(0, now - start));
        }
        lastQuit.set(now);
    }

    /** 会话在线时长（毫秒）；若不在线返回 0。 */
    public long sessionDuration() {
        long start = sessionStart.get();
        return start > 0 ? Math.max(0, System.currentTimeMillis() - start) : 0;
    }

    /** 记录一个 IP 的出现。 */
    public void recordIp(String ip) {
        long now = System.currentTimeMillis();
        ips.compute(ip, (k, old) -> {
            if (old == null) {
                return new IpRecord(now, now);
            }
            old.merge(now);
            return old;
        });
    }

    /**
     * 将磁盘上的历史数据合并进内存记录（只合并一次，避免重复累加）。
     *
     * @return 是否发生了实际合并（首次合并返回 true）
     */
    public boolean mergeFromDisk(PlayerData disk) {
        if (disk == null) {
            loadedFromDisk.set(true);
            return false;
        }
        if (loadedFromDisk.getAndSet(true)) {
            return false;
        }
        firstSeen.accumulateAndGet(disk.firstSeen(), Math::min);
        lastSeen.accumulateAndGet(disk.lastSeen(), Math::max);
        lastQuit.accumulateAndGet(disk.lastQuit(), Math::max);
        totalPlaytime.addAndGet(disk.totalPlaytime());
        joinCount.addAndGet(disk.joinCount());
        for (Map.Entry<String, IpRecord> e : disk.ips.entrySet()) {
            ips.merge(e.getKey(), e.getValue(), (a, b) -> {
                a.merge(b);
                return a;
            });
        }
        return true;
    }

    /** 从 YAML 恢复。 */
    public static PlayerData fromYaml(UUID uuid, YamlConfiguration yaml) {
        String name = yaml.getString("name", "");
        String ip = yaml.getString("current-ip", "");
        PlayerData d = new PlayerData(uuid, name, ip);
        d.firstSeen.set(yaml.getLong("first-seen", 0));
        d.lastSeen.set(yaml.getLong("last-seen", 0));
        d.lastQuit.set(yaml.getLong("last-quit", 0));
        d.totalPlaytime.set(yaml.getLong("total-playtime", 0));
        d.joinCount.set(yaml.getLong("join-count", 0));
        ConfigurationSection sec = yaml.getConfigurationSection("ips");
        if (sec != null) {
            for (String ipKey : sec.getKeys(false)) {
                long first = sec.getLong(ipKey + ".first-seen", 0);
                long last = sec.getLong(ipKey + ".last-seen", 0);
                d.ips.put(ipKey, new IpRecord(first, last));
            }
        }
        return d;
    }

    /** 写入 YAML（调用方需保证在异步线程）。 */
    public void toYaml(YamlConfiguration yaml) {
        yaml.set("name", name);
        yaml.set("current-ip", currentIp);
        yaml.set("first-seen", firstSeen.get());
        yaml.set("last-seen", lastSeen.get());
        yaml.set("last-quit", lastQuit.get());
        yaml.set("total-playtime", totalPlaytime.get());
        yaml.set("join-count", joinCount.get());
        for (Map.Entry<String, IpRecord> e : ips.entrySet()) {
            yaml.set("ips." + e.getKey() + ".first-seen", e.getValue().firstSeen());
            yaml.set("ips." + e.getKey() + ".last-seen", e.getValue().lastSeen());
        }
    }

    /** 单个 IP 的记录。 */
    public static final class IpRecord {
        private final AtomicLong firstSeen;
        private final AtomicLong lastSeen;

        public IpRecord(long first, long last) {
            this.firstSeen = new AtomicLong(first);
            this.lastSeen = new AtomicLong(last);
        }

        public void merge(long now) {
            firstSeen.accumulateAndGet(now, Math::min);
            lastSeen.accumulateAndGet(now, Math::max);
        }

        public void merge(IpRecord other) {
            firstSeen.accumulateAndGet(other.firstSeen(), Math::min);
            lastSeen.accumulateAndGet(other.lastSeen(), Math::max);
        }

        public long firstSeen() {
            return firstSeen.get();
        }

        public long lastSeen() {
            return lastSeen.get();
        }
    }
}
