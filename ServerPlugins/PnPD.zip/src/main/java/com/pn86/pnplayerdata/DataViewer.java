package com.pn86.pnplayerdata;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.World;
import org.bukkit.advancement.Advancement;
import org.bukkit.advancement.AdvancementProgress;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 玩家数据展示：/info 与 /seen 共享的查询与格式化逻辑。
 * - 所有文件 IO（离线数据读取、IP 账户磁盘查询）都在异步线程执行；
 * - 所有实体 API 调用都在目标实体所属线程执行；
 * - 结果通过 Messages 调度到接收者所属线程发送，全程线程安全。
 */
public final class DataViewer {

    private DataViewer() {
    }

    // ======================== /info ========================

    public static void showInfo(PnPlayerData plugin, Player player) {
        Lang lang = plugin.getLang();
        PlayerData d = plugin.getStore().get(player.getUniqueId());
        List<String> lines = new ArrayList<>();
        lines.add(lang.get("info-header"));
        lines.add(lang.format("info-field-uuid", "uuid", player.getUniqueId().toString()));
        lines.add(lang.format("info-field-name", "name", player.getName()));
        lines.add(lang.format("info-field-current-ip", "ip", currentIpOf(player, d)));
        lines.add(lang.format("info-field-first-seen", "time", d == null ? "-" : Formatter.time(d.firstSeen())));
        lines.add(lang.format("info-field-last-seen", "time", d == null ? "-" : Formatter.time(d.lastSeen())));
        lines.add(lang.format("info-field-last-quit", "time", d == null ? "-" : Formatter.time(d.lastQuit())));
        long playtime = d == null ? 0 : d.totalPlaytime() + d.sessionDuration();
        lines.add(lang.format("info-field-playtime", "duration", Formatter.duration(playtime)));
        lines.add(lang.format("info-field-join-count", "count", d == null ? "0" : String.valueOf(d.joinCount())));
        if (d != null && !d.ips().isEmpty()) {
            lines.add(lang.get("info-field-ips"));
            d.ips().forEach((ip, rec) -> lines.add(lang.format("info-field-ip-line",
                    "ip", ip, "first", Formatter.time(rec.firstSeen()), "last", Formatter.time(rec.lastSeen()))));
        }
        lines.add(lang.format("info-achievements-count", "count", String.valueOf(countDoneAdvancements(player))));
        lines.add(lang.get("info-stats-header"));
        List<String> stats = new ArrayList<>();
        collectLiveStats(plugin, lang, player, stats, "info-stats-line", "info-stats-more");
        if (stats.isEmpty()) {
            lines.add(lang.get("info-stats-none"));
        } else {
            lines.addAll(stats);
        }

        String ip = currentIpOf(player, d);
        List<String> finalLines = lines;
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            appendIpAccounts(plugin, lang, ip, finalLines, "info-accounts-header");
            player.getScheduler().run(plugin, tt -> player.sendMessage(finalLines.toArray(new String[0])), null);
        });
    }

    // ======================== /seen ========================

    public static void showPlayer(PnPlayerData plugin, CommandSender sender, String input) {
        UUID uuid = tryParseUuid(input);
        if (uuid != null) {
            showByUuid(plugin, sender, uuid);
            return;
        }
        Player online = findOnline(input);
        if (online != null) {
            showSeenOnline(plugin, sender, online);
            return;
        }
        OfflinePlayer op = findOffline(input);
        if (op == null || !op.hasPlayedBefore()) {
            Messages.send(plugin, sender, plugin.getLang().prefix()
                    + plugin.getLang().format("player-not-found", "input", input));
            return;
        }
        showSeenOffline(plugin, sender, op.getUniqueId(), op.getName());
    }

    public static void showByIp(PnPlayerData plugin, CommandSender sender, String ip) {
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            Lang lang = plugin.getLang();
            List<PlayerData> accounts = plugin.getStore().findByIp(ip);
            List<String> lines = new ArrayList<>();
            lines.add(lang.format("seen-ip-header", "ip", ip));
            if (accounts.isEmpty()) {
                lines.add(lang.get("seen-ip-empty"));
            } else {
                long now = System.currentTimeMillis();
                for (PlayerData d : accounts) {
                    long offline = d.lastQuit() > 0 ? Math.max(0, now - d.lastQuit()) : 0;
                    lines.add(lang.format("seen-account-line",
                            "name", d.name() == null ? d.uuid().toString() : d.name(),
                            "uuid", d.uuid().toString(),
                            "playtime", Formatter.duration(d.totalPlaytime()),
                            "count", String.valueOf(d.joinCount()),
                            "last", Formatter.time(d.lastQuit()),
                            "offline", Formatter.duration(offline)));
                }
            }
            Messages.sendLines(plugin, sender, lines);
        });
    }

    private static void showByUuid(PnPlayerData plugin, CommandSender sender, UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            showSeenOnline(plugin, sender, online);
            return;
        }
        OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
        if (op == null || !op.hasPlayedBefore()) {
            Messages.send(plugin, sender, plugin.getLang().prefix()
                    + plugin.getLang().format("player-not-found", "input", uuid.toString()));
            return;
        }
        showSeenOffline(plugin, sender, uuid, op.getName());
    }

    private static void showSeenOnline(PnPlayerData plugin, CommandSender sender, Player target) {
        target.getScheduler().run(plugin, t -> {
            Lang lang = plugin.getLang();
            PlayerData d = plugin.getStore().get(target.getUniqueId());
            List<String> lines = new ArrayList<>();
            lines.add(lang.get("seen-header"));
            lines.add(lang.format("seen-field-uuid", "uuid", target.getUniqueId().toString()));
            lines.add(lang.format("seen-field-name", "name", target.getName()));
            lines.add(lang.get("seen-field-status-online"));
            lines.add(lang.format("seen-field-current-ip", "ip", currentIpOf(target, d)));
            lines.add(lang.format("seen-field-first-seen", "time", d == null ? "-" : Formatter.time(d.firstSeen())));
            lines.add(lang.format("seen-field-last-seen", "time", d == null ? "-" : Formatter.time(d.lastSeen())));
            lines.add(lang.format("seen-field-session-online", "duration",
                    d == null ? "-" : Formatter.duration(d.sessionDuration())));
            long playtime = d == null ? 0 : d.totalPlaytime() + d.sessionDuration();
            lines.add(lang.format("seen-field-playtime", "duration", Formatter.duration(playtime)));
            lines.add(lang.format("seen-field-join-count", "count",
                    d == null ? "0" : String.valueOf(d.joinCount())));
            if (d != null && !d.ips().isEmpty()) {
                lines.add(lang.get("seen-field-ips"));
                d.ips().forEach((ip, rec) -> lines.add(lang.format("seen-field-ip-line",
                        "ip", ip, "first", Formatter.time(rec.firstSeen()), "last", Formatter.time(rec.lastSeen()))));
            }
            // 只显示成就数量，隐藏具体成就名称
            lines.add(lang.format("seen-achievements-count", "count", String.valueOf(countDoneAdvancements(target))));
            lines.add(lang.get("seen-stats-header"));
            List<String> stats = new ArrayList<>();
            collectLiveStats(plugin, lang, target, stats, "seen-stats-line", "seen-stats-more");
            if (stats.isEmpty()) {
                lines.add(lang.get("seen-stats-none"));
            } else {
                lines.addAll(stats);
            }

            String ip = currentIpOf(target, d);
            List<String> finalLines = lines;
            plugin.getServer().getAsyncScheduler().runNow(plugin, at -> {
                appendIpAccounts(plugin, lang, ip, finalLines, "seen-accounts-header");
                Messages.sendLines(plugin, sender, finalLines);
            });
        }, () -> showSeenOffline(plugin, sender, target.getUniqueId(), target.getName()));
    }

    private static void showSeenOffline(PnPlayerData plugin, CommandSender sender, UUID uuid, String knownName) {
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            Lang lang = plugin.getLang();
            PlayerData d = plugin.getStore().load(uuid);
            String name = knownName != null ? knownName : (d != null && d.name() != null ? d.name() : uuid.toString());
            List<String> lines = new ArrayList<>();
            lines.add(lang.get("seen-header"));
            lines.add(lang.format("seen-field-uuid", "uuid", uuid.toString()));
            lines.add(lang.format("seen-field-name", "name", name));
            lines.add(lang.get("seen-field-status-offline"));
            lines.add(lang.format("seen-field-current-ip", "ip", d == null ? "-" : d.currentIp()));
            lines.add(lang.format("seen-field-first-seen", "time", d == null ? "-" : Formatter.time(d.firstSeen())));
            lines.add(lang.format("seen-field-last-seen", "time", d == null ? "-" : Formatter.time(d.lastSeen())));
            lines.add(lang.format("seen-field-last-quit", "time", d == null ? "-" : Formatter.time(d.lastQuit())));
            long offline = d == null || d.lastQuit() <= 0 ? 0 : Math.max(0, System.currentTimeMillis() - d.lastQuit());
            lines.add(lang.format("seen-field-offline-duration", "duration", Formatter.duration(offline)));
            lines.add(lang.format("seen-field-playtime", "duration",
                    d == null ? "-" : Formatter.duration(d.totalPlaytime())));
            lines.add(lang.format("seen-field-join-count", "count",
                    d == null ? "0" : String.valueOf(d.joinCount())));
            if (d != null && !d.ips().isEmpty()) {
                lines.add(lang.get("seen-field-ips"));
                d.ips().forEach((ip, rec) -> lines.add(lang.format("seen-field-ip-line",
                        "ip", ip, "first", Formatter.time(rec.firstSeen()), "last", Formatter.time(rec.lastSeen()))));
            }
            lines.add(lang.get("seen-offline-note"));

            OfflineStats os = readOfflineFiles(plugin, uuid);
            // 只显示成就数量，隐藏具体成就名称
            lines.add(lang.format("seen-offline-achievements", "count", String.valueOf(os.doneAdvancements.size())));

            lines.add(lang.get("seen-offline-stats-header"));
            List<String> stats = new ArrayList<>();
            collectOfflineStats(plugin, lang, os, stats, "seen-stats-line", "seen-stats-more");
            if (stats.isEmpty()) {
                lines.add(lang.get("seen-stats-none"));
            } else {
                lines.addAll(stats);
            }

            String ip = d == null ? null : d.currentIp();
            appendIpAccounts(plugin, lang, ip, lines, "seen-accounts-header");
            Messages.sendLines(plugin, sender, lines);
        });
    }

    // ======================== IP 账户 ========================

    /** 追加某个 IP 下的所有账户列表（需在异步线程调用，因为会查询磁盘）。 */
    private static void appendIpAccounts(PnPlayerData plugin, Lang lang, String ip,
                                         List<String> lines, String headerKey) {
        if (ip == null || ip.isEmpty() || "-".equals(ip)) {
            return;
        }
        List<PlayerData> accounts = plugin.getStore().findByIp(ip);
        if (accounts.isEmpty()) {
            return;
        }
        lines.add(lang.get(headerKey));
        long now = System.currentTimeMillis();
        for (PlayerData acc : accounts) {
            long offline = acc.lastQuit() > 0 ? Math.max(0, now - acc.lastQuit()) : 0;
            lines.add(lang.format("seen-account-line",
                    "name", acc.name() == null ? acc.uuid().toString() : acc.name(),
                    "uuid", acc.uuid().toString(),
                    "playtime", Formatter.duration(acc.totalPlaytime()),
                    "count", String.valueOf(acc.joinCount()),
                    "last", Formatter.time(acc.lastQuit()),
                    "offline", Formatter.duration(offline)));
        }
    }

    private static String currentIpOf(Player player, PlayerData d) {
        if (d != null && d.currentIp() != null && !d.currentIp().isEmpty()) {
            return d.currentIp();
        }
        return player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "-";
    }

    // ======================== 统计采集 ========================

    private static void collectLiveStats(PnPlayerData plugin, Lang lang, Player player,
                                         List<String> out, String lineKey, String moreKey) {
        int max = Math.max(1, plugin.getConfig().getInt("max-stat-lines", 200));
        int total = 0;
        for (Statistic stat : Statistic.values()) {
            switch (stat.getType()) {
                case UNTYPED -> {
                    int v = player.getStatistic(stat);
                    if (v > 0) {
                        total++;
                        if (out.size() < max) {
                            out.add(statLine(lang, lineKey, statKey(stat), v));
                        }
                    }
                }
                case ITEM -> {
                    for (Material m : Material.values()) {
                        if (!m.isItem()) {
                            continue;
                        }
                        int v = player.getStatistic(stat, m);
                        if (v > 0) {
                            total++;
                            if (out.size() < max) {
                                out.add(statLine(lang, lineKey, statKey(stat, m.name()), v));
                            }
                        }
                    }
                }
                case BLOCK -> {
                    for (Material m : Material.values()) {
                        if (!m.isBlock()) {
                            continue;
                        }
                        int v = player.getStatistic(stat, m);
                        if (v > 0) {
                            total++;
                            if (out.size() < max) {
                                out.add(statLine(lang, lineKey, statKey(stat, m.name()), v));
                            }
                        }
                    }
                }
                case ENTITY -> {
                    for (EntityType et : EntityType.values()) {
                        try {
                            int v = player.getStatistic(stat, et);
                            if (v > 0) {
                                total++;
                                if (out.size() < max) {
                                    out.add(statLine(lang, lineKey, statKey(stat, et.name()), v));
                                }
                            }
                        } catch (IllegalArgumentException ignored) {
                            // 该实体类型对此统计无效
                        }
                    }
                }
            }
        }
        if (total > out.size()) {
            out.add(lang.format(moreKey, "count", String.valueOf(total - out.size())));
        }
    }

    private static void collectOfflineStats(PnPlayerData plugin, Lang lang, OfflineStats os,
                                            List<String> out, String lineKey, String moreKey) {
        int max = Math.max(1, plugin.getConfig().getInt("max-stat-lines", 200));
        int total = 0;
        for (Map.Entry<String, Long> e : os.stats.entrySet()) {
            total++;
            if (out.size() < max) {
                out.add(lang.format(lineKey, "key", lang.statName(e.getKey()),
                        "value", formatStatValue(e.getKey(), e.getValue())));
            }
        }
        if (total > out.size()) {
            out.add(lang.format(moreKey, "count", String.valueOf(total - out.size())));
        }
    }

    private static String statLine(Lang lang, String lineKey, String key, long value) {
        return lang.format(lineKey, "key", lang.statName(key), "value", formatStatValue(key, value));
    }

    private static String statKey(Statistic stat) {
        return stat.name().toLowerCase();
    }

    private static String statKey(Statistic stat, String sub) {
        return stat.name().toLowerCase() + ":" + sub.toLowerCase();
    }

    private static String formatStatValue(String key, long value) {
        if ("play_one_minute".equals(key) || "total_world_time".equals(key)) {
            return Formatter.duration(value * 50L); // 1 tick = 50ms
        }
        return String.format("%,d", value);
    }

    private static int countDoneAdvancements(Player player) {
        int n = 0;
        Iterator<Advancement> it = Bukkit.advancementIterator();
        while (it.hasNext()) {
            Advancement adv = it.next();
            AdvancementProgress prog = player.getAdvancementProgress(adv);
            if (prog != null && prog.isDone()) {
                n++;
            }
        }
        return n;
    }

    // ======================== 离线文件读取 ========================

    private record OfflineStats(List<String> doneAdvancements, Map<String, Long> stats) {
    }

    private static OfflineStats readOfflineFiles(PnPlayerData plugin, UUID uuid) {
        List<String> advancements = new ArrayList<>();
        Map<String, Long> stats = new LinkedHashMap<>();
        for (World world : Bukkit.getWorlds()) {
            File wf = world.getWorldFolder();
            File achFile = new File(wf, "advancements" + File.separator + uuid + ".json");
            File statFile = new File(wf, "stats" + File.separator + uuid + ".json");
            if (advancements.isEmpty() && achFile.isFile()) {
                advancements.addAll(readAdvancements(achFile));
            }
            if (stats.isEmpty() && statFile.isFile()) {
                stats.putAll(readStats(statFile));
            }
            if (!advancements.isEmpty() && !stats.isEmpty()) {
                break;
            }
        }
        return new OfflineStats(advancements, stats);
    }

    private static List<String> readAdvancements(File file) {
        List<String> done = new ArrayList<>();
        try {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            for (String key : yaml.getKeys(false)) {
                if (yaml.getBoolean(key + ".done", false)) {
                    done.add(key);
                }
            }
        } catch (Exception ignored) {
            // 文件缺失或损坏时静默跳过
        }
        return done;
    }

    private static Map<String, Long> readStats(File file) {
        Map<String, Long> result = new LinkedHashMap<>();
        try {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            ConfigurationSection statsSec = yaml.getConfigurationSection("stats");
            if (statsSec == null) {
                return result;
            }
            for (String category : statsSec.getKeys(false)) {
                ConfigurationSection cat = statsSec.getConfigurationSection(category);
                if (cat == null) {
                    continue;
                }
                for (String sub : cat.getKeys(false)) {
                    long value = cat.getLong(sub, 0);
                    if (value > 0) {
                        result.put(offlineStatKey(category, sub), value);
                    }
                }
            }
        } catch (Exception ignored) {
            // 文件缺失或损坏时静默跳过
        }
        return result;
    }

    private static String offlineStatKey(String category, String sub) {
        String cat = category.contains(":") ? category.substring(category.indexOf(':') + 1) : category;
        String s = sub.contains(":") ? sub.substring(sub.indexOf(':') + 1) : sub;
        if ("custom".equals(cat)) {
            return s.toLowerCase();
        }
        return switch (cat) {
            case "mined" -> "mine_block:" + s.toLowerCase();
            case "crafted" -> "craft_item:" + s.toLowerCase();
            case "used" -> "use_item:" + s.toLowerCase();
            case "broken" -> "break_item:" + s.toLowerCase();
            case "picked_up" -> "pickup:" + s.toLowerCase();
            case "dropped" -> "drop:" + s.toLowerCase();
            case "killed" -> "kill_entity:" + s.toLowerCase();
            case "killed_by" -> "entity_killed_by:" + s.toLowerCase();
            default -> cat + ":" + s.toLowerCase();
        };
    }

    // ======================== 解析辅助 ========================

    private static UUID tryParseUuid(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static Player findOnline(String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p != null) {
            return p;
        }
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getName().equalsIgnoreCase(name)) {
                return o;
            }
        }
        return null;
    }

    private static OfflinePlayer findOffline(String name) {
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(name);
        if (op != null && op.hasPlayedBefore()) {
            return op;
        }
        for (OfflinePlayer o : Bukkit.getOfflinePlayers()) {
            if (o.getName() != null && o.getName().equalsIgnoreCase(name) && o.hasPlayedBefore()) {
                return o;
            }
        }
        return op;
    }
}
