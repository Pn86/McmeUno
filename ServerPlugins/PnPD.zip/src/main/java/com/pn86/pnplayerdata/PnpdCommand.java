package com.pn86.pnplayerdata;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * /pnpd reload —— 重载插件配置
 * /pnpd delete &lt;玩家名&gt; —— 重置玩家 playerdata/成就/统计等数据并踢出该玩家
 */
public final class PnpdCommand implements CommandExecutor {

    private final PnPlayerData plugin;

    public PnpdCommand(PnPlayerData plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("unknown-command"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                if (!sender.hasPermission("pnpd.reload")) {
                    sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("no-permission"));
                    return true;
                }
                plugin.reload();
                sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("reload-success"));
                return true;
            }
            case "delete" -> {
                if (!sender.hasPermission("pnpd.delete")) {
                    sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("delete-usage"));
                    return true;
                }
                handleDelete(sender, args[1]);
                return true;
            }
            default -> sender.sendMessage(plugin.getLang().prefix() + plugin.getLang().get("unknown-command"));
        }
        return true;
    }

    private void handleDelete(CommandSender sender, String name) {
        Player online = findOnline(name);
        if (online != null) {
            plugin.getListener().requestDelete(online, sender);
            sender.sendMessage(plugin.getLang().prefix()
                    + plugin.getLang().format("delete-waiting", "player", online.getName()));
            return;
        }

        OfflinePlayer op = findOffline(name);
        if (op == null || !op.hasPlayedBefore()) {
            sender.sendMessage(plugin.getLang().prefix()
                    + plugin.getLang().format("player-not-found", "input", name));
            return;
        }

        UUID uuid = op.getUniqueId();
        String displayName = op.getName() == null ? name : op.getName();
        plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
            PlayerDataDeleter.delete(plugin, uuid);
            String msg = plugin.getLang().prefix()
                    + plugin.getLang().format("delete-success", "player", displayName, "uuid", uuid.toString());
            Messages.send(plugin, sender, msg);
        });
    }

    private Player findOnline(String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p != null) {
            return p;
        }
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getName().equalsIgnoreCase(name)) {
                return o;
            }
        }
        return null;
    }

    private OfflinePlayer findOffline(String name) {
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(name);
        if (op != null && op.hasPlayedBefore()) {
            return op;
        }
        for (OfflinePlayer o : Bukkit.getOfflinePlayers()) {
            if (o.getName() != null && o.getName().equalsIgnoreCase(name) && o.hasPlayedBefore()) {
                return o;
            }
        }
        return op;
    }
}
