package com.pn86.pnplayerdata;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * 时间与时长格式化工具。
 */
public final class Formatter {

    private static final DateTimeFormatter TIME = DateTimeFormatter
            .ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneId.systemDefault());

    private Formatter() {
    }

    /** 毫秒时间戳 -> 服务器本地时间字符串。 */
    public static String time(long epochMillis) {
        if (epochMillis <= 0) {
            return "-";
        }
        return TIME.format(Instant.ofEpochMilli(epochMillis));
    }

    /** 毫秒时长 -> 中文可读时长，例如 1天2小时3分4秒。 */
    public static String duration(long millis) {
        if (millis < 0) {
            millis = 0;
        }
        long s = millis / 1000;
        long d = s / 86400;
        s %= 86400;
        long h = s / 3600;
        s %= 3600;
        long m = s / 60;
        s %= 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) {
            sb.append(d).append("天");
        }
        if (h > 0) {
            sb.append(h).append("小时");
        }
        if (m > 0) {
            sb.append(m).append("分");
        }
        if (s > 0 || sb.length() == 0) {
            sb.append(s).append("秒");
        }
        return sb.toString();
    }
}
