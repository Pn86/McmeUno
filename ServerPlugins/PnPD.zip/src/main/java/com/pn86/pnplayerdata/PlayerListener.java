package com.pn86.pnplayerdata;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 玩家上下线监听：
 * - 上线时实时记录额外数据并异步落盘（含磁盘历史合并，避免阻塞服务器线程）；
 * - 下线时保存累计时长、最后下线时间等；
 * - 配合 /pnpd delete 在玩家被踢出并完全下线后清理其全部数据文件。
 */
public final class PlayerListener implements Listener {

    private final PnPlayerData plugin;
    private final Map<UUID, CommandSender> deleteCallbacks = new ConcurrentHashMap<>();

    public PlayerListener(PnPlayerData plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getStore().onPlayerJoin(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        CommandSender requester = deleteCallbacks.remove(uid);
        if (requester != null) {
            // 该玩家数据将被重置：直接移出内存并删除文件，避免“先保存又删除”的竞态
            String name = player.getName();
            plugin.getStore().remove(uid);
            plugin.getServer().getAsyncScheduler().runNow(plugin, t -> {
                PlayerDataDeleter.delete(plugin, uid);
                String msg = plugin.getLang().prefix()
                        + plugin.getLang().format("delete-success", "player", name, "uuid", uid.toString());
                Messages.send(plugin, requester, msg);
            });
        } else {
            plugin.getStore().onPlayerQuit(player);
        }
    }

    /**
     * 请求删除在线玩家：踢出玩家，并在其完全下线后清理数据文件。
     * 若 10 秒后仍未下线，则视为失败并通知请求者。
     */
    public void requestDelete(Player target, CommandSender requester) {
        UUID uid = target.getUniqueId();
        deleteCallbacks.put(uid, requester);
        String kickMsg = Lang.color(plugin.getLang().get("delete-kick-message"));
        target.getScheduler().run(plugin, t -> target.kick(Lang.component(kickMsg)), null);

        plugin.getServer().getGlobalRegionScheduler().runDelayed(plugin, t -> {
            if (deleteCallbacks.remove(uid, requester)) {
                String msg = plugin.getLang().prefix()
                        + plugin.getLang().format("delete-failed-online", "player", target.getName());
                Messages.send(plugin, requester, msg);
            }
        }, 200L);
    }
}
