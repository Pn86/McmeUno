package com.pn86.pnplayerdata;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * 跨线程安全的消息发送：玩家消息统一调度到其所属线程，控制台直接发送。
 */
public final class Messages {

    private Messages() {
    }

    public static void send(PnPlayerData plugin, CommandSender sender, String msg) {
        if (sender instanceof Player p) {
            p.getScheduler().run(plugin, t -> p.sendMessage(msg), null);
        } else {
            sender.sendMessage(msg);
        }
    }

    public static void sendLines(PnPlayerData plugin, CommandSender sender, List<String> lines) {
        String[] arr = lines.toArray(new String[0]);
        if (sender instanceof Player p) {
            p.getScheduler().run(plugin, t -> p.sendMessage(arr), null);
        } else {
            sender.sendMessage(arr);
        }
    }
}
