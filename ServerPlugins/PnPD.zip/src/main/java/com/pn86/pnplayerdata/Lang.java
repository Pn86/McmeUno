package com.pn86.pnplayerdata;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

/**
 * 语言文本加载器：从 config.yml 的 messages 节点读取全部文本并缓存。
 */
public final class Lang {

    private final PnPlayerData plugin;
    private String prefix;
    private final Map<String, String> messages = new HashMap<>();

    public Lang(PnPlayerData plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration cfg = plugin.getConfig();
        this.prefix = color(cfg.getString("messages.prefix", "&7[&bPnPlayerData&7] "));
        messages.clear();
        ConfigurationSection sec = cfg.getConfigurationSection("messages");
        if (sec != null) {
            for (String key : sec.getKeys(true)) {
                if (key.startsWith("stat-names.")) {
                    continue;
                }
                if (sec.isString(key)) {
                    messages.put(key, color(sec.getString(key)));
                }
            }
        }
    }

    public String prefix() {
        return prefix;
    }

    public String get(String key) {
        return messages.getOrDefault(key, key);
    }

    /**
     * 以 {占位符} 替换的方式格式化文本，参数格式为 key1, value1, key2, value2 ...
     */
    public String format(String key, String... pairs) {
        String msg = get(key);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            String val = pairs[i + 1];
            msg = msg.replace("{" + pairs[i] + "}", val == null ? "" : val);
        }
        return msg;
    }

    /**
     * 统计键的显示名称；未配置时返回原始键名。
     */
    public String statName(String raw) {
        String name = plugin.getConfig().getString("messages.stat-names." + raw);
        return name != null ? name : raw;
    }

    public static String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    /** 将已转换颜色码（§）的字符串构建为 Adventure 组件（用于踢出消息等）。 */
    public static Component component(String colored) {
        return LegacyComponentSerializer.legacySection().deserialize(colored == null ? "" : colored);
    }
}
