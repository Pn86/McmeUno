package cn.pn86.pnplayerbot.data;

import java.util.Locale;

public record WorkStep(Type type, String content) {
    public WorkStep {
        if (type == null) throw new IllegalArgumentException("type");
        content = content == null ? "" : content.strip();
    }

    public enum Type {
        CMD, BOT;

        public static Type parse(String value) {
            return value == null ? null : switch (value.toLowerCase(Locale.ROOT)) {
                case "cmd" -> CMD;
                case "bot" -> BOT;
                default -> null;
            };
        }
    }
}
