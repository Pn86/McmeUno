package cn.pn86.pnplayerbot.simulation;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.geysermc.mcprotocollib.protocol.data.game.entity.type.EntityType;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.Map;

public final class EntityRegistry {
    public static final EntityRegistry INSTANCE = load();
    public static final Definition PLAYER = new Definition("player", 0.6, 1.8, true, true, true);
    private final Definition[] definitions;
    private final Map<EntityType, Definition> byType = new EnumMap<>(EntityType.class);

    private EntityRegistry(Definition[] definitions) { this.definitions = definitions; }
    public Definition definition(int typeId) {
        return typeId >= 0 && typeId < definitions.length && definitions[typeId] != null
                ? definitions[typeId] : new Definition("unknown", 0.6, 1.8, false, false, false);
    }

    public Definition definition(EntityType type) {
        return byType.getOrDefault(type, new Definition("unknown", 0.6, 1.8, false, false, false));
    }

    private static EntityRegistry load() {
        try (InputStream input = EntityRegistry.class.getResourceAsStream("/minecraft-data/1.21.8/entities.json")) {
            if (input == null) throw new IllegalStateException("缺少实体注册表");
            JsonArray array = JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonArray();
            // EntityType枚举的 ordinal 可能与注册表 ID 不一致，所以使用 EntityType.values().length 作为数组大小
            Definition[] result = new Definition[EntityType.values().length];
            for (JsonElement element : array) {
                JsonObject entity = element.getAsJsonObject();
                int id = entity.get("id").getAsInt();
                if (id >= result.length) continue; // 跳过超出枚举范围的 ID
                String name = entity.get("name").getAsString(), type = entity.get("type").getAsString();
                double width = number(entity, "width", 0.6), height = number(entity, "height", 1.8);
                boolean attackable = width > 0 && height > 0 && !type.equals("projectile")
                        && !name.equals("item") && !name.equals("experience_orb") && !name.endsWith("_display")
                        && !name.equals("area_effect_cloud") && !name.equals("marker") && !name.equals("interaction")
                        && !name.equals("lightning_bolt");
                boolean living = !type.equals("other") && !type.equals("projectile");
                result[id] = new Definition(name, width, height, attackable, living, type.equals("player"));
            }
            EntityRegistry registry = new EntityRegistry(result);
            // 构建 EntityType -> Definition 映射表，用于 EntityType 的 ordinal 映射
            for (EntityType entityType : EntityType.values()) {
                if (entityType == EntityType.PLAYER) {
                    registry.byType.put(entityType, PLAYER);
                } else {
                    // 使用 EntityType 的 ordinal 作为索引，如果超出范围则使用默认定义
                    int ordinal = entityType.ordinal();
                    Definition def = ordinal < result.length && result[ordinal] != null
                            ? result[ordinal]
                            : new Definition("unknown", 0.6, 1.8, false, false, false);
                    registry.byType.put(entityType, def);
                }
            }
            return registry;
        } catch (Exception error) { throw new ExceptionInInitializerError(error); }
    }

    private static double number(JsonObject object, String key, double fallback) {
        return object.has(key) && !object.get(key).isJsonNull() ? object.get(key).getAsDouble() : fallback;
    }
    public record Definition(String name, double width, double height, boolean attackable,
                             boolean living, boolean player) { }
}
