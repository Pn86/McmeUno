package cn.pn86.pnplayerbot.simulation;

/** 轻量轴对齐碰撞箱，坐标单位为方块。 */
public record Aabb(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
    private static final double EPSILON = 1.0E-7;

    public Aabb move(double x, double y, double z) {
        return new Aabb(minX + x, minY + y, minZ + z, maxX + x, maxY + y, maxZ + z);
    }

    public Aabb expandTowards(double x, double y, double z) {
        return new Aabb(x < 0 ? minX + x : minX, y < 0 ? minY + y : minY, z < 0 ? minZ + z : minZ,
                x > 0 ? maxX + x : maxX, y > 0 ? maxY + y : maxY, z > 0 ? maxZ + z : maxZ);
    }

    public Aabb inflate(double value) {
        return new Aabb(minX - value, minY - value, minZ - value, maxX + value, maxY + value, maxZ + value);
    }

    public boolean intersects(Aabb other) {
        return maxX > other.minX + EPSILON && minX < other.maxX - EPSILON
                && maxY > other.minY + EPSILON && minY < other.maxY - EPSILON
                && maxZ > other.minZ + EPSILON && minZ < other.maxZ - EPSILON;
    }

    public double clipX(Aabb moving, double amount) {
        if (moving.maxY <= minY + EPSILON || moving.minY >= maxY - EPSILON
                || moving.maxZ <= minZ + EPSILON || moving.minZ >= maxZ - EPSILON) return amount;
        if (amount > 0 && moving.maxX <= minX) amount = Math.min(amount, minX - moving.maxX);
        else if (amount < 0 && moving.minX >= maxX) amount = Math.max(amount, maxX - moving.minX);
        return amount;
    }

    public double clipY(Aabb moving, double amount) {
        if (moving.maxX <= minX + EPSILON || moving.minX >= maxX - EPSILON
                || moving.maxZ <= minZ + EPSILON || moving.minZ >= maxZ - EPSILON) return amount;
        if (amount > 0 && moving.maxY <= minY) amount = Math.min(amount, minY - moving.maxY);
        else if (amount < 0 && moving.minY >= maxY) amount = Math.max(amount, maxY - moving.minY);
        return amount;
    }

    public double clipZ(Aabb moving, double amount) {
        if (moving.maxX <= minX + EPSILON || moving.minX >= maxX - EPSILON
                || moving.maxY <= minY + EPSILON || moving.minY >= maxY - EPSILON) return amount;
        if (amount > 0 && moving.maxZ <= minZ) amount = Math.min(amount, minZ - moving.maxZ);
        else if (amount < 0 && moving.minZ >= maxZ) amount = Math.max(amount, maxZ - moving.minZ);
        return amount;
    }

    /** 返回射线首次进入碰撞箱的距离；未命中返回正无穷。direction 必须已经归一化。 */
    public double rayDistance(double ox, double oy, double oz, double dx, double dy, double dz, double maxDistance) {
        double near = 0.0, far = maxDistance;
        double[] origins = {ox, oy, oz}, directions = {dx, dy, dz};
        double[] mins = {minX, minY, minZ}, maxs = {maxX, maxY, maxZ};
        for (int axis = 0; axis < 3; axis++) {
            double direction = directions[axis];
            if (Math.abs(direction) < EPSILON) {
                if (origins[axis] < mins[axis] || origins[axis] > maxs[axis]) return Double.POSITIVE_INFINITY;
                continue;
            }
            double a = (mins[axis] - origins[axis]) / direction;
            double b = (maxs[axis] - origins[axis]) / direction;
            if (a > b) { double swap = a; a = b; b = swap; }
            near = Math.max(near, a); far = Math.min(far, b);
            if (near > far) return Double.POSITIVE_INFINITY;
        }
        return near >= 0 && near <= maxDistance ? near : Double.POSITIVE_INFINITY;
    }
}
