package cn.pn86.pnplayerbot.protocol;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class PacketBuffer {
    private PacketBuffer() { }

    public static final class Reader {
        private final DataInputStream input;
        public Reader(byte[] data) { input = new DataInputStream(new ByteArrayInputStream(data)); }
        public int varInt() throws IOException {
            int value = 0;
            int position = 0;
            while (true) {
                int current = input.read();
                if (current < 0) throw new EOFException();
                value |= (current & 0x7F) << position;
                if ((current & 0x80) == 0) return value;
                position += 7;
                if (position >= 35) throw new IOException("VarInt 过长");
            }
        }
        public long longValue() throws IOException { return input.readLong(); }
        public int intValue() throws IOException { return input.readInt(); }
        public double doubleValue() throws IOException { return input.readDouble(); }
        public float floatValue() throws IOException { return input.readFloat(); }
        public boolean bool() throws IOException { return input.readBoolean(); }
        public int unsignedByte() throws IOException { return input.readUnsignedByte(); }
        public UUID uuid() throws IOException { return new UUID(input.readLong(), input.readLong()); }
        public String string(int maxChars) throws IOException {
            int length = varInt();
            if (length < 0 || length > maxChars * 4) throw new IOException("字符串长度无效：" + length);
            byte[] bytes = input.readNBytes(length);
            if (bytes.length != length) throw new EOFException();
            String value = new String(bytes, StandardCharsets.UTF_8);
            if (value.length() > maxChars) throw new IOException("字符串字符数超限");
            return value;
        }
        public int available() throws IOException { return input.available(); }
    }

    public static final class Writer {
        private final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        private final DataOutputStream output = new DataOutputStream(bytes);
        public Writer varInt(int value) throws IOException {
            while ((value & ~0x7F) != 0) {
                output.writeByte((value & 0x7F) | 0x80);
                value >>>= 7;
            }
            output.writeByte(value);
            return this;
        }
        public Writer longValue(long value) throws IOException { output.writeLong(value); return this; }
        public Writer intValue(int value) throws IOException { output.writeInt(value); return this; }
        public Writer doubleValue(double value) throws IOException { output.writeDouble(value); return this; }
        public Writer floatValue(float value) throws IOException { output.writeFloat(value); return this; }
        public Writer bool(boolean value) throws IOException { output.writeBoolean(value); return this; }
        public Writer byteValue(int value) throws IOException { output.writeByte(value); return this; }
        public Writer shortValue(int value) throws IOException { output.writeShort(value); return this; }
        public Writer uuid(UUID value) throws IOException { output.writeLong(value.getMostSignificantBits()); output.writeLong(value.getLeastSignificantBits()); return this; }
        public Writer string(String value) throws IOException {
            byte[] encoded = value.getBytes(StandardCharsets.UTF_8);
            varInt(encoded.length); output.write(encoded); return this;
        }
        public Writer bytes(byte[] value) throws IOException { output.write(value); return this; }
        public byte[] toByteArray() throws IOException { output.flush(); return bytes.toByteArray(); }
    }
}
