package cn.pn86.pnplayerbot.integration;

import cn.pn86.pnplayerbot.bot.BotManager;
import cn.pn86.pnplayerbot.bot.BotSession;
import cn.pn86.pnplayerbot.bot.InventoryItem;
import cn.pn86.pnplayerbot.config.ConfigService;
import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerCommon;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.component.ComponentTypes;
import com.github.retrooper.packetevents.protocol.item.ItemStack;
import com.github.retrooper.packetevents.protocol.item.type.ItemType;
import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetPlayerInventory;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetSlot;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowItems;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerJoinGame;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRespawn;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * 标准 PacketEvents Velocity 2.13 适配层。
 *
 * 内置客户端仍然是主数据源；此监听器读取 Velocity 已解码的数据包，提供主人位置/维度，并作为
 * 背包与容器解析的第二数据源。它不会改变包、取消事件或向服务器重复发包。
 */
public final class PacketEventsBridge implements AutoCloseable {
    private final ConfigService config;
    private final BotManager bots;
    private final Logger logger;
    private final PlainTextComponentSerializer plain = PlainTextComponentSerializer.plainText();
    private PacketListenerCommon listener;

    public PacketEventsBridge(ConfigService config, BotManager bots, Logger logger) {
        this.config = config;
        this.bots = bots;
        this.logger = logger;
    }

    public boolean initialize() {
        if (!config.bool("tracking.packetevents-integration", true)) {
            logger.info("已检测到 PacketEvents，但 config.yml 已关闭其背包备用读取。 ");
            return false;
        }
        try {
            if (PacketEvents.getAPI() == null || !PacketEvents.getAPI().isInitialized()) {
                throw new IllegalStateException("PacketEvents API 尚未初始化");
            }
            int registeredItems = registerItemNames();
            listener = new PacketListenerAbstract(PacketListenerPriority.MONITOR) {
                @Override public void onPacketReceive(PacketReceiveEvent event) { acceptOwnerMovement(event); }
                @Override public void onPacketSend(PacketSendEvent event) { accept(event); }
            };
            PacketEvents.getAPI().getEventManager().registerListener(listener);
            logger.info("已连接标准 PacketEvents {}：启用主人世界/坐标跟踪及假人背包、容器双通道读取，已载入 {} 个物品 ID。",
                    PacketEvents.getAPI().getVersion(), registeredItems);
            return true;
        } catch (Throwable error) {
            listener = null;
            if (config.bool("tracking.require-packetevents", false)) {
                throw new IllegalStateException("PacketEvents 兼容层初始化失败", error);
            }
            logger.warn("检测到 PacketEvents，但兼容层未能启用；继续使用内置背包解析器：{}", error.toString());
            return false;
        }
    }

    private int registerItemNames() {
        try {
            int count = 0;
            for (ItemType type : ItemTypes.values()) {
                int id = type.getId(ClientVersion.V_1_21_7);
                if (id < 0 || type.getName() == null) continue;
                InventoryItem.registerRegistryName(id, type.getName().toString());
                count++;
            }
            return count;
        } catch (Throwable error) {
            // 物品名称表失败不能连带关闭主人世界/坐标跟踪，背包仍会显示纯数字 ID。
            config.logDebug("PacketEvents 物品 ID 对照加载失败，将显示数字 ID：{}", error.toString());
            return 0;
        }
    }

    private void accept(PacketSendEvent event) {
        try {
            String name = event.getUser() == null ? null : event.getUser().getName();
            if (name != null && bots.sessionByBotName(name) == null) {
                if (event.getPacketType() == PacketType.Play.Server.JOIN_GAME) {
                    bots.updateOwnerWorld(name, new WrapperPlayServerJoinGame(event).getWorldName());
                } else if (event.getPacketType() == PacketType.Play.Server.RESPAWN) {
                    bots.updateOwnerWorld(name, new WrapperPlayServerRespawn(event).getWorldName().orElse(""));
                }
            }
            BotSession session = name == null ? null : bots.sessionByBotName(name);
            if (session == null) return;

            if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
                WrapperPlayServerWindowItems packet = new WrapperPlayServerWindowItems(event);
                List<InventoryItem> items = new ArrayList<>();
                List<ItemStack> stacks = packet.getItems();
                for (int slot = 0; slot < stacks.size(); slot++) {
                    InventoryItem item = snapshot(slot, stacks.get(slot), event);
                    if (item != null) items.add(item);
                }
                if (packet.getWindowId() == 0) session.inventory.clearAndSet(items, packet.getStateId());
                else session.container.clearAndSet(packet.getWindowId(), items, packet.getStateId());
            } else if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
                WrapperPlayServerSetSlot packet = new WrapperPlayServerSetSlot(event);
                InventoryItem item = snapshot(packet.getSlot(), packet.getItem(), event);
                if (packet.getWindowId() == 0 || packet.getWindowId() == -2) {
                    update(session, packet.getSlot(), item, packet.getStateId());
                } else session.container.set(packet.getWindowId(), packet.getSlot(), item, packet.getStateId());
            } else if (event.getPacketType() == PacketType.Play.Server.SET_PLAYER_INVENTORY) {
                WrapperPlayServerSetPlayerInventory packet = new WrapperPlayServerSetPlayerInventory(event);
                int slot = playerInventoryToContainerSlot(packet.getSlot());
                if (slot >= 0) update(session, slot, snapshot(slot, packet.getStack(), event), session.inventory.stateId());
            } else if (event.getPacketType() == PacketType.Play.Server.HELD_ITEM_CHANGE) {
                session.inventory.selectedHotbar(new WrapperPlayServerHeldItemChange(event).getSlot());
            }
        } catch (Throwable error) {
            config.logDebug("PacketEvents 背包备用读取失败：{}", error.toString());
        }
    }

    private void acceptOwnerMovement(PacketReceiveEvent event) {
        try {
            if (!WrapperPlayClientPlayerFlying.isFlying(event.getPacketType()) || event.getUser() == null) return;
            String name = event.getUser().getName();
            if (name == null || bots.sessionByBotName(name) != null) return;
            WrapperPlayClientPlayerFlying packet = new WrapperPlayClientPlayerFlying(event);
            // Flying 包只有世界类型（主世界/下界/末地），没有准确的自定义世界名称。
            // 这里必须保留 Join Game / Respawn 已记录的 world name，否则多世界插件中的
            // 两个主世界会被错误地当成同一个世界。
            bots.updateOwnerMotion(name, packet.hasPositionChanged(), packet.getLocation().getX(),
                    packet.getLocation().getY(), packet.getLocation().getZ(),
                    packet.hasRotationChanged(), packet.getLocation().getYaw(), packet.getLocation().getPitch(), "");
        } catch (Throwable error) {
            config.logDebug("PacketEvents 主人坐标读取失败：{}", error.toString());
        }
    }

    private void update(BotSession session, int slot, InventoryItem item, int stateId) {
        if (item == null) session.inventory.clear(slot, stateId);
        else session.inventory.set(item, stateId);
    }

    private InventoryItem snapshot(int slot, ItemStack stack, PacketSendEvent event) {
        if (stack == null || stack.isEmpty() || stack.getAmount() <= 0) return null;
        Component component = stack.getComponent(ComponentTypes.CUSTOM_NAME)
                .orElseGet(() -> stack.getComponent(ComponentTypes.ITEM_NAME).orElse(null));
        String name = component == null ? stack.getType().getName().toString() : plain.serialize(component).strip();
        if (name.isBlank()) name = stack.getType().getName().toString();
        int id = stack.getType().getId(event.getClientVersion());
        return new InventoryItem(slot, id, stack.getAmount(), name, stack.getType().getName().toString());
    }

    /** PlayerInventory 的 0..8 是快捷栏，而玩家容器中的快捷栏是 36..44。 */
    private int playerInventoryToContainerSlot(int slot) {
        if (slot >= 0 && slot <= 8) return slot + 36;
        if (slot >= 9 && slot <= 35) return slot;
        return switch (slot) {
            case 36 -> 8;
            case 37 -> 7;
            case 38 -> 6;
            case 39 -> 5;
            case 40 -> 45;
            default -> -1;
        };
    }

    @Override public void close() {
        if (listener == null) return;
        try { PacketEvents.getAPI().getEventManager().unregisterListener(listener); }
        catch (Throwable ignored) { }
        listener = null;
    }
}
