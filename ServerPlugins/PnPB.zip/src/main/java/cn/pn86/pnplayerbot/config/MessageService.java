package cn.pn86.pnplayerbot.config;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MessageService {
    private final ConfigService config;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();

    public MessageService(ConfigService config) {
        this.config = config;
    }

    public void send(Audience audience, String key, Object... pairs) {
        for (String line : config.messageLines(key, key)) audience.sendMessage(componentRaw(line, pairs));
    }

    public Component component(String key, Object... pairs) {
        return componentRaw(config.message(key, key), pairs);
    }

    private Component componentRaw(String line, Object... pairs) {
        String raw = config.message("prefix", "") + line;
        Map<String, String> replacements = new LinkedHashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            replacements.put(String.valueOf(pairs[i]), String.valueOf(pairs[i + 1]));
        }
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            raw = raw.replace("{" + entry.getKey() + "}", escape(entry.getValue()));
        }
        return legacy.deserialize(raw);
    }

    private String escape(String value) {
        // 变量来自玩家名、输入内容或状态，禁止它们注入额外颜色代码。
        return value.replace('&', '＆');
    }
}
