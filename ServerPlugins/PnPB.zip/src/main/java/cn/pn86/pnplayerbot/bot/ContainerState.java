package cn.pn86.pnplayerbot.bot;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** 当前由假人打开的箱子类容器快照。槽位编号使用服务端菜单槽位，不与玩家 window 0 混用。 */
public final class ContainerState {
    private final Map<Integer, InventoryItem> slots = new ConcurrentHashMap<>();
    private volatile int containerId = -1;
    private volatile int stateId;
    private volatile int storageSlots;
    private volatile String type = "";

    public synchronized void open(int id, String type, int storageSlots) {
        this.containerId = id;
        this.type = type == null ? "" : type;
        this.storageSlots = Math.max(0, storageSlots);
        this.stateId = 0;
        slots.clear();
    }

    public synchronized void close() {
        containerId = -1;
        stateId = 0;
        storageSlots = 0;
        type = "";
        slots.clear();
    }

    public synchronized void clearAndSet(int id, List<InventoryItem> items, int newStateId) {
        if (id != containerId) return;
        slots.clear();
        for (InventoryItem item : items) if (item != null && item.amount() > 0) slots.put(item.containerSlot(), item);
        stateId = newStateId;
    }

    public synchronized void set(int id, int slot, InventoryItem item, int newStateId) {
        if (id != containerId) return;
        if (item == null || item.amount() <= 0) slots.remove(slot);
        else slots.put(slot, item);
        stateId = newStateId;
    }

    public boolean isOpen() { return containerId >= 0 && storageSlots > 0; }
    public int containerId() { return containerId; }
    public int stateId() { return stateId; }
    public int storageSlots() { return storageSlots; }
    public String type() { return type; }

    public List<InventoryItem> storageItems(String filter) {
        return filtered(0, storageSlots, filter);
    }

    public List<InventoryItem> playerItems(String filter) {
        return filtered(storageSlots, storageSlots + 36, filter);
    }

    private List<InventoryItem> filtered(int from, int to, String filter) {
        List<InventoryItem> result = new ArrayList<>();
        for (InventoryItem item : slots.values()) {
            if (item.containerSlot() < from || item.containerSlot() >= to) continue;
            if (!item.matches(filter)) continue;
            result.add(item);
        }
        result.sort(Comparator.comparingInt(InventoryItem::containerSlot));
        return List.copyOf(result);
    }

    /** 采用保守的 64 堆叠估算；存在空槽时才允许无法确认堆叠上限的物品进入。 */
    public boolean hasSpaceFor(boolean intoStorage, List<InventoryItem> moving) {
        if (moving.isEmpty()) return false;
        int from = intoStorage ? 0 : storageSlots;
        int to = intoStorage ? storageSlots : storageSlots + 36;
        int empty = 0;
        Map<Integer, Long> capacity = new HashMap<>();
        for (int slot = from; slot < to; slot++) {
            InventoryItem item = slots.get(slot);
            if (item == null) empty++;
            else capacity.merge(item.itemId(), (long) Math.max(0, 64 - item.amount()), Long::sum);
        }
        Map<Integer, Long> demand = new HashMap<>();
        for (InventoryItem item : moving) demand.merge(item.itemId(), (long) item.amount(), Long::sum);
        long generic = (long) empty * 64L;
        for (Map.Entry<Integer, Long> entry : demand.entrySet()) {
            long remaining = Math.max(0, entry.getValue() - capacity.getOrDefault(entry.getKey(), 0L));
            if (remaining > generic) return false;
            generic -= remaining;
        }
        return true;
    }
}
