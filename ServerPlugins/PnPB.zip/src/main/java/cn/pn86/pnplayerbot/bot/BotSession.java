package cn.pn86.pnplayerbot.bot;

import cn.pn86.pnplayerbot.data.PlayerData;
import com.velocitypowered.api.proxy.Player;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentHashMap;

public final class BotSession {
    public final String ownerName;
    public final String ownerKey;
    public final String botName;
    public final UUID loginToken;
    public final PlayerData data;
    public final AtomicInteger generation = new AtomicInteger();
    public volatile String targetServer;
    public volatile String connectedServer = "";
    public volatile BotStatus status = BotStatus.CONNECTING;
    public volatile MinecraftClient client;
    public volatile Player proxyPlayer;
    public volatile boolean playReady;
    public volatile boolean intentionalStop;
    public volatile int reconnectAttempts;
    public volatile long reconnectStartedMillis;
    public volatile long onlineSinceNanos;
    public volatile long lastBillingNanos;
    public volatile long lastDisconnectHandledGeneration = -1;
    public volatile long announcedGeneration = -1;
    public volatile double x, y, z;
    public volatile float yaw, pitch;
    public volatile float health = 20.0f;
    public final InventoryState inventory = new InventoryState();
    public final ContainerState container = new ContainerState();
    public volatile boolean destroyContinuous;
    public volatile boolean attackContinuous;
    public volatile boolean useContinuous;
    public volatile boolean putContinuous;
    public volatile long actionGeneration;
    public volatile long attackGeneration;
    public volatile long attackRequestId;
    public volatile long destroyGeneration;
    public volatile long destroyRequestId;
    public volatile int destroyRemaining;
    public volatile long facingRequestId;
    public volatile DestroyTarget destroyTarget;
    public volatile long useGeneration;
    public volatile long putGeneration;
    public volatile long movementGeneration;
    public volatile boolean movementActive;
    public volatile char movementDirection;
    public volatile long inventoryGeneration;
    public volatile long containerGeneration;
    public volatile boolean followOwner;
    public volatile boolean navigatingHere;
    public volatile long navigationGeneration;
    public volatile double navigationTargetX, navigationTargetY, navigationTargetZ;
    public volatile String navigationDimension = "";
    public volatile String navigationServer = "";
    public volatile double lastPlannedTargetX, lastPlannedTargetY, lastPlannedTargetZ;
    public volatile long lastNavigationPlanMillis;
    public volatile int navigationFailures;
    public final ConcurrentHashMap<String, Long> lastOperations = new ConcurrentHashMap<>();
    public volatile long workGeneration;
    public volatile long autoWorksGeneration;
    public volatile int nextWorkIndex = 1;
    public final Instant createdAt = Instant.now();

    public BotSession(String ownerName, String ownerKey, String botName, UUID loginToken, String targetServer, PlayerData data) {
        this.ownerName = ownerName;
        this.ownerKey = ownerKey;
        this.botName = botName;
        this.loginToken = loginToken;
        this.targetServer = targetServer;
        this.data = data;
    }
}
