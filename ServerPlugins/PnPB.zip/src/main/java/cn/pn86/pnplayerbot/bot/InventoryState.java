package cn.pn86.pnplayerbot.bot;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class InventoryState {
    private final Map<Integer, InventoryItem> slots = new ConcurrentHashMap<>();
    private volatile int stateId;
    private volatile int selectedHotbar;

    public int stateId() { return stateId; }
    public void stateId(int value) { stateId = value; }
    public int selectedHotbar() { return selectedHotbar; }
    public void selectedHotbar(int value) { selectedHotbar = Math.max(0, Math.min(8, value)); }
    public int heldItemId() {
        InventoryItem item = slots.get(36 + selectedHotbar);
        return item == null ? 0 : item.itemId();
    }

    public void clearAndSet(List<InventoryItem> items, int newStateId) {
        slots.clear();
        for (InventoryItem item : items) if (item != null && item.amount() > 0) slots.put(item.containerSlot(), item);
        stateId = newStateId;
    }

    public void set(InventoryItem item, int newStateId) {
        if (item == null || item.amount() <= 0) return;
        slots.put(item.containerSlot(), item);
        stateId = newStateId;
    }

    public void clear(int slot, int newStateId) {
        slots.remove(slot);
        stateId = newStateId;
    }

    /** 返回当前非空物品的稳定视图；序号由该列表的 1-based 下标决定。 */
    public List<InventoryItem> indexedItems() {
        List<InventoryItem> result = new ArrayList<>(slots.values());
        result.sort(Comparator.comparingInt(InventoryItem::containerSlot));
        return List.copyOf(result);
    }
}
