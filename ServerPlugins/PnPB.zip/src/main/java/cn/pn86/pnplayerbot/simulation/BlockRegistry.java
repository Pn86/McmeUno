package cn.pn86.pnplayerbot.simulation;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 由 minecraft-data 生成的共享方块状态、碰撞形状和挖掘速度表。 */
public final class BlockRegistry {
    public static final BlockRegistry INSTANCE = load();
    private static final Aabb[] EMPTY = new Aabb[0];
    private static final Aabb[] FULL_BLOCK = {new Aabb(0, 0, 0, 1, 1, 1)};
    private final State[] states;
    private final Map<String, Map<Integer, Double>> materialSpeeds;

    private BlockRegistry(State[] states, Map<String, Map<Integer, Double>> materialSpeeds) {
        this.states = states;
        this.materialSpeeds = materialSpeeds;
    }

    public State state(int id) {
        return id >= 0 && id < states.length && states[id] != null ? states[id] : State.UNKNOWN;
    }

    public int breakTicks(State state, int heldItemId, boolean onGround, int maximum) {
        if (!state.targetable || !state.diggable || state.hardness < 0) return -maximum;
        if (state.hardness == 0) return 1;
        double speed = materialSpeeds.getOrDefault(state.material, Map.of()).getOrDefault(heldItemId, 1.0);
        boolean correctTool = state.harvestTools.isEmpty() || state.harvestTools.contains(heldItemId);
        if (!onGround) speed /= 5.0;
        double damage = speed / state.hardness / (correctTool ? 30.0 : 100.0);
        if (damage <= 0) return maximum;
        return Math.max(1, Math.min(maximum, (int) Math.ceil(1.0 / damage)));
    }

    private static BlockRegistry load() {
        JsonArray blocks = read("/minecraft-data/1.21.8/blocks.json").getAsJsonArray();
        JsonObject collisionRoot = read("/minecraft-data/1.21.8/blockCollisionShapes.json").getAsJsonObject();
        JsonObject blockShapes = collisionRoot.getAsJsonObject("blocks");
        JsonObject shapesJson = collisionRoot.getAsJsonObject("shapes");
        Map<Integer, Aabb[]> shapes = new HashMap<>();
        for (Map.Entry<String, JsonElement> entry : shapesJson.entrySet()) {
            JsonArray boxes = entry.getValue().getAsJsonArray();
            Aabb[] result = new Aabb[boxes.size()];
            for (int index = 0; index < boxes.size(); index++) {
                JsonArray b = boxes.get(index).getAsJsonArray();
                result[index] = new Aabb(b.get(0).getAsDouble(), b.get(1).getAsDouble(), b.get(2).getAsDouble(),
                        b.get(3).getAsDouble(), b.get(4).getAsDouble(), b.get(5).getAsDouble());
            }
            shapes.put(Integer.parseInt(entry.getKey()), result);
        }

        int maximumState = 0;
        for (JsonElement element : blocks) maximumState = Math.max(maximumState, element.getAsJsonObject().get("maxStateId").getAsInt());
        State[] byState = new State[maximumState + 1];
        for (JsonElement element : blocks) {
            JsonObject block = element.getAsJsonObject();
            String name = block.get("name").getAsString();
            int min = block.get("minStateId").getAsInt(), max = block.get("maxStateId").getAsInt();
            double hardness = block.has("hardness") && !block.get("hardness").isJsonNull() ? block.get("hardness").getAsDouble() : -1;
            boolean diggable = block.has("diggable") && block.get("diggable").getAsBoolean();
            String material = block.has("material") ? block.get("material").getAsString() : "default";
            List<Property> properties = readProperties(block);
            Set<Integer> harvestTools = new HashSet<>();
            if (block.has("harvestTools")) for (String key : block.getAsJsonObject("harvestTools").keySet()) harvestTools.add(Integer.parseInt(key));
            boolean air = name.equals("air") || name.equals("cave_air") || name.equals("void_air");
            boolean fluid = name.equals("water") || name.equals("lava") || name.equals("bubble_column");
            boolean targetable = !air && !fluid;
            JsonElement shapeMapping = blockShapes.get(name);
            for (int id = min; id <= max; id++) {
                int shapeId = 0;
                if (shapeMapping != null && shapeMapping.isJsonArray()) {
                    JsonArray mappings = shapeMapping.getAsJsonArray();
                    int offset = Math.min(mappings.size() - 1, id - min);
                    if (offset >= 0) shapeId = mappings.get(offset).getAsInt();
                } else if (shapeMapping != null) shapeId = shapeMapping.getAsInt();
                Aabb[] collision = shapes.getOrDefault(shapeId, shapeId == 0 ? EMPTY : FULL_BLOCK);
                Map<String, String> values = decodeProperties(id - min, properties);
                boolean waterlogged = Boolean.parseBoolean(values.getOrDefault("waterlogged", "false"));
                byState[id] = new State(id, name, hardness, diggable, targetable, material,
                        Set.copyOf(harvestTools), collision, values.getOrDefault("facing", ""), waterlogged);
            }
        }

        JsonObject materials = read("/minecraft-data/1.21.8/materials.json").getAsJsonObject();
        Map<String, Map<Integer, Double>> speeds = new HashMap<>();
        for (Map.Entry<String, JsonElement> material : materials.entrySet()) {
            Map<Integer, Double> values = new HashMap<>();
            for (Map.Entry<String, JsonElement> value : material.getValue().getAsJsonObject().entrySet())
                values.put(Integer.parseInt(value.getKey()), value.getValue().getAsDouble());
            speeds.put(material.getKey(), Map.copyOf(values));
        }
        return new BlockRegistry(byState, Map.copyOf(speeds));
    }

    private static JsonElement read(String resource) {
        try (InputStream input = BlockRegistry.class.getResourceAsStream(resource)) {
            if (input == null) throw new IllegalStateException("缺少内置数据：" + resource);
            return JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8));
        } catch (Exception error) { throw new ExceptionInInitializerError(error); }
    }

    private static List<Property> readProperties(JsonObject block) {
        if (!block.has("states")) return List.of();
        java.util.ArrayList<Property> result = new java.util.ArrayList<>();
        for (JsonElement element : block.getAsJsonArray("states")) {
            JsonObject property = element.getAsJsonObject();
            String name = property.get("name").getAsString();
            java.util.ArrayList<String> values = new java.util.ArrayList<>();
            if (property.has("values")) {
                for (JsonElement value : property.getAsJsonArray("values")) values.add(value.getAsString());
            } else if (property.get("type").getAsString().equals("bool")) {
                // minecraft-data 的布尔状态顺序与方块状态 ID 一致：true 在前、false 在后。
                values.add("true"); values.add("false");
            } else {
                int count = property.get("num_values").getAsInt();
                for (int index = 0; index < count; index++) values.add(String.valueOf(index));
            }
            result.add(new Property(name, List.copyOf(values)));
        }
        return List.copyOf(result);
    }

    /** 方块状态 ID 的最后一个属性变化最快，与原版状态定义的笛卡尔积顺序一致。 */
    private static Map<String, String> decodeProperties(int offset, List<Property> properties) {
        if (properties.isEmpty()) return Map.of();
        Map<String, String> result = new HashMap<>();
        int remaining = offset;
        for (int index = properties.size() - 1; index >= 0; index--) {
            Property property = properties.get(index);
            int size = Math.max(1, property.values.size());
            int value = Math.floorMod(remaining, size);
            remaining = Math.floorDiv(remaining, size);
            result.put(property.name, property.values.get(value));
        }
        return Map.copyOf(result);
    }

    public record State(int id, String name, double hardness, boolean diggable, boolean targetable,
                        String material, Set<Integer> harvestTools, Aabb[] collision,
                        String facing, boolean waterlogged) {
        private static final State UNKNOWN = new State(-1, "unknown", -1, false, false,
                "default", Set.of(), EMPTY, "", false);

        public boolean water() { return name.equals("water") || name.equals("bubble_column") || waterlogged; }
        public boolean lava() { return name.equals("lava"); }
        public boolean climbable() {
            return name.equals("ladder") || name.equals("vine") || name.equals("scaffolding")
                    || name.equals("weeping_vines") || name.equals("weeping_vines_plant")
                    || name.equals("twisting_vines") || name.equals("twisting_vines_plant")
                    || name.equals("cave_vines") || name.equals("cave_vines_plant");
        }
        public boolean scaffolding() { return name.equals("scaffolding"); }
        public double friction() {
            if (name.equals("blue_ice")) return 0.989;
            if (name.equals("ice") || name.equals("packed_ice") || name.equals("frosted_ice")) return 0.98;
            if (name.equals("slime_block")) return 0.8;
            return 0.6;
        }
        public double speedFactor() {
            return name.equals("soul_sand") || name.equals("honey_block") ? 0.4 : 1.0;
        }
    }

    private record Property(String name, List<String> values) { }
}
