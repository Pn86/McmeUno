package cn.pn86.pnplayerbot.protocol;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Arrays;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public final class ProtocolConnection implements AutoCloseable {
    private final Socket socket = new Socket();
    private final int maxPacketBytes;
    private DataInputStream input;
    private DataOutputStream output;
    private volatile int compressionThreshold = -1;

    public ProtocolConnection(int maxPacketBytes) {
        this.maxPacketBytes = maxPacketBytes;
    }

    public void connect(String host, int port, int timeoutMillis, int readTimeoutMillis) throws IOException {
        socket.setTcpNoDelay(true);
        socket.setKeepAlive(true);
        socket.connect(new InetSocketAddress(host, port), timeoutMillis);
        socket.setSoTimeout(Math.max(0, readTimeoutMillis));
        input = new DataInputStream(socket.getInputStream());
        output = new DataOutputStream(socket.getOutputStream());
    }

    public void compressionThreshold(int value) { compressionThreshold = value; }

    public synchronized void send(int packetId, PacketWriter payloadWriter) throws IOException {
        PacketBuffer.Writer packet = new PacketBuffer.Writer().varInt(packetId);
        if (payloadWriter != null) payloadWriter.write(packet);
        byte[] uncompressed = packet.toByteArray();
        if (uncompressed.length > maxPacketBytes) throw new IOException("发送包超过限制");

        byte[] framedData;
        int threshold = compressionThreshold;
        if (threshold >= 0) {
            PacketBuffer.Writer framed = new PacketBuffer.Writer();
            if (uncompressed.length >= threshold) {
                framed.varInt(uncompressed.length).bytes(deflate(uncompressed));
            } else {
                framed.varInt(0).bytes(uncompressed);
            }
            framedData = framed.toByteArray();
        } else {
            framedData = uncompressed;
        }
        writeVarInt(output, framedData.length);
        output.write(framedData);
        output.flush();
    }

    public ReceivedPacket read() throws IOException {
        int frameLength = readVarInt(input);
        if (frameLength < 0 || frameLength > maxPacketBytes) throw new IOException("接收包长度无效：" + frameLength);
        byte[] frame = input.readNBytes(frameLength);
        if (frame.length != frameLength) throw new EOFException("连接已关闭");
        byte[] packetData = frame;
        if (compressionThreshold >= 0) {
            PacketBuffer.Reader compressed = new PacketBuffer.Reader(frame);
            int uncompressedLength = compressed.varInt();
            int prefixBytes = frame.length - compressed.available();
            byte[] body = Arrays.copyOfRange(frame, prefixBytes, frame.length);
            if (uncompressedLength > 0) {
                if (uncompressedLength > maxPacketBytes) throw new IOException("解压后数据包超过限制");
                packetData = inflate(body, uncompressedLength);
            } else packetData = body;
        }
        PacketBuffer.Reader reader = new PacketBuffer.Reader(packetData);
        int id = reader.varInt();
        int idBytes = packetData.length - reader.available();
        return new ReceivedPacket(id, Arrays.copyOfRange(packetData, idBytes, packetData.length));
    }

    private byte[] deflate(byte[] input) throws IOException {
        Deflater deflater = new Deflater();
        try {
            deflater.setInput(input); deflater.finish();
            ByteArrayOutputStream result = new ByteArrayOutputStream(input.length);
            byte[] buffer = new byte[8192];
            while (!deflater.finished()) result.write(buffer, 0, deflater.deflate(buffer));
            return result.toByteArray();
        } finally { deflater.end(); }
    }

    private byte[] inflate(byte[] input, int expected) throws IOException {
        Inflater inflater = new Inflater();
        try {
            inflater.setInput(input);
            byte[] result = new byte[expected];
            int offset = 0;
            while (!inflater.finished() && offset < expected) offset += inflater.inflate(result, offset, expected - offset);
            if (offset != expected) throw new IOException("解压数据长度不匹配");
            return result;
        } catch (Exception e) { throw new IOException("解压数据包失败", e); }
        finally { inflater.end(); }
    }

    private static int readVarInt(DataInputStream input) throws IOException {
        int value = 0, position = 0;
        while (true) {
            int current = input.read();
            if (current < 0) throw new EOFException("连接已关闭");
            value |= (current & 0x7F) << position;
            if ((current & 0x80) == 0) return value;
            position += 7;
            if (position >= 35) throw new IOException("帧 VarInt 过长");
        }
    }

    private static void writeVarInt(DataOutputStream output, int value) throws IOException {
        while ((value & ~0x7F) != 0) { output.writeByte((value & 0x7F) | 0x80); value >>>= 7; }
        output.writeByte(value);
    }

    @Override public void close() {
        try { socket.close(); } catch (IOException ignored) { }
    }

    public record ReceivedPacket(int id, byte[] payload) { }
    @FunctionalInterface public interface PacketWriter { void write(PacketBuffer.Writer writer) throws IOException; }
}
