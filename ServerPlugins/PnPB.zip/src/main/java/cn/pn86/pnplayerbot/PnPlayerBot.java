package cn.pn86.pnplayerbot;

import cn.pn86.pnplayerbot.bot.BotManager;
import cn.pn86.pnplayerbot.command.PnpbCommand;
import cn.pn86.pnplayerbot.config.ConfigService;
import cn.pn86.pnplayerbot.config.MessageService;
import cn.pn86.pnplayerbot.data.PlayerStore;
import cn.pn86.pnplayerbot.integration.PacketEventsBridge;
import cn.pn86.pnplayerbot.integration.ServerApiService;
import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.connection.PreLoginEvent;
import com.velocitypowered.api.event.player.PlayerChooseInitialServerEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import org.slf4j.Logger;

import java.nio.file.Path;

@Plugin(id = "pnplayerbot", name = "PnPlayerBot", version = "1.6.0",
        description = "Embedded Minecraft 1.21.11 headless player bots for Velocity", authors = {"Pn86"},
        dependencies = {@Dependency(id = "packetevents", optional = true)})
public final class PnPlayerBot {
    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;
    private ConfigService config;
    private MessageService messages;
    private PlayerStore store;
    private BotManager bots;
    private ServerApiService serverApi;
    private PacketEventsBridge packetEvents;

    @Inject
    public PnPlayerBot(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory) {
        this.proxy = proxy; this.logger = logger; this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onInitialize(ProxyInitializeEvent event) {
        try {
            config = new ConfigService(dataDirectory, logger);
            config.initialize();
            messages = new MessageService(config);
            store = new PlayerStore(config, logger);
            store.load();
            bots = new BotManager(this, proxy, config, messages, store, logger);
            proxy.getCommandManager().register(proxy.getCommandManager().metaBuilder("pnpb").plugin(this).build(),
                    new PnpbCommand(proxy, config, messages, store, bots));
            bots.startTasks();
            serverApi = new ServerApiService(config, store, bots, logger);
            serverApi.start();
            bots.setServerApiRestart(() -> {
                try { serverApi.restart(); }
                catch (Exception e) { logger.warn("ServerApi 重载监听失败：{}", e.toString()); }
            });
            if (proxy.getPluginManager().isLoaded("packetevents")) {
                try {
                    packetEvents = new PacketEventsBridge(config, bots, logger);
                    packetEvents.initialize();
                } catch (Throwable error) {
                    packetEvents = null;
                    if (config.bool("tracking.require-packetevents", false)) {
                        throw new IllegalStateException("PacketEvents 兼容层加载失败", error);
                    }
                    logger.warn("已安装 PacketEvents，但其 API 无法连接；继续使用内置协议解析器：{}", error.toString());
                }
            } else if (config.bool("tracking.require-packetevents", false)) {
                throw new IllegalStateException("config.yml 要求 PacketEvents，但 Velocity 未检测到 packetevents");
            } else logger.info("未检测到 PacketEvents：假人自身的背包、坐标和动作仍由内置协议解析；自动跟随和 move here 将不可用。 ");
            logger.info("PnPlayerBot v1.6.0 已启动：内置协议 {} / {}，Velocity API 3.5",
                    config.string("connection.minecraft-version", "1.21.11"), config.integer("connection.protocol-version", 774));
        } catch (Exception e) {
            logger.error("PnPlayerBot 初始化失败", e);
            throw new IllegalStateException("PnPlayerBot initialization failed", e);
        }
    }

    @Subscribe public void onPreLogin(PreLoginEvent event) { if (bots != null) bots.onPreLogin(event); }
    @Subscribe public void onChooseServer(PlayerChooseInitialServerEvent event) { if (bots != null) bots.onChooseServer(event); }
    @Subscribe public void onPostLogin(PostLoginEvent event) { if (bots != null) bots.onPostLogin(event); }
    @Subscribe public void onServerConnected(ServerConnectedEvent event) { if (bots != null) bots.onServerConnected(event); }
    @Subscribe public void onDisconnect(DisconnectEvent event) { if (bots != null) bots.onDisconnect(event); }

    @Subscribe
    public void onShutdown(ProxyShutdownEvent event) {
        if (packetEvents != null) packetEvents.close();
        if (serverApi != null) serverApi.close();
        if (bots != null) bots.close();
        if (store != null) store.close();
        logger.info("PnPlayerBot 已关闭，所有假人连接和玩家数据均已安全处理。 ");
    }
}
