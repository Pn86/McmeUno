package cn.pn86.pnplayerbot.bot;

import cn.pn86.pnplayerbot.config.ConfigService;
import cn.pn86.pnplayerbot.protocol.PacketBuffer;
import cn.pn86.pnplayerbot.protocol.ProtocolConnection;
import cn.pn86.pnplayerbot.simulation.ClientSimulation;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.geysermc.mcprotocollib.protocol.codec.MinecraftPacket;
import org.geysermc.mcprotocollib.protocol.data.game.inventory.ContainerActionType;
import org.geysermc.mcprotocollib.protocol.data.game.inventory.DropItemAction;
import org.geysermc.mcprotocollib.protocol.data.game.inventory.MoveToHotbarAction;
import org.geysermc.mcprotocollib.protocol.data.game.inventory.ShiftClickItemAction;
import org.geysermc.mcprotocollib.protocol.data.game.inventory.ContainerType;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.Hand;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.InteractAction;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.PlayerAction;
import org.geysermc.mcprotocollib.protocol.data.game.entity.object.Direction;
import org.geysermc.mcprotocollib.protocol.data.game.item.ItemStack;
import org.geysermc.mcprotocollib.protocol.data.game.item.component.DataComponentTypes;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundContainerSetContentPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundContainerSetSlotPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundContainerClosePacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundOpenScreenPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundSetPlayerInventoryPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.inventory.ServerboundContainerClickPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.inventory.ServerboundContainerClosePacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundInteractPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundPlayerActionPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundUseItemOnPacket;
import org.cloudburstmc.math.vector.Vector3i;

import java.io.IOException;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class MinecraftClient implements AutoCloseable {
    private enum State { LOGIN, CONFIGURATION, PLAY }
    private final ConfigService config;
    private final String username;
    private final UUID loginUuid;
    private final Listener listener;
    private final ProtocolConnection connection;
    private final ClientSimulation simulation;
    private final AtomicBoolean closed = new AtomicBoolean();
    private final AtomicInteger sequence = new AtomicInteger();
    private final Object clientTickLock = new Object();
    private volatile int desiredInputFlags;
    private int sentInputFlags;
    private boolean movementPacketSentThisTick;
    private final PlainTextComponentSerializer plainText = PlainTextComponentSerializer.plainText();
    private volatile State state = State.LOGIN;
    private volatile double currentX, currentY, currentZ;
    private volatile float currentYaw, currentPitch;
    private boolean positionInitialized;

    public MinecraftClient(ConfigService config, String username, UUID loginUuid, Listener listener) {
        this.config = config;
        this.username = username;
        this.loginUuid = loginUuid;
        this.listener = listener;
        this.connection = new ProtocolConnection(config.integer("connection.max-packet-bytes", 8 * 1024 * 1024));
        this.simulation = new ClientSimulation(config, new ClientSimulation.Host() {
            @Override public boolean movement(double x, double y, double z, float yaw, float pitch, boolean onGround, boolean horizontalCollision) {
                flushInputState();
                boolean sent = sendMovement(x, y, z, yaw, pitch, onGround, horizontalCollision);
                movementPacketSentThisTick |= sent;
                return sent;
            }
            @Override public void trackedPosition(double x, double y, double z, float yaw, float pitch) {
                currentX = x; currentY = y; currentZ = z; currentYaw = yaw; currentPitch = pitch;
                listener.position(x, y, z, yaw, pitch);
            }
            @Override public boolean input(char direction, boolean jump, boolean shift, boolean sprint) {
                return queueInputState(direction, jump, shift, sprint);
            }
            @Override public boolean rotation(float yaw, float pitch) { return sendSimulationLook(yaw, pitch); }
            @Override public boolean swing() { return swingMainHand(); }
            @Override public boolean attack(int entityId) { return attackEntity(entityId); }
            @Override public boolean startDig(int x, int y, int z, int face) { return dig(false, x, y, z, face); }
            @Override public boolean finishDig(int x, int y, int z, int face) { return dig(true, x, y, z, face); }
            @Override public boolean cancelDig(int x, int y, int z, int face) { return MinecraftClient.this.cancelDig(x, y, z, face); }
            @Override public boolean place(cn.pn86.pnplayerbot.simulation.ClientWorld.BlockHit target, float yaw, float pitch) {
                return rightClickPlacement(target, yaw, pitch);
            }
            @Override public int heldItemId() { return listener.heldItemId(); }
        });
    }

    public void connect() throws IOException {
        String host = config.string("connection.host", "127.0.0.1");
        int port = config.integer("connection.port", 25577);
        connection.connect(host, port, config.integer("connection.connect-timeout-millis", 10_000),
                config.integer("connection.socket-read-timeout-millis", 0));
        connection.send(0, out -> out.varInt(config.integer("connection.protocol-version", 772))
                .string(config.string("connection.virtual-host", "localhost"))
                .shortValue(port).varInt(2));
        connection.send(0, out -> out.string(username).uuid(loginUuid));
        Thread.ofVirtual().name("PnPlayerBot-" + username).start(this::readLoop);
    }

    private void readLoop() {
        Throwable failure = null;
        try {
            while (!closed.get()) {
                ProtocolConnection.ReceivedPacket packet = connection.read();
                switch (state) {
                    case LOGIN -> handleLogin(packet);
                    case CONFIGURATION -> handleConfiguration(packet);
                    case PLAY -> handlePlay(packet);
                }
            }
        } catch (Throwable throwable) {
            if (!closed.get()) failure = throwable;
        } finally {
            close();
            listener.disconnected(failure);
        }
    }

    private void handleLogin(ProtocolConnection.ReceivedPacket packet) throws IOException {
        PacketBuffer.Reader in = new PacketBuffer.Reader(packet.payload());
        switch (packet.id()) {
            case 0 -> throw new IOException("登录被拒绝：" + safeString(in));
            case 1 -> throw new IOException("代理要求正版加密；PnPlayerBot 仅支持离线模式 Velocity");
            case 2 -> { // 1.21.11: Login Plugin Request（1.21.8 时此位置是 Login Success）
                int messageId = in.varInt();
                connection.send(2, out -> out.varInt(messageId).bool(false));
            }
            case 3 -> connection.compressionThreshold(in.varInt());
            case 4 -> { } // 1.21.11: Cookie Request，直接忽略
            case 5 -> { // 1.21.11: Login Success（1.21.8 时此包在 ID 2）
                connection.send(3, null); // Login Acknowledged（1.21.11 serverbound ID 3）
                state = State.CONFIGURATION;
                simulation.beginConfiguration();
                listener.configuring();
                sendClientSettings();
            }
            default -> { }
        }
    }

    private void sendClientSettings() throws IOException {
        connection.send(config.integer("protocol-packets.configuration.serverbound-settings", 0), out -> out
                .string(config.string("connection.locale", "zh_cn"))
                .byteValue(config.integer("connection.view-distance", 2))
                .varInt(config.integer("connection.chat-mode", 0))
                .bool(config.bool("connection.chat-colors", true))
                .byteValue(config.integer("connection.skin-parts", 127))
                .varInt(config.integer("connection.main-hand", 1))
                .bool(config.bool("connection.text-filtering", false))
                .bool(config.bool("connection.server-listings", false))
                .varInt(config.integer("connection.particle-status", 2)));
    }

    private void handleConfiguration(ProtocolConnection.ReceivedPacket packet) throws IOException {
        PacketBuffer.Reader in = new PacketBuffer.Reader(packet.payload());
        if (packet.id() == config.integer("protocol-packets.configuration.clientbound-finish", 3)) {
            connection.send(config.integer("protocol-packets.configuration.serverbound-finish", 3), null);
            state = State.PLAY;
            listener.playReady();
        } else if (packet.id() == config.integer("protocol-packets.configuration.clientbound-keepalive", 4)) {
            long id = in.longValue();
            connection.send(config.integer("protocol-packets.configuration.serverbound-keepalive", 4), out -> out.longValue(id));
        } else if (packet.id() == config.integer("protocol-packets.configuration.clientbound-ping", 5)) {
            int id = in.intValue();
            connection.send(config.integer("protocol-packets.configuration.serverbound-pong", 5), out -> out.intValue(id));
        } else if (packet.id() == config.integer("protocol-packets.configuration.clientbound-registry-data", 7)) {
            try { simulation.acceptRegistryData(packet.payload()); }
            catch (Throwable error) { listener.protocolWarning("世界资料解析失败", error); }
        } else if (packet.id() == config.integer("protocol-packets.configuration.clientbound-known-packs", 14)) {
            connection.send(config.integer("protocol-packets.configuration.serverbound-known-packs", 7), out -> out.varInt(0));
        } else if (packet.id() == config.integer("protocol-packets.configuration.clientbound-resource-pack", 9)) {
            UUID id = in.uuid();
            int result = config.string("resource-pack.response", "decline").equalsIgnoreCase("accept") ? 0 : 1;
            connection.send(config.integer("protocol-packets.configuration.serverbound-resource-pack", 6), out -> out.uuid(id).varInt(result));
            if (result == 0) connection.send(config.integer("protocol-packets.configuration.serverbound-resource-pack", 6), out -> out.uuid(id).varInt(3));
        }
    }

    private void handlePlay(ProtocolConnection.ReceivedPacket packet) throws IOException {
        try { simulation.acceptPacket(packet.id(), packet.payload()); }
        catch (Throwable error) { listener.protocolWarning("世界/实体数据包解析失败 id=" + packet.id(), error); }
        PacketBuffer.Reader in = new PacketBuffer.Reader(packet.payload());
        if (packet.id() == config.integer("protocol-packets.play.clientbound-keepalive", 38)) {
            long id = in.longValue();
            sendSimple(config.integer("protocol-packets.play.serverbound-keepalive", 27), out -> out.longValue(id));
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-ping", 54)) {
            int id = in.intValue();
            sendSimple(config.integer("protocol-packets.play.serverbound-pong", 44), out -> out.intValue(id));
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-position", 65)) {
            decodePositionCorrection(packet.payload());
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-health", 97)) {
            float health = in.floatValue();
            listener.health(health);
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-login", 43)) {
            sendSimple(config.integer("protocol-packets.play.serverbound-player-loaded", 43), null);
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-start-configuration", 111)) {
            connection.send(config.integer("protocol-packets.play.serverbound-configuration-acknowledged", 15), null);
            state = State.CONFIGURATION;
            simulation.beginConfiguration();
            listener.configuring();
            sendClientSettings();
        } else if (config.bool("features.inventory.enabled", true)
                && packet.id() == config.integer("protocol-packets.play.clientbound-window-items", 18)) {
            decodeFullInventory(packet.payload());
        } else if (config.bool("features.inventory.enabled", true)
                && packet.id() == config.integer("protocol-packets.play.clientbound-set-slot", 20)) {
            decodeInventorySlot(packet.payload());
        } else if (config.bool("features.inventory.enabled", true)
                && packet.id() == config.integer("protocol-packets.play.clientbound-player-inventory", 101)) {
            decodePlayerInventorySlot(packet.payload());
        } else if (config.bool("features.inventory.chest.enabled", true)
                && packet.id() == config.integer("protocol-packets.play.clientbound-open-screen", 52)) {
            decodeOpenScreen(packet.payload());
        } else if (config.bool("features.inventory.chest.enabled", true)
                && packet.id() == config.integer("protocol-packets.play.clientbound-container-close", 17)) {
            decodeContainerClose(packet.payload());
        } else if (packet.id() == config.integer("protocol-packets.play.clientbound-held-slot", 98)) {
            listener.selectedHotbar(in.varInt());
        }
    }

    private void decodePositionCorrection(byte[] payload) throws IOException {
        synchronized (clientTickLock) { decodePositionCorrectionInTick(payload); }
    }

    private void decodePositionCorrectionInTick(byte[] payload) throws IOException {
        // 使用 1.0/1.1 版已经验证过的轻量读取方式。这里不能依赖完整协议库对象图：
        // 首次位置包紧跟在子服加入之后，任何可选依赖或反序列化异常都会结束读取线程，
        // 表现为玩家已在 Paper 触发 Join、随后立即从 Velocity 断开。
        PacketBuffer.Reader in = new PacketBuffer.Reader(payload);
        int teleportId = in.varInt();
        double x = in.doubleValue();
        double y = in.doubleValue();
        double z = in.doubleValue();
        // 服务端同时发送速度修正；当前控制功能不需要使用，但必须完整消费。
        in.doubleValue();
        in.doubleValue();
        in.doubleValue();
        float yaw = in.floatValue();
        float pitch = in.floatValue();
        // Synchronize Player Position 的 Flags 是 1 字节（Byte），而非 4 字节 int。
        // 之前的写法在读完 yaw/pitch 后 available()==1，永远小于 4，导致相对坐标修正被静默丢弃。
        int relativeFlags = in.available() >= 1 ? in.unsignedByte() : 0;

        if ((relativeFlags & 0x01) != 0) x += currentX;
        if ((relativeFlags & 0x02) != 0) y += currentY;
        if ((relativeFlags & 0x04) != 0) z += currentZ;
        if ((relativeFlags & 0x08) != 0) yaw += currentYaw;
        if ((relativeFlags & 0x10) != 0) pitch += currentPitch;

        // accept-server-corrections: false 时信任本地预测、忽略服务端位置纠正（首次定位仍必须接受）。
        boolean accept = config.bool("anti-cheat-compatibility.accept-server-corrections", true);
        if (accept || !positionInitialized) {
            currentX = x; currentY = y; currentZ = z; currentYaw = yaw; currentPitch = pitch;
            simulation.teleport(x, y, z, yaw, pitch);
            listener.position(x, y, z, yaw, pitch);
            positionInitialized = true;
        }
        connection.send(config.integer("protocol-packets.play.serverbound-teleport-confirm", 0), out -> out.varInt(teleportId));
        double acceptedX = currentX, acceptedY = currentY, acceptedZ = currentZ;
        float acceptedYaw = currentYaw, acceptedPitch = currentPitch;
        flushInputState();
        connection.send(config.integer("protocol-packets.play.serverbound-position-rotation", 30), out -> out
                .doubleValue(acceptedX).doubleValue(acceptedY).doubleValue(acceptedZ)
                .floatValue(acceptedYaw).floatValue(acceptedPitch).byteValue(0));
        sendClientTickEnd();
    }

    private void decodeFullInventory(byte[] payload) {
        ByteBuf buf = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundContainerSetContentPacket packet = new ClientboundContainerSetContentPacket(buf);
            List<InventoryItem> items = new ArrayList<>();
            ItemStack[] stacks = packet.getItems();
            for (int slot = 0; slot < stacks.length; slot++) {
                InventoryItem item = snapshot(slot, stacks[slot]);
                if (item != null) items.add(item);
            }
            if (packet.getContainerId() == 0) listener.inventoryFull(items, packet.getStateId());
            else listener.containerFull(packet.getContainerId(), items, packet.getStateId());
        } catch (Throwable throwable) {
            listener.inventoryDecodeError(throwable);
        } finally { buf.release(); }
    }

    private void decodeInventorySlot(byte[] payload) {
        ByteBuf buf = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundContainerSetSlotPacket packet = new ClientboundContainerSetSlotPacket(buf);
            // -2 也是“直接更新玩家背包槽位”，常用于无动画的服务端物品修改。
            InventoryItem item = snapshot(packet.getSlot(), packet.getItem());
            if (packet.getContainerId() == 0 || packet.getContainerId() == -2) {
                listener.inventorySlot(packet.getSlot(), item, packet.getStateId());
            } else listener.containerSlot(packet.getContainerId(), packet.getSlot(), item, packet.getStateId());
        } catch (Throwable throwable) {
            listener.inventoryDecodeError(throwable);
        } finally { buf.release(); }
    }

    private void decodePlayerInventorySlot(byte[] payload) {
        ByteBuf buf = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundSetPlayerInventoryPacket packet = new ClientboundSetPlayerInventoryPacket(buf);
            int slot = playerInventoryToContainerSlot(packet.getSlot());
            if (slot >= 0) listener.inventorySlot(slot, snapshot(slot, packet.getContents()), -1);
        } catch (Throwable throwable) {
            listener.inventoryDecodeError(throwable);
        } finally { buf.release(); }
    }

    private void decodeOpenScreen(byte[] payload) {
        ByteBuf buf = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundOpenScreenPacket packet = new ClientboundOpenScreenPacket(buf);
            int storageSlots = storageSlots(packet.getType());
            if (storageSlots > 0) listener.containerOpened(packet.getContainerId(), packet.getType().name(), storageSlots);
        } catch (Throwable throwable) {
            listener.inventoryDecodeError(throwable);
        } finally { buf.release(); }
    }

    private void decodeContainerClose(byte[] payload) {
        ByteBuf buf = Unpooled.wrappedBuffer(payload);
        try { listener.containerClosed(new ClientboundContainerClosePacket(buf).getContainerId()); }
        catch (Throwable throwable) { listener.inventoryDecodeError(throwable); }
        finally { buf.release(); }
    }

    private int storageSlots(ContainerType type) {
        int ordinal = type.ordinal();
        if (ordinal >= ContainerType.GENERIC_9X1.ordinal() && ordinal <= ContainerType.GENERIC_9X6.ordinal()) {
            return (ordinal - ContainerType.GENERIC_9X1.ordinal() + 1) * 9;
        }
        return type == ContainerType.SHULKER_BOX ? 27 : 0;
    }

    /** 把 PlayerInventory 索引转换成玩家容器（window 0）槽位。 */
    private int playerInventoryToContainerSlot(int slot) {
        if (slot >= 0 && slot <= 8) return slot + 36;
        if (slot >= 9 && slot <= 35) return slot;
        return switch (slot) {
            case 36 -> 8;
            case 37 -> 7;
            case 38 -> 6;
            case 39 -> 5;
            case 40 -> 45;
            default -> -1;
        };
    }

    private InventoryItem snapshot(int slot, ItemStack stack) {
        if (stack == null || stack.getAmount() <= 0) return null;
        String name = "物品#" + stack.getId();
        try {
            if (stack.getDataComponentsPatch() != null) {
                Component custom = stack.getDataComponentsPatch().get(DataComponentTypes.CUSTOM_NAME);
                if (custom == null) custom = stack.getDataComponentsPatch().get(DataComponentTypes.ITEM_NAME);
                if (custom != null) {
                    String text = plainText.serialize(custom).strip();
                    if (!text.isBlank()) name = text;
                }
            }
        } catch (Throwable ignored) { /* 名称异常不能让有效物品从背包列表消失。 */ }
        return new InventoryItem(slot, stack.getId(), stack.getAmount(), name);
    }

    public boolean sendCommand(String command) {
        if (closed.get() || state != State.PLAY) return false;
        try {
            // 1.19.3+ 的 serverbound chat_command（无符号）必须携带时间戳、盐、空签名表、
            // 已确认消息数（0）和 20 位 Acknowledged BitSet（3 字节全零）。
            // 之前只写 String，严格解析的子服会直接拒绝该包，导致 work 的 cmd 步骤在部分子服无效。
            connection.send(config.integer("protocol-packets.play.serverbound-command", 7), out -> out
                    .string(command)
                    .longValue(System.currentTimeMillis())
                    .longValue(0L)
                    .varInt(0)
                    .varInt(0)
                    .byteValue(0).byteValue(0).byteValue(0));
            return true;
        } catch (IOException e) { close(); return false; }
    }

    public void respawn() {
        if (closed.get() || state != State.PLAY) return;
        try { connection.send(config.integer("protocol-packets.play.serverbound-client-command", 11), out -> out.varInt(0)); }
        catch (IOException e) { close(); }
    }

    public boolean dropInventorySlot(int slot) {
        if (!ready()) return false;
        ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                0, listener.inventoryStateId(), slot, ContainerActionType.DROP_ITEM,
                DropItemAction.DROP_SELECTED_STACK, null, Map.of());
        return sendSerialized(config.integer("protocol-packets.play.serverbound-window-click", 17), packet);
    }

    public boolean handInventorySlot(int slot, int selectedHotbar) {
        if (!ready()) return false;
        int hotbar = Math.max(0, Math.min(8, selectedHotbar));
        try {
            if (slot < 36 || slot > 44) {
                ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                        0, listener.inventoryStateId(), slot, ContainerActionType.MOVE_TO_HOTBAR_SLOT,
                        MoveToHotbarAction.values()[hotbar], null, Map.of());
                if (!sendSerialized(config.integer("protocol-packets.play.serverbound-window-click", 17), packet)) return false;
            } else hotbar = slot - 36;
            int selected = hotbar;
            connection.send(config.integer("protocol-packets.play.serverbound-held-slot", 52), out -> out.shortValue(selected));
            listener.selectedHotbar(selected);
            return true;
        } catch (IOException e) { close(); return false; }
    }

    public boolean openNearbyContainer(double reach) {
        if (!ready()) return false;
        cn.pn86.pnplayerbot.simulation.ClientWorld.ContainerTarget target = simulation.nearbyContainer(reach);
        if (target == null) return false;
        float[] look = simulation.lookAt(target.x() + 0.5, target.y() + 0.5, target.z() + 0.5);
        if (!sendLook(look[0], look[1])) return false;
        ServerboundUseItemOnPacket packet = new ServerboundUseItemOnPacket(
                Vector3i.from(target.x(), target.y(), target.z()), Direction.from(target.face()), Hand.MAIN_HAND,
                0.5f, 0.5f, 0.5f, false, false, sequence.incrementAndGet());
        return sendSerialized(config.integer("protocol-packets.play.serverbound-use-item-on", 63), packet);
    }

    /** 对准星位置执行原版右键流程；船类物品在 use-on 返回 PASS 后还会继续发送 use-item。 */
    public boolean rightClickPlacement(cn.pn86.pnplayerbot.simulation.ClientWorld.BlockHit target,
                                       float yaw, float pitch) {
        if (!ready()) return false;
        boolean sent = false;
        if (target != null) {
            ServerboundUseItemOnPacket packet = new ServerboundUseItemOnPacket(
                    Vector3i.from(target.x(), target.y(), target.z()), Direction.from(target.face()), Hand.MAIN_HAND,
                    (float) target.hitX(), (float) target.hitY(), (float) target.hitZ(),
                    false, false, sequence.incrementAndGet());
            sent = sendSerialized(config.integer("protocol-packets.play.serverbound-use-item-on", 63), packet);
        }
        String held = InventoryItem.registryIdentifier(listener.heldItemId());
        boolean genericUse = target == null || held.endsWith("_boat") || held.endsWith("_chest_boat");
        return genericUse ? useMainHand(yaw, pitch) || sent : sent;
    }

    public String rideNearby(double reach) {
        if (!ready()) return "";
        cn.pn86.pnplayerbot.simulation.EntityTracker.RideTarget target = simulation.nearbyRideable(reach);
        if (target == null) return "";
        float[] look = simulation.lookAt(target.x(), target.y(), target.z());
        if (!sendLook(look[0], look[1])) return "";
        boolean sent = sendSerialized(config.integer("protocol-packets.play.serverbound-interact-entity", 25),
                new ServerboundInteractPacket(target.entityId(), InteractAction.INTERACT, Hand.MAIN_HAND, false));
        return sent ? target.type() : "";
    }

    public boolean dismount() { return ready() && simulation.dismount(); }

    public boolean closeContainer(int containerId) {
        return sendSerialized(config.integer("protocol-packets.play.serverbound-container-close", 18),
                new ServerboundContainerClosePacket(containerId));
    }

    public boolean shiftClickContainer(int containerId, int stateId, int slot) {
        ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                containerId, stateId, slot, ContainerActionType.SHIFT_CLICK_ITEM,
                ShiftClickItemAction.LEFT_CLICK, null, Map.of());
        return sendSerialized(config.integer("protocol-packets.play.serverbound-window-click", 17), packet);
    }

    public boolean swingMainHand() {
        return sendSimple(config.integer("protocol-packets.play.serverbound-swing", 60), out -> out.varInt(0));
    }

    public boolean attackEntity(int entityId) {
        return sendSerialized(config.integer("protocol-packets.play.serverbound-interact-entity", 25),
                new ServerboundInteractPacket(entityId, InteractAction.ATTACK, false));
    }

    public boolean useMainHand(float yaw, float pitch) {
        return sendSimple(config.integer("protocol-packets.play.serverbound-use-item", 64), out -> out
                .varInt(0).varInt(sequence.incrementAndGet()).floatValue(yaw).floatValue(pitch));
    }

    public boolean releaseUse() {
        return sendPlayerAction(PlayerAction.RELEASE_USE_ITEM, 0, 0, 0, 0);
    }

    public boolean dig(boolean finish, int x, int y, int z, int face) {
        return sendPlayerAction(finish ? PlayerAction.FINISH_DIGGING : PlayerAction.START_DIGGING, x, y, z, face);
    }

    public boolean cancelDig(int x, int y, int z, int face) {
        return sendPlayerAction(PlayerAction.CANCEL_DIGGING, x, y, z, face);
    }

    private boolean sendPlayerAction(PlayerAction action, int x, int y, int z, int face) {
        Direction direction = Direction.from(Math.max(0, Math.min(5, face)));
        ServerboundPlayerActionPacket packet = new ServerboundPlayerActionPacket(
                action, Vector3i.from(x, y, z), direction, sequence.incrementAndGet());
        return sendSerialized(config.integer("protocol-packets.play.serverbound-player-action", 40), packet);
    }

    public boolean sendMovement(double x, double y, double z, float yaw, float pitch) {
        return sendMovement(x, y, z, yaw, pitch, true, false);
    }

    private boolean sendMovement(double x, double y, double z, float yaw, float pitch, boolean onGround, boolean horizontalCollision) {
        int flags = (onGround ? 0x01 : 0) | (horizontalCollision ? 0x02 : 0);
        boolean sent = sendSimple(config.integer("protocol-packets.play.serverbound-position-rotation", 30), out -> out
                .doubleValue(x).doubleValue(y).doubleValue(z).floatValue(yaw).floatValue(pitch).byteValue(flags));
        if (sent) {
            currentX = x; currentY = y; currentZ = z; currentYaw = yaw; currentPitch = pitch;
            listener.position(x, y, z, yaw, pitch);
        }
        return sent;
    }

    public boolean sendLook(float yaw, float pitch) {
        synchronized (clientTickLock) {
            flushInputState();
            boolean sent = sendSimple(config.integer("protocol-packets.play.serverbound-rotation", 31), out -> out
                    .floatValue(yaw).floatValue(pitch).byteValue(1));
            if (sent) {
                currentYaw = yaw; currentPitch = pitch; simulation.look(yaw, pitch);
                sendClientTickEnd();
            }
            return sent;
        }
    }

    private boolean sendSimulationLook(float yaw, float pitch) {
        boolean sent = sendSimple(config.integer("protocol-packets.play.serverbound-rotation", 31), out -> out
                .floatValue(yaw).floatValue(pitch).byteValue(1));
        if (sent) {
            currentYaw = yaw; currentPitch = pitch;
            listener.position(currentX, currentY, currentZ, yaw, pitch);
        }
        return sent;
    }

    private boolean queueInputState(char direction, boolean jump, boolean shift, boolean sprint) {
        int flags = 0;
        flags |= switch (Character.toUpperCase(direction)) {
            case 'W' -> 0x01; case 'S' -> 0x02; case 'A' -> 0x04; case 'D' -> 0x08; default -> 0;
        };
        if (jump) flags |= 0x10;
        if (shift) flags |= 0x20;
        if (sprint) flags |= 0x40;
        desiredInputFlags = flags;
        return ready();
    }

    private boolean flushInputState() {
        int value = desiredInputFlags;
        if (value == sentInputFlags) return true;
        boolean sent = sendSimple(config.integer("protocol-packets.play.serverbound-player-input", 42), out -> out.byteValue(value));
        if (sent) sentInputFlags = value;
        return sent;
    }

    public void simulationTick() {
        synchronized (clientTickLock) {
            if (!ready()) return;
            movementPacketSentThisTick = false;
            try {
                simulation.tick();
                // 没有 flying 包时可在 tick 末提交输入；有 flying 包时，移动回调已经在其前提交。
                // 移动结束后产生的新输入状态留到下一 tick，避免 PacketEvents 判定包序错误。
                if (!movementPacketSentThisTick) flushInputState();
            }
            finally { sendClientTickEnd(); }
        }
    }
    public boolean simulateMove(char direction, int ticks) { return ready() && simulation.move(direction, ticks); }
    public boolean simulateJump() { return ready() && simulation.jump(); }
    public boolean simulateAction(String kind, boolean continuous, int count) { return ready() && simulation.action(kind, continuous, count); }
    public ClientSimulation.NavigationResult navigateTo(double x, double y, double z, double maximumDistance, int maximumNodes) {
        return ready() ? simulation.navigateTo(x, y, z, maximumDistance, maximumNodes)
                : ClientSimulation.NavigationResult.NOT_READY;
    }
    public void cancelNavigation() { simulation.cancelNavigation(); }
    public boolean autoLook(String mode, String filter) { return ready() && simulation.autoLook(mode, filter); }
    public boolean mounted() { return ready() && simulation.mounted(); }
    public String dimension() { return simulation.dimension(); }
    public void stopSimulation() { simulation.stopAll(); }
    public void stopMovement() { simulation.stopMovement(); }

    private boolean sendClientTickEnd() {
        return sendSimple(config.integer("protocol-packets.play.serverbound-client-tick-end", 12), null);
    }

    private boolean sendSerialized(int packetId, MinecraftPacket packet) {
        synchronized (clientTickLock) {
            if (!ready()) return false;
            ByteBuf buffer = Unpooled.buffer();
            try {
                packet.serialize(buffer);
                byte[] payload = ByteBufUtil.getBytes(buffer);
                connection.send(packetId, out -> out.bytes(payload));
                return true;
            } catch (Throwable throwable) {
                close();
                return false;
            } finally { buffer.release(); }
        }
    }

    private boolean sendSimple(int packetId, ProtocolConnection.PacketWriter writer) {
        synchronized (clientTickLock) {
            if (!ready()) return false;
            try { connection.send(packetId, writer); return true; }
            catch (IOException e) { close(); return false; }
        }
    }

    private boolean ready() { return !closed.get() && state == State.PLAY; }

    private String safeString(PacketBuffer.Reader reader) {
        try { return reader.string(32767); } catch (Exception ignored) { return "未知原因"; }
    }

    @Override public void close() {
        if (closed.compareAndSet(false, true)) connection.close();
    }

    public interface Listener {
        void configuring();
        void playReady();
        void position(double x, double y, double z, float yaw, float pitch);
        void health(float health);
        void inventoryFull(List<InventoryItem> items, int stateId);
        void inventorySlot(int slot, InventoryItem item, int stateId);
        void containerOpened(int containerId, String type, int storageSlots);
        void containerFull(int containerId, List<InventoryItem> items, int stateId);
        void containerSlot(int containerId, int slot, InventoryItem item, int stateId);
        void containerClosed(int containerId);
        void selectedHotbar(int slot);
        int inventoryStateId();
        int heldItemId();
        void inventoryDecodeError(Throwable cause);
        void protocolWarning(String message, Throwable cause);
        void disconnected(Throwable cause);
    }
}
