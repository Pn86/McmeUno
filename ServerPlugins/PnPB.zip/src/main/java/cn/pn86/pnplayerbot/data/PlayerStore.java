package cn.pn86.pnplayerbot.data;

import cn.pn86.pnplayerbot.config.ConfigService;
import org.slf4j.Logger;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PlayerStore implements AutoCloseable {
    private final ConfigService config;
    private final Logger logger;
    private final Path file;
    private final Map<String, PlayerData> players = new ConcurrentHashMap<>();
    private final Object playerMutationLock = new Object();
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "PnPlayerBot-Storage"); t.setDaemon(true); return t;
    });
    private final AtomicBoolean dirty = new AtomicBoolean();
    private final AtomicBoolean debounceQueued = new AtomicBoolean();
    private final Yaml yaml;
    private volatile String lastDailyResetDate = "";

    public PlayerStore(ConfigService config, Logger logger) {
        this.config = config;
        this.logger = logger;
        this.file = config.dataDirectory().resolve("player.yml");
        LoaderOptions loader = new LoaderOptions();
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        options.setIndent(2);
        this.yaml = new Yaml(new SafeConstructor(loader), new Representer(options), options, loader);
    }

    public void load() throws IOException {
        Path source = file;
        try {
            read(source);
        } catch (Exception primary) {
            Path backup = file.resolveSibling("player.yml.bak");
            if (!Files.exists(backup)) throw new IOException("player.yml 读取失败且无备份", primary);
            logger.error("player.yml 读取失败，正在载入备份：{}", primary.getMessage());
            read(backup);
            markDirty(true);
        }
    }

    @SuppressWarnings("unchecked")
    private void read(Path source) throws IOException {
        try (Reader reader = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
            Object rootValue = yaml.load(reader);
            if (!(rootValue instanceof Map<?, ?> root)) return;
            Object metaValue = root.get("meta");
            if (metaValue instanceof Map<?, ?> meta) {
                Object resetDate = meta.get("last-daily-reset-date");
                lastDailyResetDate = resetDate == null ? "" : String.valueOf(resetDate);
            }
            Object playersValue = root.get("players");
            if (!(playersValue instanceof Map<?, ?> playerMap)) return;
            for (Map.Entry<?, ?> entry : playerMap.entrySet()) {
                if (!(entry.getValue() instanceof Map<?, ?> values)) continue;
                String key = normalize(String.valueOf(entry.getKey()));
                String name = string(values, "name", String.valueOf(entry.getKey()));
                boolean hasSplitBalance = values.containsKey("daily-millis") || values.containsKey("permanent-millis");
                long daily = hasSplitBalance ? number(values, "daily-millis", initialDailyMillis()) : 0;
                // 旧版无法判断余额来源，因此全部迁移到不会被每日重置的永久额度，避免玩家损失。
                long permanent = hasSplitBalance
                        ? number(values, "permanent-millis", 0)
                        : number(values, "remaining-millis", 0);
                PlayerData data = new PlayerData(name, daily, permanent);
                data.usedMillis(number(values, "used-millis", 0));
                data.autoWorks(string(values, "autoworks", ""));
                data.desiredActive(bool(values, "desired-active", false));
                data.lastServer(string(values, "last-server", ""));
                data.workEnabled(bool(values, "work-enabled", false));
                data.workWaitMillis(number(values, "work-wait-millis", 1000));
                Object stepsValue = values.get("work-steps");
                if (stepsValue instanceof Map<?, ?> steps) {
                    for (Map.Entry<?, ?> workEntry : steps.entrySet()) {
                        int index;
                        try { index = Integer.parseInt(String.valueOf(workEntry.getKey())); }
                        catch (NumberFormatException ignored) { continue; }
                        if (!(workEntry.getValue() instanceof Map<?, ?> stepMap)) continue;
                        WorkStep.Type type = WorkStep.Type.parse(string(stepMap, "type", ""));
                        String content = string(stepMap, "content", "");
                        if (type != null && !content.isBlank()) data.setWorkStep(index, new WorkStep(type, content));
                    }
                }
                players.put(key, data);
            }
        }
    }

    public PlayerData getOrCreate(String name) {
        String key = normalize(name);
        synchronized (playerMutationLock) {
            PlayerData data = players.computeIfAbsent(key, ignored -> new PlayerData(name, initialDailyMillis(), 0));
            data.name(name);
            return data;
        }
    }

    public PlayerData find(String name) {
        return players.get(normalize(name));
    }

    public Map<String, PlayerData> all() { return Map.copyOf(players); }
    public String lastDailyResetDate() { return lastDailyResetDate; }
    public void lastDailyResetDate(String value) { lastDailyResetDate = value; markDirty(true); }

    /**
     * 重置所有已有玩家数据。保留玩家条目和名称，使管理查询与 Paper API 在重置过程中始终有稳定对象。
     * 写盘仍走单线程异步队列，并使用原子替换，避免在 Velocity 指令线程直接执行 YAML I/O。
     */
    public ResetResult resetAllPlayerData() {
        long dailyMillis = initialDailyMillis();
        int count;
        synchronized (playerMutationLock) {
            count = players.size();
            for (PlayerData data : players.values()) data.resetAll(dailyMillis);
        }
        markDirty(true);
        logger.warn("管理员已重置全部玩家数据：{} 名玩家，每日初始余额 {} 分钟", count, dailyMillis / 60_000L);
        return new ResetResult(count, dailyMillis);
    }

    public void markDirty(boolean critical) {
        dirty.set(true);
        if (critical) {
            writer.execute(this::saveIfDirty);
            return;
        }
        if (debounceQueued.compareAndSet(false, true)) {
            long delay = Math.max(100, config.longValue("storage.debounce-millis", 1500));
            writer.execute(() -> {
                try { Thread.sleep(delay); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                debounceQueued.set(false);
                saveIfDirty();
            });
        }
    }

    public ScheduledFuture<?> scheduleAutosave(ScheduledExecutorService scheduler) {
        long seconds = Math.max(5, config.longValue("storage.autosave-seconds", 60));
        return scheduler.scheduleAtFixedRate(() -> writer.execute(this::saveIfDirty), seconds, seconds, TimeUnit.SECONDS);
    }

    private void saveIfDirty() {
        if (!dirty.compareAndSet(true, false)) return;
        try { saveSnapshot(); }
        catch (Exception e) {
            dirty.set(true);
            logger.error("保存 player.yml 失败", e);
        }
    }

    private void saveSnapshot() throws IOException {
        Map<String, Object> root = new LinkedHashMap<>();
        Map<String, Object> meta = new LinkedHashMap<>();
        meta.put("schema", 2);
        meta.put("last-daily-reset-date", lastDailyResetDate);
        root.put("meta", meta);
        Map<String, Object> serializedPlayers = new LinkedHashMap<>();
        players.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry -> {
            PlayerData data = entry.getValue();
            Map<String, Object> values = new LinkedHashMap<>();
            synchronized (data) {
                values.put("name", data.name());
                values.put("daily-millis", data.dailyMillis());
                values.put("permanent-millis", data.permanentMillis());
                values.put("used-millis", data.usedMillis());
                values.put("autoworks", data.autoWorks());
                values.put("desired-active", data.desiredActive());
                values.put("last-server", data.lastServer());
                values.put("work-enabled", data.workEnabled());
                values.put("work-wait-millis", data.workWaitMillis());
                Map<String, Object> steps = new LinkedHashMap<>();
                for (int i = 1; i <= PlayerData.MAX_WORK_STEPS; i++) {
                    WorkStep step = data.workStep(i);
                    if (step == null) continue;
                    Map<String, Object> serializedStep = new LinkedHashMap<>();
                    serializedStep.put("type", step.type().name().toLowerCase(Locale.ROOT));
                    serializedStep.put("content", step.content());
                    steps.put(String.valueOf(i), serializedStep);
                }
                values.put("work-steps", steps);
            }
            serializedPlayers.put(entry.getKey(), values);
        });
        root.put("players", serializedPlayers);

        Path temporary = file.resolveSibling("player.yml.tmp");
        try (Writer output = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            output.write("# 此文件由 PnPlayerBot 自动维护，请勿在插件运行时手工编辑。\n");
            yaml.dump(root, output);
        }
        if (config.bool("storage.force-to-disk", true)) {
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) { channel.force(true); }
        }
        if (config.bool("storage.keep-backup", true) && Files.exists(file)) {
            Files.copy(file, file.resolveSibling("player.yml.bak"), StandardCopyOption.REPLACE_EXISTING);
        }
        try {
            Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
        }
        config.logDebug("player.yml 已异步保存（{} 名玩家）", players.size());
    }

    public void flush() {
        dirty.set(true);
        try { writer.submit(this::saveIfDirty).get(10, TimeUnit.SECONDS); }
        catch (Exception e) { logger.error("关闭前保存玩家数据失败", e); }
    }

    private long initialDailyMillis() {
        if (!config.bool("daily-reset.enabled", true)) return 0;
        return Math.max(0, config.longValue("daily-reset.initial-balance-minutes", 120)) * 60_000L;
    }
    private String normalize(String name) { return name.toLowerCase(Locale.ROOT); }
    private String string(Map<?, ?> map, String key, String fallback) {
        Object value = map.get(key); return value == null ? fallback : String.valueOf(value);
    }
    private long number(Map<?, ?> map, String key, long fallback) {
        Object value = map.get(key);
        if (value instanceof Number number) return number.longValue();
        try { return Long.parseLong(String.valueOf(value)); } catch (Exception ignored) { return fallback; }
    }
    private boolean bool(Map<?, ?> map, String key, boolean fallback) {
        Object value = map.get(key); return value == null ? fallback : Boolean.parseBoolean(String.valueOf(value));
    }

    public record ResetResult(int players, long dailyMillis) { }

    @Override public void close() {
        flush();
        writer.shutdown();
    }
}
