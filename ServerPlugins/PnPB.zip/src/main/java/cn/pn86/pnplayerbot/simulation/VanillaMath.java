package cn.pn86.pnplayerbot.simulation;

/** Minecraft Mth 使用的 65536 项 float 正弦表；移动预测不能用 Math.sin 的 double 结果替代。 */
final class VanillaMath {
    private static final float[] SIN = new float[65536];
    private static final float RAD_TO_INDEX = 10430.378F;

    static {
        for (int index = 0; index < SIN.length; index++) {
            SIN[index] = (float) Math.sin(index * Math.PI * 2.0 / SIN.length);
        }
    }

    static float sin(float radians) { return SIN[(int) (radians * RAD_TO_INDEX) & 65535]; }
    static float cos(float radians) { return SIN[(int) (radians * RAD_TO_INDEX + 16384.0F) & 65535]; }

    private VanillaMath() { }
}
