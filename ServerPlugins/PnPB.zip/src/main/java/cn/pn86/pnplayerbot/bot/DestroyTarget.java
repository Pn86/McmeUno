package cn.pn86.pnplayerbot.bot;

/** 由子服实际世界光线检测得到的合法挖掘目标。 */
public record DestroyTarget(int x, int y, int z, int face, int breakTicks) { }
