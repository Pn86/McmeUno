package cn.pn86.pnplayerbot.bot;

public enum BotStatus {
    CONNECTING("连接中"), CONFIGURING("配置中"), ONLINE("在线"), RECONNECTING("等待重连"), STOPPING("正在退出"), OFFLINE("离线");
    private final String display;
    BotStatus(String display) { this.display = display; }
    public String display() { return display; }
}
