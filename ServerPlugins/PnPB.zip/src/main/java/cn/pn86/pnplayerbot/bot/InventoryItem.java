package cn.pn86.pnplayerbot.bot;

public record InventoryItem(int containerSlot, int itemId, int amount, String displayName, String registryName) {
    private static final java.util.concurrent.ConcurrentHashMap<Integer, String> REGISTRY_NAMES =
            new java.util.concurrent.ConcurrentHashMap<>();

    public InventoryItem {
        registryName = registryName == null ? "" : registryName;
        if (registryName.isBlank()) registryName = REGISTRY_NAMES.getOrDefault(itemId, "");
        else REGISTRY_NAMES.put(itemId, registryName);
        if (displayName == null || displayName.isBlank() || displayName.equals("物品#" + itemId)) {
            displayName = registryName.isBlank() ? String.valueOf(itemId) : registryName;
        }
    }

    public static void registerRegistryName(int numericId, String name) {
        if (numericId >= 0 && name != null && !name.isBlank()) REGISTRY_NAMES.put(numericId, name);
    }

    public static String registryIdentifier(int numericId) {
        return REGISTRY_NAMES.getOrDefault(numericId, "");
    }

    /** inv look 使用稳定物品 ID；有注册名时显示 minecraft:stone，否则退回数字 ID。 */
    public String identifier() {
        String known = registryName.isBlank() ? REGISTRY_NAMES.getOrDefault(itemId, "") : registryName;
        return known.isBlank() ? String.valueOf(itemId) : known;
    }

    public InventoryItem(int containerSlot, int itemId, int amount, String displayName) {
        this(containerSlot, itemId, amount, displayName, "");
    }

    public boolean matches(String filter) {
        if (filter == null || filter.isBlank()) return true;
        String value = normalize(filter);
        try { return itemId == Integer.parseInt(value); }
        catch (NumberFormatException ignored) {
            String registry = normalize(registryName);
            String display = normalize(displayName);
            return !registry.isBlank() && (registry.equals(value) || stripNamespace(registry).equals(stripNamespace(value)))
                    || !display.isBlank() && display.equals(value);
        }
    }

    private String normalize(String value) {
        return value == null ? "" : value.strip().toLowerCase(java.util.Locale.ROOT).replace(' ', '_');
    }

    private String stripNamespace(String value) {
        int separator = value.indexOf(':');
        return separator >= 0 ? value.substring(separator + 1) : value;
    }

    public String slotLabel() {
        return switch (containerSlot) {
            case 0 -> "合成输出";
            case 1, 2, 3, 4 -> "合成栏";
            case 5 -> "头盔";
            case 6 -> "胸甲";
            case 7 -> "护腿";
            case 8 -> "靴子";
            case 45 -> "副手";
            default -> containerSlot >= 36 && containerSlot <= 44 ? "快捷栏" + (containerSlot - 35) : "背包";
        };
    }
}
