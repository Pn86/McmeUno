package cn.pn86.pnplayerbot.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PlayerData {
    public static final int MAX_WORK_STEPS = 10;

    private String name;
    private long dailyMillis;
    private long permanentMillis;
    private long usedMillis;
    private String autoWorks = "";
    private boolean desiredActive;
    private String lastServer = "";
    private final List<WorkStep> workSteps = new ArrayList<>(Collections.nCopies(MAX_WORK_STEPS, null));
    private boolean workEnabled;
    private long workWaitMillis = 1000;

    public PlayerData(String name, long dailyMillis, long permanentMillis) {
        this.name = name;
        this.dailyMillis = Math.max(0, dailyMillis);
        this.permanentMillis = Math.max(0, permanentMillis);
    }

    public synchronized String name() { return name; }
    public synchronized void name(String value) { name = value; }
    public synchronized long dailyMillis() { return dailyMillis; }
    public synchronized long permanentMillis() { return permanentMillis; }
    public synchronized long remainingMillis() { return safeAdd(dailyMillis, permanentMillis); }
    public synchronized long usedMillis() { return usedMillis; }
    public synchronized String autoWorks() { return autoWorks; }
    public synchronized boolean desiredActive() { return desiredActive; }
    public synchronized String lastServer() { return lastServer; }
    public synchronized boolean workEnabled() { return workEnabled; }
    public synchronized long workWaitMillis() { return workWaitMillis; }
    public synchronized List<WorkStep> workSteps() {
        List<WorkStep> steps = new ArrayList<>(workSteps.size());
        for (WorkStep step : workSteps) if (step != null) steps.add(step);
        return List.copyOf(steps);
    }

    public synchronized void setDailyMillis(long value) { dailyMillis = Math.max(0, value); }
    public synchronized void setPermanentMillis(long value) { permanentMillis = Math.max(0, value); }
    public synchronized void addPermanentMillis(long value) {
        permanentMillis = Math.max(0, safeAdd(permanentMillis, value));
    }

    /** 优先扣每日额度，每日额度耗尽后才扣永久额度。 */
    public synchronized long charge(long requestedMillis) {
        long request = Math.max(0, requestedMillis);
        long dailyCharge = Math.min(request, dailyMillis);
        dailyMillis -= dailyCharge;
        long remainder = request - dailyCharge;
        long permanentCharge = Math.min(remainder, permanentMillis);
        permanentMillis -= permanentCharge;
        long charged = dailyCharge + permanentCharge;
        usedMillis = safeAdd(usedMillis, charged);
        return charged;
    }

    public synchronized void usedMillis(long value) { usedMillis = Math.max(0, value); }
    public synchronized void autoWorks(String value) { autoWorks = value == null ? "" : value; }
    public synchronized void desiredActive(boolean value) { desiredActive = value; }
    public synchronized void lastServer(String value) { lastServer = value == null ? "" : value; }
    public synchronized void workEnabled(boolean value) { workEnabled = value; }
    public synchronized void workWaitMillis(long value) { workWaitMillis = Math.max(1, value); }

    /** 将该玩家恢复为全新数据，同时保留规范显示名称。 */
    public synchronized void resetAll(long initialDailyMillis) {
        dailyMillis = Math.max(0, initialDailyMillis);
        permanentMillis = 0;
        usedMillis = 0;
        autoWorks = "";
        desiredActive = false;
        lastServer = "";
        Collections.fill(workSteps, null);
        workEnabled = false;
        workWaitMillis = 1000;
    }

    public synchronized boolean setWorkStep(int oneBasedIndex, WorkStep step) {
        if (oneBasedIndex < 1 || oneBasedIndex > MAX_WORK_STEPS) return false;
        workSteps.set(oneBasedIndex - 1, step);
        return true;
    }

    public synchronized WorkStep workStep(int oneBasedIndex) {
        return oneBasedIndex < 1 || oneBasedIndex > MAX_WORK_STEPS ? null : workSteps.get(oneBasedIndex - 1);
    }

    public synchronized void clearWorkSteps() {
        Collections.fill(workSteps, null);
    }

    private long safeAdd(long a, long b) {
        try { return Math.addExact(a, b); }
        catch (ArithmeticException ignored) { return b >= 0 ? Long.MAX_VALUE : 0; }
    }
}
