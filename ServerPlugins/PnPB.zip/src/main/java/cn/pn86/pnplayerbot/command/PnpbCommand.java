package cn.pn86.pnplayerbot.command;

import cn.pn86.pnplayerbot.bot.BotManager;
import cn.pn86.pnplayerbot.bot.BotSession;
import cn.pn86.pnplayerbot.config.ConfigService;
import cn.pn86.pnplayerbot.config.MessageService;
import cn.pn86.pnplayerbot.data.PlayerData;
import cn.pn86.pnplayerbot.data.PlayerStore;
import cn.pn86.pnplayerbot.data.WorkStep;
import cn.pn86.pnplayerbot.bot.InventoryItem;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class PnpbCommand implements SimpleCommand {
    private static final String USE = "pnplayerbot.use";
    private static final String ADMIN = "pnplayerbot.admin";
    private final ProxyServer proxy;
    private final ConfigService config;
    private final MessageService messages;
    private final PlayerStore store;
    private final BotManager bots;

    public PnpbCommand(ProxyServer proxy, ConfigService config, MessageService messages, PlayerStore store, BotManager bots) {
        this.proxy = proxy;
        this.config = config;
        this.messages = messages;
        this.store = store;
        this.bots = bots;
    }

    @Override public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        String[] args = invocation.arguments();
        if (args.length == 0) { messages.send(source, "help"); return; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        try {
            switch (sub) {
                case "start" -> start(source);
                case "exit" -> exit(source);
                case "time" -> time(source);
                case "bot" -> bot(source, args);
                case "reload" -> reload(source);
                case "add", "set", "reset", "look" -> adminBalance(source, sub, args);
                case "stop" -> adminStop(source, args);
                case "cleardata" -> clearData(source, args);
                default -> messages.send(source, "help");
            }
        } catch (Exception e) {
            messages.send(source, "internal-error");
            throw e;
        }
    }

    private void start(CommandSource source) {
        Player player = requirePlayer(source, USE);
        if (player == null) return;
        BotManager.StartResult result = bots.start(player);
        switch (result) {
            case STARTED -> { }
            case ALREADY_RUNNING -> messages.send(source, "already-running");
            case NOT_ON_SERVER -> messages.send(source, "not-on-server");
            case SERVER_NOT_ALLOWED -> messages.send(source, "server-not-allowed", "server",
                    player.getCurrentServer().map(s -> s.getServerInfo().getName()).orElse("?"));
            case NO_BALANCE -> messages.send(source, "no-balance");
            case GLOBAL_LIMIT -> messages.send(source, "global-limit");
            case SERVER_LIMIT -> messages.send(source, "server-limit");
        }
    }

    private void exit(CommandSource source) {
        Player player = requirePlayer(source, USE);
        if (player == null) return;
        if (bots.exit(player.getUsername())) messages.send(source, "exited");
        else messages.send(source, "not-running");
    }

    private void time(CommandSource source) {
        Player player = requirePlayer(source, USE);
        if (player == null) return;
        PlayerData data = store.getOrCreate(player.getUsername());
        BotSession session = bots.session(player.getUsername());
        messages.send(source, "time", "remaining", BotManager.formatDuration(data.remainingMillis()),
                "daily", BotManager.formatDuration(data.dailyMillis()), "permanent", BotManager.formatDuration(data.permanentMillis()),
                "used", BotManager.formatDuration(data.usedMillis()),
                "status", session == null ? "未运行" : session.status.display());
    }

    private void bot(CommandSource source, String[] args) {
        Player player = requirePlayer(source, USE);
        if (player == null) return;
        if (args.length < 2) { usage(source, "bot"); return; }
        BotSession session = bots.session(player.getUsername());
        String action = args[1].toLowerCase(Locale.ROOT);
        if (action.equals("info")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            messages.send(source, "info", "bot", session.botName, "status", session.status.display(),
                    "server", session.connectedServer.isBlank() ? session.targetServer : session.connectedServer,
                    "dimension", session.client == null ? "未知" : session.client.dimension(),
                    "x", format(session.x), "y", format(session.y), "z", format(session.z),
                    "yaw", format(session.yaw), "pitch", format(session.pitch), "health", format(session.health),
                    "mode", session.followOwner ? "自动跟随" : session.navigatingHere ? "寻路到这里" : "普通",
                    "attempts", session.reconnectAttempts);
            return;
        }
        if (action.equals("cmd")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (args.length < 3) { usage(source, "cmd"); return; }
            String raw = join(args, 2);
            BotManager.CommandValidation validation = bots.validateCommand(raw);
            if (validation != BotManager.CommandValidation.ALLOWED) { messages.send(source, "command-blocked"); return; }
            String command = bots.normalizeCommand(raw);
            if (bots.sendCommand(session, command)) messages.send(source, "command-sent", "command", command);
            else messages.send(source, "command-failed");
            return;
        }
        if (action.equals("message")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (args.length < 3) { usage(source, "message"); return; }
            if (!bots.sendMessage(session, join(args, 2))) { messages.send(source, "operation-failed"); usage(source, "message"); }
            else messages.send(source, "message-sent", "message", join(args, 2));
            return;
        }
        if (action.equals("stopaction")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (bots.stopAllBehaviors(session)) messages.send(source, "stopaction-ok");
            else messages.send(source, "operation-failed");
            return;
        }
        if (action.equals("inv")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (!config.bool("features.inventory.enabled", true)) { messages.send(source, "operation-disabled"); return; }
            if (args.length < 3) { usage(source, "inv"); return; }
            String invAction = args[2].toLowerCase(Locale.ROOT);
            if (invAction.equals("look")) {
                int page = args.length >= 4 ? parsePositiveInt(args[3], -1) : 1;
                List<InventoryItem> items = session.inventory.indexedItems();
                int pages = Math.max(1, (items.size() + 14) / 15);
                if (page < 1 || page > pages) { messages.send(source, "invalid-page", "pages", pages); return; }
                messages.send(source, "inventory-header", "page", page, "pages", pages, "count", items.size());
                int from = (page - 1) * 15, to = Math.min(items.size(), from + 15);
                for (int i = from; i < to; i++) {
                    InventoryItem item = items.get(i);
                    String itemId = item.identifier();
                    messages.send(source, "inventory-line", "index", i + 1, "name", itemId,
                            "amount", item.amount(), "slot", item.slotLabel(), "id", item.itemId(),
                            "registry", itemId);
                }
                if (items.isEmpty()) messages.send(source, "inventory-empty");
            } else if (invAction.equals("drop")) {
                if (args.length < 4) { usage(source, "inv-drop"); return; }
                boolean all = args[3].equalsIgnoreCase("all");
                Integer index = all ? null : parsePositiveInt(args[3], -1);
                if (bots.drop(session, index, all)) messages.send(source, "operation-ok"); else { messages.send(source, "operation-failed"); usage(source, "inv-drop"); }
            } else if (invAction.equals("hand")) {
                if (args.length < 4) { usage(source, "inv-hand"); return; }
                if (bots.hand(session, parsePositiveInt(args[3], -1))) messages.send(source, "operation-ok"); else { messages.send(source, "operation-failed"); usage(source, "inv-hand"); }
            } else if (invAction.equals("chest")) {
                if (args.length < 4) { usage(source, "inv-chest"); return; }
                String operation = args[3].toLowerCase(Locale.ROOT);
                BotManager.ChestResult result;
                if (operation.equals("open")) result = bots.chestOpen(session);
                else if (operation.equals("get") || operation.equals("full")) {
                    result = bots.chestTransfer(session, operation.equals("get"), args.length >= 5 ? args[4] : null);
                } else { usage(source, "inv-chest"); return; }
                sendChestResult(source, result);
            } else usage(source, "inv");
            return;
        }
        if (action.equals("action")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (args.length < 3) { usage(source, "action"); return; }
            String kind = args[2].toLowerCase(Locale.ROOT);
            if (kind.equals("automove")) {
                if (args.length < 4 || !(args[3].equalsIgnoreCase("on") || args[3].equalsIgnoreCase("off"))) {
                    usage(source, "action-automove"); return;
                }
                sendNavigationResult(source, bots.automove(session, args[3].equalsIgnoreCase("on")), "follow");
                return;
            }
            if (!List.of("destroy", "attack", "use", "put").contains(kind)) { usage(source, "action"); return; }
            if (args.length < 4) { usage(source, "action-" + kind); return; }
            if (!bots.action(session, kind, args[3])) { messages.send(source, "operation-failed"); usage(source, "action-" + kind); }
            else messages.send(source, "operation-ok");
            return;
        }
        if (action.equals("move")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (args.length >= 3 && args[2].equalsIgnoreCase("here")) {
                sendNavigationResult(source, bots.moveHere(session), "here");
                return;
            }
            if (args.length >= 3 && args[2].equalsIgnoreCase("boat")) {
                String type = bots.rideNearby(session);
                if (type.isBlank()) messages.send(source, "ride-not-found");
                else messages.send(source, "ride-requested", "type", type);
                return;
            }
            if (args.length >= 3 && args[2].equalsIgnoreCase("leave")) {
                if (bots.leaveVehicle(session)) messages.send(source, "vehicle-left");
                else messages.send(source, "vehicle-not-mounted");
                return;
            }
            if (args.length >= 3 && args[2].equalsIgnoreCase("stop")) {
                if (bots.stopMovement(session)) messages.send(source, "movement-stopped");
                else messages.send(source, "operation-failed");
                return;
            }
            if (args.length < 4) { usage(source, "move"); return; }
            try {
                if (!bots.move(session, args[2].charAt(0), Double.parseDouble(args[3]))) { messages.send(source, "operation-failed"); usage(source, "move"); }
                else messages.send(source, "operation-ok");
            } catch (RuntimeException e) { messages.send(source, "operation-failed"); usage(source, "move"); }
            return;
        }
        if (action.equals("jump")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (!bots.jump(session)) { messages.send(source, "operation-failed"); usage(source, "jump"); }
            else messages.send(source, "operation-ok");
            return;
        }
        if (action.equals("facing")) {
            if (session == null) { messages.send(source, "not-running"); return; }
            if (args.length < 3) { usage(source, "facing"); return; }
            try {
                String axis = args[2].toLowerCase(Locale.ROOT);
                if (axis.equals("auto")) {
                    if (args.length < 4 || !(args[3].equalsIgnoreCase("all") || args[3].equalsIgnoreCase("summer"))) {
                        usage(source, "facing-auto"); return;
                    }
                    if (!bots.autoFace(session, args[3], args.length >= 5 ? args[4] : null)) {
                        messages.send(source, "operation-failed"); usage(source, "facing-auto");
                    } else messages.send(source, "auto-facing-enabled", "mode", args[3],
                            "filter", args.length >= 5 ? args[4] : "无");
                    return;
                }
                if (!List.of("horizontal", "vertical").contains(axis)) { usage(source, "facing"); return; }
                if (args.length < 4) { usage(source, "facing-" + axis); return; }
                float degrees = Float.parseFloat(args[3]);
                if (!bots.face(session, axis, degrees)) { messages.send(source, "operation-failed"); usage(source, "facing-" + axis); }
                else messages.send(source, "operation-ok");
            } catch (RuntimeException e) { messages.send(source, "operation-failed"); usage(source, "facing"); }
            return;
        }
        if (action.equals("work")) {
            PlayerData data = store.getOrCreate(player.getUsername());
            if (!config.bool("features.work.enabled", true)) { messages.send(source, "operation-disabled"); return; }
            if (args.length < 3) { usage(source, "work"); return; }
            switch (args[2].toLowerCase(Locale.ROOT)) {
                case "list" -> {
                    messages.send(source, "work-header", "enabled", data.workEnabled(), "wait", data.workWaitMillis() / 1000.0);
                    boolean empty = true;
                    for (int i = 1; i <= PlayerData.MAX_WORK_STEPS; i++) {
                        WorkStep step = data.workStep(i);
                        if (step != null) { empty = false; messages.send(source, "work-line", "index", i, "type", step.type().name().toLowerCase(Locale.ROOT), "content", step.content()); }
                    }
                    if (empty) messages.send(source, "work-empty");
                }
                case "add" -> {
                    if (args.length < 6) { usage(source, "work-add"); return; }
                    WorkStep.Type type = WorkStep.Type.parse(args[3]);
                    int index = parsePositiveInt(args[4], -1);
                    String content = join(args, 5);
                    if (type == null || index < 1 || index > 10 || content.isBlank()) { messages.send(source, "operation-failed"); usage(source, "work-add"); return; }
                    if (type == WorkStep.Type.CMD && bots.validateCommand(content) != BotManager.CommandValidation.ALLOWED) { messages.send(source, "command-blocked"); return; }
                    data.setWorkStep(index, new WorkStep(type, content)); store.markDirty(true); bots.refreshWork(session); messages.send(source, "operation-ok");
                }
                case "remove" -> {
                    int index = args.length >= 4 ? parsePositiveInt(args[3], -1) : -1;
                    if (index < 1 || index > 10) { messages.send(source, "operation-failed"); usage(source, "work-remove"); }
                    else { data.setWorkStep(index, null); store.markDirty(true); bots.refreshWork(session); messages.send(source, "operation-ok"); }
                }
                case "use" -> {
                    if (args.length < 4 || !(args[3].equalsIgnoreCase("on") || args[3].equalsIgnoreCase("off"))) { messages.send(source, "operation-failed"); usage(source, "work-use"); return; }
                    data.workEnabled(args[3].equalsIgnoreCase("on")); store.markDirty(true); bots.refreshWork(session); messages.send(source, "operation-ok");
                }
                case "wait" -> {
                    try {
                        BigDecimal seconds = new BigDecimal(args[3]);
                        if (seconds.signum() <= 0) throw new NumberFormatException();
                        BigDecimal millis = seconds.multiply(BigDecimal.valueOf(1000));
                        if (millis.compareTo(BigDecimal.valueOf(Long.MAX_VALUE)) > 0) throw new NumberFormatException();
                        // 不再限制 0.5~3 秒和 0.1 秒精度；仅保留“必须为正数且能转换成毫秒”的技术校验。
                        data.workWaitMillis(Math.max(1, millis.setScale(0, RoundingMode.CEILING).longValueExact()));
                        store.markDirty(true); bots.refreshWork(session); messages.send(source, "operation-ok");
                    } catch (RuntimeException e) { messages.send(source, "operation-failed"); usage(source, "work-wait"); }
                }
                case "clear" -> {
                    data.clearWorkSteps();
                    data.workEnabled(false);
                    store.markDirty(true);
                    bots.refreshWork(session);
                    messages.send(source, "work-cleared");
                }
                case "reset" -> {
                    if (session == null) { messages.send(source, "not-running"); return; }
                    bots.resetWork(session);
                    messages.send(source, "work-reset");
                }
                case "run" -> {
                    if (session == null) { messages.send(source, "not-running"); return; }
                    if (bots.runWorkOnce(session)) messages.send(source, "work-run");
                    else messages.send(source, "work-empty");
                }
                default -> usage(source, "work");
            }
            return;
        }
        if (action.equals("autoworks")) {
            if (args.length < 3) { usage(source, "autoworks"); return; }
            PlayerData data = store.getOrCreate(player.getUsername());
            String raw = join(args, 2);
            if (raw.equalsIgnoreCase("off") || raw.equalsIgnoreCase("clear") || raw.equals("关闭")) {
                data.autoWorks(""); store.markDirty(true); messages.send(source, "autoworks-cleared"); return;
            }
            if (bots.validateCommand(raw) != BotManager.CommandValidation.ALLOWED) { messages.send(source, "command-blocked"); return; }
            String command = bots.normalizeCommand(raw);
            data.autoWorks(command); store.markDirty(true);
            messages.send(source, "autoworks-set", "command", command);
            return;
        }
        usage(source, "bot");
    }

    private void reload(CommandSource source) {
        if (!permission(source, ADMIN)) return;
        try { config.reload(); bots.reloadConfiguration(); messages.send(source, "reload-ok"); }
        catch (Exception e) { messages.send(source, "reload-failed", "error", e.getMessage()); }
    }

    private void adminBalance(CommandSource source, String action, String[] args) {
        if (!permission(source, ADMIN)) return;
        int required = action.equals("reset") || action.equals("look") ? 2 : 3;
        if (args.length < required) { messages.send(source, "admin-usage"); return; }
        String playerName = args[1];
        PlayerData data = store.getOrCreate(playerName);
        if (action.equals("look")) {
            messages.send(source, "admin-look", "player", data.name(), "remaining", BotManager.formatDuration(data.remainingMillis()),
                    "daily", BotManager.formatDuration(data.dailyMillis()), "permanent", BotManager.formatDuration(data.permanentMillis()),
                    "used", BotManager.formatDuration(data.usedMillis()),
                    "autoworks", data.autoWorks().isBlank() ? "未设置" : "/" + data.autoWorks());
            return;
        }
        if (action.equals("reset")) {
            long millis = config.bool("billing.admin-reset-to-initial", false)
                    ? config.longValue("billing.admin-initial-permanent-minutes", 0) * 60_000L : 0;
            data.setPermanentMillis(millis); store.markDirty(true);
            messages.send(source, "admin-reset", "player", data.name(), "remaining", BotManager.formatDuration(millis));
            return;
        }
        Long millis = parseMinutes(args[2]);
        if (millis == null) { messages.send(source, "invalid-number"); return; }
        if (action.equals("add")) {
            data.addPermanentMillis(millis); store.markDirty(true);
            messages.send(source, "admin-added", "player", data.name(), "minutes", args[2],
                    "remaining", BotManager.formatDuration(data.remainingMillis()));
        } else {
            data.setPermanentMillis(millis); store.markDirty(true);
            messages.send(source, "admin-set", "player", data.name(), "minutes", args[2]);
        }
    }

    private void adminStop(CommandSource source, String[] args) {
        if (!permission(source, ADMIN)) return;
        if (args.length != 2) { usage(source, "stop"); return; }
        String target = args[1];
        if (target.equalsIgnoreCase("all")) {
            int stopped = bots.forceStopAll();
            messages.send(source, "admin-stop-all", "count", stopped);
            return;
        }
        if (bots.forceStop(target)) messages.send(source, "admin-stop-player", "player", target);
        else messages.send(source, "admin-stop-not-running", "player", target);
    }

    private void clearData(CommandSource source, String[] args) {
        if (!permission(source, ADMIN)) return;
        if (args.length != 1) { usage(source, "cleardata"); return; }
        // 先使全部会话及其重连/脚本代次失效，防止旧 PlayerData 在重置后继续扣费或恢复运行状态。
        int stopped = bots.forceStopAll();
        PlayerStore.ResetResult result = store.resetAllPlayerData();
        messages.send(source, "admin-cleardata", "players", result.players(), "stopped", stopped,
                "daily", BotManager.formatDuration(result.dailyMillis()));
    }

    private Long parseMinutes(String input) {
        try {
            BigDecimal minutes = new BigDecimal(input);
            if (minutes.signum() < 0) return null;
            BigDecimal millis = minutes.multiply(BigDecimal.valueOf(60_000));
            if (millis.compareTo(BigDecimal.valueOf(Long.MAX_VALUE)) > 0) return null;
            return millis.setScale(0, RoundingMode.HALF_UP).longValueExact();
        } catch (Exception ignored) { return null; }
    }

    private int parsePositiveInt(String input, int fallback) {
        try { int value = Integer.parseInt(input); return value > 0 ? value : fallback; }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private void sendNavigationResult(CommandSource source, BotManager.NavigationStartResult result, String mode) {
        switch (result) {
            case STARTED -> messages.send(source, mode.equals("follow") ? "follow-started" : "navigation-started");
            case STOPPED -> messages.send(source, "follow-stopped");
            case NOT_ACTIVE -> messages.send(source, "follow-not-active");
            case NO_OWNER_POSITION -> messages.send(source, "navigation-no-owner-position");
            case DIFFERENT_SERVER -> messages.send(source, "navigation-different-server");
            case DIFFERENT_DIMENSION -> messages.send(source, "navigation-different-dimension");
            case TOO_FAR -> messages.send(source, "navigation-too-far");
            case RATE_LIMITED -> messages.send(source, "operation-too-fast");
            case NOT_READY -> messages.send(source, "operation-disabled");
        }
    }

    private void sendChestResult(CommandSource source, BotManager.ChestResult result) {
        switch (result) {
            case OPEN_REQUESTED -> messages.send(source, "chest-opening");
            case CLOSED -> messages.send(source, "chest-closed");
            case TRANSFER_STARTED -> messages.send(source, "chest-transfer-started");
            case NOT_OPEN -> messages.send(source, "chest-not-open");
            case NO_CONTAINER -> messages.send(source, "chest-not-found");
            case NO_ITEMS -> messages.send(source, "chest-no-items");
            case NO_SPACE -> messages.send(source, "chest-no-space");
            case RATE_LIMITED -> messages.send(source, "operation-too-fast");
            case DISABLED_OR_OFFLINE -> messages.send(source, "operation-disabled");
            case FAILED -> messages.send(source, "operation-failed");
        }
    }

    private void usage(CommandSource source, String command) { messages.send(source, "usage-" + command); }

    private Player requirePlayer(CommandSource source, String permission) {
        if (!permission(source, permission)) return null;
        if (source instanceof Player player) return player;
        messages.send(source, "players-only"); return null;
    }

    private boolean permission(CommandSource source, String permission) {
        if (source.hasPermission(permission)) return true;
        messages.send(source, "no-permission", "permission", permission); return false;
    }

    private String join(String[] args, int from) { return String.join(" ", Arrays.copyOfRange(args, from, args.length)); }
    private String format(double number) { return String.format(Locale.ROOT, "%.2f", number); }

    @Override public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        List<String> choices = new ArrayList<>();
        if (args.length <= 1) {
            choices.addAll(List.of("start", "exit", "time", "bot"));
            if (invocation.source().hasPermission(ADMIN)) choices.addAll(List.of(
                    "reload", "add", "set", "reset", "look", "stop", "cleardata"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("bot")) choices.addAll(List.of("cmd", "message", "autoworks", "info", "inv", "action", "move", "jump", "facing", "work", "stopaction"));
        else if (args.length == 3 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("inv")) choices.addAll(List.of("look", "drop", "hand", "chest"));
        else if (args.length == 4 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("inv") && args[2].equalsIgnoreCase("chest")) choices.addAll(List.of("open", "get", "full"));
        else if (args.length == 3 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("action")) choices.addAll(List.of("destroy", "attack", "use", "put", "automove"));
        else if (args.length == 4 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("action")
                && List.of("destroy", "attack", "use", "put", "automove").contains(args[2].toLowerCase(Locale.ROOT))) {
            choices.addAll(List.of("on", "off"));
        }
        else if (args.length == 3 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("move")) choices.addAll(List.of("W", "A", "S", "D", "here", "boat", "leave", "stop"));
        else if (args.length == 3 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("facing")) choices.addAll(List.of("horizontal", "vertical", "auto"));
        else if (args.length == 4 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("facing") && args[2].equalsIgnoreCase("auto")) choices.addAll(List.of("all", "summer"));
        else if (args.length == 3 && args[0].equalsIgnoreCase("bot") && args[1].equalsIgnoreCase("work")) choices.addAll(List.of("list", "add", "remove", "use", "wait", "run", "reset", "clear"));
        else if (args.length == 2 && List.of("add", "set", "reset", "look").contains(args[0].toLowerCase(Locale.ROOT))) {
            choices.addAll(store.all().values().stream().map(PlayerData::name).toList());
            choices.addAll(proxy.getAllPlayers().stream().map(Player::getUsername).toList());
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stop") && invocation.source().hasPermission(ADMIN)) {
            choices.add("all");
            choices.addAll(bots.sessions().stream().map(session -> session.ownerName).toList());
        }
        String token = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        return choices.stream().distinct().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(token)).sorted().toList();
    }

    @Override public boolean hasPermission(Invocation invocation) { return true; }
}
