package cn.pn86.pnplayerbot.integration;

import cn.pn86.pnplayerbot.bot.BotManager;
import cn.pn86.pnplayerbot.bot.BotSession;
import cn.pn86.pnplayerbot.bot.BotStatus;
import cn.pn86.pnplayerbot.config.ConfigService;
import cn.pn86.pnplayerbot.data.PlayerData;
import cn.pn86.pnplayerbot.data.PlayerStore;
import org.slf4j.Logger;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicBoolean;

/** 供 Paper 子服访问的轻量鉴权接口，不依赖在线载体玩家；跨机器部署时把 bind 配置为 0.0.0.0。 */
public final class ServerApiService implements AutoCloseable {
    public static final int MAGIC = 0x504E5042;
    private final ConfigService config;
    private final PlayerStore store;
    private final BotManager bots;
    private final Logger logger;
    private final AtomicBoolean closed = new AtomicBoolean();
    private volatile ServerSocket server;

    public ServerApiService(ConfigService config, PlayerStore store, BotManager bots, Logger logger) {
        this.config = config; this.store = store; this.bots = bots; this.logger = logger;
    }

    public void start() throws Exception {
        if (!config.bool("server-api.enabled", true)) return;
        String token = config.string("server-api.token", "pnplayerbot-local-change-this-2026");
        if (token.length() < 16) throw new IllegalArgumentException("server-api.token 至少需要 16 个字符");
        ServerSocket socket = new ServerSocket(config.integer("server-api.port", 28786),
                Math.max(1, config.integer("server-api.backlog", 32)),
                InetAddress.getByName(config.string("server-api.bind", "127.0.0.1")));
        server = socket;
        Thread.ofVirtual().name("PnPlayerBot-ServerAPI").start(() -> acceptLoop(socket));
        logger.info("PnPlayerBotServers 接口已监听 {}:{}", socket.getInetAddress().getHostAddress(), socket.getLocalPort());
    }

    /** 配置重载时重启监听，使 bind/port/token 变更即时生效。 */
    public synchronized void restart() throws Exception {
        if (closed.get()) return;
        ServerSocket old = server;
        server = null;
        if (old != null) { try { old.close(); } catch (Exception ignored) { } }
        start();
    }

    private void acceptLoop(ServerSocket listening) {
        while (!closed.get() && listening == server) {
            try {
                Socket client = listening.accept();
                Thread.ofVirtual().name("PnPlayerBot-ServerAPI-Client").start(() -> handle(client));
            } catch (Exception e) {
                if (closed.get() || listening != server) return;
                logger.warn("子服接口接受连接失败：{}", e.getMessage());
            }
        }
    }

    private void handle(Socket socket) {
        try (socket; DataInputStream in = new DataInputStream(socket.getInputStream()); DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {
            socket.setSoTimeout(Math.max(500, config.integer("server-api.read-timeout-millis", 3000)));
            if (in.readInt() != MAGIC || !validToken(in.readUTF())) { write(out, false, "鉴权失败", 0, 0, false); return; }
            String action = in.readUTF().toUpperCase(java.util.Locale.ROOT);
            String player = in.readUTF().strip();
            long millis = Math.max(0, in.readLong());
            if (player.isBlank() || player.length() > 64) { write(out, false, "玩家名无效", 0, 0, false); return; }
            PlayerData data = store.getOrCreate(player);
            switch (action) {
                case "ADD" -> { data.addPermanentMillis(millis); store.markDirty(true); }
                case "REMOVE" -> { data.setPermanentMillis(Math.max(0, data.permanentMillis() - millis)); store.markDirty(true); }
                case "LOOK" -> { }
                default -> { write(out, false, "未知操作", 0, 0, false); return; }
            }
            BotSession session = bots.session(player);
            write(out, true, "OK", data.dailyMillis(), data.permanentMillis(),
                    session != null && session.status == BotStatus.ONLINE);
        } catch (Exception e) { config.logDebug("子服接口请求失败：{}", e.getMessage()); }
    }

    private boolean validToken(String supplied) {
        return MessageDigest.isEqual(config.string("server-api.token", "pnplayerbot-local-change-this-2026").getBytes(StandardCharsets.UTF_8),
                supplied.getBytes(StandardCharsets.UTF_8));
    }

    private void write(DataOutputStream out, boolean ok, String message, long daily, long permanent, boolean online) throws Exception {
        out.writeInt(MAGIC); out.writeBoolean(ok); out.writeUTF(message); out.writeLong(daily); out.writeLong(permanent); out.writeBoolean(online); out.flush();
    }

    @Override public void close() {
        closed.set(true);
        try { if (server != null) server.close(); } catch (Exception ignored) { }
    }
}
