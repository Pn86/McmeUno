package cn.pn86.pnplayerbot.simulation;

import cn.pn86.pnplayerbot.config.ConfigService;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.cloudburstmc.math.vector.Vector3i;
import org.geysermc.mcprotocollib.protocol.codec.MinecraftTypes;
import org.geysermc.mcprotocollib.protocol.data.game.chunk.ChunkSection;
import org.geysermc.mcprotocollib.protocol.data.game.level.block.BlockChangeEntry;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundBlockUpdatePacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundForgetLevelChunkPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundLevelChunkWithLightPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundSectionBlocksUpdatePacket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** 假人本地维护的区块与碰撞世界；不访问任何 Paper/Bukkit API。 */
public final class ClientWorld {
    private final ConfigService config;
    private final BlockRegistry blocks = BlockRegistry.INSTANCE;
    private final Map<Long, Column> chunks = new ConcurrentHashMap<>();
    private volatile int minY = -64;
    private volatile int height = 384;
    private volatile String dimension = "minecraft:overworld";

    public ClientWorld(ConfigService config) { this.config = config; selectDimension(dimension); }

    public synchronized void selectDimension(String name) {
        selectDimension(name, Integer.MIN_VALUE, 0, "");
    }

    /** 使用服务端注册表给出的真实世界高度；effects 只在缺少高度数据时用于选择兼容配置。 */
    public synchronized void selectDimension(String name, int registryMinY, int registryHeight, String effects) {
        dimension = name == null || name.isBlank() ? "minecraft:overworld" : name;
        if (registryMinY != Integer.MIN_VALUE && registryMinY % 16 == 0
                && registryHeight > 0 && registryHeight <= 4096 && registryHeight % 16 == 0) {
            minY = registryMinY;
            height = registryHeight;
        } else {
            String type = effects == null ? "" : effects;
            String preset = type.endsWith("the_nether") || dimension.endsWith("the_nether") ? "nether"
                    : type.endsWith("the_end") || dimension.endsWith("the_end") ? "end" : "overworld";
            minY = config.integer("client-simulation.dimensions." + preset + ".min-y", preset.equals("overworld") ? -64 : 0);
            height = Math.max(16, config.integer("client-simulation.dimensions." + preset + ".height", preset.equals("overworld") ? 384 : 256));
        }
        chunks.clear();
    }

    public synchronized void clear() { chunks.clear(); }
    public String dimension() { return dimension; }
    public int minY() { return minY; }
    public int height() { return height; }

    public synchronized void acceptChunk(byte[] payload) {
        ByteBuf source = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundLevelChunkWithLightPacket packet = new ClientboundLevelChunkWithLightPacket(source);
            ByteBuf data = Unpooled.wrappedBuffer(packet.getChunkData());
            try {
                int sectionCount = Math.max(1, height / 16);
                ChunkSection[] sections = new ChunkSection[sectionCount];
                int minSectionY = minY >> 4;
                for (int sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++) {
                    // 保留协议调色板压缩结构，避免为每个非空区块段展开 4096 个 int。
                    // mcprotocollib 1.21.11 要求传入 sectionY 和 blockStatesBits。
                    sections[sectionIndex] = MinecraftTypes.readChunkSection(data, minSectionY + sectionIndex, 0);
                }
                chunks.put(key(packet.getX(), packet.getZ()), new Column(minY >> 4, sections));
            } finally { data.release(); }
        } finally { source.release(); }
    }

    public synchronized void acceptForget(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundForgetLevelChunkPacket packet = new ClientboundForgetLevelChunkPacket(buffer);
            chunks.remove(key(packet.getX(), packet.getZ()));
        } finally { buffer.release(); }
    }

    public synchronized void acceptBlockUpdate(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try { update(new ClientboundBlockUpdatePacket(buffer).getEntry()); }
        finally { buffer.release(); }
    }

    public synchronized void acceptSectionUpdate(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            for (BlockChangeEntry entry : new ClientboundSectionBlocksUpdatePacket(buffer).getEntries()) update(entry);
        } finally { buffer.release(); }
    }

    private void update(BlockChangeEntry entry) {
        Vector3i position = entry.getPosition();
        setBlock(position.getX(), position.getY(), position.getZ(), entry.getBlock());
    }

    public synchronized void setBlock(int x, int y, int z, int state) {
        Column column = chunks.get(key(Math.floorDiv(x, 16), Math.floorDiv(z, 16)));
        if (column == null) return;
        int sectionIndex = Math.floorDiv(y, 16) - column.minSection;
        if (sectionIndex < 0 || sectionIndex >= column.sections.length) return;
        ChunkSection section = column.sections[sectionIndex];
        if (section == null) {
            if (state == 0) return;
            section = column.sections[sectionIndex] = new ChunkSection(0, 4, 0, 1);
        }
        section.setBlock(x & 15, y & 15, z & 15, state);
    }

    public synchronized int blockState(int x, int y, int z) {
        Column column = chunks.get(key(Math.floorDiv(x, 16), Math.floorDiv(z, 16)));
        if (column == null) return 0;
        int sectionIndex = Math.floorDiv(y, 16) - column.minSection;
        if (sectionIndex < 0 || sectionIndex >= column.sections.length) return 0;
        ChunkSection section = column.sections[sectionIndex];
        return section == null ? 0 : section.getBlock(x & 15, y & 15, z & 15);
    }

    public boolean loadedAt(double x, double z) {
        return chunks.containsKey(key(Math.floorDiv((int) Math.floor(x), 16), Math.floorDiv((int) Math.floor(z), 16)));
    }

    public synchronized MoveResult move(Aabb original, double dx, double dy, double dz, double stepHeight, boolean wasOnGround) {
        return move(original, dx, dy, dz, stepHeight, wasOnGround, false);
    }

    public synchronized MoveResult move(Aabb original, double dx, double dy, double dz, double stepHeight,
                                        boolean wasOnGround, boolean ignoreClimbableCollision) {
        MoveResult normal = collide(original, dx, dy, dz, ignoreClimbableCollision);
        boolean horizontalBlocked = Math.abs(normal.dx - dx) > 1.0E-7 || Math.abs(normal.dz - dz) > 1.0E-7;
        if (!horizontalBlocked || stepHeight <= 0 || !(wasOnGround || dy < 0 && Math.abs(normal.dy - dy) > 1.0E-7)) return normal;

        MoveResult up = collide(original, dx, stepHeight, dz, ignoreClimbableCollision);
        if (up.dy < stepHeight - 1.0E-7) return normal;
        MoveResult down = collide(up.box, 0, -stepHeight, 0, ignoreClimbableCollision);
        MoveResult stepped = new MoveResult(down.box, up.dx, up.dy + down.dy, up.dz,
                down.dy > -stepHeight + 1.0E-7, Math.abs(up.dx - dx) > 1.0E-7 || Math.abs(up.dz - dz) > 1.0E-7);
        double normalHorizontal = normal.dx * normal.dx + normal.dz * normal.dz;
        double stepHorizontal = stepped.dx * stepped.dx + stepped.dz * stepped.dz;
        return stepHorizontal > normalHorizontal + 1.0E-9 ? stepped : normal;
    }

    private MoveResult collide(Aabb original, double dx, double dy, double dz) {
        return collide(original, dx, dy, dz, false);
    }

    private MoveResult collide(Aabb original, double dx, double dy, double dz, boolean ignoreClimbableCollision) {
        List<Aabb> obstacles = collisionBoxes(original.expandTowards(dx, dy, dz).inflate(1.0E-7), ignoreClimbableCollision);
        Aabb box = original;
        double actualY = dy;
        for (Aabb obstacle : obstacles) actualY = obstacle.clipY(box, actualY);
        box = box.move(0, actualY, 0);
        double actualX = dx;
        for (Aabb obstacle : obstacles) actualX = obstacle.clipX(box, actualX);
        box = box.move(actualX, 0, 0);
        double actualZ = dz;
        for (Aabb obstacle : obstacles) actualZ = obstacle.clipZ(box, actualZ);
        box = box.move(0, 0, actualZ);
        boolean onGround = dy < 0 && actualY > dy + 1.0E-7;
        boolean horizontal = Math.abs(actualX - dx) > 1.0E-7 || Math.abs(actualZ - dz) > 1.0E-7;
        return new MoveResult(box, actualX, actualY, actualZ, onGround, horizontal);
    }

    private List<Aabb> collisionBoxes(Aabb area) {
        return collisionBoxes(area, false);
    }

    private List<Aabb> collisionBoxes(Aabb area, boolean ignoreClimbableCollision) {
        int minBlockX = (int) Math.floor(area.minX()), maxBlockX = (int) Math.floor(area.maxX() - 1.0E-7);
        int minBlockY = (int) Math.floor(area.minY()), maxBlockY = (int) Math.floor(area.maxY() - 1.0E-7);
        int minBlockZ = (int) Math.floor(area.minZ()), maxBlockZ = (int) Math.floor(area.maxZ() - 1.0E-7);
        List<Aabb> result = new ArrayList<>();
        for (int y = minBlockY; y <= maxBlockY; y++) for (int z = minBlockZ; z <= maxBlockZ; z++) for (int x = minBlockX; x <= maxBlockX; x++) {
            BlockRegistry.State state = blocks.state(blockState(x, y, z));
            if (ignoreClimbableCollision && state.climbable()) continue;
            for (Aabb shape : state.collision()) {
                Aabb absolute = shape.move(x, y, z);
                if (absolute.intersects(area)) result.add(absolute);
            }
        }
        return result;
    }

    /** 返回玩家当前接触的介质及脚下方块属性，供客户端按原版分支计算移动。 */
    public synchronized MovementEnvironment environment(Aabb body) {
        boolean water = false, lava = false, climbable = false, scaffolding = false;
        int minX = (int) Math.floor(body.minX()), maxX = (int) Math.floor(body.maxX() - 1.0E-7);
        int minY = (int) Math.floor(body.minY()), maxY = (int) Math.floor(body.maxY() - 1.0E-7);
        int minZ = (int) Math.floor(body.minZ()), maxZ = (int) Math.floor(body.maxZ() - 1.0E-7);
        for (int by = minY; by <= maxY; by++) for (int bz = minZ; bz <= maxZ; bz++) for (int bx = minX; bx <= maxX; bx++) {
            BlockRegistry.State state = blocks.state(blockState(bx, by, bz));
            water |= state.water(); lava |= state.lava(); climbable |= state.climbable(); scaffolding |= state.scaffolding();
        }
        int centerX = (int) Math.floor((body.minX() + body.maxX()) * 0.5);
        int centerZ = (int) Math.floor((body.minZ() + body.maxZ()) * 0.5);
        BlockRegistry.State support = blocks.state(blockState(centerX, (int) Math.floor(body.minY() - 0.05), centerZ));
        return new MovementEnvironment(water, lava, climbable, scaffolding,
                support.friction(), support.speedFactor(), support.name());
    }

    public synchronized boolean waterAt(double x, double y, double z) {
        return blocks.state(blockState((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z))).water();
    }

    public synchronized float climbYaw(double x, double y, double z, float fallback) {
        BlockRegistry.State state = blocks.state(blockState((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z)));
        if (!state.name().equals("ladder")) return fallback;
        // 梯子的 facing 指向梯子外侧；玩家需要朝支撑墙（反方向）持续按前进。
        return switch (state.facing()) {
            case "north" -> 0.0f;
            case "south" -> 180.0f;
            case "west" -> -90.0f;
            case "east" -> 90.0f;
            default -> fallback;
        };
    }

    public synchronized BlockHit raycastBlock(double ox, double oy, double oz, double dx, double dy, double dz, double reach) {
        int previousX = (int) Math.floor(ox), previousY = (int) Math.floor(oy), previousZ = (int) Math.floor(oz);
        double step = 0.025;
        for (double distance = 0; distance <= reach; distance += step) {
            int x = (int) Math.floor(ox + dx * distance), y = (int) Math.floor(oy + dy * distance), z = (int) Math.floor(oz + dz * distance);
            BlockRegistry.State state = blocks.state(blockState(x, y, z));
            if (state.targetable()) {
                double hitX = clamp(ox + dx * distance - x, 0, 1);
                double hitY = clamp(oy + dy * distance - y, 0, 1);
                double hitZ = clamp(oz + dz * distance - z, 0, 1);
                return new BlockHit(x, y, z, face(previousX, previousY, previousZ, x, y, z, dx, dy, dz),
                        distance, hitX, hitY, hitZ, state);
            }
            previousX = x; previousY = y; previousZ = z;
        }
        return null;
    }

    /**
     * 有界 A* 寻路。节点高度按 1/16 格保存，因而台阶、楼梯、半砖和地毯不会被取整。
     * 水面、梯子和脚手架使用独立遍历类型；落差上限用于避免自动寻路把假人送下危险高度。
     */
    public synchronized List<PathPoint> findPath(double fromX, double fromY, double fromZ,
                                                 double toX, double toY, double toZ,
                                                 double maximumDistance, int maximumExpandedNodes) {
        if (!loadedAt(fromX, fromZ) || !loadedAt(toX, toZ)) return List.of();
        int sx = (int) Math.floor(fromX), sz = (int) Math.floor(fromZ);
        int tx = (int) Math.floor(toX), tz = (int) Math.floor(toZ);
        Node start = nearestNavigationNode(sx, fromY, sz, 3.0);
        Node goal = nearestNavigationNode(tx, toY, tz, 4.0);
        if (start == null || goal == null) return List.of();
        double direct = Math.sqrt(square(tx - sx) + square(nodeY(goal) - nodeY(start)) + square(tz - sz));
        if (direct > maximumDistance) return List.of();

        PriorityQueue<QueueNode> open = new PriorityQueue<>(Comparator.comparingDouble(QueueNode::score));
        Map<Node, Double> costs = new HashMap<>();
        Map<Node, Node> parent = new HashMap<>();
        Map<Node, PathPoint.Traversal> traversals = new HashMap<>();
        Set<Node> closed = new HashSet<>();
        costs.put(start, 0.0);
        open.add(new QueueNode(start, heuristic(start, goal)));
        Node best = start;
        double bestHeuristic = heuristic(start, goal);
        int expanded = 0;

        while (!open.isEmpty() && expanded++ < Math.max(64, maximumExpandedNodes)) {
            Node current = open.poll().node;
            if (!closed.add(current)) continue;
            double currentHeuristic = heuristic(current, goal);
            if (currentHeuristic < bestHeuristic) { best = current; bestHeuristic = currentHeuristic; }
            if (current.equals(goal) || currentHeuristic <= 1.0) { best = current; break; }
            for (int[] direction : CARDINALS) {
                int nx = current.x + direction[0], nz = current.z + direction[1];
                if (Math.abs(nx - sx) > maximumDistance || Math.abs(nz - sz) > maximumDistance) continue;
                Node next = reachableNode(nx, nodeY(current), nz);
                if (next == null) continue;
                if (closed.contains(next)) continue;
                double heightDelta = nodeY(next) - nodeY(current);
                PathPoint.Traversal traversal = traversal(current, next);
                double nextCost = costs.get(current) + 1.0 + Math.max(0, heightDelta) * 0.45
                        + Math.max(0, -heightDelta) * 0.15
                        + (traversal == PathPoint.Traversal.SWIM ? 0.2 : traversal == PathPoint.Traversal.CLIMB ? 0.35 : 0);
                if (nextCost >= costs.getOrDefault(next, Double.POSITIVE_INFINITY)) continue;
                costs.put(next, nextCost);
                parent.put(next, current);
                traversals.put(next, traversal);
                open.add(new QueueNode(next, nextCost + heuristic(next, goal)));
            }
            if (isClimbNode(current)) {
                for (int vertical : new int[]{1, -1}) {
                    Node next = verticalClimbNode(current, vertical);
                    if (next == null || closed.contains(next)) continue;
                    double nextCost = costs.get(current) + 1.2;
                    if (nextCost >= costs.getOrDefault(next, Double.POSITIVE_INFINITY)) continue;
                    costs.put(next, nextCost); parent.put(next, current);
                    traversals.put(next, PathPoint.Traversal.CLIMB);
                    open.add(new QueueNode(next, nextCost + heuristic(next, goal)));
                }
            }
        }
        if (best.equals(start) || bestHeuristic > 2.5) return List.of();
        List<PathPoint> result = new ArrayList<>();
        for (Node node = best; !node.equals(start); node = parent.get(node)) {
            if (node == null) return List.of();
            result.add(new PathPoint(node.x + 0.5, nodeY(node), node.z + 0.5,
                    traversals.getOrDefault(node, PathPoint.Traversal.WALK)));
        }
        Collections.reverse(result);
        return List.copyOf(result);
    }

    /** 寻找准星不必预先对准的最近可打开箱子，并要求当前方块射线确实可见。 */
    public synchronized ContainerTarget nearestContainer(double x, double eyeY, double z, double reach) {
        ContainerTarget closest = null;
        int radius = Math.max(1, (int) Math.ceil(reach));
        int ox = (int) Math.floor(x), oy = (int) Math.floor(eyeY), oz = (int) Math.floor(z);
        for (int by = oy - radius; by <= oy + radius; by++) {
            for (int bz = oz - radius; bz <= oz + radius; bz++) {
                for (int bx = ox - radius; bx <= ox + radius; bx++) {
                    BlockRegistry.State state = blocks.state(blockState(bx, by, bz));
                    if (!isContainer(state.name())) continue;
                    double dx = bx + 0.5 - x, dy = by + 0.5 - eyeY, dz = bz + 0.5 - z;
                    double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (distance > reach || closest != null && distance >= closest.distance) continue;
                    BlockHit visible = raycastBlock(x, eyeY, z, dx / distance, dy / distance, dz / distance, distance + 0.1);
                    if (visible == null || visible.x != bx || visible.y != by || visible.z != bz) continue;
                    closest = new ContainerTarget(bx, by, bz, visible.face, distance, state.name());
                }
            }
        }
        return closest;
    }

    private Node nearestNavigationNode(int x, double aroundY, int z, double radius) {
        if (!loadedAt(x + 0.5, z + 0.5)) return null;
        double swim = swimSurfaceY(x, aroundY, z, radius);
        if (Double.isFinite(swim) && (waterAt(x + 0.5, aroundY + 0.2, z + 0.5)
                || waterAt(x + 0.5, aroundY + 1.0, z + 0.5))) return node(x, swim, z);
        double stand = standSurfaceY(x, aroundY, z, radius, radius);
        if (Double.isFinite(stand)) return node(x, stand, z);
        int climbY = nearestClimbY(x, aroundY, z, radius);
        if (climbY != Integer.MIN_VALUE) return node(x, climbY, z);
        return Double.isFinite(swim) ? node(x, swim, z) : null;
    }

    private Node reachableNode(int x, double currentY, int z) {
        double maximumFall = Math.max(1.0, config.decimal("client-simulation.physics.pathfinding-safe-fall", 3.0));
        double stand = standSurfaceY(x, currentY, z, 1.05, maximumFall);
        Node result = Double.isFinite(stand) ? node(x, stand, z) : null;
        double swim = swimSurfaceY(x, currentY, z, 2.5);
        if (Double.isFinite(swim) && Math.abs(swim - currentY) <= 2.5) {
            Node water = node(x, swim, z);
            if (result == null || Math.abs(swim - currentY) < Math.abs(stand - currentY)) result = water;
        }
        int climbY = nearestClimbY(x, currentY, z, 1.25);
        if (climbY != Integer.MIN_VALUE) {
            Node climb = node(x, climbY, z);
            if (result == null || Math.abs(climbY - currentY) < Math.abs(nodeY(result) - currentY)) result = climb;
        }
        return result;
    }

    private double standSurfaceY(int blockX, double aroundY, int blockZ, double maxUp, double maxDown) {
        if (!loadedAt(blockX + 0.5, blockZ + 0.5)) return Double.NaN;
        List<Double> candidates = new ArrayList<>();
        int minimum = Math.max(minY, (int) Math.floor(aroundY - maxDown - 1));
        int maximum = Math.min(minY + height - 1, (int) Math.ceil(aroundY + maxUp));
        Aabb footprint = new Aabb(blockX + 0.2, minimum, blockZ + 0.2,
                blockX + 0.8, maximum + 1, blockZ + 0.8);
        for (int by = minimum; by <= maximum; by++) {
            BlockRegistry.State state = blocks.state(blockState(blockX, by, blockZ));
            if (isDangerous(state.name())) continue;
            for (Aabb shape : state.collision()) {
                Aabb absolute = shape.move(blockX, by, blockZ);
                if (absolute.maxX() <= footprint.minX() || absolute.minX() >= footprint.maxX()
                        || absolute.maxZ() <= footprint.minZ() || absolute.minZ() >= footprint.maxZ()) continue;
                double top = absolute.maxY();
                if (top <= aroundY + maxUp + 1.0E-7 && top >= aroundY - maxDown - 1.0E-7) candidates.add(top);
            }
        }
        candidates.sort(Comparator.comparingDouble(value -> Math.abs(value - aroundY)));
        for (double candidate : candidates) if (canStandAt(blockX, candidate, blockZ)) return candidate;
        return Double.NaN;
    }

    private boolean canStandAt(int blockX, double feetY, int blockZ) {
        if (feetY < minY || feetY + 1.8 >= minY + height) return false;
        Aabb body = new Aabb(blockX + 0.2, feetY, blockZ + 0.2,
                blockX + 0.8, feetY + 1.8, blockZ + 0.8);
        if (!collisionBoxes(body).isEmpty()) return false;
        int feetBlock = (int) Math.floor(feetY + 1.0E-5);
        BlockRegistry.State feet = blocks.state(blockState(blockX, feetBlock, blockZ));
        BlockRegistry.State head = blocks.state(blockState(blockX, (int) Math.floor(feetY + 1.7), blockZ));
        if (isDangerous(feet.name()) || isDangerous(head.name())) return false;
        return collide(body, 0, -0.08, 0).onGround;
    }

    private double swimSurfaceY(int x, double aroundY, int z, double radius) {
        int center = (int) Math.floor(aroundY);
        int found = Integer.MIN_VALUE;
        int scan = Math.max(2, (int) Math.ceil(radius));
        for (int delta = 0; delta <= scan && found == Integer.MIN_VALUE; delta++) {
            int up = center + delta, down = center - delta;
            if (blocks.state(blockState(x, up, z)).water()) found = up;
            else if (delta > 0 && blocks.state(blockState(x, down, z)).water()) found = down;
        }
        if (found == Integer.MIN_VALUE) return Double.NaN;
        int top = found;
        while (top + 1 < minY + height && blocks.state(blockState(x, top + 1, z)).water()) top++;
        // 普通站立姿态的眼睛略低于液面，持续跳跃输入会像原版玩家一样在表面上下浮动。
        return quantize16(top + 1.0 - config.decimal("client-simulation.physics.eye-height", 1.62) + 0.08);
    }

    private int nearestClimbY(int x, double aroundY, int z, double radius) {
        int scan = Math.max(1, (int) Math.ceil(radius));
        int center = (int) Math.floor(aroundY);
        for (int delta = 0; delta <= scan; delta++) {
            int up = center + delta, down = center - delta;
            if (blocks.state(blockState(x, up, z)).climbable()) return up;
            if (delta > 0 && blocks.state(blockState(x, down, z)).climbable()) return down;
        }
        return Integer.MIN_VALUE;
    }

    private boolean isClimbNode(Node node) {
        return blocks.state(blockState(node.x, (int) Math.floor(nodeY(node) + 0.1), node.z)).climbable();
    }

    private Node verticalClimbNode(Node current, int direction) {
        double nextY = nodeY(current) + direction;
        if (nextY < minY || nextY + 1.8 >= minY + height) return null;
        int blockY = (int) Math.floor(nextY + 0.1);
        BlockRegistry.State state = blocks.state(blockState(current.x, blockY, current.z));
        if (state.climbable()) return node(current.x, nextY, current.z);
        if (direction > 0) {
            double stand = standSurfaceY(current.x, nextY, current.z, 0.7, 1.0);
            if (Double.isFinite(stand)) return node(current.x, stand, current.z);
        }
        return null;
    }

    private PathPoint.Traversal traversal(Node from, Node to) {
        double y = nodeY(to);
        BlockRegistry.State state = blocks.state(blockState(to.x, (int) Math.floor(y + 0.1), to.z));
        if (state.climbable()) return PathPoint.Traversal.CLIMB;
        if (state.water() || waterAt(to.x + 0.5, y + 0.2, to.z + 0.5)) return PathPoint.Traversal.SWIM;
        return y - nodeY(from) > config.decimal("client-simulation.physics.step-height", 0.6) + 1.0E-5
                ? PathPoint.Traversal.JUMP : PathPoint.Traversal.WALK;
    }

    private Node node(int x, double y, int z) { return new Node(x, (int) Math.round(quantize16(y) * 16.0), z); }
    private double nodeY(Node node) { return node.y16 / 16.0; }
    private double quantize16(double value) { return Math.rint(value * 16.0) / 16.0; }

    private boolean isDangerous(String name) {
        return name.contains("lava") || name.contains("fire") || name.contains("cactus")
                || name.contains("magma") || name.contains("sweet_berry") || name.contains("powder_snow");
    }

    private boolean isContainer(String name) {
        return name.equals("chest") || name.equals("trapped_chest") || name.equals("ender_chest")
                || name.equals("barrel") || name.endsWith("shulker_box");
    }

    private double heuristic(Node from, Node to) {
        return Math.abs(from.x - to.x) + Math.abs(from.z - to.z) + Math.abs(nodeY(from) - nodeY(to)) * 1.25;
    }

    private double square(double value) { return value * value; }
    private double clamp(double value, double minimum, double maximum) { return Math.max(minimum, Math.min(maximum, value)); }

    private int face(int px, int py, int pz, int x, int y, int z, double dx, double dy, double dz) {
        if (x > px) return 4; if (x < px) return 5;
        if (y > py) return 0; if (y < py) return 1;
        if (z > pz) return 2; if (z < pz) return 3;
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ay >= ax && ay >= az) return dy > 0 ? 0 : 1;
        if (ax >= az) return dx > 0 ? 4 : 5;
        return dz > 0 ? 2 : 3;
    }

    private long key(int x, int z) { return ((long) x << 32) ^ (z & 0xffffffffL); }
    private static final int[][] CARDINALS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private record Node(int x, int y16, int z) { }
    private record QueueNode(Node node, double score) { }
    private record Column(int minSection, ChunkSection[] sections) { }
    public record MoveResult(Aabb box, double dx, double dy, double dz, boolean onGround, boolean horizontalCollision) { }
    public record MovementEnvironment(boolean water, boolean lava, boolean climbable, boolean scaffolding,
                                      double friction, double speedFactor, String supportBlock) { }
    public record BlockHit(int x, int y, int z, int face, double distance,
                           double hitX, double hitY, double hitZ, BlockRegistry.State state) { }
    public record PathPoint(double x, double y, double z, Traversal traversal) {
        public enum Traversal { WALK, JUMP, SWIM, CLIMB }
    }
    public record ContainerTarget(int x, int y, int z, int face, double distance, String type) { }
}
