package cn.pn86.pnplayerbot.simulation;

import cn.pn86.pnplayerbot.config.ConfigService;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundLoginPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundRespawnPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundSetPassengersPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundMoveVehiclePacket;
import org.geysermc.mcprotocollib.protocol.packet.configuration.clientbound.ClientboundRegistryDataPacket;
import org.geysermc.mcprotocollib.protocol.data.game.RegistryEntry;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 运行在 Velocity 内的简化原版客户端：维护世界、实体、碰撞、重力和鼠标按键状态。
 * Paper 插件不参与本类的任何动作或数据查询。
 */
public final class ClientSimulation {
    private static final double PLAYER_HALF_WIDTH = 0.3;
    private static final double PLAYER_HEIGHT = 1.8;
    private final ConfigService config;
    private final Host host;
    private final ClientWorld world;
    private final EntityTracker entities = new EntityTracker();
    private final Map<Integer, DimensionSettings> dimensionTypes = new HashMap<>();
    private double x, y, z;
    private float yaw, pitch;
    private double velocityX, velocityY, velocityZ;
    private boolean located;
    private boolean onGround;
    private char movementDirection;
    private int movementTicks;
    private boolean jumpQueued;
    private int jumpQueueTicks;
    private boolean jumpInputSent;
    private boolean navigationActive;
    private List<ClientWorld.PathPoint> navigationPath = List.of();
    private int navigationIndex;
    private ClientWorld.PathPoint.Traversal navigationTraversal = ClientWorld.PathPoint.Traversal.WALK;
    private int navigationStuckTicks;
    private double navigationLastX, navigationLastZ;
    private double navigationTargetX, navigationTargetY, navigationTargetZ;
    private String autoLookMode = "";
    private String autoLookFilter = "";
    private int autoLookCooldown;
    private boolean attackContinuous;
    private int attackRemaining;
    private int attackCooldown;
    private boolean destroyContinuous;
    private int destroyRemaining;
    private int destroyRetry;
    private ClientWorld.BlockHit destroyTarget;
    private int destroyTicksRemaining;
    private int destroySwingTick;
    private boolean putContinuous;
    private int putRemaining;
    private int putCooldown;
    private int selfEntityId = Integer.MIN_VALUE;
    private int mountedVehicleId = Integer.MIN_VALUE;
    private int dismountInputTicks;

    public ClientSimulation(ConfigService config, Host host) {
        this.config = config;
        this.host = host;
        this.world = new ClientWorld(config);
    }

    public synchronized void beginConfiguration() {
        dimensionTypes.clear();
    }

    /** 保存服务器实际发送的世界类型高度，支持多世界插件创建的自定义世界。 */
    public synchronized void acceptRegistryData(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundRegistryDataPacket packet = new ClientboundRegistryDataPacket(buffer);
            if (!packet.getRegistry().asString().equals("minecraft:dimension_type")) return;
            dimensionTypes.clear();
            List<RegistryEntry> entries = packet.getEntries();
            for (int index = 0; index < entries.size(); index++) {
                RegistryEntry entry = entries.get(index);
                if (entry.getData() == null) continue;
                int minY = entry.getData().getInt("min_y", Integer.MIN_VALUE);
                int height = entry.getData().getInt("height", 0);
                String effects = entry.getData().getString("effects", entry.getId().asString());
                dimensionTypes.put(index, new DimensionSettings(minY, height, effects));
            }
        } finally { buffer.release(); }
    }

    public synchronized void acceptPacket(int packetId, byte[] payload) {
        if (!enabled()) return;
        if (packetId == config.integer("protocol-packets.play.clientbound-login", 43)) acceptLogin(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-respawn", 75)) acceptRespawn(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-chunk-with-light", 39)) world.acceptChunk(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-forget-chunk", 33)) world.acceptForget(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-block-update", 8)) world.acceptBlockUpdate(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-section-block-update", 77)) world.acceptSectionUpdate(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-add-entity", 1)) entities.acceptAdd(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-entity-position-sync", 31)) entities.acceptSync(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-move-entity-position", 46)) entities.acceptRelativePosition(payload, false);
        else if (packetId == config.integer("protocol-packets.play.clientbound-move-entity-position-rotation", 47)) entities.acceptRelativePosition(payload, true);
        else if (packetId == config.integer("protocol-packets.play.clientbound-remove-entities", 70)) entities.acceptRemove(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-teleport-entity", 118)) entities.acceptTeleport(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-set-passengers", 100)) acceptPassengers(payload);
        else if (packetId == config.integer("protocol-packets.play.clientbound-move-vehicle", 50)) acceptMoveVehicle(payload);
    }

    private void acceptLogin(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundLoginPacket packet = new ClientboundLoginPacket(buffer);
            entities.clear(); selfEntityId = packet.getEntityId(); entities.selfEntityId(selfEntityId);
            selectWorld(packet.getCommonPlayerSpawnInfo());
            resetMotion();
        } finally { buffer.release(); }
    }

    private void acceptRespawn(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundRespawnPacket packet = new ClientboundRespawnPacket(buffer);
            entities.clear(); selectWorld(packet.getCommonPlayerSpawnInfo());
            resetMotion(); located = false;
        } finally { buffer.release(); }
    }

    private void selectWorld(org.geysermc.mcprotocollib.protocol.data.game.entity.player.PlayerSpawnInfo spawn) {
        DimensionSettings settings = dimensionTypes.get(spawn.getDimension());
        if (settings == null) world.selectDimension(spawn.getWorldName().asString());
        else world.selectDimension(spawn.getWorldName().asString(), settings.minY, settings.height, settings.effects);
    }

    private void acceptPassengers(byte[] payload) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundSetPassengersPacket packet = new ClientboundSetPassengersPacket(buffer);
            boolean containsSelf = false;
            for (int passenger : packet.getPassengerIds()) {
                if (passenger == selfEntityId) { containsSelf = true; break; }
            }
            if (containsSelf) {
                mountedVehicleId = packet.getEntityId();
                velocityX = velocityY = velocityZ = 0;
                cancelNavigationInternal();
            } else if (packet.getEntityId() == mountedVehicleId) mountedVehicleId = Integer.MIN_VALUE;
        } finally { buffer.release(); }
    }

    private void acceptMoveVehicle(byte[] payload) {
        if (mountedVehicleId == Integer.MIN_VALUE) return;
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try {
            ClientboundMoveVehiclePacket packet = new ClientboundMoveVehiclePacket(buffer);
            x = packet.getPosition().getX(); y = packet.getPosition().getY(); z = packet.getPosition().getZ();
            yaw = packet.getYRot(); pitch = packet.getXRot();
            host.trackedPosition(x, y, z, yaw, pitch);
        } finally { buffer.release(); }
    }

    public synchronized void teleport(double x, double y, double z, float yaw, float pitch) {
        this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
        velocityX = velocityY = velocityZ = 0;
        located = true;
    }

    public synchronized void look(float yaw, float pitch) { this.yaw = yaw; this.pitch = pitch; }

    public synchronized boolean move(char direction, int ticks) {
        direction = Character.toUpperCase(direction);
        if (!enabled() || !located || "WASD".indexOf(direction) < 0 || ticks <= 0) return false;
        cancelNavigationInternal();
        movementDirection = direction; movementTicks = ticks;
        host.input(movementDirection, jumpInputSent, false, false);
        return true;
    }

    public synchronized boolean jump() {
        if (!enabled() || !located || jumpQueued) return false;
        // 原版允许玩家提前按住跳跃：区块或落地状态尚未同步时先排队，落地后立即起跳。
        jumpQueued = true;
        jumpQueueTicks = Math.max(1, config.integer("features.jump.queue-ticks", 40));
        return true;
    }

    public synchronized boolean action(String kind, boolean continuous, int count) {
        if (!enabled()) return false;
        if (kind.equals("attack")) {
            attackContinuous = continuous;
            attackRemaining = continuous ? 0 : Math.max(0, count);
            attackCooldown = 0;
            return true;
        }
        if (kind.equals("destroy")) {
            if (!continuous && count == 0) cancelDestroy();
            destroyContinuous = continuous;
            destroyRemaining = continuous ? 0 : Math.max(0, count);
            destroyRetry = 0;
            return true;
        }
        if (kind.equals("put")) {
            putContinuous = continuous;
            putRemaining = continuous ? 0 : Math.max(0, count);
            putCooldown = 0;
            return true;
        }
        return false;
    }

    public synchronized void stopAll() {
        stopMovement();
        attackContinuous = false; attackRemaining = 0;
        destroyContinuous = false; destroyRemaining = 0; cancelDestroy();
        putContinuous = false; putRemaining = 0; putCooldown = 0;
        autoLookMode = ""; autoLookFilter = "";
    }

    public synchronized void stopMovement() {
        movementTicks = 0; movementDirection = 0; jumpQueued = false; jumpQueueTicks = 0; jumpInputSent = false;
        velocityX = velocityZ = 0;
        cancelNavigationInternal();
        host.input((char) 0, false, false, false);
    }

    public synchronized void tick() {
        if (!enabled() || !located) return;
        // 原版客户端在本 tick 的 movement/flying 包之前处理攻击和挖掘，最后才发送 tick end。
        tickAutoLook();
        tickAttack();
        tickDestroy();
        tickPut();
        tickMovement();
    }

    private void tickMovement() {
        updateNavigationInput();
        boolean moving = (navigationActive || movementTicks > 0) && movementDirection != 0;
        Aabb box = playerBox();
        ClientWorld.MovementEnvironment environment = world.environment(box);
        // 在眼睛仍浸水时持续保持原版跳跃键；到达液面后自动松开，形成正常的水面浮动而非匀速飞行。
        boolean swimmingUp = environment.water() && world.waterAt(x, eyeY() - 0.05, z);
        boolean climbingUp = navigationActive && navigationTraversal == ClientWorld.PathPoint.Traversal.CLIMB
                && navigationIndex < navigationPath.size() && navigationPath.get(navigationIndex).y() > y + 0.15;
        boolean climbingDown = navigationActive && navigationTraversal == ClientWorld.PathPoint.Traversal.CLIMB
                && navigationIndex < navigationPath.size() && navigationPath.get(navigationIndex).y() < y - 0.15;

        // 骑乘时原版客户端只发送按键输入，玩家本体坐标由载具和服务端同步。
        if (mountedVehicleId != Integer.MIN_VALUE) {
            velocityX = velocityY = velocityZ = 0;
            boolean dismount = dismountInputTicks > 0;
            host.input(movementDirection, jumpInputSent, dismount, false);
            if (dismountInputTicks > 0) dismountInputTicks--;
            jumpInputSent = false;
            if (moving && !navigationActive && --movementTicks <= 0) {
                movementDirection = 0;
                host.input((char) 0, false, false, false);
            }
            return;
        }

        boolean physicsActive = moving || jumpQueued || !onGround
                || Math.abs(velocityX) > 0.001 || Math.abs(velocityY) > 0.001 || Math.abs(velocityZ) > 0.001;
        if (!physicsActive || !world.loadedAt(x, z)) return;

        boolean jumpKey = jumpInputSent || swimmingUp || climbingUp && environment.scaffolding();
        boolean shiftKey = climbingDown && environment.scaffolding() || dismountInputTicks > 0;
        if (dismountInputTicks > 0) dismountInputTicks--;
        jumpInputSent = false;
        boolean fluidJumpApplied = false;
        if (jumpQueued && (environment.water() || environment.lava())) {
            velocityY += config.decimal("client-simulation.physics.water-jump-velocity", 0.04);
            jumpQueued = false;
            jumpKey = true;
            fluidJumpApplied = true;
        } else if (jumpQueued && onGround) {
            velocityY = (float) config.decimal("client-simulation.physics.jump-velocity", 0.42);
            onGround = false; jumpQueued = false;
            jumpKey = true;
        } else if (jumpQueued && --jumpQueueTicks <= 0) {
            jumpQueued = false;
        }

        if (swimmingUp && !fluidJumpApplied) velocityY += config.decimal("client-simulation.physics.water-jump-velocity", 0.04);
        if (environment.climbable()) {
            double maximumHorizontal = config.decimal("client-simulation.physics.climb-horizontal-limit", 0.15);
            velocityX = clamp(velocityX, -maximumHorizontal, maximumHorizontal);
            velocityZ = clamp(velocityZ, -maximumHorizontal, maximumHorizontal);
            velocityY = Math.max(velocityY, -config.decimal("client-simulation.physics.climb-down-speed", 0.15));
            if (climbingUp) velocityY = Math.max(velocityY,
                    config.decimal("client-simulation.physics.climb-up-speed", 0.2));
            else if (climbingDown) velocityY = Math.min(velocityY,
                    -config.decimal("client-simulation.physics.climb-down-speed", 0.15));
        }

        if (moving) {
            float radians = yaw * ((float) Math.PI / 180.0F);
            double sin = VanillaMath.sin(radians), cos = VanillaMath.cos(radians);
            double forwardX = -sin, forwardZ = cos;
            double inputX = switch (movementDirection) {
                case 'W' -> forwardX; case 'S' -> -forwardX;
                case 'A' -> cos; case 'D' -> -cos; default -> 0;
            };
            double inputZ = switch (movementDirection) {
                case 'W' -> forwardZ; case 'S' -> -forwardZ;
                case 'A' -> sin; case 'D' -> -sin; default -> 0;
            };
            float inputScale = (float) config.decimal("client-simulation.physics.input-scale", 0.98);
            inputX *= inputScale; inputZ *= inputScale;
            double acceleration;
            if (environment.water() || environment.lava()) {
                acceleration = config.decimal("client-simulation.physics.fluid-acceleration", 0.02);
            } else if (onGround) {
                float blockFriction = (float) Math.max(0.01, environment.friction());
                float movementSpeed = (float) config.decimal("client-simulation.physics.ground-acceleration", 0.1);
                acceleration = movementSpeed * (0.21600002F
                        / (blockFriction * blockFriction * blockFriction));
            } else acceleration = config.decimal("client-simulation.physics.air-acceleration", 0.02);
            velocityX += inputX * acceleration;
            velocityZ += inputZ * acceleration;
        }

        ClientWorld.MoveResult result = world.move(box, velocityX, velocityY, velocityZ,
                config.decimal("client-simulation.physics.step-height", 0.6), onGround,
                environment.scaffolding() && (climbingUp || climbingDown));
        x = (result.box().minX() + result.box().maxX()) / 2.0;
        y = result.box().minY();
        z = (result.box().minZ() + result.box().maxZ()) / 2.0;
        if (Math.abs(result.dx() - velocityX) > 1.0E-7) velocityX = 0;
        if (Math.abs(result.dz() - velocityZ) > 1.0E-7) velocityZ = 0;
        if (Math.abs(result.dy() - velocityY) > 1.0E-7) velocityY = 0;
        onGround = result.onGround();

        velocityX *= environment.speedFactor();
        velocityZ *= environment.speedFactor();

        double friction;
        if (environment.water()) friction = config.decimal("client-simulation.physics.water-friction", 0.8);
        else if (environment.lava()) friction = config.decimal("client-simulation.physics.lava-friction", 0.5);
        else if (onGround) friction = Math.abs(environment.friction() - 0.6) < 1.0E-6
                    ? config.decimal("client-simulation.physics.ground-friction", 0.54600006)
                    : (float) environment.friction() * 0.91F;
        else friction = config.decimal("client-simulation.physics.air-friction", 0.91);
        velocityX *= friction; velocityZ *= friction;
        if (environment.water()) {
            velocityY = velocityY * config.decimal("client-simulation.physics.water-vertical-drag", 0.8)
                    - config.decimal("client-simulation.physics.water-gravity", 0.005);
        } else if (environment.lava()) {
            velocityY = velocityY * config.decimal("client-simulation.physics.lava-vertical-drag", 0.5)
                    - config.decimal("client-simulation.physics.water-gravity", 0.005);
        } else {
            // 原版先使用本 tick 速度移动，随后计算下一 tick 的重力速度；跳跃首 tick 因此完整移动 0.42。
            velocityY = (velocityY - config.decimal("client-simulation.physics.gravity", 0.08))
                    * (float) config.decimal("client-simulation.physics.vertical-drag", 0.98);
        }
        host.input(movementDirection, jumpKey, shiftKey, false);
        host.movement(x, y, z, yaw, pitch, onGround, result.horizontalCollision());

        if (navigationActive) {
            double progressed = Math.hypot(x - navigationLastX, z - navigationLastZ);
            if (progressed < 0.005 && (result.horizontalCollision() || moving)) navigationStuckTicks++;
            else navigationStuckTicks = 0;
            navigationLastX = x; navigationLastZ = z;
            int jumpAfter = Math.max(4, config.integer("performance.pathfinding-stuck-jump-ticks", 12));
            if (navigationStuckTicks == jumpAfter && onGround && !environment.water() && !environment.climbable()) {
                jumpQueued = true;
                jumpQueueTicks = Math.max(1, config.integer("features.jump.queue-ticks", 40));
            }
            int replanAfter = Math.max(jumpAfter + 4,
                    config.integer("performance.pathfinding-stuck-replan-ticks", 30));
            if (navigationStuckTicks >= replanAfter) cancelNavigationInternal();
        }

        if (moving && !navigationActive && --movementTicks <= 0) {
            movementDirection = 0;
            host.input((char) 0, jumpInputSent, false, false);
        }
    }

    private void updateNavigationInput() {
        if (!navigationActive) return;
        while (navigationIndex < navigationPath.size()) {
            ClientWorld.PathPoint point = navigationPath.get(navigationIndex);
            double dx = point.x() - x, dz = point.z() - z;
            if (dx * dx + dz * dz > 0.18 || Math.abs(point.y() - y) > 1.1) break;
            navigationIndex++;
        }
        double remainingX = navigationTargetX - x, remainingY = navigationTargetY - y, remainingZ = navigationTargetZ - z;
        if (navigationIndex >= navigationPath.size()) {
            if (remainingX * remainingX + remainingZ * remainingZ <= 1.7 * 1.7 && Math.abs(remainingY) <= 0.75) {
                cancelNavigationInternal();
            }
            return;
        }
        ClientWorld.PathPoint point = navigationPath.get(navigationIndex);
        double dx = point.x() - x, dz = point.z() - z;
        navigationTraversal = point.traversal();
        if (point.traversal() == ClientWorld.PathPoint.Traversal.CLIMB && dx * dx + dz * dz < 0.08) {
            yaw = world.climbYaw(x, y, z, yaw);
        } else yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        movementDirection = 'W';
        movementTicks = Integer.MAX_VALUE;
        if (point.traversal() == ClientWorld.PathPoint.Traversal.JUMP
                && point.y() > y + 0.35 && onGround && !jumpQueued) {
            jumpQueued = true;
            jumpQueueTicks = Math.max(1, config.integer("features.jump.queue-ticks", 40));
        }
    }

    private void tickAutoLook() {
        if (autoLookMode.isBlank()) return;
        if (autoLookCooldown-- > 0) return;
        autoLookCooldown = Math.max(1, config.integer("features.facing.auto.interval-millis", 100) / 50) - 1;
        double radius = Math.max(1.0, config.decimal("features.facing.auto.radius-blocks", 16.0));
        EntityTracker.LookTarget target = entities.lookTarget(x, eyeY(), z, radius, autoLookMode, autoLookFilter);
        if (target == null) return;
        float nextYaw = (float) Math.toDegrees(Math.atan2(-(target.x() - x), target.z() - z));
        double horizontal = Math.hypot(target.x() - x, target.z() - z);
        float nextPitch = (float) -Math.toDegrees(Math.atan2(target.y() - eyeY(), horizontal));
        nextPitch = Math.max(-90, Math.min(90, nextPitch));
        // 反作弊兼容：平滑转头而不是瞬间跳转，避免被判定为机器人视角瞬移。
        float step = (float) Math.max(1.0, config.decimal("anti-cheat-compatibility.look-step-degrees", 30.0));
        float deltaYaw = wrapDegrees(nextYaw - yaw);
        yaw = Math.abs(deltaYaw) <= step ? nextYaw : yaw + Math.copySign(step, deltaYaw);
        float deltaPitch = nextPitch - pitch;
        pitch = Math.abs(deltaPitch) <= step ? nextPitch : pitch + Math.copySign(step, deltaPitch);
        if (Math.abs(deltaYaw) < 0.1f && Math.abs(deltaPitch) < 0.1f) return;
        host.rotation(yaw, pitch);
    }

    /** 把角度差折叠到 (-180, 180]，用于平滑旋转时选择最短路径。 */
    private static float wrapDegrees(float delta) {
        while (delta > 180f) delta -= 360f;
        while (delta <= -180f) delta += 360f;
        return delta;
    }

    private void tickAttack() {
        if (!attackContinuous && attackRemaining <= 0) return;
        if (attackCooldown > 0) { attackCooldown--; return; }
        int intervalTicks = Math.max(1, (int) Math.ceil(config.integer("features.actions.attack.interval-millis", 500) / 50.0));
        // 反作弊兼容：攻击间隔加入 ±25% 抖动，避免完美固定的机器人节奏。
        int jitter = intervalTicks / 4;
        if (jitter > 0) intervalTicks += ThreadLocalRandom.current().nextInt(-jitter, jitter + 1);
        attackCooldown = Math.max(1, intervalTicks) - 1;
        Direction direction = direction();
        double reach = config.decimal("features.actions.attack.reach-blocks", 3.0);
        // 左键攻击包必须包含实体 ID，所以仍需从服务端同步的实体中选择一个目标；但不再用方块距离
        // 截断判定，并允许紧贴假人的实体命中，避免碰撞箱边缘造成“只挥手、不攻击”。
        EntityTracker.EntityHit entity = entities.leftClickTarget(
                x, eyeY(), z, direction.x, direction.y, direction.z, reach);
        // 原版顺序是先提交攻击交互，再播放主手挥动；部分战斗检查依赖该顺序。
        if (entity != null) host.attack(entity.entityId());
        host.swing();
        if (!attackContinuous) attackRemaining--;
    }

    private void tickDestroy() {
        if (!destroyContinuous && destroyRemaining <= 0) return;
        Direction direction = direction();
        double reach = config.decimal("features.actions.destroy.reach-blocks", 4.5);
        ClientWorld.BlockHit aimed = world.raycastBlock(x, eyeY(), z, direction.x, direction.y, direction.z, reach);
        if (destroyTarget != null && !sameBlock(destroyTarget, aimed)) {
            host.cancelDig(destroyTarget.x(), destroyTarget.y(), destroyTarget.z(), destroyTarget.face());
            destroyTarget = null; destroyTicksRemaining = 0; destroyRetry = 0;
        }
        if (destroyRetry-- > 0) return;
        if (destroyTarget == null) {
            destroyTarget = aimed;
            if (destroyTarget == null) {
                destroyRetry = Math.max(1, config.integer("features.actions.destroy.no-target-retry-millis", 300) / 50);
                swingDestroyArm();
                return;
            }
            destroyTicksRemaining = BlockRegistry.INSTANCE.breakTicks(
                    destroyTarget.state(), host.heldItemId(), onGround,
                    Math.max(1, config.integer("features.actions.destroy.max-hold-ticks", 240)));
            // 原版顺序：先发送 START，再挥手。反过来会被部分数据包检查视为无目标挥手。
            if (!host.startDig(destroyTarget.x(), destroyTarget.y(), destroyTarget.z(), destroyTarget.face())) {
                destroyTarget = null; return;
            }
            swingDestroyArm();
        } else {
            swingDestroyArm();
        }

        if (destroyTicksRemaining < 0) {
            // 原版对基岩等不可破坏方块只保持左键，不会伪造 FINISH；有限次数在安全上限后松开。
            if (destroyContinuous || ++destroyTicksRemaining < 0) return;
            host.cancelDig(destroyTarget.x(), destroyTarget.y(), destroyTarget.z(), destroyTarget.face());
            destroyTarget = null; destroyRemaining--; destroyRetry = 3;
            return;
        }
        if (--destroyTicksRemaining > 0) return;
        host.finishDig(destroyTarget.x(), destroyTarget.y(), destroyTarget.z(), destroyTarget.face());
        // 不提前把本地区块强制改成空气。刷石机可能在同一服务端 tick 生成新圆石，客户端预测
        // 会覆盖那次真实更新，随后便只能一直挥手。下一轮直接按当前服务端区块快照继续按住左键。
        destroyTarget = null;
        if (!destroyContinuous) destroyRemaining--;
        destroyRetry = Math.max(1, config.integer("features.actions.destroy.next-block-delay-millis", 150) / 50);
    }

    /** 模拟一次完整右键：优先对准星方块交互，未命中时使用手中物品，兼容船等 use 型物品。 */
    private void tickPut() {
        if (!putContinuous && putRemaining <= 0) return;
        if (putCooldown-- > 0) return;
        putCooldown = Math.max(1, config.integer("features.actions.put.interval-millis", 250) / 50) - 1;
        Direction direction = direction();
        double reach = config.decimal("features.actions.put.reach-blocks", 4.5);
        ClientWorld.BlockHit target = world.raycastBlock(x, eyeY(), z,
                direction.x, direction.y, direction.z, reach);
        host.place(target, yaw, pitch);
        if (!putContinuous) putRemaining--;
    }

    private void swingDestroyArm() {
        int swingInterval = Math.max(1, config.integer("features.actions.destroy.swing-interval-ticks", 4));
        if (destroySwingTick++ % swingInterval == 0) host.swing();
    }

    private boolean sameBlock(ClientWorld.BlockHit first, ClientWorld.BlockHit second) {
        return second != null && first.x() == second.x() && first.y() == second.y() && first.z() == second.z();
    }

    private void cancelDestroy() {
        if (destroyTarget != null) host.cancelDig(destroyTarget.x(), destroyTarget.y(), destroyTarget.z(), destroyTarget.face());
        destroyTarget = null; destroyTicksRemaining = 0;
    }

    private void resetMotion() {
        velocityX = velocityY = velocityZ = 0; movementTicks = 0; movementDirection = 0;
        jumpQueued = false; jumpQueueTicks = 0; jumpInputSent = false; onGround = false;
        cancelDestroy(); attackRemaining = destroyRemaining = putRemaining = 0;
        putContinuous = false; putCooldown = 0; mountedVehicleId = Integer.MIN_VALUE; dismountInputTicks = 0;
        cancelNavigationInternal(); autoLookMode = ""; autoLookFilter = "";
    }

    public synchronized NavigationResult navigateTo(double targetX, double targetY, double targetZ,
                                                     double maximumDistance, int maximumExpandedNodes) {
        if (!enabled() || !located) return NavigationResult.NOT_READY;
        double dx = targetX - x, dy = targetY - y, dz = targetZ - z;
        if (Math.sqrt(dx * dx + dy * dy + dz * dz) > maximumDistance) return NavigationResult.TOO_FAR;
        if (dx * dx + dz * dz <= 1.7 * 1.7 && Math.abs(dy) <= 0.75) {
            cancelNavigationInternal();
            return NavigationResult.ARRIVED;
        }
        // 目标可在当前视距之外（move here 最远 100 格）。原版客户端同样只能依据已加载区块
        // 行走，因此先规划到视距内的分段点；BotManager 会在新区块加载后继续重算下一段。
        double planX = targetX, planY = targetY, planZ = targetZ;
        if (!world.loadedAt(planX, planZ)) {
            double horizontal = Math.hypot(dx, dz);
            double segment = Math.min(horizontal,
                    Math.max(4.0, config.decimal("performance.pathfinding-segment-blocks", 24.0)));
            boolean foundLoadedSegment = false;
            while (segment >= 2.0 && horizontal > 1.0E-6) {
                double ratio = segment / horizontal;
                planX = x + dx * ratio;
                planY = y + dy * ratio;
                planZ = z + dz * ratio;
                if (world.loadedAt(planX, planZ)) { foundLoadedSegment = true; break; }
                segment -= 2.0;
            }
            if (!foundLoadedSegment) return NavigationResult.NO_PATH;
        }
        List<ClientWorld.PathPoint> path = world.findPath(x, y, z, planX, planY, planZ,
                maximumDistance, maximumExpandedNodes);
        if (path.isEmpty()) return NavigationResult.NO_PATH;
        navigationPath = path;
        navigationIndex = 0;
        navigationTargetX = targetX; navigationTargetY = targetY; navigationTargetZ = targetZ;
        navigationActive = true;
        movementDirection = 'W'; movementTicks = Integer.MAX_VALUE;
        navigationStuckTicks = 0; navigationLastX = x; navigationLastZ = z;
        return NavigationResult.STARTED;
    }

    public synchronized void cancelNavigation() { cancelNavigationInternal(); }

    private void cancelNavigationInternal() {
        navigationActive = false;
        navigationPath = List.of();
        navigationIndex = 0;
        navigationTraversal = ClientWorld.PathPoint.Traversal.WALK;
        navigationStuckTicks = 0;
        if (movementTicks == Integer.MAX_VALUE) movementTicks = 0;
        if (movementDirection == 'W') movementDirection = 0;
        host.input((char) 0, jumpInputSent, false, false);
    }

    public synchronized boolean autoLook(String mode, String filter) {
        if (mode == null || mode.isBlank()) {
            autoLookMode = ""; autoLookFilter = ""; return true;
        }
        if (!mode.equalsIgnoreCase("all") && !mode.equalsIgnoreCase("summer")) return false;
        autoLookMode = mode.toLowerCase(java.util.Locale.ROOT);
        autoLookFilter = filter == null ? "" : filter.strip();
        autoLookCooldown = 0;
        return true;
    }

    public synchronized ClientWorld.ContainerTarget nearbyContainer(double reach) {
        return !located ? null : world.nearestContainer(x, eyeY(), z, reach);
    }

    public synchronized EntityTracker.RideTarget nearbyRideable(double reach) {
        return !located ? null : entities.nearestRideable(x, eyeY(), z, reach);
    }

    public synchronized boolean mounted() { return mountedVehicleId != Integer.MIN_VALUE; }

    public synchronized boolean dismount() {
        if (!located || mountedVehicleId == Integer.MIN_VALUE) return false;
        // 保持两个客户端 tick，确保在代理调度抖动时服务端仍能收到一次 Shift 按下，再由后续 tick 释放。
        dismountInputTicks = 2;
        return true;
    }

    public synchronized float[] lookAt(double targetX, double targetY, double targetZ) {
        double dx = targetX - x, dz = targetZ - z;
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(targetY - eyeY(), Math.hypot(dx, dz)));
        return new float[]{targetYaw, Math.max(-90, Math.min(90, targetPitch))};
    }

    public String dimension() { return world.dimension(); }
    public int worldMinY() { return world.minY(); }
    public int worldHeight() { return world.height(); }

    private Aabb playerBox() { return new Aabb(x - PLAYER_HALF_WIDTH, y, z - PLAYER_HALF_WIDTH, x + PLAYER_HALF_WIDTH, y + PLAYER_HEIGHT, z + PLAYER_HALF_WIDTH); }
    private double eyeY() { return y + config.decimal("client-simulation.physics.eye-height", 1.62); }
    private boolean enabled() { return config.bool("client-simulation.enabled", true); }
    private double clamp(double value, double minimum, double maximum) { return Math.max(minimum, Math.min(maximum, value)); }
    private Direction direction() {
        float yawRadians = yaw * ((float) Math.PI / 180.0F), pitchRadians = pitch * ((float) Math.PI / 180.0F);
        double horizontal = VanillaMath.cos(pitchRadians);
        return new Direction(-VanillaMath.sin(yawRadians) * horizontal,
                -VanillaMath.sin(pitchRadians), VanillaMath.cos(yawRadians) * horizontal);
    }

    private record DimensionSettings(int minY, int height, String effects) { }

    private record Direction(double x, double y, double z) { }

    public interface Host {
        boolean movement(double x, double y, double z, float yaw, float pitch, boolean onGround, boolean horizontalCollision);
        void trackedPosition(double x, double y, double z, float yaw, float pitch);
        boolean input(char direction, boolean jump, boolean shift, boolean sprint);
        boolean rotation(float yaw, float pitch);
        boolean swing();
        boolean attack(int entityId);
        boolean startDig(int x, int y, int z, int face);
        boolean finishDig(int x, int y, int z, int face);
        boolean cancelDig(int x, int y, int z, int face);
        boolean place(ClientWorld.BlockHit target, float yaw, float pitch);
        int heldItemId();
    }

    public enum NavigationResult { STARTED, ARRIVED, NO_PATH, TOO_FAR, NOT_READY }
}
