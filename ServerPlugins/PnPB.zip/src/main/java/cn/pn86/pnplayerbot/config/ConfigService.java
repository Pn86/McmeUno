package cn.pn86.pnplayerbot.config;

import org.slf4j.Logger;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ConfigService {
    private final Path dataDirectory;
    private final Logger logger;
    private final Yaml yaml;
    private volatile Map<String, Object> config = Map.of();
    private volatile Map<String, Object> messages = Map.of();

    public ConfigService(Path dataDirectory, Logger logger) {
        this.dataDirectory = dataDirectory;
        this.logger = logger;
        LoaderOptions loader = new LoaderOptions();
        loader.setMaxAliasesForCollections(50);
        DumperOptions dumper = new DumperOptions();
        dumper.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        dumper.setPrettyFlow(true);
        dumper.setIndent(2);
        this.yaml = new Yaml(new SafeConstructor(loader), new Representer(dumper), dumper, loader);
    }

    public synchronized void initialize() throws IOException {
        Files.createDirectories(dataDirectory);
        copyDefault("config.yml");
        copyDefault("message.yml");
        copyDefault("player.yml");
        migrateMiniMessageFile();
        reload();
    }

    /** 1.4.0 起语言文件改用 & 颜色；只转换明确包含旧标准颜色标签的已有文件，并保留备份。 */
    private void migrateMiniMessageFile() throws IOException {
        Path file = dataDirectory.resolve("message.yml");
        String source = Files.readString(file, StandardCharsets.UTF_8);
        if (!(source.contains("<red>") || source.contains("<yellow>") || source.contains("<green>")
                || source.contains("<aqua>") || source.contains("<gray>") || source.contains("<gold>"))) return;
        String migrated = source
                .replace("<black>", "&0").replace("<dark_blue>", "&1")
                .replace("<dark_green>", "&2").replace("<dark_aqua>", "&3")
                .replace("<dark_red>", "&4").replace("<dark_purple>", "&5")
                .replace("<gold>", "&6").replace("<gray>", "&7")
                .replace("<dark_gray>", "&8").replace("<blue>", "&9")
                .replace("<green>", "&a").replace("<aqua>", "&b")
                .replace("<red>", "&c").replace("<light_purple>", "&d")
                .replace("<yellow>", "&e").replace("<white>", "&f")
                .replace("<bold>", "&l").replace("<italic>", "&o")
                .replace("<underlined>", "&n").replace("<strikethrough>", "&m")
                .replace("<reset>", "&r").replace("&lt;", "<").replace("&gt;", ">");
        migrated = migrated.replaceAll("</(?:black|dark_blue|dark_green|dark_aqua|dark_red|dark_purple|gold|gray|dark_gray|blue|green|aqua|red|light_purple|yellow|white|bold|italic|underlined|strikethrough|reset)>", "");
        Path backup = dataDirectory.resolve("message.yml.minimessage.bak");
        if (!Files.exists(backup)) Files.copy(file, backup, StandardCopyOption.COPY_ATTRIBUTES);
        Files.writeString(file, migrated, StandardCharsets.UTF_8);
        logger.info("已将旧版 message.yml 的 MiniMessage 颜色转换为 & 颜色，原文件备份为 message.yml.minimessage.bak");
    }

    public synchronized void reload() throws IOException {
        Map<String, Object> resource = loadResourceMap("config.yml");
        Map<String, Object> user = loadMap(dataDirectory.resolve("config.yml"));
        Map<String, Object> merged = merge(resource, user);
        // 协议版本与包编号由 JAR 内置数据决定，升级插件后必须跟随新版本，
        // 避免用户目录里旧的 1.21.8 config.yml 覆盖新协议造成假人无法加入。
        forceResourceSection(merged, resource, "protocol-packets");
        forceResourceKeys(merged, resource, "connection", "protocol-version", "minecraft-version");
        config = Collections.unmodifiableMap(merged);
        messages = Collections.unmodifiableMap(merge(loadResourceMap("message.yml"), loadMap(dataDirectory.resolve("message.yml"))));
        validate();
    }

    @SuppressWarnings("unchecked")
    private void forceResourceSection(Map<String, Object> merged, Map<String, Object> resource, String section) {
        Object value = resource.get(section);
        if (value instanceof Map<?, ?> map) merged.put(section, stringMap(map));
    }

    @SuppressWarnings("unchecked")
    private void forceResourceKeys(Map<String, Object> merged, Map<String, Object> resource, String section, String... keys) {
        Object sectionValue = resource.get(section);
        if (!(sectionValue instanceof Map<?, ?> map)) return;
        Map<String, Object> resourceSection = stringMap(map);
        Object mergedSection = merged.get(section);
        if (!(mergedSection instanceof Map<?, ?>)) return;
        Map<String, Object> target = (Map<String, Object>) mergedSection;
        for (String key : keys) {
            Object value = resourceSection.get(key);
            if (value != null) target.put(key, value);
        }
    }

    private Map<String, Object> loadResourceMap(String name) throws IOException {
        try (InputStream input = ConfigService.class.getClassLoader().getResourceAsStream(name)) {
            if (input == null) throw new IOException("JAR 中缺少默认资源：" + name);
            try (Reader reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
                Object value = yaml.load(reader);
                return value instanceof Map<?, ?> map ? stringMap(map) : new LinkedHashMap<>();
            }
        }
    }

    /** 递归补齐新版本默认键，同时始终保留用户文件中已经存在的值。 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> merge(Map<String, Object> defaults, Map<String, Object> user) {
        Map<String, Object> result = new LinkedHashMap<>(defaults);
        for (Map.Entry<String, Object> entry : user.entrySet()) {
            Object before = result.get(entry.getKey()), value = entry.getValue();
            if (before instanceof Map<?, ?> defaultMap && value instanceof Map<?, ?> userMap) {
                result.put(entry.getKey(), merge((Map<String, Object>) defaultMap, (Map<String, Object>) userMap));
            } else result.put(entry.getKey(), value);
        }
        return result;
    }

    private Map<String, Object> loadMap(Path path) throws IOException {
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            Object value = yaml.load(reader);
            if (value == null) return new LinkedHashMap<>();
            if (!(value instanceof Map<?, ?> source)) {
                throw new IOException(path.getFileName() + " 的根节点必须是 YAML 映射");
            }
            return stringMap(source);
        }
    }

    private Map<String, Object> stringMap(Map<?, ?> source) {
        Map<String, Object> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(String.valueOf(key), normalize(value)));
        return result;
    }

    private Object normalize(Object value) {
        if (value instanceof Map<?, ?> map) return stringMap(map);
        if (value instanceof List<?> list) {
            List<Object> result = new ArrayList<>(list.size());
            for (Object item : list) result.add(normalize(item));
            return result;
        }
        return value;
    }

    private void validate() {
        if (integer("connection.protocol-version", 772) <= 0) {
            throw new IllegalArgumentException("connection.protocol-version 必须大于 0");
        }
        int port = integer("connection.port", 25577);
        if (port < 1 || port > 65535) throw new IllegalArgumentException("connection.port 无效");
        ZoneId.of(string("daily-reset.time-zone", "Asia/Shanghai"));
        LocalTime.parse(string("daily-reset.time", "04:00"));
        if (longValue("daily-reset.initial-balance-minutes", 120) < 0) {
            throw new IllegalArgumentException("daily-reset.initial-balance-minutes 不得小于 0");
        }
    }

    private void copyDefault(String name) throws IOException {
        Path target = dataDirectory.resolve(name);
        if (Files.exists(target)) return;
        try (InputStream input = ConfigService.class.getClassLoader().getResourceAsStream(name)) {
            if (input == null) throw new IOException("JAR 中缺少默认资源：" + name);
            Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public Path dataDirectory() {
        return dataDirectory;
    }

    public boolean bool(String path, boolean fallback) {
        Object value = find(config, path);
        if (value instanceof Boolean b) return b;
        if (value != null) return Boolean.parseBoolean(String.valueOf(value));
        return fallback;
    }

    public int integer(String path, int fallback) {
        long value = longValue(path, fallback);
        return value > Integer.MAX_VALUE ? Integer.MAX_VALUE : value < Integer.MIN_VALUE ? Integer.MIN_VALUE : (int) value;
    }

    public long longValue(String path, long fallback) {
        Object value = find(config, path);
        if (value instanceof Number number) return number.longValue();
        if (value != null) {
            try { return Long.parseLong(String.valueOf(value)); } catch (NumberFormatException ignored) { }
        }
        return fallback;
    }

    public double decimal(String path, double fallback) {
        Object value = find(config, path);
        if (value instanceof Number number) return number.doubleValue();
        if (value != null) {
            try { return Double.parseDouble(String.valueOf(value)); } catch (NumberFormatException ignored) { }
        }
        return fallback;
    }

    public String string(String path, String fallback) {
        Object value = find(config, path);
        return value == null ? fallback : String.valueOf(value);
    }

    public List<String> stringList(String path) {
        Object value = find(config, path);
        if (!(value instanceof List<?> list)) return List.of();
        return list.stream().map(String::valueOf).toList();
    }

    public String message(String key, String fallback) {
        Object value = find(messages, key);
        return value == null ? fallback : String.valueOf(value);
    }

    public List<String> messageLines(String key, String fallback) {
        Object value = find(messages, key);
        if (value instanceof List<?> list) return list.stream().map(String::valueOf).toList();
        return List.of(value == null ? fallback : String.valueOf(value));
    }

    public boolean debug() {
        return bool("general.debug", false);
    }

    public boolean isServerAllowed(String server) {
        String normalized = server.toLowerCase(Locale.ROOT);
        List<String> allowed = stringList("server-policy.allowed-servers").stream()
                .map(s -> s.toLowerCase(Locale.ROOT)).toList();
        List<String> denied = stringList("server-policy.denied-servers").stream()
                .map(s -> s.toLowerCase(Locale.ROOT)).toList();
        if (denied.contains(normalized)) return false;
        return !string("server-policy.mode", "allow-list").equalsIgnoreCase("allow-list") || allowed.contains(normalized);
    }

    public boolean isCommandAllowed(String command) {
        String normalized = command.strip().toLowerCase(Locale.ROOT);
        if (normalized.startsWith("/")) normalized = normalized.substring(1);
        String first = normalized.split("\\s+", 2)[0];
        for (String blocked : stringList("commands.blocked-prefixes")) {
            if (first.equals(blocked.toLowerCase(Locale.ROOT))) return false;
        }
        if (bool("commands.allow-by-default", true)) return true;
        for (String allowed : stringList("commands.allowed-prefixes")) {
            if (first.equals(allowed.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private Object find(Map<String, Object> root, String path) {
        Object current = root;
        for (String part : path.split("\\.")) {
            if (!(current instanceof Map<?, ?> map)) return null;
            current = ((Map<String, Object>) map).get(part);
        }
        return current;
    }

    public void logDebug(String text, Object... args) {
        if (debug()) logger.info("[调试] " + text, args);
    }
}
