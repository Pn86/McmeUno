package cn.pn86.pnplayerbot.simulation;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.PositionElement;
import org.geysermc.mcprotocollib.protocol.data.game.entity.type.EntityType;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundAddEntityPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundEntityPositionSyncPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundMoveEntityPosPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundMoveEntityPosRotPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundRemoveEntitiesPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundTeleportEntityPacket;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class EntityTracker {
    private final EntityRegistry registry = EntityRegistry.INSTANCE;
    private final Map<Integer, Tracked> entities = new ConcurrentHashMap<>();
    private volatile int selfEntityId = Integer.MIN_VALUE;

    public void selfEntityId(int value) { selfEntityId = value; entities.remove(value); }
    public void clear() { entities.clear(); }

    public void acceptAdd(byte[] payload) {
        with(payload, buffer -> {
            ClientboundAddEntityPacket packet = new ClientboundAddEntityPacket(buffer);
            if (packet.getEntityId() == selfEntityId) return;
            // 玩家实体使用固定原版碰撞箱，避免实体数据表版本差异导致 PLAYER 被当成不可攻击实体。
            EntityRegistry.Definition definition = packet.getType() == EntityType.PLAYER
                    ? EntityRegistry.PLAYER : registry.definition(packet.getType());
            entities.put(packet.getEntityId(), Tracked.spawn(packet.getEntityId(), definition,
                    packet.getX(), packet.getY(), packet.getZ(), packet.getYaw(), packet.getPitch()));
        });
    }

    public void acceptRelativePosition(byte[] payload, boolean rotation) {
        with(payload, buffer -> {
            if (rotation) {
                ClientboundMoveEntityPosRotPacket packet = new ClientboundMoveEntityPosRotPacket(buffer);
                entities.computeIfPresent(packet.getEntityId(), (id, entity) -> entity.move(
                        delta(packet.getMoveX()), delta(packet.getMoveY()), delta(packet.getMoveZ()),
                        packet.getYaw(), packet.getPitch()));
            } else {
                ClientboundMoveEntityPosPacket packet = new ClientboundMoveEntityPosPacket(buffer);
                entities.computeIfPresent(packet.getEntityId(), (id, entity) -> entity.move(
                        delta(packet.getMoveX()), delta(packet.getMoveY()), delta(packet.getMoveZ()),
                        entity.yaw, entity.pitch));
            }
        });
    }

    public void acceptSync(byte[] payload) {
        with(payload, buffer -> {
            ClientboundEntityPositionSyncPacket packet = new ClientboundEntityPositionSyncPacket(buffer);
            entities.computeIfPresent(packet.getId(), (id, entity) -> entity.at(packet.getPosition().getX(),
                    packet.getPosition().getY(), packet.getPosition().getZ(), packet.getYRot(), packet.getXRot()));
        });
    }

    public void acceptTeleport(byte[] payload) {
        with(payload, buffer -> {
            ClientboundTeleportEntityPacket packet = new ClientboundTeleportEntityPacket(buffer);
            entities.computeIfPresent(packet.getId(), (id, entity) -> {
                double x = packet.getPosition().getX(), y = packet.getPosition().getY(), z = packet.getPosition().getZ();
                float yaw = packet.getYRot(), pitch = packet.getXRot();
                if (packet.getRelatives().contains(PositionElement.X)) x += entity.x;
                if (packet.getRelatives().contains(PositionElement.Y)) y += entity.y;
                if (packet.getRelatives().contains(PositionElement.Z)) z += entity.z;
                if (packet.getRelatives().contains(PositionElement.Y_ROT)) yaw += entity.yaw;
                if (packet.getRelatives().contains(PositionElement.X_ROT)) pitch += entity.pitch;
                return entity.snap(x, y, z, yaw, pitch);
            });
        });
    }

    public void acceptRemove(byte[] payload) {
        with(payload, buffer -> {
            for (int id : new ClientboundRemoveEntitiesPacket(buffer).getEntityIds()) entities.remove(id);
        });
    }

    public EntityHit raycast(double ox, double oy, double oz, double dx, double dy, double dz, double reach, double blockDistance) {
        EntityHit closest = null;
        double maximum = Math.min(reach, blockDistance);
        for (Tracked entity : entities.values()) {
            if (!entity.definition.attackable()) continue;
            double half = entity.definition.width() / 2.0;
            Aabb box = new Aabb(entity.x - half, entity.y, entity.z - half,
                    entity.x + half, entity.y + entity.definition.height(), entity.z + half).inflate(0.1);
            double distance = box.rayDistance(ox, oy, oz, dx, dy, dz, maximum);
            if (Double.isFinite(distance) && (closest == null || distance < closest.distance)) {
                closest = new EntityHit(entity.id, distance);
                maximum = distance;
            }
        }
        return closest;
    }

    /**
     * 模拟按下左键时的目标选择：当前碰撞箱精确命中优先，其次检查最近 0.3 秒内移动路径形成的
     * 插值碰撞箱，最后只对真正贴身的实体容错。服务端攻击协议必须携带实体 ID，无法发送无目标左键。
     */
    public EntityHit leftClickTarget(double ox, double oy, double oz, double dx, double dy, double dz, double reach) {
        EntityHit exact = raycast(ox, oy, oz, dx, dy, dz, reach, reach);
        if (exact != null) return exact;

        EntityHit interpolated = null;
        double maximum = reach;
        long now = System.nanoTime();
        for (Tracked entity : entities.values()) {
            if (!entity.definition.attackable() || now - entity.updatedNanos > 300_000_000L || !entity.moved()) continue;
            double distance = entity.sweptBox().inflate(0.1).rayDistance(ox, oy, oz, dx, dy, dz, maximum);
            if (Double.isFinite(distance) && (interpolated == null || distance < interpolated.distance)) {
                interpolated = new EntityHit(entity.id, distance);
                maximum = distance;
            }
        }
        if (interpolated != null) return interpolated;

        EntityHit closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (Tracked entity : entities.values()) {
            if (!entity.definition.attackable()) continue;
            double half = entity.definition.width() / 2.0;
            Aabb box = new Aabb(entity.x - half, entity.y, entity.z - half,
                    entity.x + half, entity.y + entity.definition.height(), entity.z + half).inflate(0.15);
            double px = clamp(ox, box.minX(), box.maxX());
            double py = clamp(oy, box.minY(), box.maxY());
            double pz = clamp(oz, box.minZ(), box.maxZ());
            double vx = px - ox, vy = py - oy, vz = pz - oz;
            double distanceSquared = vx * vx + vy * vy + vz * vz;
            if (distanceSquared > 0.85 * 0.85 || distanceSquared >= closestDistance) continue;

            double distance = Math.sqrt(distanceSquared);
            if (distance > 0.1) {
                // 贴身容错也不能明显打到身后的实体，避免多个生物重叠时携带错误的实体 ID。
                double dot = vx * dx + vy * dy + vz * dz;
                if (dot / distance < -0.15) continue;
            }
            closestDistance = distanceSquared;
            closest = new EntityHit(entity.id, distance);
        }
        return closest;
    }

    /** 为自动视角选择最近目标。summer 仅包含生物，all 包含玩家及其他可交互实体。 */
    public LookTarget lookTarget(double ox, double oy, double oz, double maximumDistance,
                                 String mode, String filter) {
        LookTarget closest = null;
        double maximumSquared = maximumDistance * maximumDistance;
        Integer entityIdFilter = parseEntityId(filter);
        String typeFilter = normalizeType(filter);
        for (Tracked entity : entities.values()) {
            boolean allowed = mode.equalsIgnoreCase("summer")
                    ? entity.definition.living() && !entity.definition.player()
                    : entity.definition.width() > 0 && entity.definition.height() > 0;
            if (!allowed) continue;
            if (entityIdFilter != null && entity.id != entityIdFilter) continue;
            if (entityIdFilter == null && !typeFilter.isBlank()
                    && !entity.definition.name().equalsIgnoreCase(typeFilter)) continue;
            double targetY = entity.y + entity.definition.height() * 0.55;
            double dx = entity.x - ox, dy = targetY - oy, dz = entity.z - oz;
            double distanceSquared = dx * dx + dy * dy + dz * dz;
            if (distanceSquared < 1.0E-6 || distanceSquared > maximumSquared) continue;
            maximumSquared = distanceSquared;
            closest = new LookTarget(entity.id, entity.definition.name(), entity.x, targetY, entity.z,
                    Math.sqrt(distanceSquared));
        }
        return closest;
    }

    /** 选择交互距离内最近的可骑乘实体；是否能实际乘坐仍由子服按原版规则判定。 */
    public RideTarget nearestRideable(double ox, double oy, double oz, double maximumDistance) {
        RideTarget closest = null;
        double maximumSquared = maximumDistance * maximumDistance;
        for (Tracked entity : entities.values()) {
            if (!isRideable(entity.definition.name())) continue;
            double targetY = entity.y + Math.min(entity.definition.height() * 0.5, 1.5);
            double dx = entity.x - ox, dy = targetY - oy, dz = entity.z - oz;
            double distanceSquared = dx * dx + dy * dy + dz * dz;
            if (distanceSquared > maximumSquared) continue;
            maximumSquared = distanceSquared;
            closest = new RideTarget(entity.id, entity.definition.name(), entity.x, targetY, entity.z,
                    Math.sqrt(distanceSquared));
        }
        return closest;
    }

    private boolean isRideable(String name) {
        return name.endsWith("_boat") || name.equals("horse") || name.equals("skeleton_horse")
                || name.equals("zombie_horse") || name.equals("donkey") || name.equals("mule")
                || name.equals("camel") || name.equals("happy_ghast");
    }

    private Integer parseEntityId(String filter) {
        if (filter == null || filter.isBlank()) return null;
        try { return Integer.parseInt(filter); }
        catch (NumberFormatException ignored) { return null; }
    }

    private String normalizeType(String filter) {
        if (filter == null || filter.isBlank() || parseEntityId(filter) != null) return "";
        String value = filter.strip().toLowerCase(java.util.Locale.ROOT);
        int separator = value.indexOf(':');
        return separator >= 0 ? value.substring(separator + 1) : value;
    }

    private double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    /** 相对移动包中的坐标增量已由 mcprotocollib 解码为实际偏移量（double），直接使用即可。 */
    private static double delta(double raw) {
        return raw;
    }

    private void with(byte[] payload, BufferReader reader) {
        ByteBuf buffer = Unpooled.wrappedBuffer(payload);
        try { reader.read(buffer); } finally { buffer.release(); }
    }

    private record Tracked(int id, EntityRegistry.Definition definition,
                           double x, double y, double z, float yaw, float pitch,
                           double previousX, double previousY, double previousZ, long updatedNanos) {
        private static Tracked spawn(int id, EntityRegistry.Definition definition,
                                     double x, double y, double z, float yaw, float pitch) {
            return new Tracked(id, definition, x, y, z, yaw, pitch, x, y, z, System.nanoTime());
        }
        private Tracked move(double dx, double dy, double dz, float yaw, float pitch) {
            return at(x + dx, y + dy, z + dz, yaw, pitch);
        }
        private Tracked at(double x, double y, double z, float yaw, float pitch) {
            return new Tracked(id, definition, x, y, z, yaw, pitch,
                    this.x, this.y, this.z, System.nanoTime());
        }
        private Tracked snap(double x, double y, double z, float yaw, float pitch) {
            return new Tracked(id, definition, x, y, z, yaw, pitch, x, y, z, System.nanoTime());
        }
        private boolean moved() {
            return Math.abs(x - previousX) > 1.0E-7 || Math.abs(y - previousY) > 1.0E-7 || Math.abs(z - previousZ) > 1.0E-7;
        }
        private Aabb sweptBox() {
            double half = definition.width() / 2.0;
            return new Aabb(Math.min(x, previousX) - half, Math.min(y, previousY), Math.min(z, previousZ) - half,
                    Math.max(x, previousX) + half, Math.max(y, previousY) + definition.height(), Math.max(z, previousZ) + half);
        }
    }
    public record EntityHit(int entityId, double distance) { }
    public record LookTarget(int entityId, String type, double x, double y, double z, double distance) { }
    public record RideTarget(int entityId, String type, double x, double y, double z, double distance) { }
    @FunctionalInterface private interface BufferReader { void read(ByteBuf buffer); }
}
