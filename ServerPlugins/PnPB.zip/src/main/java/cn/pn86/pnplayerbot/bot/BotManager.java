package cn.pn86.pnplayerbot.bot;

import cn.pn86.pnplayerbot.config.ConfigService;
import cn.pn86.pnplayerbot.config.MessageService;
import cn.pn86.pnplayerbot.data.PlayerData;
import cn.pn86.pnplayerbot.data.PlayerStore;
import cn.pn86.pnplayerbot.data.WorkStep;
import cn.pn86.pnplayerbot.simulation.ClientSimulation;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.connection.PreLoginEvent;
import com.velocitypowered.api.event.player.PlayerChooseInitialServerEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;

import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class BotManager implements AutoCloseable {
    private final Object plugin;
    private final ProxyServer proxy;
    private final ConfigService config;
    private final MessageService messages;
    private final PlayerStore store;
    private final Logger logger;
    private final Map<String, BotSession> byOwner = new ConcurrentHashMap<>();
    private final Map<String, BotSession> byBot = new ConcurrentHashMap<>();
    private final Map<String, BotSession> pending = new ConcurrentHashMap<>();
    private final Map<String, OwnerMotion> ownerMotions = new ConcurrentHashMap<>();
    private final ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(2, r -> {
        Thread t = new Thread(r, "PnPlayerBot-Scheduler"); t.setDaemon(true); return t;
    });
    private final AtomicBoolean closed = new AtomicBoolean();
    private volatile ScheduledFuture<?> billingFuture;
    private volatile ScheduledFuture<?> dailyResetFuture;
    private volatile ScheduledFuture<?> clientTickFuture;
    private volatile ScheduledFuture<?> autosaveFuture;
    private volatile Runnable serverApiRestart;

    public BotManager(Object plugin, ProxyServer proxy, ConfigService config, MessageService messages,
                      PlayerStore store, Logger logger) {
        this.plugin = plugin;
        this.proxy = proxy;
        this.config = config;
        this.messages = messages;
        this.store = store;
        this.logger = logger;
        scheduler.setRemoveOnCancelPolicy(true);
    }

    public void startTasks() {
        reschedulePeriodicTasks();
        dailyResetTick();
        if (config.bool("general.restore-active-bots-after-restart", false)) restoreBots();
        else {
            for (PlayerData data : store.all().values()) data.desiredActive(false);
            store.markDirty(false);
        }
    }

    public StartResult start(Player owner) {
        String ownerKey = key(owner.getUsername());
        if (byOwner.containsKey(ownerKey)) return StartResult.ALREADY_RUNNING;
        Optional<String> server = owner.getCurrentServer().map(connection -> connection.getServerInfo().getName());
        if (server.isEmpty()) return StartResult.NOT_ON_SERVER;
        if (!config.isServerAllowed(server.get())) return StartResult.SERVER_NOT_ALLOWED;
        PlayerData data = store.getOrCreate(owner.getUsername());
        if (data.remainingMillis() <= 0) return StartResult.NO_BALANCE;
        if (byOwner.size() >= config.integer("limits.max-total-bots", 50)) return StartResult.GLOBAL_LIMIT;
        if (countOnServer(server.get()) >= config.integer("limits.max-bots-per-server", 20)) return StartResult.SERVER_LIMIT;

        BotSession session = createSession(owner.getUsername(), server.get(), data);
        if (byOwner.putIfAbsent(ownerKey, session) != null) return StartResult.ALREADY_RUNNING;
        byBot.put(key(session.botName), session);
        data.desiredActive(true);
        data.lastServer(server.get());
        store.markDirty(true);
        connect(session);
        messages.send(owner, "starting", "bot", session.botName, "server", session.targetServer);
        return StartResult.STARTED;
    }

    private BotSession createSession(String ownerName, String server, PlayerData data) {
        String ownerKey = key(ownerName);
        String botName = generateBotName(ownerName);
        return new BotSession(ownerName, ownerKey, botName, UUID.randomUUID(), server, data);
    }

    private void connect(BotSession session) {
        if (closed.get() || session.intentionalStop) return;
        int generation = session.generation.incrementAndGet();
        session.status = BotStatus.CONNECTING;
        session.playReady = false;
        session.proxyPlayer = null;
        pending.put(key(session.botName), session);
        MinecraftClient client = new MinecraftClient(config, session.botName, session.loginToken, new MinecraftClient.Listener() {
            private boolean inventoryWarningShown;
            @Override public void configuring() { if (current()) session.status = BotStatus.CONFIGURING; }
            @Override public void playReady() { if (current()) { session.playReady = true; becomeOnlineIfReady(session, generation); } }
            @Override public void position(double x, double y, double z, float yaw, float pitch) {
                if (!current()) return;
                if (!config.bool("tracking.position", true)) return;
                session.x = x; session.y = y; session.z = z; session.yaw = yaw; session.pitch = pitch;
            }
            @Override public void health(float health) {
                if (!current()) return;
                if (!config.bool("tracking.health-and-death", true)) return;
                float previous = session.health;
                session.health = health;
                if (health <= 0 && previous > 0 && config.bool("respawn.enabled", true)) {
                    scheduler.schedule(() -> { if (current() && session.client != null) session.client.respawn(); },
                            Math.max(0, config.longValue("respawn.delay-millis", 500)), TimeUnit.MILLISECONDS);
                }
            }
            @Override public void inventoryFull(java.util.List<InventoryItem> items, int stateId) {
                if (current()) session.inventory.clearAndSet(items, stateId);
            }
            @Override public void inventorySlot(int slot, InventoryItem item, int stateId) {
                if (!current()) return;
                int nextState = stateId < 0 ? session.inventory.stateId() : stateId;
                if (item == null) session.inventory.clear(slot, nextState);
                else session.inventory.set(item, nextState);
            }
            @Override public void containerOpened(int containerId, String type, int storageSlots) {
                if (current()) session.container.open(containerId, type, storageSlots);
            }
            @Override public void containerFull(int containerId, java.util.List<InventoryItem> items, int stateId) {
                if (current()) session.container.clearAndSet(containerId, items, stateId);
            }
            @Override public void containerSlot(int containerId, int slot, InventoryItem item, int stateId) {
                if (current()) session.container.set(containerId, slot, item, stateId);
            }
            @Override public void containerClosed(int containerId) {
                if (current() && session.container.containerId() == containerId) {
                    session.container.close(); session.containerGeneration++;
                }
            }
            @Override public void selectedHotbar(int selected) { if (current()) session.inventory.selectedHotbar(selected); }
            @Override public int inventoryStateId() { return session.inventory.stateId(); }
            @Override public int heldItemId() { return session.inventory.heldItemId(); }
            @Override public void inventoryDecodeError(Throwable error) {
                if (!current()) return;
                if (!inventoryWarningShown) {
                    inventoryWarningShown = true;
                    logger.warn("假人 {} 背包数据解析失败；后续同类错误将只在 debug 中记录：{}", session.botName, error.toString());
                } else config.logDebug("假人 {} 背包数据解析失败：{}", session.botName, error.getMessage());
            }
            @Override public void protocolWarning(String message, Throwable error) {
                if (current()) config.logDebug("假人 {} {}：{}", session.botName, message, error.getMessage());
            }
            @Override public void disconnected(Throwable cause) { handleDisconnect(session, generation, cause); }
            private boolean current() { return generation == session.generation.get() && !session.intentionalStop; }
        });
        session.client = client;
        Thread.ofVirtual().name("PnPlayerBot-Connect-" + session.botName).start(() -> {
            try { client.connect(); }
            catch (Throwable throwable) {
                client.close();
                handleDisconnect(session, generation, throwable);
            }
        });
    }

    public void onPreLogin(PreLoginEvent event) {
        String name = key(event.getUsername());
        BotSession session = pending.get(name);
        if (session != null) {
            InetAddress address = event.getConnection().getRemoteAddress().getAddress();
            UUID supplied = event.getUniqueId();
            boolean validUuid = !config.bool("naming.verify-login-uuid", false)
                    || supplied == null || supplied.equals(session.loginToken);
            if (address != null && address.isLoopbackAddress() && validUuid) {
                event.setResult(PreLoginEvent.PreLoginComponentResult.forceOfflineMode());
            } else {
                event.setResult(PreLoginEvent.PreLoginComponentResult.denied(Component.text("PnPlayerBot internal login rejected")));
            }
            return;
        }
        if (config.bool("naming.protect-reserved-names", true) && isReservedName(event.getUsername())) {
            event.setResult(PreLoginEvent.PreLoginComponentResult.denied(messages.component("reserved-name-kick")));
        }
    }

    public void onChooseServer(PlayerChooseInitialServerEvent event) {
        BotSession session = byBot.get(key(event.getPlayer().getUsername()));
        if (session == null) return;
        RegisteredServer target = proxy.getServer(session.targetServer).orElseGet(() -> {
            String fallback = config.string("server-policy.fallback-server", "");
            return fallback.isBlank() ? null : proxy.getServer(fallback).orElse(null);
        });
        if (target != null) event.setInitialServer(target);
    }

    public void onPostLogin(PostLoginEvent event) {
        BotSession session = byBot.get(key(event.getPlayer().getUsername()));
        if (session == null) return;
        session.proxyPlayer = event.getPlayer();
        pending.remove(key(session.botName), session);
    }

    public void onServerConnected(ServerConnectedEvent event) {
        String server = event.getServer().getServerInfo().getName();
        BotSession session = byBot.get(key(event.getPlayer().getUsername()));
        if (session == null) {
            String ownerKey = key(event.getPlayer().getUsername());
            ownerMotions.compute(ownerKey, (ignored, before) -> before == null
                    ? OwnerMotion.unknown(server)
                    : before.withServer(server, !server.equalsIgnoreCase(before.server)));
            return;
        }
        session.proxyPlayer = event.getPlayer();
        session.connectedServer = server;
        if (!server.equalsIgnoreCase(session.targetServer) || !config.isServerAllowed(server)) {
            MinecraftClient client = session.client;
            if (client != null) client.close();
            return;
        }
        becomeOnlineIfReady(session, session.generation.get());
    }

    private void becomeOnlineIfReady(BotSession session, int generation) {
        if (session.intentionalStop || !session.playReady || session.proxyPlayer == null || session.connectedServer.isBlank()) return;
        if (session.status == BotStatus.ONLINE && session.announcedGeneration == generation) return;
        session.status = BotStatus.ONLINE;
        long now = System.nanoTime();
        long warmup = TimeUnit.SECONDS.toNanos(Math.max(0, config.longValue("billing.warmup-seconds", 10)));
        session.onlineSinceNanos = now;
        session.lastBillingNanos = now + warmup;
        session.announcedGeneration = generation;
        session.data.lastServer(session.connectedServer);
        store.markDirty(false);
        proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "started", "bot", session.botName, "server", session.connectedServer));
        if (session.reconnectAttempts > 0 && !session.data.autoWorks().isBlank()) {
            long delay = Math.max(0, config.longValue("commands.autoworks-delay-millis", 1500));
            long autoWorksToken = ++session.autoWorksGeneration;
            scheduler.schedule(() -> {
                if (generation == session.generation.get() && autoWorksToken == session.autoWorksGeneration
                        && session.status == BotStatus.ONLINE) sendCommand(session, session.data.autoWorks());
            }, delay, TimeUnit.MILLISECONDS);
        }
        session.reconnectAttempts = 0;
        session.reconnectStartedMillis = 0;
        startWorkLoop(session);
    }

    public void onDisconnect(DisconnectEvent event) {
        BotSession session = byBot.get(key(event.getPlayer().getUsername()));
        if (session != null) handleDisconnect(session, session.generation.get(), null);
        else ownerMotions.remove(key(event.getPlayer().getUsername()));
    }

    private void handleDisconnect(BotSession session, int generation, Throwable cause) {
        synchronized (session) {
            if (session.intentionalStop || generation != session.generation.get() || session.lastDisconnectHandledGeneration == generation) return;
            session.lastDisconnectHandledGeneration = generation;
        }
        pending.remove(key(session.botName), session);
        session.proxyPlayer = null;
        session.playReady = false;
        session.connectedServer = "";
        session.actionGeneration++;
        session.attackGeneration++; session.destroyGeneration++; session.useGeneration++; session.putGeneration++;
        session.attackRequestId = 0; session.facingRequestId = 0;
        session.movementGeneration++; session.inventoryGeneration++;
        session.autoWorksGeneration++;
        session.containerGeneration++; session.container.close();
        session.navigationGeneration++; session.followOwner = false; session.navigatingHere = false;
        session.movementActive = false;
        session.workGeneration++;
        if (cause != null) config.logDebug("假人 {} 连接断开：{}", session.botName, cause.getMessage());
        if (!config.bool("reconnect.enabled", true)) { giveUp(session); return; }
        if (session.reconnectStartedMillis == 0) session.reconnectStartedMillis = System.currentTimeMillis();
        int maxAttempts = Math.max(0, config.integer("reconnect.max-attempts", 30));
        long maxDuration = TimeUnit.MINUTES.toMillis(Math.max(0, config.longValue("reconnect.max-duration-minutes", 30)));
        if (session.reconnectAttempts >= maxAttempts || System.currentTimeMillis() - session.reconnectStartedMillis >= maxDuration) {
            giveUp(session); return;
        }
        session.status = BotStatus.RECONNECTING;
        int attempt = ++session.reconnectAttempts;
        proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "reconnecting",
                "attempt", attempt, "max", maxAttempts));
        long base = Math.max(1, config.longValue("reconnect.interval-seconds", 60));
        long jitter = Math.max(0, config.longValue("reconnect.jitter-seconds", 5));
        long delay = base + (jitter == 0 ? 0 : ThreadLocalRandom.current().nextLong(jitter + 1));
        scheduler.schedule(() -> connect(session), delay, TimeUnit.SECONDS);
    }

    private void giveUp(BotSession session) {
        proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "reconnect-give-up"));
        stop(session, false);
    }

    public boolean exit(String ownerName) {
        BotSession session = byOwner.get(key(ownerName));
        if (session == null) return false;
        stop(session, true);
        return true;
    }

    /** 管理员按所有者名称强制结束假人，覆盖在线、连接中和等待重连状态。 */
    public boolean forceStop(String ownerName) {
        BotSession session = byOwner.get(key(ownerName));
        if (session == null) return false;
        stop(session, false);
        logger.warn("管理员强制停止了玩家 {} 的假人 {}", session.ownerName, session.botName);
        return true;
    }

    /** 管理员批量结束当前所有假人，并通过 intentionalStop 使已排队的重连任务失效。 */
    public int forceStopAll() {
        int stopped = 0;
        for (BotSession session : byOwner.values().toArray(BotSession[]::new)) {
            if (session.intentionalStop) continue;
            stop(session, false);
            stopped++;
        }
        logger.warn("管理员强制停止了全部假人，共 {} 个", stopped);
        return stopped;
    }

    private void stop(BotSession session, boolean userRequested) {
        if (session.intentionalStop) return;
        session.intentionalStop = true;
        session.status = BotStatus.STOPPING;
        session.workGeneration++;
        session.autoWorksGeneration++;
        session.navigationGeneration++;
        session.containerGeneration++;
        session.data.desiredActive(false);
        byOwner.remove(session.ownerKey, session);
        byBot.remove(key(session.botName), session);
        pending.remove(key(session.botName), session);
        Player proxyPlayer = session.proxyPlayer;
        MinecraftClient client = session.client;
        if (client != null) client.stopSimulation();
        if (proxyPlayer != null) proxyPlayer.disconnect(Component.text(userRequested ? "PnPlayerBot exit" : "PnPlayerBot stopped"));
        if (client != null) client.close();
        session.status = BotStatus.OFFLINE;
        store.markDirty(true);
    }

    public BotSession session(String ownerName) { return byOwner.get(key(ownerName)); }
    public BotSession sessionByBotName(String botName) { return byBot.get(key(botName)); }
    public Collection<BotSession> sessions() { return byOwner.values(); }

    public synchronized void reloadConfiguration() {
        // 更新周期任务：计费间隔与自动保存间隔可能已被用户修改。
        reschedulePeriodicTasks();
        // ServerApiService 的端口/绑定地址/令牌变更需要重启监听；该职责由主类通过
        // restartServerApi() 回调注入，见 PnPlayerBot.onReload。
        if (serverApiRestart != null) {
            try { serverApiRestart.run(); }
            catch (Exception e) { config.logDebug("重载 ServerApi 监听失败：{}", e.getMessage()); }
        }
    }

    private void reschedulePeriodicTasks() {
        cancelFuture(billingFuture);
        cancelFuture(dailyResetFuture);
        cancelFuture(clientTickFuture);
        cancelFuture(autosaveFuture);

        long billingTick = Math.max(1, config.longValue("billing.tick-seconds", 1));
        billingFuture = scheduler.scheduleAtFixedRate(this::billingTick, billingTick, billingTick, TimeUnit.SECONDS);
        dailyResetFuture = scheduler.scheduleAtFixedRate(this::dailyResetTick, 5, 30, TimeUnit.SECONDS);
        // 客户端 tick 不允许“追赶式”补发：固定频率任务在线程短暂停顿后会瞬间连发多个
        // flying packet，触发 TickTimer。固定延迟保证相邻 tick 至少间隔 50ms。
        clientTickFuture = scheduler.scheduleWithFixedDelay(this::clientSimulationTick, 50, 50, TimeUnit.MILLISECONDS);
        autosaveFuture = store.scheduleAutosave(scheduler);
    }

    private void cancelFuture(ScheduledFuture<?> future) {
        if (future != null) future.cancel(false);
    }

    public synchronized void setServerApiRestart(Runnable restart) { this.serverApiRestart = restart; }

    public boolean sendCommand(BotSession session, String raw) {
        if (session == null || raw == null) return false;
        String command = normalizeCommand(raw);
        if (command.isBlank() || command.length() > config.integer("commands.max-length", 256) || !config.isCommandAllowed(command)) return false;
        if (!allowOperation(session, "command", "performance.command-cooldown-millis", 100)) return false;
        MinecraftClient client = session.client;
        return client != null && client.sendCommand(command);
    }

    public boolean sendMessage(BotSession session, String text) {
        if (!config.bool("features.message.enabled", true) || session == null || text == null) return false;
        String value = text.strip();
        int max = Math.max(1, config.integer("features.message.max-length", 256));
        if (value.isBlank() || value.length() > max || !allowOperation(session, "message", "performance.message-cooldown-millis", 500)) return false;
        Player player = session.proxyPlayer;
        if (player == null || session.status != BotStatus.ONLINE) return false;
        try {
            // 交给 Velocity 3.5 构造并写入后端连接，避免手写签名/确认位集造成解码异常。
            player.spoofChatInput(value);
            return true;
        } catch (RuntimeException error) {
            logger.warn("通过 Velocity 转发假人 {} 聊天失败：{}", session.botName, error.getMessage());
            return false;
        }
    }

    public boolean drop(BotSession session, Integer index, boolean all) {
        if (!config.bool("features.inventory.drop-enabled", true) || !online(session)) return false;
        if (!allowOperation(session, "inventory", "performance.inventory-cooldown-millis", 250)) return false;
        java.util.List<InventoryItem> items = session.inventory.indexedItems();
        if (all) {
            if (items.isEmpty()) return false;
            long token = ++session.inventoryGeneration;
            long interval = Math.max(25, config.longValue("performance.drop-all-interval-millis", 75));
            dropNext(session, items, 0, token, interval);
            return true;
        }
        return index != null && index >= 1 && index <= items.size()
                && session.client.dropInventorySlot(items.get(index - 1).containerSlot());
    }

    public boolean hand(BotSession session, int index) {
        if (!config.bool("features.inventory.hand-enabled", true) || !online(session)
                || !allowOperation(session, "inventory", "performance.inventory-cooldown-millis", 250)) return false;
        java.util.List<InventoryItem> items = session.inventory.indexedItems();
        if (index < 1 || index > items.size()) return false;
        int hotbar = session.inventory.selectedHotbar();
        return session.client.handInventorySlot(items.get(index - 1).containerSlot(), hotbar);
    }

    public ChestResult chestOpen(BotSession session) {
        if (!online(session) || !config.bool("features.inventory.enabled", true)
                || !config.bool("features.inventory.chest.enabled", true)) return ChestResult.DISABLED_OR_OFFLINE;
        if (!allowOperation(session, "inventory-chest", "performance.inventory-cooldown-millis", 250)) {
            return ChestResult.RATE_LIMITED;
        }
        session.inventoryGeneration++;
        long token = ++session.containerGeneration;
        if (session.container.isOpen()) {
            int containerId = session.container.containerId();
            boolean sent = session.client.closeContainer(containerId);
            session.container.close();
            return sent ? ChestResult.CLOSED : ChestResult.FAILED;
        }
        double reach = Math.max(1.0, config.decimal("features.inventory.chest.reach", 4.5));
        if (!session.client.openNearbyContainer(reach)) return ChestResult.NO_CONTAINER;
        // 打开界面由服务端确认；若迟迟没有收到 Open Screen，令本次操作代次失效即可。
        scheduler.schedule(() -> {
            if (online(session) && token == session.containerGeneration && !session.container.isOpen()) {
                config.logDebug("假人 {} 请求打开附近容器，但服务端未返回容器界面", session.botName);
            }
        }, Math.max(500, config.longValue("features.inventory.chest.open-timeout-millis", 2000)), TimeUnit.MILLISECONDS);
        return ChestResult.OPEN_REQUESTED;
    }

    public ChestResult chestTransfer(BotSession session, boolean takeFromChest, String filter) {
        if (!online(session) || !config.bool("features.inventory.enabled", true)
                || !config.bool("features.inventory.chest.enabled", true)) return ChestResult.DISABLED_OR_OFFLINE;
        if (!session.container.isOpen()) return ChestResult.NOT_OPEN;
        if (!allowOperation(session, "inventory-chest", "performance.inventory-cooldown-millis", 250)) {
            return ChestResult.RATE_LIMITED;
        }
        java.util.List<InventoryItem> items = takeFromChest
                ? session.container.storageItems(filter) : session.container.playerItems(filter);
        if (items.isEmpty()) return ChestResult.NO_ITEMS;
        // full 表示把玩家背包内容放入容器，get 则相反。
        if (!session.container.hasSpaceFor(!takeFromChest, items)) return ChestResult.NO_SPACE;
        int maximum = Math.max(1, config.integer("features.inventory.chest.max-stacks-per-operation", 54));
        if (items.size() > maximum) items = java.util.List.copyOf(items.subList(0, maximum));
        long token = ++session.containerGeneration;
        long interval = Math.max(50, config.longValue("features.inventory.chest.transfer-interval-millis", 150));
        transferContainerNext(session, items, 0, token, interval);
        return ChestResult.TRANSFER_STARTED;
    }

    private void transferContainerNext(BotSession session, java.util.List<InventoryItem> items,
                                       int index, long token, long interval) {
        if (!online(session) || token != session.containerGeneration || !session.container.isOpen()
                || index >= items.size()) return;
        InventoryItem item = items.get(index);
        int sentState = session.container.stateId();
        if (!session.client.shiftClickContainer(session.container.containerId(), sentState, item.containerSlot())) return;
        if (index + 1 < items.size()) {
            long timeout = Math.max(interval,
                    config.longValue("features.inventory.chest.response-timeout-millis", 1500));
            scheduler.schedule(() -> awaitContainerUpdate(session, items, index + 1, token, interval,
                    sentState, System.currentTimeMillis() + timeout), interval, TimeUnit.MILLISECONDS);
        }
    }

    private void awaitContainerUpdate(BotSession session, java.util.List<InventoryItem> items, int index,
                                      long token, long interval, int previousState, long deadlineMillis) {
        if (!online(session) || token != session.containerGeneration || !session.container.isOpen()) return;
        if (session.container.stateId() != previousState) {
            transferContainerNext(session, items, index, token, interval);
            return;
        }
        if (System.currentTimeMillis() >= deadlineMillis) {
            config.logDebug("假人 {} 容器点击未在限定时间内收到状态确认，已停止本次批量转移", session.botName);
            return;
        }
        scheduler.schedule(() -> awaitContainerUpdate(session, items, index, token, interval,
                previousState, deadlineMillis), Math.min(100, interval), TimeUnit.MILLISECONDS);
    }

    public boolean action(BotSession session, String kind, String value) {
        if (!online(session) || !config.bool("features.actions." + kind + ".enabled", true)) return false;
        if (session.followOwner || session.navigatingHere) cancelNavigation(session, false, "已切换到其他动作");
        // off 属于安全停止操作，永不被冷却拦截。
        if (!value.equalsIgnoreCase("off")
                && !allowOperation(session, "action-" + kind, "performance.action-cooldown-millis", 250)) return false;
        if (value.equalsIgnoreCase("on") || value.equalsIgnoreCase("off")) {
            boolean enabled = value.equalsIgnoreCase("on");
            if (enabled && config.bool("performance.exclusive-continuous-actions", true)) disableOtherContinuous(session, kind);
            switch (kind) {
                case "attack" -> {
                    session.attackContinuous = enabled;
                    return session.client.simulateAction("attack", enabled, 0);
                }
                case "destroy" -> {
                    session.destroyGeneration++;
                    session.destroyContinuous = enabled;
                    return session.client.simulateAction("destroy", enabled, 0);
                }
                case "use" -> {
                    session.useContinuous = enabled;
                    return enabled ? session.client.useMainHand(session.yaw, session.pitch) : session.client.releaseUse();
                }
                case "put" -> {
                    session.putGeneration++;
                    session.putContinuous = enabled;
                    return session.client.simulateAction("put", enabled, 0);
                }
                default -> { return false; }
            }
        }
        try {
            double amount = Double.parseDouble(value);
            double max = Math.max(0.1, config.decimal("features.actions.max-value", 10));
            if (amount <= 0 || amount > max || Math.abs(amount * 10 - Math.rint(amount * 10)) > 0.0001) return false;
            if (config.bool("performance.exclusive-continuous-actions", true)) disableOtherContinuous(session, kind);
            if (kind.equals("use")) {
                session.useContinuous = false;
                long token = ++session.useGeneration;
                if (!session.client.useMainHand(session.yaw, session.pitch)) return false;
                scheduler.schedule(() -> { if (online(session) && token == session.useGeneration) session.client.releaseUse(); }, Math.round(amount * 1000), TimeUnit.MILLISECONDS);
                return true;
            }
            if (kind.equals("destroy")) {
                // destroy 的数字参数表示左键保持秒数，而不是破坏次数。到时直接发送 CANCEL 松开，
                // 不依赖方块是否成功破坏，因此 destroy 1 必定在约 1 秒后停止。
                // 注意：必须把 session.destroyContinuous 置为 true，与 ClientSimulation 内部状态一致，
                // 否则期间触发 disableOtherContinuous 会误判“破坏未进行”，导致攻击与破坏并存。
                session.destroyContinuous = true;
                long token = ++session.destroyGeneration;
                if (!session.client.simulateAction("destroy", true, 0)) { session.destroyContinuous = false; return false; }
                scheduler.schedule(() -> {
                    if (online(session) && token == session.destroyGeneration && session.client != null) {
                        session.destroyContinuous = false;
                        session.client.simulateAction("destroy", false, 0);
                    }
                }, Math.round(amount * 1000), TimeUnit.MILLISECONDS);
                return true;
            }
            if (kind.equals("put")) {
                // put 的数字参数与 destroy 一致，表示持续右键秒数；每次右键间隔由配置控制。
                session.putContinuous = true;
                long token = ++session.putGeneration;
                if (!session.client.simulateAction("put", true, 0)) { session.putContinuous = false; return false; }
                scheduler.schedule(() -> {
                    if (online(session) && token == session.putGeneration && session.client != null) {
                        session.putContinuous = false;
                        session.client.simulateAction("put", false, 0);
                    }
                }, Math.round(amount * 1000), TimeUnit.MILLISECONDS);
                return true;
            }
            int clicks = (int) amount;
            if (clicks != amount) return false;
            if (kind.equals("attack")) session.attackContinuous = false;
            else return false;
            return session.client.simulateAction(kind, false, clicks);
        } catch (NumberFormatException ignored) { return false; }
    }

    private void dropNext(BotSession session, java.util.List<InventoryItem> items, int index, long token, long interval) {
        if (index >= items.size() || !online(session) || token != session.inventoryGeneration) return;
        session.client.dropInventorySlot(items.get(index).containerSlot());
        if (index + 1 < items.size()) scheduler.schedule(() -> dropNext(session, items, index + 1, token, interval), interval, TimeUnit.MILLISECONDS);
    }

    private void disableOtherContinuous(BotSession session, String keep) {
        if (!keep.equals("attack") && session.attackContinuous) {
            session.attackContinuous = false; session.attackGeneration++;
            session.client.simulateAction("attack", false, 0);
        }
        if (!keep.equals("destroy") && session.destroyContinuous) {
            session.destroyContinuous = false; session.destroyGeneration++;
            session.client.simulateAction("destroy", false, 0);
        }
        if (!keep.equals("use") && session.useContinuous) { session.useContinuous = false; session.useGeneration++; session.client.releaseUse(); }
        if (!keep.equals("put") && session.putContinuous) {
            session.putContinuous = false; session.putGeneration++;
            session.client.simulateAction("put", false, 0);
        }
    }

    public boolean move(BotSession session, char direction, double seconds) {
        direction = Character.toUpperCase(direction);
        if ("WASD".indexOf(direction) < 0 || !online(session) || !config.bool("features.movement.enabled", true) || seconds < 0.1
                || seconds > config.longValue("features.movement.max-seconds", 10)
                || Math.abs(seconds * 10 - Math.rint(seconds * 10)) > 0.0001
                || !allowOperation(session, "move", "performance.movement-cooldown-millis", 250)) return false;
        int ticks = (int) Math.round(seconds * 20);
        if (session.followOwner || session.navigatingHere) cancelNavigation(session, false, "已切换到手动移动");
        session.movementActive = true; session.movementDirection = direction;
        long token = ++session.movementGeneration;
        if (!session.client.simulateMove(direction, ticks)) { session.movementActive = false; return false; }
        scheduler.schedule(() -> { if (token == session.movementGeneration) session.movementActive = false; }, ticks * 50L, TimeUnit.MILLISECONDS);
        return true;
    }

    public boolean jump(BotSession session) {
        return online(session) && config.bool("features.jump.enabled", true)
                && allowOperation(session, "jump", "performance.movement-cooldown-millis", 250)
                && session.client.simulateJump();
    }

    /** 只停止移动和寻路，保留攻击、放置及脚本等其他行为。 */
    public boolean stopMovement(BotSession session) {
        if (!online(session)) return false;
        cancelNavigation(session, false, "");
        session.movementGeneration++;
        session.movementActive = false;
        session.client.stopMovement();
        return true;
    }

    /** 搜索并右键最近的船、马、骆驼或快乐恶魂；最终能否乘坐由子服原版规则决定。 */
    public String rideNearby(BotSession session) {
        if (!online(session) || !config.bool("features.movement.boat.enabled", true)
                || !allowOperation(session, "move-boat", "performance.movement-cooldown-millis", 250)) return "";
        stopMovement(session);
        return session.client.rideNearby(config.decimal("features.movement.boat.reach-blocks", 3.0));
    }

    /** 实用补充：模拟按下 Shift 离开当前载具。 */
    public boolean leaveVehicle(BotSession session) {
        return online(session) && config.bool("features.movement.boat.enabled", true)
                && session.client.dismount();
    }

    /** 最高优先级安全停止，不受任何动作冷却影响，也不会让假人退出服务器。 */
    public boolean stopAllBehaviors(BotSession session) {
        if (!online(session) || !config.bool("features.stopaction.enabled", true)) return false;
        cancelNavigation(session, false, "");
        session.actionGeneration++;
        session.attackGeneration++; session.destroyGeneration++; session.useGeneration++; session.putGeneration++;
        session.attackContinuous = false; session.destroyContinuous = false;
        session.useContinuous = false; session.putContinuous = false;
        session.movementGeneration++; session.movementActive = false;
        session.inventoryGeneration++; session.containerGeneration++;
        session.autoWorksGeneration++; session.workGeneration++;
        session.data.workEnabled(false);
        store.markDirty(true);
        if (session.container.isOpen()) session.client.closeContainer(session.container.containerId());
        session.container.close();
        session.client.releaseUse();
        session.client.stopSimulation();
        return true;
    }

    public boolean face(BotSession session, String axis, float degrees) {
        if (!online(session) || !config.bool("features.facing.enabled", true)
                || !allowOperation(session, "facing", "performance.facing-cooldown-millis", 100)) return false;
        float beforeYaw = session.yaw, beforePitch = session.pitch;
        session.client.autoLook(null, null);
        switch (axis.toLowerCase(Locale.ROOT)) {
            case "horizontal" -> session.yaw = degrees;
            case "vertical" -> session.pitch = Math.max(-90, Math.min(90, degrees));
            default -> { return false; }
        }
        if (Math.abs(beforeYaw - session.yaw) < 0.001f && Math.abs(beforePitch - session.pitch) < 0.001f) return true;
        return session.client.sendLook(session.yaw, session.pitch);
    }

    public boolean autoFace(BotSession session, String mode, String filter) {
        if (!online(session) || !config.bool("features.facing.enabled", true)
                || !config.bool("features.facing.auto.enabled", true)
                || !(mode.equalsIgnoreCase("all") || mode.equalsIgnoreCase("summer"))
                || !allowOperation(session, "facing", "performance.facing-cooldown-millis", 100)) return false;
        if (session.followOwner || session.navigatingHere) cancelNavigation(session, false, "已切换到自动视角");
        return session.client.autoLook(mode, filter);
    }

    public NavigationStartResult automove(BotSession session, boolean enabled) {
        if (!online(session) || !config.bool("features.actions.automove.enabled", true)) return NavigationStartResult.NOT_READY;
        if (!enabled) {
            if (!session.followOwner) return NavigationStartResult.NOT_ACTIVE;
            cancelNavigation(session, false, "已关闭自动跟随");
            return NavigationStartResult.STOPPED;
        }
        if (session.followOwner) return NavigationStartResult.STARTED;
        if (!allowOperation(session, "automove", "performance.action-cooldown-millis", 250)) {
            return NavigationStartResult.RATE_LIMITED;
        }
        OwnerMotion owner = currentOwnerMotion(session.ownerKey);
        NavigationStartResult validation = validateTarget(session, owner,
                config.decimal("features.actions.automove.max-distance", 50.0));
        if (validation != NavigationStartResult.STARTED) return validation;
        stopOtherBehaviorsForFollow(session);
        session.followOwner = true;
        session.navigatingHere = false;
        session.navigationServer = owner.server;
        session.navigationDimension = normalizeWorldKey(owner.dimension);
        session.navigationFailures = 0;
        long token = ++session.navigationGeneration;
        planNavigation(session, owner.x, owner.y, owner.z,
                config.decimal("features.actions.automove.max-distance", 50.0), token, true);
        return NavigationStartResult.STARTED;
    }

    /** move here 固定执行指令时主人的位置，不会在主人随后移动时改变终点。 */
    public NavigationStartResult moveHere(BotSession session) {
        if (!online(session) || !config.bool("features.movement.here.enabled", true)) return NavigationStartResult.NOT_READY;
        if (!allowOperation(session, "move-here", "performance.movement-cooldown-millis", 250)) {
            return NavigationStartResult.RATE_LIMITED;
        }
        OwnerMotion owner = currentOwnerMotion(session.ownerKey);
        double maximum = config.decimal("features.movement.here.max-distance", 100.0);
        NavigationStartResult validation = validateTarget(session, owner, maximum);
        if (validation != NavigationStartResult.STARTED) return validation;
        cancelNavigation(session, false, "");
        session.client.autoLook(null, null);
        session.movementGeneration++; session.movementActive = false;
        session.followOwner = false;
        session.navigatingHere = true;
        session.navigationTargetX = owner.x; session.navigationTargetY = owner.y; session.navigationTargetZ = owner.z;
        session.navigationServer = owner.server; session.navigationDimension = normalizeWorldKey(owner.dimension);
        session.navigationFailures = 0;
        long token = ++session.navigationGeneration;
        planNavigation(session, owner.x, owner.y, owner.z, maximum, token, false);
        return NavigationStartResult.STARTED;
    }

    private void planNavigation(BotSession session, double targetX, double targetY, double targetZ,
                                double maximumDistance, long token, boolean follow) {
        if (!online(session) || token != session.navigationGeneration || follow != session.followOwner
                || !follow && !session.navigatingHere) return;
        OwnerMotion target = follow ? currentOwnerMotion(session.ownerKey)
                : new OwnerMotion(targetX, targetY, targetZ, 0, 0, true, false,
                session.navigationDimension, session.navigationServer, System.nanoTime());
        NavigationStartResult validation = validateTarget(session, target, maximumDistance);
        if (validation != NavigationStartResult.STARTED) {
            cancelNavigation(session, true, navigationReason(validation));
            return;
        }
        double stopDistance = follow
                ? config.decimal("features.actions.automove.stop-distance", 2.5)
                : config.decimal("features.movement.here.stop-distance", 1.7);
        double distance = distance(session.x, session.y, session.z, target.x, target.y, target.z);
        if (distance <= stopDistance) {
            session.client.cancelNavigation();
            if (!follow) {
                session.navigatingHere = false;
                proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "navigation-arrived"));
                return;
            }
        } else {
            long now = System.currentTimeMillis();
            double moved = distance(session.lastPlannedTargetX, session.lastPlannedTargetY, session.lastPlannedTargetZ,
                    target.x, target.y, target.z);
            long forceReplan = Math.max(500, config.longValue("performance.pathfinding-force-replan-millis", 2500));
            if (session.lastNavigationPlanMillis == 0 || moved >= config.decimal("performance.pathfinding-target-change-blocks", 1.5)
                    || now - session.lastNavigationPlanMillis >= forceReplan) {
                ClientSimulation.NavigationResult result = session.client.navigateTo(target.x, target.y, target.z,
                        maximumDistance, Math.max(64, config.integer("performance.pathfinding-max-expanded-nodes", 2048)));
                session.lastNavigationPlanMillis = now;
                session.lastPlannedTargetX = target.x; session.lastPlannedTargetY = target.y; session.lastPlannedTargetZ = target.z;
                if (result == ClientSimulation.NavigationResult.NO_PATH) session.navigationFailures++;
                else if (result == ClientSimulation.NavigationResult.TOO_FAR) {
                    cancelNavigation(session, true, "目标距离超过限制"); return;
                } else session.navigationFailures = 0;
                int maximumFailures = Math.max(1, config.integer("performance.pathfinding-max-failures", 5));
                if (session.navigationFailures >= maximumFailures) {
                    cancelNavigation(session, true, "连续多次无法找到安全路径"); return;
                }
            }
        }
        long interval = Math.max(250, config.longValue("performance.pathfinding-plan-interval-millis", 750));
        scheduler.schedule(() -> planNavigation(session, targetX, targetY, targetZ, maximumDistance, token, follow),
                interval, TimeUnit.MILLISECONDS);
    }

    private NavigationStartResult validateTarget(BotSession session, OwnerMotion target, double maximumDistance) {
        if (target == null || !target.positionKnown || target.dimension.isBlank() || target.server.isBlank()) {
            return NavigationStartResult.NO_OWNER_POSITION;
        }
        if (!target.server.equalsIgnoreCase(session.connectedServer)) return NavigationStartResult.DIFFERENT_SERVER;
        String botDimension = session.client == null ? "" : session.client.dimension();
        if (botDimension.isBlank() || !normalizeWorldKey(botDimension).equals(normalizeWorldKey(target.dimension))) {
            return NavigationStartResult.DIFFERENT_DIMENSION;
        }
        if (distance(session.x, session.y, session.z, target.x, target.y, target.z) > maximumDistance) {
            return NavigationStartResult.TOO_FAR;
        }
        return NavigationStartResult.STARTED;
    }

    private OwnerMotion currentOwnerMotion(String ownerKey) {
        OwnerMotion motion = ownerMotions.get(ownerKey);
        if (motion == null) return null;
        long timeout = TimeUnit.SECONDS.toNanos(Math.max(2,
                config.longValue("features.actions.automove.owner-position-timeout-seconds", 5)));
        return System.nanoTime() - motion.updatedNanos > timeout ? null : motion;
    }

    private void stopOtherBehaviorsForFollow(BotSession session) {
        session.attackContinuous = false; session.attackGeneration++;
        session.destroyContinuous = false; session.destroyGeneration++;
        session.useContinuous = false; session.useGeneration++;
        session.putContinuous = false; session.putGeneration++;
        session.client.simulateAction("attack", false, 0);
        session.client.simulateAction("destroy", false, 0);
        session.client.simulateAction("put", false, 0);
        session.client.releaseUse();
        session.client.autoLook(null, null);
        session.client.cancelNavigation();
        session.movementGeneration++; session.movementActive = false;
        session.workGeneration++;
        session.autoWorksGeneration++;
        session.inventoryGeneration++; session.containerGeneration++;
        if (session.container.isOpen()) session.client.closeContainer(session.container.containerId());
        session.container.close();
    }

    private void cancelNavigation(BotSession session, boolean notifyOwner, String reason) {
        if (session == null) return;
        boolean active = session.followOwner || session.navigatingHere;
        session.followOwner = false; session.navigatingHere = false;
        session.navigationGeneration++;
        session.navigationFailures = 0; session.lastNavigationPlanMillis = 0;
        if (session.client != null) session.client.cancelNavigation();
        if (active && notifyOwner) proxy.getPlayer(session.ownerName).ifPresent(owner ->
                messages.send(owner, "navigation-cancelled", "reason", reason == null || reason.isBlank() ? "未知原因" : reason));
    }

    private String navigationReason(NavigationStartResult result) {
        return switch (result) {
            case NO_OWNER_POSITION -> "无法读取主人坐标";
            case DIFFERENT_SERVER -> "主人和假人不在同一子服务器";
            case DIFFERENT_DIMENSION -> "主人和假人不在同一维度";
            case TOO_FAR -> "目标距离超过限制";
            default -> "寻路状态无效";
        };
    }

    private double distance(double ax, double ay, double az, double bx, double by, double bz) {
        double dx = ax - bx, dy = ay - by, dz = az - bz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public void updateOwnerWorld(String owner, String dimension) {
        if (owner == null || owner.isBlank()) return;
        String value = normalizeWorldKey(dimension);
        String server = proxy.getPlayer(owner).flatMap(Player::getCurrentServer)
                .map(connection -> connection.getServerInfo().getName()).orElse("");
        ownerMotions.compute(key(owner), (ignored, before) -> {
            OwnerMotion base = before == null ? OwnerMotion.unknown(server) : before;
            boolean changed = !value.isBlank() && !value.equalsIgnoreCase(base.dimension);
            return new OwnerMotion(changed ? 0 : base.x, changed ? 0 : base.y, changed ? 0 : base.z,
                    base.yaw, base.pitch, changed ? false : base.positionKnown, base.rotationKnown,
                    value.isBlank() ? base.dimension : value, server.isBlank() ? base.server : server,
                    System.nanoTime());
        });
    }

    public void updateOwnerMotion(String owner, boolean hasPosition, double x, double y, double z,
                                  boolean hasRotation, float yaw, float pitch, String dimension) {
        if (owner == null || owner.isBlank()) return;
        String server = proxy.getPlayer(owner).flatMap(Player::getCurrentServer)
                .map(connection -> connection.getServerInfo().getName()).orElse("");
        ownerMotions.compute(key(owner), (ignored, before) -> {
            OwnerMotion base = before == null ? OwnerMotion.unknown(server) : before;
            String nextDimension = dimension == null || dimension.isBlank()
                    ? base.dimension : normalizeWorldKey(dimension);
            boolean dimensionChanged = !base.dimension.isBlank() && !nextDimension.equalsIgnoreCase(base.dimension);
            return new OwnerMotion(hasPosition ? x : base.x, hasPosition ? y : base.y, hasPosition ? z : base.z,
                    hasRotation ? yaw : base.yaw, hasRotation ? pitch : base.pitch,
                    hasPosition && !dimensionChanged || base.positionKnown && !dimensionChanged,
                    hasRotation || base.rotationKnown, nextDimension,
                    server.isBlank() ? base.server : server, System.nanoTime());
        });
    }

    public void refreshWork(BotSession session) { if (session != null) { session.workGeneration++; startWorkLoop(session); } }

    public boolean resetWork(BotSession session) {
        if (session == null) return false;
        session.nextWorkIndex = 1;
        session.workGeneration++;
        startWorkLoop(session);
        return true;
    }

    /** 从 1 到 10 单独执行一轮，不改变脚本开关；本轮结束后会恢复已开启的循环。 */
    public boolean runWorkOnce(BotSession session) {
        if (!online(session) || !config.bool("features.work.enabled", true)) return false;
        boolean found = false;
        for (int i = 1; i <= PlayerData.MAX_WORK_STEPS; i++) {
            if (session.data.workStep(i) != null) { found = true; break; }
        }
        if (!found) return false;
        long token = ++session.workGeneration;
        runWorkOnceStep(session, token, 1);
        return true;
    }

    private void runWorkOnceStep(BotSession session, long token, int fromIndex) {
        if (!online(session) || token != session.workGeneration) return;
        WorkStep step = null;
        int next = fromIndex;
        while (next <= PlayerData.MAX_WORK_STEPS) {
            step = session.data.workStep(next++);
            if (step != null) break;
        }
        if (step == null) {
            session.nextWorkIndex = 1;
            if (session.data.workEnabled()) startWorkLoop(session);
            return;
        }
        long overrideDelay = executeWorkStep(session, step);
        long delay = overrideDelay >= 0 ? overrideDelay : Math.max(1, session.data.workWaitMillis());
        int following = next;
        scheduler.schedule(() -> runWorkOnceStep(session, token, following), delay, TimeUnit.MILLISECONDS);
    }

    private void startWorkLoop(BotSession session) {
        if (!online(session) || !config.bool("features.work.enabled", true) || !session.data.workEnabled()) return;
        long token = ++session.workGeneration;
        runWorkStep(session, token);
    }

    private void runWorkStep(BotSession session, long token) {
        if (!online(session) || token != session.workGeneration || !session.data.workEnabled()) return;
        WorkStep step = null;
        for (int tried = 0; tried < PlayerData.MAX_WORK_STEPS; tried++) {
            int index = session.nextWorkIndex++;
            if (session.nextWorkIndex > PlayerData.MAX_WORK_STEPS) session.nextWorkIndex = 1;
            step = session.data.workStep(index);
            if (step != null) break;
        }
        if (step == null) return; // 脚本被清空时停止空转，等待 refreshWork/resetWork 再次驱动。
        long overrideDelay = executeWorkStep(session, step);
        long delay = overrideDelay >= 0 ? overrideDelay : Math.max(1, session.data.workWaitMillis());
        scheduler.schedule(() -> runWorkStep(session, token), delay, TimeUnit.MILLISECONDS);
    }

    private long executeWorkStep(BotSession session, WorkStep step) {
        if (step.type() == WorkStep.Type.CMD) {
            sendCommand(session, step.content());
            return -1;
        }
        return executeBotWork(session, step.content());
    }

    /** @return 覆盖下一步等待的毫秒数，-1 表示使用玩家设置的全局间隔。 */
    private long executeBotWork(BotSession session, String input) {
        String[] a = input.strip().split("\\s+");
        if (a.length == 0) return -1;
        try {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "message" -> sendMessage(session, input.substring(a[0].length()).strip());
                case "inv" -> {
                    if (a.length >= 3 && a[1].equalsIgnoreCase("drop")) drop(session, a[2].equalsIgnoreCase("all") ? null : Integer.parseInt(a[2]), a[2].equalsIgnoreCase("all"));
                    else if (a.length >= 3 && a[1].equalsIgnoreCase("hand")) hand(session, Integer.parseInt(a[2]));
                    else if (a.length >= 3 && a[1].equalsIgnoreCase("chest")) {
                        String filter = a.length >= 4 ? a[3] : null;
                        if (a[2].equalsIgnoreCase("open")) chestOpen(session);
                        else if (a[2].equalsIgnoreCase("get")) chestTransfer(session, true, filter);
                        else if (a[2].equalsIgnoreCase("full")) chestTransfer(session, false, filter);
                    }
                }
                case "action" -> {
                    if (a.length >= 3 && a[1].equalsIgnoreCase("automove")) {
                        automove(session, a[2].equalsIgnoreCase("on"));
                    } else if (a.length >= 3) action(session, a[1].toLowerCase(Locale.ROOT), a[2]);
                }
                case "move" -> {
                    if (a.length >= 2 && a[1].equalsIgnoreCase("here")) moveHere(session);
                    else if (a.length >= 2 && a[1].equalsIgnoreCase("boat")) rideNearby(session);
                    else if (a.length >= 2 && a[1].equalsIgnoreCase("leave")) leaveVehicle(session);
                    else if (a.length >= 2 && a[1].equalsIgnoreCase("stop")) stopMovement(session);
                    else if (a.length >= 3) move(session, a[1].charAt(0), Double.parseDouble(a[2]));
                }
                case "jump" -> jump(session);
                case "stopaction" -> stopAllBehaviors(session);
                case "facing" -> {
                    if (a.length >= 3 && a[1].equalsIgnoreCase("auto")) autoFace(session, a[2], a.length >= 4 ? a[3] : null);
                    else if (a.length >= 3) face(session, a[1], Float.parseFloat(a[2]));
                }
                case "delay" -> {
                    if (a.length >= 2) {
                        double seconds = Double.parseDouble(a[1]);
                        double maximum = Math.max(0.1, config.decimal("features.work.max-delay-seconds", 3600));
                        if (seconds >= 0 && seconds <= maximum) return Math.max(1, Math.round(seconds * 1000));
                    }
                }
                default -> { }
            }
        } catch (RuntimeException ignored) { }
        return -1;
    }

    private boolean online(BotSession session) { return session != null && session.status == BotStatus.ONLINE && session.client != null; }

    private boolean allowOperation(BotSession session, String key, String configPath, long fallbackMillis) {
        if (session == null || !config.bool("performance.rate-limit-enabled", true)) return true;
        long cooldown = Math.max(0, config.longValue(configPath, fallbackMillis));
        if (cooldown == 0) return true;
        long now = System.nanoTime(), limit = TimeUnit.MILLISECONDS.toNanos(cooldown);
        final boolean[] allowed = {false};
        session.lastOperations.compute(key, (ignored, previous) -> {
            if (previous == null || now - previous >= limit) { allowed[0] = true; return now; }
            return previous;
        });
        return allowed[0];
    }

    public CommandValidation validateCommand(String raw) {
        String command = normalizeCommand(raw);
        if (command.isBlank() || command.length() > config.integer("commands.max-length", 256)) return CommandValidation.INVALID;
        return config.isCommandAllowed(command) ? CommandValidation.ALLOWED : CommandValidation.BLOCKED;
    }

    public String normalizeCommand(String raw) {
        String command = raw == null ? "" : raw.strip();
        if (config.bool("commands.strip-leading-slash", true) && command.startsWith("/")) command = command.substring(1);
        return command;
    }

    private void clientSimulationTick() {
        if (closed.get()) return;
        for (BotSession session : byOwner.values()) {
            if (session.status != BotStatus.ONLINE || session.client == null) continue;
            try { session.client.simulationTick(); }
            catch (Throwable error) { config.logDebug("假人 {} 客户端模拟 tick 失败：{}", session.botName, error.getMessage()); }
        }
    }

    private void billingTick() {
        if (closed.get()) return;
        boolean chargeReconnecting = config.bool("billing.charge-while-reconnecting", false);
        long now = System.nanoTime();
        for (BotSession session : byOwner.values()) {
            boolean billable = session.status == BotStatus.ONLINE
                    || (chargeReconnecting && session.status == BotStatus.RECONNECTING);
            if (!billable) continue;
            if (now <= session.lastBillingNanos) continue;
            long deltaNanos = now - session.lastBillingNanos;
            long deltaMillis = TimeUnit.NANOSECONDS.toMillis(deltaNanos);
            if (deltaMillis <= 0) continue;
            session.lastBillingNanos += TimeUnit.MILLISECONDS.toNanos(deltaMillis);
            session.data.charge(deltaMillis);
            store.markDirty(false);
            if (session.data.remainingMillis() <= 0) {
                proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "balance-expired"));
                stop(session, false);
            }
        }
    }

    private void dailyResetTick() {
        if (closed.get() || !config.bool("daily-reset.enabled", true)) return;
        try {
            ZoneId zone = ZoneId.of(config.string("daily-reset.time-zone", "Asia/Shanghai"));
            LocalDateTime now = LocalDateTime.now(zone);
            LocalDate today = now.toLocalDate();
            LocalTime resetAt = LocalTime.parse(config.string("daily-reset.time", "04:00"));
            if (now.toLocalTime().isBefore(resetAt)) return;
            if (store.lastDailyResetDate().equals(today.toString())) return;
            if (!config.bool("daily-reset.catch-up-after-downtime", true) && now.toLocalTime().isAfter(resetAt.plusMinutes(1))) {
                store.lastDailyResetDate(today.toString()); return;
            }
            long minutes = Math.max(0, config.longValue("daily-reset.initial-balance-minutes", 120));
            for (PlayerData data : store.all().values()) data.setDailyMillis(minutes * 60_000L);
            store.lastDailyResetDate(today.toString());
            store.markDirty(true);
            for (BotSession session : byOwner.values()) {
                proxy.getPlayer(session.ownerName).ifPresent(owner -> messages.send(owner, "daily-reset", "minutes", minutes));
            }
            if (config.bool("daily-reset.stop-active-bots", false)) {
                for (BotSession session : byOwner.values().toArray(BotSession[]::new)) stop(session, false);
            }
            logger.info("每日余额重置完成：{} 分钟，时区 {}", minutes, zone);
        } catch (Exception e) { logger.error("执行每日余额重置失败", e); }
    }

    private void restoreBots() {
        for (PlayerData data : store.all().values()) {
            if (!data.desiredActive() || data.lastServer().isBlank() || data.remainingMillis() <= 0) continue;
            if (!config.isServerAllowed(data.lastServer())) { data.desiredActive(false); continue; }
            BotSession session = createSession(data.name(), data.lastServer(), data);
            if (byOwner.putIfAbsent(session.ownerKey, session) == null) {
                byBot.put(key(session.botName), session);
                connect(session);
            }
        }
    }

    private int countOnServer(String server) {
        return (int) byOwner.values().stream().filter(s -> s.targetServer.equalsIgnoreCase(server)).count();
    }

    private String generateBotName(String ownerName) {
        if (config.string("naming.strategy", "owner-suffix").equalsIgnoreCase("owner-suffix")) {
            String candidate = ownerName + config.string("naming.suffix", "_Bot");
            if (candidate.matches("[A-Za-z0-9_]{1,16}")) return candidate;
        }
        String prefix = config.string("naming.internal-prefix", "PNB").replaceAll("[^A-Za-z0-9_]", "");
        if (prefix.isBlank()) prefix = "PNB";
        if (prefix.length() > 6) prefix = prefix.substring(0, 6);
        UUID hash = UUID.nameUUIDFromBytes(("PnPlayerBot:" + key(ownerName)).getBytes(StandardCharsets.UTF_8));
        String suffix = hash.toString().replace("-", "");
        return (prefix + suffix).substring(0, Math.min(16, prefix.length() + suffix.length()));
    }

    private boolean isReservedName(String name) {
        if (byBot.containsKey(key(name)) || pending.containsKey(key(name))) return true;
        String suffix = config.string("naming.suffix", "_Bot");
        if (config.bool("naming.block-suffix-for-real-players", true) && !suffix.isBlank()
                && name.toLowerCase(Locale.ROOT).contains(suffix.toLowerCase(Locale.ROOT))) return true;
        String prefix = config.string("naming.internal-prefix", "PNB");
        return !prefix.isBlank() && name.regionMatches(true, 0, prefix, 0, prefix.length());
    }

    public static String formatDuration(long millis) {
        Duration duration = Duration.ofMillis(Math.max(0, millis));
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();
        return hours > 0 ? "%d小时%02d分%02d秒".formatted(hours, minutes, seconds) : "%d分%02d秒".formatted(minutes, seconds);
    }

    private String key(String name) { return name.toLowerCase(Locale.ROOT); }

    private String normalizeWorldKey(String world) {
        if (world == null || world.isBlank()) return "";
        String value = world.strip().toLowerCase(Locale.ROOT);
        return value.indexOf(':') < 0 ? "minecraft:" + value : value;
    }

    private record OwnerMotion(double x, double y, double z, float yaw, float pitch,
                               boolean positionKnown, boolean rotationKnown,
                               String dimension, String server, long updatedNanos) {
        private static OwnerMotion unknown(String server) {
            return new OwnerMotion(0, 0, 0, 0, 0, false, false, "",
                    server == null ? "" : server, System.nanoTime());
        }

        private OwnerMotion withServer(String nextServer, boolean resetPosition) {
            String value = nextServer == null ? "" : nextServer;
            if (!resetPosition) {
                return new OwnerMotion(x, y, z, yaw, pitch, positionKnown, rotationKnown,
                        dimension, value, System.nanoTime());
            }
            return new OwnerMotion(0, 0, 0, yaw, pitch, false, rotationKnown,
                    "", value, System.nanoTime());
        }
    }

    @Override public void close() {
        if (!closed.compareAndSet(false, true)) return;
        boolean preserveForRestore = config.bool("general.restore-active-bots-after-restart", false);
        for (BotSession session : byOwner.values().toArray(BotSession[]::new)) {
            if (!preserveForRestore) {
                stop(session, false);
                continue;
            }
            session.intentionalStop = true;
            session.status = BotStatus.STOPPING;
            session.data.desiredActive(true);
            session.data.lastServer(session.targetServer);
            if (session.proxyPlayer != null) session.proxyPlayer.disconnect(Component.text(config.string("general.shutdown-reason", "PnPlayerBot 正在关闭")));
            if (session.client != null) session.client.close();
        }
        store.markDirty(true);
        scheduler.shutdownNow();
    }

    public enum StartResult { STARTED, ALREADY_RUNNING, NOT_ON_SERVER, SERVER_NOT_ALLOWED, NO_BALANCE, GLOBAL_LIMIT, SERVER_LIMIT }
    public enum CommandValidation { ALLOWED, BLOCKED, INVALID }
    public enum ChestResult {
        OPEN_REQUESTED, CLOSED, TRANSFER_STARTED, NOT_OPEN, NO_CONTAINER, NO_ITEMS,
        NO_SPACE, RATE_LIMITED, DISABLED_OR_OFFLINE, FAILED
    }
    public enum NavigationStartResult {
        STARTED, STOPPED, NOT_ACTIVE, NOT_READY, NO_OWNER_POSITION,
        DIFFERENT_SERVER, DIFFERENT_DIMENSION, TOO_FAR, RATE_LIMITED
    }
}
