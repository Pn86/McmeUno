package dev.craftwizard.pnlitecheckin;

import dev.craftwizard.pnlitecheckin.command.CheckInCommand;
import dev.craftwizard.pnlitecheckin.command.PnLiteCheckInCommand;
import dev.craftwizard.pnlitecheckin.manager.CheckInManager;
import dev.craftwizard.pnlitecheckin.placeholder.PnLiteCheckInExpansion;
import org.bukkit.plugin.java.JavaPlugin;

public final class PnLiteCheckIn extends JavaPlugin {

    private CheckInManager checkInManager;
    private PnLiteCheckInExpansion expansion;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();

        this.checkInManager = new CheckInManager(this);

        // Register commands
        PnLiteCheckInCommand adminCommand = new PnLiteCheckInCommand(this);
        getCommand("pnlc").setExecutor(adminCommand);
        getCommand("pnlc").setTabCompleter(adminCommand);
        getCommand("checkin").setExecutor(new CheckInCommand(this));

        // Register PAPI expansion
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            this.expansion = new PnLiteCheckInExpansion(this);
            this.expansion.register();
            getLogger().info("PlaceholderAPI expansion registered.");
        } else {
            getLogger().warning("PlaceholderAPI not found! Placeholders will not work.");
        }

        getLogger().info("PnLiteCheckIn enabled. Author: Pn86");
    }

    @Override
    public void onDisable() {
        if (expansion != null) {
            expansion.unregister();
        }
        if (checkInManager != null) {
            checkInManager.savePlayerData();
        }
        getLogger().info("PnLiteCheckIn disabled.");
    }

    public CheckInManager getCheckInManager() {
        return checkInManager;
    }

    public void reloadPlugin() {
        reloadConfig();
        checkInManager.reloadConfig();
    }
}
