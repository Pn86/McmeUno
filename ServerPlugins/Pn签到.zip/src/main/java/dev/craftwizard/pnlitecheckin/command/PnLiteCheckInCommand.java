package dev.craftwizard.pnlitecheckin.command;

import dev.craftwizard.pnlitecheckin.PnLiteCheckIn;
import dev.craftwizard.pnlitecheckin.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class PnLiteCheckInCommand implements CommandExecutor, TabCompleter {

    private final PnLiteCheckIn plugin;

    private static final List<String> SUB_COMMANDS = Arrays.asList("reload", "reset");

    public PnLiteCheckInCommand(PnLiteCheckIn plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("pnlitecheckin.admin")) {
            send(sender, plugin.getConfig().getString("messages.prefix", "")
                    + plugin.getConfig().getString("messages.no_permission", "&cYou do not have permission."));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload" -> handleReload(sender);
            case "reset" -> handleReset(sender, args);
            default -> sendUsage(sender);
        }

        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadPlugin();
        String msg = plugin.getConfig().getString("messages.reload_success", "&aConfiguration reloaded.");
        send(sender, plugin.getConfig().getString("messages.prefix", "") + msg);
    }

    private void handleReset(CommandSender sender, String[] args) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");

        if (args.length < 2) {
            send(sender, prefix + "&cUsage: /pnlc reset <player|all>");
            return;
        }

        String target = args[1];

        if (target.equalsIgnoreCase("all")) {
            plugin.getCheckInManager().resetAll();
            String msg = plugin.getConfig().getString("messages.reset_all_success", "&aAll player check-in data has been reset.");
            send(sender, prefix + msg);
            return;
        }

        // Try to find player by name (online first, then offline)
        UUID targetUuid = null;
        String targetName = target;

        Player onlinePlayer = Bukkit.getPlayer(target);
        if (onlinePlayer != null) {
            targetUuid = onlinePlayer.getUniqueId();
            targetName = onlinePlayer.getName();
        } else {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayerIfCached(target);
            if (offlinePlayer != null && offlinePlayer.hasPlayedBefore()) {
                targetUuid = offlinePlayer.getUniqueId();
                targetName = offlinePlayer.getName() != null ? offlinePlayer.getName() : target;
            }
        }

        if (targetUuid == null) {
            String msg = plugin.getConfig().getString("messages.player_not_found", "&cPlayer &e%player% &cnot found.")
                    .replace("%player%", target);
            send(sender, prefix + msg);
            return;
        }

        plugin.getCheckInManager().resetPlayer(targetUuid);
        String msg = plugin.getConfig().getString("messages.reset_player_success", "&aReset check-in data for &e%player%&a.")
                .replace("%player%", targetName);
        send(sender, prefix + msg);
    }

    private void sendUsage(CommandSender sender) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        send(sender, prefix + "&6PnLiteCheckIn &7v" + plugin.getPluginMeta().getVersion() + " by Pn86");
        send(sender, "&7/pnlc reload &8- &fReload configuration");
        send(sender, "&7/pnlc reset <player|all> &8- &fReset check-in data");
        send(sender, "&7/checkin &8- &fDaily check-in");
    }

    /**
     * Send a message to the sender, resolving PAPI placeholders using the
     * sender's player context when available.
     */
    private void send(CommandSender sender, String text) {
        OfflinePlayer context = sender instanceof Player player ? player : null;
        sender.sendMessage(colorize(PlaceholderUtil.applyPlaceholders(context, text)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("pnlitecheckin.admin")) {
            return List.of();
        }

        if (args.length == 1) {
            return SUB_COMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("reset")) {
            List<String> suggestions = new ArrayList<>();
            suggestions.add("all");
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    suggestions.add(player.getName());
                }
            }
            return suggestions;
        }

        return List.of();
    }

    private String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
