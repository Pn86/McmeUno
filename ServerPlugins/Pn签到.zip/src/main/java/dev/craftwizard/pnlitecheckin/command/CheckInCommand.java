package dev.craftwizard.pnlitecheckin.command;

import dev.craftwizard.pnlitecheckin.PnLiteCheckIn;
import dev.craftwizard.pnlitecheckin.manager.CheckInManager;
import dev.craftwizard.pnlitecheckin.util.PlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class CheckInCommand implements CommandExecutor {

    private final PnLiteCheckIn plugin;

    public CheckInCommand(PnLiteCheckIn plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(colorize(plugin.getConfig().getString("messages.player_only", "&cThis command can only be used by players.")));
            return true;
        }

        if (!sender.hasPermission("pnlitecheckin.use")) {
            sender.sendMessage(colorize(PlaceholderUtil.applyPlaceholders(player,
                    plugin.getConfig().getString("messages.no_permission", "&cYou do not have permission."))));
            return true;
        }

        CheckInManager manager = plugin.getCheckInManager();
        CheckInManager.CheckInResult result = manager.checkIn(player.getUniqueId());

        String prefix = plugin.getConfig().getString("messages.prefix", "");

        if (!result.success) {
            // Already checked in
            String msg = plugin.getConfig().getString("messages.already_checked_in", "&cYou have already checked in today!");
            player.sendMessage(colorize(PlaceholderUtil.applyPlaceholders(player, prefix + msg)));
            return true;
        }

        // Send success messages
        List<String> successMessages = plugin.getConfig().getStringList("messages.checkin_success");
        if (successMessages.isEmpty()) {
            successMessages = List.of("&aCheck-in successful!");
        }

        for (String line : successMessages) {
            // Resolve built-in %pnlc_*% placeholders first, then any other PAPI placeholder.
            String processed = applyInternal(line, result);
            processed = PlaceholderUtil.applyPlaceholders(player, processed);
            player.sendMessage(colorize(prefix + processed));
        }

        // Execute console commands (supports arbitrary PAPI placeholders)
        for (String cmd : plugin.getConfig().getStringList("checkin_commands")) {
            String processed = cmd.replace("%player_name%", player.getName());
            processed = applyInternal(processed, result);
            processed = PlaceholderUtil.applyPlaceholders(player, processed);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processed);
        }

        return true;
    }

    private String applyInternal(String text, CheckInManager.CheckInResult result) {
        return text
                .replace("%pnlc_top%", String.valueOf(result.todayPosition))
                .replace("%pnlc_max%", String.valueOf(result.consecutiveDays))
                .replace("%pnlc_day%", String.valueOf(result.totalDays));
    }

    private String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
