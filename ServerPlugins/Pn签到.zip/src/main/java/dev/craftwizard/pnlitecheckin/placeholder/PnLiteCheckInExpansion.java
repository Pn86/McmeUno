package dev.craftwizard.pnlitecheckin.placeholder;

import dev.craftwizard.pnlitecheckin.PnLiteCheckIn;
import dev.craftwizard.pnlitecheckin.manager.CheckInManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PnLiteCheckInExpansion extends PlaceholderExpansion {

    private final PnLiteCheckIn plugin;

    public PnLiteCheckInExpansion(PnLiteCheckIn plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "pnlc";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Pn86";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) {
            return "";
        }

        CheckInManager manager = plugin.getCheckInManager();

        return switch (params) {
            case "use" -> {
                // %pnlc_use% - 今天是否签到 (是/否)
                yield manager.hasCheckedInToday(player.getUniqueId()) ? "是" : "否";
            }
            case "day" -> {
                // %pnlc_day% - 一共签到了多少天
                yield String.valueOf(manager.getTotalDays(player.getUniqueId()));
            }
            case "max" -> {
                // %pnlc_max% - 连续签到了多少天
                yield String.valueOf(manager.getConsecutiveDays(player.getUniqueId()));
            }
            case "top" -> {
                // %pnlc_top% - 今天第几个签到的玩家（未签到返回 0）
                yield String.valueOf(manager.getTodayPosition(player.getUniqueId()));
            }
            default -> null;
        };
    }
}
