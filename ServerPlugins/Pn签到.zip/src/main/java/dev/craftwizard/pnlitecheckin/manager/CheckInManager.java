package dev.craftwizard.pnlitecheckin.manager;

import dev.craftwizard.pnlitecheckin.PnLiteCheckIn;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class CheckInManager {

    private final PnLiteCheckIn plugin;
    private final File playerFile;
    private YamlConfiguration playerData;

    private String todayDate;
    private final List<UUID> todayOrder;

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public CheckInManager(PnLiteCheckIn plugin) {
        this.plugin = plugin;
        this.playerFile = new File(plugin.getDataFolder(), "player.yml");
        this.todayOrder = new ArrayList<>();
        loadPlayerData();
        refreshToday();
    }

    /**
     * Compute current check-in date based on reset time.
     * If current time is before reset_time, the check-in "day" is yesterday.
     */
    public String computeTodayDate() {
        String resetTimeStr = plugin.getConfig().getString("reset_time", "00:00");
        LocalTime resetTime;
        try {
            resetTime = LocalTime.parse(resetTimeStr, DateTimeFormatter.ofPattern("HH:mm"));
        } catch (Exception e) {
            resetTime = LocalTime.MIDNIGHT;
        }

        LocalTime now = LocalTime.now();
        LocalDate today = LocalDate.now();

        if (now.isBefore(resetTime)) {
            today = today.minusDays(1);
        }

        return today.format(DATE_FORMAT);
    }

    /**
     * Refresh today tracking. If the stored date differs from computed today,
     * clear today's order list.
     */
    public void refreshToday() {
        String computed = computeTodayDate();
        String stored = playerData.getString("today.date", "");

        if (!computed.equals(stored)) {
            // New day: clear order
            playerData.set("today.date", computed);
            playerData.set("today.order", new ArrayList<>());
            todayOrder.clear();
        } else {
            // Same day: reload order from data
            todayOrder.clear();
            List<String> storedOrder = playerData.getStringList("today.order");
            for (String uuidStr : storedOrder) {
                try {
                    todayOrder.add(UUID.fromString(uuidStr));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        this.todayDate = computed;
    }

    public void loadPlayerData() {
        if (!playerFile.exists()) {
            try {
                playerFile.getParentFile().mkdirs();
                playerFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create player.yml: " + e.getMessage());
            }
        }
        this.playerData = YamlConfiguration.loadConfiguration(playerFile);

        // Ensure today section exists
        if (!playerData.contains("today.date")) {
            playerData.set("today.date", computeTodayDate());
            playerData.set("today.order", new ArrayList<>());
        }
        if (!playerData.contains("players")) {
            playerData.createSection("players");
        }

        // Load today order
        todayOrder.clear();
        List<String> storedOrder = playerData.getStringList("today.order");
        for (String uuidStr : storedOrder) {
            try {
                todayOrder.add(UUID.fromString(uuidStr));
            } catch (IllegalArgumentException ignored) {
            }
        }
        this.todayDate = playerData.getString("today.date", computeTodayDate());
    }

    public void savePlayerData() {
        // Save today order back to config
        List<String> uuidList = new ArrayList<>();
        for (UUID uuid : todayOrder) {
            uuidList.add(uuid.toString());
        }
        playerData.set("today.date", todayDate);
        playerData.set("today.order", uuidList);

        try {
            playerData.save(playerFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save player.yml: " + e.getMessage());
        }
    }

    /**
     * Result of a check-in attempt.
     */
    public static class CheckInResult {
        public final boolean success;
        public final int totalDays;
        public final int consecutiveDays;
        public final int todayPosition;

        public CheckInResult(boolean success, int totalDays, int consecutiveDays, int todayPosition) {
            this.success = success;
            this.totalDays = totalDays;
            this.consecutiveDays = consecutiveDays;
            this.todayPosition = todayPosition;
        }
    }

    /**
     * Perform a check-in for the player.
     */
    public CheckInResult checkIn(UUID uuid) {
        refreshToday();

        // Already checked in today?
        if (todayOrder.contains(uuid)) {
            int idx = todayOrder.indexOf(uuid) + 1;
            int total = getTotalDays(uuid);
            int consecutive = getConsecutiveDays(uuid);
            return new CheckInResult(false, total, consecutive, idx);
        }

        // Compute new stats
        String path = "players." + uuid.toString();
        int totalDays = playerData.getInt(path + ".total_days", 0) + 1;

        int consecutiveDays;
        String lastCheckinDateStr = playerData.getString(path + ".last_checkin", "");
        if (lastCheckinDateStr.isEmpty()) {
            consecutiveDays = 1;
        } else {
            try {
                LocalDate lastDate = LocalDate.parse(lastCheckinDateStr, DATE_FORMAT);
                LocalDate today = LocalDate.parse(todayDate, DATE_FORMAT);
                if (lastDate.equals(today.minusDays(1))) {
                    // Consecutive: yesterday
                    consecutiveDays = playerData.getInt(path + ".consecutive_days", 0) + 1;
                } else if (lastDate.equals(today)) {
                    // Shouldn't happen since we check todayOrder, but handle gracefully
                    consecutiveDays = playerData.getInt(path + ".consecutive_days", 0);
                } else {
                    // Broken streak
                    consecutiveDays = 1;
                }
            } catch (Exception e) {
                consecutiveDays = 1;
            }
        }

        // Add to today order
        todayOrder.add(uuid);
        int todayPosition = todayOrder.size();

        // Save player data
        playerData.set(path + ".last_checkin", todayDate);
        playerData.set(path + ".total_days", totalDays);
        playerData.set(path + ".consecutive_days", consecutiveDays);

        // Persist order
        List<String> uuidList = new ArrayList<>();
        for (UUID id : todayOrder) {
            uuidList.add(id.toString());
        }
        playerData.set("today.date", todayDate);
        playerData.set("today.order", uuidList);

        savePlayerData();

        return new CheckInResult(true, totalDays, consecutiveDays, todayPosition);
    }

    public boolean hasCheckedInToday(UUID uuid) {
        refreshToday();
        return todayOrder.contains(uuid);
    }

    public int getTotalDays(UUID uuid) {
        return playerData.getInt("players." + uuid.toString() + ".total_days", 0);
    }

    public int getConsecutiveDays(UUID uuid) {
        return playerData.getInt("players." + uuid.toString() + ".consecutive_days", 0);
    }

    public int getTodayPosition(UUID uuid) {
        refreshToday();
        if (!todayOrder.contains(uuid)) {
            return 0;
        }
        return todayOrder.indexOf(uuid) + 1;
    }

    public int getTodayCount() {
        refreshToday();
        return todayOrder.size();
    }

    public String getTodayDate() {
        return todayDate;
    }

    /**
     * Reset a single player's data.
     */
    public void resetPlayer(UUID uuid) {
        playerData.set("players." + uuid.toString(), null);
        todayOrder.remove(uuid);
        savePlayerData();
    }

    /**
     * Reset all player data.
     */
    public void resetAll() {
        playerData.set("players", null);
        playerData.createSection("players");
        todayOrder.clear();
        playerData.set("today.order", new ArrayList<>());
        savePlayerData();
    }

    public void reloadConfig() {
        playerData = YamlConfiguration.loadConfiguration(playerFile);
        refreshToday();
    }
}
