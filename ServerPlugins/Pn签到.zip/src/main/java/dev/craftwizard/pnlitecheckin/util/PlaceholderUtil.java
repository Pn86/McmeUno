package dev.craftwizard.pnlitecheckin.util;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

/**
 * Helper for resolving PlaceholderAPI placeholders inside configuration strings.
 */
public final class PlaceholderUtil {

    private PlaceholderUtil() {
    }

    public static boolean isPlaceholderApiAvailable() {
        return Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
    }

    /**
     * Replace all PlaceholderAPI placeholders in the given text.
     *
     * @param player the player context; may be {@code null} for playerless placeholders
     *               (e.g. when the command sender is the console).
     */
    public static String applyPlaceholders(OfflinePlayer player, String text) {
        if (text == null) {
            return "";
        }
        if (!isPlaceholderApiAvailable()) {
            return text;
        }
        return PlaceholderAPI.setPlaceholders(player, text);
    }
}
