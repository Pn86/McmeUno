package dev.craftwizard.pnironelevators;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.util.concurrent.CompletableFuture;

/**
 * 电梯核心逻辑：
 * 玩家站在允许的方块上，按 Shift 传送到下方最近的方块，按跳跃传送到上方最近的方块。
 * 传送前会检查目标站立空间与头部空间是否可通行，避免卡进方块。
 * 全部使用 Folia 安全的调度方式（teleportAsync / RegionScheduler），不依赖 Bukkit 调度器。
 */
public final class ElevatorListener implements Listener {

    private enum Direction { UP, DOWN }

    private final PnIronElevators plugin;
    private final ElevatorConfig config;

    public ElevatorListener(PnIronElevators plugin, ElevatorConfig config) {
        this.plugin = plugin;
        this.config = config;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) {
            return;
        }
        Player player = event.getPlayer();
        // 脚下方块检查已确保玩家站在电梯方块上，无需依赖客户端上报的 isOnGround
        if (tryTeleport(player, Direction.DOWN)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onJump(PlayerJumpEvent event) {
        if (tryTeleport(event.getPlayer(), Direction.UP)) {
            event.setCancelled(true);
        }
    }

    private boolean tryTeleport(Player player, Direction direction) {
        if (!config.isEnabled() || !config.isWorldAllowed(player.getWorld())) {
            return false;
        }

        // 玩家脚下方块（玩家站在其上）
        Block origin = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
        if (!config.isElevatorBlock(origin.getType())) {
            return false;
        }

        int step = direction == Direction.UP ? 1 : -1;
        for (int i = 1; i <= config.getMaxDistance(); i++) {
            int y = origin.getY() + i * step;
            if (y < origin.getWorld().getMinHeight() || y >= origin.getWorld().getMaxHeight()) {
                break;
            }
            Block candidate = origin.getWorld().getBlockAt(origin.getX(), y, origin.getZ());
            if (!config.isElevatorBlock(candidate.getType())) {
                continue;
            }
            if (i < config.getMinDistance()) {
                continue;
            }
            Location destination = buildDestination(player, candidate);
            if (!isDestinationSafe(destination)) {
                // 目标空间被堵住时继续向上/向下寻找下一个可用方块，避免卡方块
                continue;
            }
            teleport(player, destination);
            return true;
        }
        return false;
    }

    private Location buildDestination(Player player, Block elevatorBlock) {
        Location destination = elevatorBlock.getLocation().clone();
        destination.setX(elevatorBlock.getX() + 0.5);
        destination.setY(elevatorBlock.getY() + 1.0 + config.getYOffset());
        destination.setZ(elevatorBlock.getZ() + 0.5);
        destination.setYaw(player.getLocation().getYaw());
        destination.setPitch(player.getLocation().getPitch());
        return destination;
    }

    /**
     * 检查目标位置的站立块与头部块是否均可通行，防止玩家卡进方块。
     */
    private boolean isDestinationSafe(Location destination) {
        Block feet = destination.getBlock();
        Block head = feet.getRelative(BlockFace.UP);
        return feet.isPassable() && head.isPassable();
    }

    private void teleport(Player player, Location destination) {
        CompletableFuture<Boolean> future = player.teleportAsync(destination);
        future.whenComplete((result, error) -> {
            if (!Boolean.TRUE.equals(result) || error != null) {
                return;
            }
            // 在目标区域线程执行状态修改与音效，保证 Paper 主线程 / Folia 区域线程安全
            Bukkit.getRegionScheduler().run(plugin, destination, task -> {
                // 重置下落距离，避免传送后摔落伤害
                player.setFallDistance(0.0f);
                if (config.isSoundEnabled()) {
                    destination.getWorld().playSound(
                            destination,
                            config.getSound(),
                            config.getSoundVolume(),
                            config.getSoundPitch());
                }
            });
        });
    }
}
