package dev.craftwizard.pnironelevators;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * 读取并校验 config.yml，为电梯行为提供配置参数。
 * 所有非法配置都会给出警告并回退到安全默认值。
 */
public final class ElevatorConfig {

    private static final int DEFAULT_MIN_DISTANCE = 2;
    private static final int DEFAULT_MAX_DISTANCE = 64;

    private final PnIronElevators plugin;

    private boolean enabled;
    private Set<String> allowedWorlds = Collections.emptySet();
    private int minDistance = DEFAULT_MIN_DISTANCE;
    private int maxDistance = DEFAULT_MAX_DISTANCE;
    private Set<Material> elevatorBlocks = Collections.singleton(Material.IRON_BLOCK);
    private boolean soundEnabled;
    private Sound sound;
    private float soundVolume;
    private float soundPitch;
    private double yOffset;
    private Component msgReloaded;
    private Component msgNoPermission;
    private Component msgUsage;

    public ElevatorConfig(PnIronElevators plugin) {
        this.plugin = plugin;
    }

    /**
     * 重新读取并校验配置。必须在 plugin.reloadConfig() 之后调用。
     */
    public void reload() {
        FileConfiguration cfg = plugin.getConfig();

        enabled = cfg.getBoolean("enabled", true);

        allowedWorlds = new HashSet<>();
        for (String world : cfg.getStringList("worlds")) {
            if (world != null && !world.isBlank()) {
                allowedWorlds.add(world.toLowerCase(Locale.ROOT));
            }
        }

        minDistance = Math.max(1, cfg.getInt("min-distance", DEFAULT_MIN_DISTANCE));
        int configuredMax = cfg.getInt("max-distance", DEFAULT_MAX_DISTANCE);
        if (configuredMax < minDistance) {
            plugin.getLogger().warning("max-distance (" + configuredMax
                    + ") 小于 min-distance (" + minDistance + ")，已调整为 " + minDistance);
            configuredMax = minDistance;
        }
        maxDistance = configuredMax;

        elevatorBlocks = new HashSet<>();
        for (String blockName : cfg.getStringList("blocks")) {
            if (blockName == null || blockName.isBlank()) {
                continue;
            }
            Material material = Material.matchMaterial(blockName);
            if (material == null) {
                plugin.getLogger().warning("无法识别的方块: " + blockName);
            } else if (!material.isBlock()) {
                plugin.getLogger().warning("'" + blockName + "' 不是方块类型，已忽略");
            } else {
                elevatorBlocks.add(material);
            }
        }
        if (elevatorBlocks.isEmpty()) {
            elevatorBlocks.add(Material.IRON_BLOCK);
            plugin.getLogger().warning("blocks 列表为空或全部无效，已回退为默认方块 IRON_BLOCK");
        }

        soundEnabled = cfg.getBoolean("sound.enabled", true);
        String soundName = cfg.getString("sound.sound", "ENTITY_ENDERMAN_TELEPORT");
        if (soundName == null || soundName.equalsIgnoreCase("none")) {
            sound = null;
            soundEnabled = false;
        } else {
            sound = parseSound(soundName);
            if (sound == null) {
                plugin.getLogger().warning("无法识别的音效: " + soundName + "，传送时将不播放音效");
                soundEnabled = false;
            }
        }
        soundVolume = (float) cfg.getDouble("sound.volume", 1.0);
        soundPitch = (float) cfg.getDouble("sound.pitch", 1.0);

        yOffset = cfg.getDouble("y-offset", 0.0);
        if (yOffset < 0.0) {
            plugin.getLogger().warning("y-offset 不能为负数，已调整为 0.0");
            yOffset = 0.0;
        }

        msgReloaded = color(cfg.getString("messages.reloaded", "&aPnIronElevators 配置已重载。"));
        msgNoPermission = color(cfg.getString("messages.no-permission", "&c你没有权限执行此命令。"));
        msgUsage = color(cfg.getString("messages.usage", "&e/pnie reload &7- 重载插件配置"));
    }

    /**
     * 解析音效名：支持 minecraft:命名空间键、旧式枚举名（ENTITY_ENDERMAN_TELEPORT）。
     */
    private Sound parseSound(String name) {
        NamespacedKey key;
        if (name.contains(":")) {
            key = NamespacedKey.fromString(name);
        } else {
            // 兼容旧式枚举名：ENTITY_ENDERMAN_TELEPORT -> entity.enderman.teleport
            key = NamespacedKey.minecraft(name.toLowerCase(Locale.ROOT).replace('_', '.'));
        }
        return key == null ? null : Registry.SOUND_EVENT.get(key);
    }

    private Component color(String text) {
        return text == null ? Component.empty() : LegacyComponentSerializer.legacyAmpersand().deserialize(text);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isWorldAllowed(World world) {
        return allowedWorlds.isEmpty()
                || allowedWorlds.contains(world.getName().toLowerCase(Locale.ROOT));
    }

    public int getMinDistance() {
        return minDistance;
    }

    public int getMaxDistance() {
        return maxDistance;
    }

    public boolean isElevatorBlock(Material material) {
        return elevatorBlocks.contains(material);
    }

    public boolean isSoundEnabled() {
        return soundEnabled && sound != null;
    }

    public Sound getSound() {
        return sound;
    }

    public float getSoundVolume() {
        return soundVolume;
    }

    public float getSoundPitch() {
        return soundPitch;
    }

    public double getYOffset() {
        return yOffset;
    }

    public Component getMsgReloaded() {
        return msgReloaded;
    }

    public Component getMsgNoPermission() {
        return msgNoPermission;
    }

    public Component getMsgUsage() {
        return msgUsage;
    }
}
