package dev.craftwizard.pnironelevators;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

/**
 * PnIronElevators 主类。
 * 铁块电梯：站在允许的方块上按 Shift 向下传送、按跳跃向上传送。
 */
public final class PnIronElevators extends JavaPlugin implements CommandExecutor {

    private ElevatorConfig elevatorConfig;
    private ElevatorListener elevatorListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.elevatorConfig = new ElevatorConfig(this);
        this.elevatorConfig.reload();

        this.elevatorListener = new ElevatorListener(this, this.elevatorConfig);
        getServer().getPluginManager().registerEvents(this.elevatorListener, this);

        Objects.requireNonNull(getCommand("pnie"), "pnie 命令未在 plugin.yml 中注册").setExecutor(this);

        getLogger().info("PnIronElevators 已启用（作者: Pn86）。");
    }

    @Override
    public void onDisable() {
        getLogger().info("PnIronElevators 已禁用。");
    }

    /**
     * 重载插件配置。
     */
    public void reloadPlugin() {
        reloadConfig();
        if (elevatorConfig != null) {
            elevatorConfig.reload();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("pnie")) {
            return false;
        }
        if (args.length == 0) {
            sender.sendMessage(elevatorConfig.getMsgUsage());
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("pnie.reload")) {
                sender.sendMessage(elevatorConfig.getMsgNoPermission());
                return true;
            }
            reloadPlugin();
            sender.sendMessage(elevatorConfig.getMsgReloaded());
            return true;
        }
        sender.sendMessage(elevatorConfig.getMsgUsage());
        return true;
    }
}
