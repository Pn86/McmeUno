package cn.pn86.pnchat.protocol;

/**
 * PnChat 代理端与子服桥之间的插件消息协议常量。
 * 该协议使用 DataInputStream / DataOutputStream 二进制格式，UTF-8 文本。
 *
 * <p>所有消息的第一个字节都是 {@link #MESSAGE_PROTOCOL_VERSION}，用于快速识别
 * 旧版插件发送的旧格式消息，避免误解析产生 EOFException。</p>
 */
public final class PnChatProtocol {

    /** 现代（1.13+）插件消息通道 */
    public static final String CHANNEL = "pnchat:main";
    /** 旧版（1.8-1.12.2）插件消息通道：1.12 及以下不允许通道名包含冒号 */
    public static final String CHANNEL_LEGACY = "PnChat";

    /** 代理 -> 桥：请求某个玩家的手持物品数据 */
    public static final String ACTION_HELD_ITEM = "HELD_ITEM";
    /** 桥 -> 代理：上报某个玩家的手持物品数据（v2 结构化负载） */
    public static final String ACTION_ITEM = "ITEM";
    /** 客户端 Mod -> 代理：客户端主动上报手持物品数据（v2 结构化负载） */
    public static final String ACTION_ITEM_CLIENT = "ITEM_CLIENT";
    /** 子服插件 -> 代理：AuthMe 登录状态上报 */
    public static final String ACTION_AUTH_STATUS = "AUTH_STATUS";
    /** 代理 -> 子服：聊天记录推送（桥接端应静默忽略） */
    public static final String ACTION_CHAT_LOG = "CHAT_LOG";
    public static final String ACTION_PRIVATE_LOG = "PRIVATE_LOG";

    /** 消息级协议版本：所有 pnchat 消息的第一个字节必须是它 */
    public static final int MESSAGE_PROTOCOL_VERSION = 2;

    /** 单条插件消息最大字节数（Minecraft 自定义负载常见上限） */
    public static final int MAX_PAYLOAD_BYTES = 30000;

    /** 物品负载协议版本 */
    public static final int ITEM_PAYLOAD_VERSION = 2;

    private PnChatProtocol() {
    }
}
