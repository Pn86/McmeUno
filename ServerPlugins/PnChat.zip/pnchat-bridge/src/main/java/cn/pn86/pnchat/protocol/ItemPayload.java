package cn.pn86.pnchat.protocol;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 结构化的物品展示数据（v2 协议）。
 *
 * <p>该类型只做二进制读写，不依赖 Bukkit/Paper API，代理端与桥接端共用。
 * 设计为 Java 8 兼容。</p>
 *
 * <p>字段说明：typeKey 为物品注册键（如 minecraft:diamond_sword，模组物品可能为
 * 非 minecraft 命名空间）；displayName/lore 为服务端读取到的显示文本（可能含 § 颜色码）；
 * nbt 为服务端序列化的 SNBT 摘要（可能为空）；modded 用于标识模组物品。</p>
 */
public final class ItemPayload {

    /** 为避免超长 lore 撑爆插件消息，做截断 */
    public static final int MAX_LORE_LINES = 10;
    public static final int MAX_LORE_LINE_LENGTH = 200;
    public static final int MAX_ENCHANT_COUNT = 20;
    public static final int MAX_NBT_LENGTH = 4000;

    public String typeKey;
    public String displayName;
    public int amount;
    public int durability;
    public int maxDurability;
    public List<String> lore;
    public List<Enchant> enchantments;
    public String nbt;
    public boolean modded;

    public ItemPayload() {
        this.typeKey = "";
        this.displayName = "";
        this.amount = 1;
        this.durability = 0;
        this.maxDurability = 0;
        this.lore = Collections.emptyList();
        this.enchantments = Collections.emptyList();
        this.nbt = "";
        this.modded = false;
    }

    /**
     * 把负载写入输出流。写之前会做截断，保证单条消息不会过大。
     */
    public void write(DataOutput out) throws IOException {
        out.writeByte(PnChatProtocol.ITEM_PAYLOAD_VERSION);
        out.writeUTF(trim(typeKey, 200));
        out.writeUTF(trim(displayName, 300));
        out.writeInt(Math.max(1, amount));
        out.writeInt(durability);
        out.writeInt(maxDurability);

        List<String> safeLore = lore == null ? Collections.<String>emptyList() : lore;
        if (safeLore.size() > MAX_LORE_LINES) {
            safeLore = safeLore.subList(0, MAX_LORE_LINES);
        }
        out.writeInt(safeLore.size());
        for (String line : safeLore) {
            out.writeUTF(trim(line, MAX_LORE_LINE_LENGTH));
        }

        List<Enchant> safeEnchants = enchantments == null ? Collections.<Enchant>emptyList() : enchantments;
        if (safeEnchants.size() > MAX_ENCHANT_COUNT) {
            safeEnchants = safeEnchants.subList(0, MAX_ENCHANT_COUNT);
        }
        out.writeInt(safeEnchants.size());
        for (Enchant enchant : safeEnchants) {
            out.writeUTF(trim(enchant == null ? "" : enchant.key, 100));
            out.writeInt(enchant == null ? 0 : Math.max(0, enchant.level));
        }

        out.writeUTF(trim(nbt, MAX_NBT_LENGTH));
        out.writeBoolean(modded);
    }

    /**
     * 从输入流读取负载。任何长度异常都会抛 IOException，由调用方记录日志。
     */
    public static ItemPayload read(DataInput in) throws IOException {
        int version = in.readUnsignedByte();
        if (version != PnChatProtocol.ITEM_PAYLOAD_VERSION) {
            throw new IOException("不支持的物品负载协议版本: " + version);
        }
        ItemPayload payload = new ItemPayload();
        payload.typeKey = in.readUTF();
        payload.displayName = in.readUTF();
        payload.amount = Math.max(1, in.readInt());
        payload.durability = in.readInt();
        payload.maxDurability = in.readInt();

        int loreCount = in.readInt();
        if (loreCount < 0 || loreCount > 64) {
            throw new IOException("物品 lore 行数异常: " + loreCount);
        }
        if (loreCount > 0) {
            List<String> lore = new ArrayList<String>(loreCount);
            for (int i = 0; i < loreCount; i++) {
                lore.add(in.readUTF());
            }
            payload.lore = lore;
        }

        int enchantCount = in.readInt();
        if (enchantCount < 0 || enchantCount > 64) {
            throw new IOException("物品附魔数量异常: " + enchantCount);
        }
        if (enchantCount > 0) {
            List<Enchant> enchants = new ArrayList<Enchant>(enchantCount);
            for (int i = 0; i < enchantCount; i++) {
                enchants.add(new Enchant(in.readUTF(), in.readInt()));
            }
            payload.enchantments = enchants;
        }

        payload.nbt = in.readUTF();
        payload.modded = in.readBoolean();
        return payload;
    }

    private static String trim(String value, int max) {
        if (value == null) {
            return "";
        }
        if (value.length() <= max) {
            return value;
        }
        return value.substring(0, max);
    }

    /** 附魔信息：key 为注册键（如 minecraft:sharpness），level 为等级 */
    public static final class Enchant {
        public final String key;
        public final int level;

        public Enchant(String key, int level) {
            this.key = key == null ? "" : key;
            this.level = level;
        }
    }
}
