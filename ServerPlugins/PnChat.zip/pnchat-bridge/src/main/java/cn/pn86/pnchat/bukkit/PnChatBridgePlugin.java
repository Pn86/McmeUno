package cn.pn86.pnchat.bukkit;

import cn.pn86.pnchat.protocol.ItemPayload;
import cn.pn86.pnchat.protocol.PnChatProtocol;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * PnChat 子服桥接插件。
 *
 * <p>编译目标为 Java 8 / spigot-api 1.12.2，运行时可被 1.12 - 1.26.x 以及各类
 * 混合模组端（Arclight/Mohist/CatServer 等）加载。仅调用 1.12 时代就存在的
 * Bukkit API，涉及新版 API（getKey、NBT 序列化等）一律使用反射并捕获异常，
 * 保证跨版本自动兼容。</p>
 *
 * <p>通道选择：1.13+ 使用 {@code pnchat:main}；1.12 及以下 Bukkit 不允许通道名
 * 包含冒号，自动降级为 {@code PnChat} 旧版通道，代理端已同时注册两个通道。</p>
 *
 * <p>职责：检测玩家手持物品变化（加入、切换热栏、点击背包、定时心跳、
 * 收到代理请求），把结构化物品数据通过插件消息通道上报给代理。</p>
 */
public final class PnChatBridgePlugin extends JavaPlugin implements Listener, PluginMessageListener {

    private volatile String channel;

    @Override
    public void onEnable() {
        if (!registerChannels()) {
            getLogger().severe("PnChatBridge 无法注册插件消息通道，插件已禁用。请确认代理端 PnChat 与子服端 PnChatBridge 版本一致。");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        // 周期心跳：兜底覆盖未触发事件的情况（交换副手、其他插件改物品等）
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    sendItem(player);
                }
            }
        }, 100L, 100L);
        getLogger().info("PnChatBridge 已启用，版本 " + getDescription().getVersion() + "，通道 " + channel);
    }

    private boolean registerChannels() {
        // 优先现代通道
        if (tryRegister(PnChatProtocol.CHANNEL)) {
            channel = PnChatProtocol.CHANNEL;
            return true;
        }
        // 1.12 及以下回退旧版通道
        if (tryRegister(PnChatProtocol.CHANNEL_LEGACY)) {
            channel = PnChatProtocol.CHANNEL_LEGACY;
            return true;
        }
        return false;
    }

    private boolean tryRegister(String name) {
        try {
            Bukkit.getMessenger().registerOutgoingPluginChannel(this, name);
            Bukkit.getMessenger().registerIncomingPluginChannel(this, name, this);
            return true;
        } catch (Throwable t) {
            getLogger().warning("注册插件消息通道 " + name + " 失败: " + t.getMessage());
            return false;
        }
    }

    @Override
    public void onDisable() {
        try {
            if (channel != null) {
                Bukkit.getMessenger().unregisterOutgoingPluginChannel(this, channel);
                Bukkit.getMessenger().unregisterIncomingPluginChannel(this, channel, this);
            }
        } catch (Throwable ignored) {
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() {
                sendItem(player);
            }
        }, 20L);
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent event) {
        final Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() {
                sendItem(player);
            }
        }, 1L);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            final Player player = (Player) event.getWhoClicked();
            Bukkit.getScheduler().runTaskLater(this, new Runnable() {
                @Override
                public void run() {
                    sendItem(player);
                }
            }, 1L);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            final Player player = (Player) event.getWhoClicked();
            Bukkit.getScheduler().runTaskLater(this, new Runnable() {
                @Override
                public void run() {
                    sendItem(player);
                }
            }, 1L);
        }
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (this.channel == null || !this.channel.equals(channel)) {
            return;
        }
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
            int version = in.readUnsignedByte();
            if (version != PnChatProtocol.MESSAGE_PROTOCOL_VERSION) {
                getLogger().warning("收到协议版本不匹配的 PnChat 代理消息 (version=" + version
                        + ", len=" + message.length + ")，已忽略。请确认代理端 PnChat 与本桥版本一致。");
                return;
            }
            String action = in.readUTF();
            if (PnChatProtocol.ACTION_HELD_ITEM.equalsIgnoreCase(action)) {
                Player target = null;
                try {
                    target = Bukkit.getPlayer(UUID.fromString(in.readUTF()));
                } catch (Exception ignored) {
                    target = null;
                }
                if (target == null) {
                    target = player;
                }
                if (target != null) {
                    sendItem(target);
                }
            } else if (PnChatProtocol.ACTION_CHAT_LOG.equals(action)
                    || PnChatProtocol.ACTION_PRIVATE_LOG.equals(action)) {
                // 聊天记录推送：桥接端不需要处理，静默忽略
            } else {
                getLogger().warning("收到未知的 PnChat 代理消息: " + action);
            }
        } catch (Exception e) {
            getLogger().warning("处理 PnChat 代理消息失败: " + e.getMessage());
        }
    }

    /**
     * 提取玩家主手物品并上报给代理。无物品 / 玩家离线时静默跳过。
     */
    private void sendItem(Player player) {
        if (player == null || !player.isOnline() || channel == null) {
            return;
        }
        ItemPayload payload = buildPayload(player);
        if (payload == null) {
            return;
        }
        try {
            byte[] data = encodeItem(player, payload);
            if (data.length > PnChatProtocol.MAX_PAYLOAD_BYTES) {
                // 超长负载截断：重建一个更精简的负载（去掉 NBT）
                payload.nbt = "";
                data = encodeItem(player, payload);
            }
            player.sendPluginMessage(this, channel, data);
        } catch (Exception e) {
            getLogger().warning("上报 " + player.getName() + " 的手持物品失败: " + e.getMessage());
        }
    }

    private byte[] encodeItem(Player player, ItemPayload payload) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeByte(PnChatProtocol.MESSAGE_PROTOCOL_VERSION);
        out.writeUTF(PnChatProtocol.ACTION_ITEM);
        out.writeUTF(player.getUniqueId().toString());
        out.writeUTF(player.getName());
        payload.write(out);
        return bytes.toByteArray();
    }

    /**
     * 从 Bukkit ItemStack 提取结构化物品数据。跨版本读取，任何新版 API 都通过反射调用。
     * 返回 null 表示玩家没有可展示的物品。
     */
    private ItemPayload buildPayload(Player player) {
        ItemStack item;
        try {
            item = player.getInventory().getItemInMainHand();
        } catch (Throwable t) {
            return null;
        }
        if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) {
            return null;
        }
        ItemPayload payload = new ItemPayload();
        payload.amount = item.getAmount();
        payload.typeKey = typeKey(item.getType());
        payload.displayName = displayName(item);
        payload.durability = durability(item);
        payload.maxDurability = maxDurability(item.getType());
        payload.lore = lore(item);
        payload.enchantments = enchantments(item);
        payload.nbt = nbtSummary(item);
        payload.modded = isModded(payload.typeKey, payload.enchantments, payload.nbt);
        return payload;
    }

    /**
     * 物品注册键。1.13+ 通过 Material.getKey() 获得 minecraft:diamond_sword；
     * 1.12 退化为大写材质名转小写。模组混合端若 getKey 返回非 minecraft 命名空间，
     * 也能被正确识别。
     */
    private static String typeKey(Material type) {
        try {
            Method method = type.getClass().getMethod("getKey");
            Object key = method.invoke(type);
            if (key != null) {
                String value = String.valueOf(key);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            return type.name().toLowerCase(Locale.ROOT);
        } catch (Throwable ignored) {
            return "unknown";
        }
    }

    private static String displayName(ItemStack item) {
        try {
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.hasDisplayName()) {
                String name = meta.getDisplayName();
                if (name != null && !name.isEmpty()) {
                    return name;
                }
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static int durability(ItemStack item) {
        try {
            return item.getDurability();
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static int maxDurability(Material type) {
        try {
            return type.getMaxDurability();
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static List<String> lore(ItemStack item) {
        try {
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.hasLore()) {
                List<String> lore = meta.getLore();
                if (lore != null) {
                    return lore;
                }
            }
        } catch (Throwable ignored) {
        }
        return new ArrayList<String>(0);
    }

    /**
     * 附魔列表。1.13+ 通过 Enchantment.getKey() 获得 minecraft:sharpness；
     * 1.12 退化为 Enchantment.getName()（如 DAMAGE_ALL）。
     */
    private static List<ItemPayload.Enchant> enchantments(ItemStack item) {
        List<ItemPayload.Enchant> result = new ArrayList<ItemPayload.Enchant>();
        try {
            Map<org.bukkit.enchantments.Enchantment, Integer> enchants = item.getEnchantments();
            if (enchants != null) {
                for (Map.Entry<org.bukkit.enchantments.Enchantment, Integer> entry : enchants.entrySet()) {
                    org.bukkit.enchantments.Enchantment enchant = entry.getKey();
                    if (enchant == null) {
                        continue;
                    }
                    result.add(new ItemPayload.Enchant(enchantKey(enchant), entry.getValue() == null ? 0 : entry.getValue()));
                }
            }
        } catch (Throwable ignored) {
        }
        return result;
    }

    private static String enchantKey(org.bukkit.enchantments.Enchantment enchant) {
        try {
            Method method = enchant.getClass().getMethod("getKey");
            Object key = method.invoke(enchant);
            if (key != null) {
                String value = String.valueOf(key);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            String name = enchant.getName();
            return name == null ? "unknown" : "minecraft:" + name.toLowerCase(Locale.ROOT);
        } catch (Throwable ignored) {
            return "unknown";
        }
    }

    /**
     * 通过 NMS 反射序列化物品 NBT（SNBT 摘要）。1.12 的
     * net.minecraft.server.v1_12_R1.ItemStack#save(NBTTagCompound)，以及
     * 1.17+ 的 net.minecraft.world.item.ItemStack#save(CompoundTag) 都叫 save
     * 且接收 net.minecraft.nbt 包下的一个参数，因此可以通用反射调用。
     */
    private static String nbtSummary(ItemStack item) {
        try {
            String packageName = Bukkit.getServer().getClass().getPackage().getName();
            Class<?> craftClass = Class.forName(packageName + ".inventory.CraftItemStack");
            Method asNmsCopy = craftClass.getMethod("asNMSCopy", ItemStack.class);
            Object nmsItem = asNmsCopy.invoke(null, item);
            if (nmsItem == null) {
                return "";
            }
            for (Method method : nmsItem.getClass().getMethods()) {
                if (!"save".equals(method.getName())) {
                    continue;
                }
                Class<?>[] params = method.getParameterTypes();
                if (params.length != 1 || !params[0].getName().startsWith("net.minecraft.nbt.")) {
                    continue;
                }
                Object tag = params[0].getDeclaredConstructor().newInstance();
                Object result = method.invoke(nmsItem, tag);
                if (result != null) {
                    String text = String.valueOf(result);
                    if (text.length() > ItemPayload.MAX_NBT_LENGTH) {
                        text = text.substring(0, ItemPayload.MAX_NBT_LENGTH);
                    }
                    return text;
                }
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static boolean isModded(String typeKey, List<ItemPayload.Enchant> enchantments, String nbt) {
        if (typeKey != null && typeKey.indexOf(':') > 0 && !typeKey.startsWith("minecraft:")) {
            return true;
        }
        if (enchantments != null) {
            for (ItemPayload.Enchant enchant : enchantments) {
                if (enchant != null && enchant.key != null
                        && enchant.key.indexOf(':') > 0 && !enchant.key.startsWith("minecraft:")) {
                    return true;
                }
            }
        }
        if (nbt != null) {
            String lower = nbt.toLowerCase(Locale.ROOT);
            return lower.contains("modid") || lower.contains("forge") || lower.contains("fabric:")
                    || lower.contains("customdata") || lower.contains("moddata");
        }
        return false;
    }
}
