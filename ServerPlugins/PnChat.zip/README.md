# PnChat

基于 **Velocity 3.5** 的多功能跨服聊天插件，用于把多个服务端**完全不同的服务器**（不同 Minecraft 版本、模组混合端）的聊天串联起来。

- 代理端（Velocity）：跨服聊天、私聊、@提醒、物品展示、敏感词/隐私过滤、反刷屏、禁言、聊天接收模式、进入提示隔离、聊天框自动放行、聊天字数限制、全服 TAB 补全。
- 子服端（Bukkit/Paper/混合模组端，同一 JAR 双身份）：物品展示桥接，**兼容 1.12 - 1.26.x 与模组混合端**，无需在子服额外安装任何插件即可使用聊天功能；物品展示由**代理端内嵌 PacketEvents 数据包识别**实现，子服端安装同一 JAR 仅用于获取更完整物品信息（可选）。

## 目录

- [构建](#构建)
- [安装与双身份说明](#安装与双身份说明)
- [新版本特性](#新版本特性)
- [配置说明](#配置说明)
- [命令与权限](#命令与权限)
- [物品展示协议](#物品展示协议)
- [已知限制](#已知限制)

## 构建

```bash
mvn clean package
```

产物：

- `pnchat-proxy/target/PnChat-1.4.0.jar` —— 最终交付 JAR（含 velocity-plugin.json + plugin.yml 双身份；内嵌 PacketEvents 2.13.0 与 configurate，均已随 JAR 打包，无需额外安装）
- `pnchat-bridge/target/pnchat-bridge-1.4.0.jar` —— 纯桥接模块（Java 8 字节码）

代理端需 **Java 17+**（velocity-api 3.5.1 为 Java 21 字节码，Velocity 3.5 本身运行于 Java 21+）。桥接模块编译目标为 **Java 8 字节码**，可在 1.12.2（Java 8）及更高版本的子服运行。

## 安装与双身份说明

同一个 JAR 同时包含：

- `velocity-plugin.json` → Velocity 代理端加载为 PnChat 主插件（`PnChatPlugin`）
- `plugin.yml` → Bukkit/Paper 子服加载为桥接插件（`PnChatBridgePlugin`）

因此只需把 `PnChat-1.4.0.jar` 放入代理端 `plugins/` 即可（**物品展示默认由代理端数据包识别完成，无需子服安装任何插件**）；子服端**可选**安装同一 JAR 作为桥接插件以获取更完整的物品信息（见下文“代理端数据包识别”）。

> 注意：Velocity 与 Bukkit 各自只读取自己识别的元数据，互不影响。子服端加载时不会加载 Velocity/Configurate 相关类（懒加载），因此不会因 Java 17 字节码报错。

## 新版本特性

### 1. 物品展示（代理端内嵌 PacketEvents 数据包识别，无需子服插件）
- **默认由代理端完成物品识别**：代理 JAR 内嵌 PacketEvents 2.13.0（已 shade 打包，**无需在代理额外安装 PacketEvents 插件**），监听 `Window Items` / `Set Slot` / `Set Player Inventory` / `Held Item Change` 数据包，识别玩家当前手持物品并写入展示缓存。子服**无需安装任何插件**即可使用物品展示。
- **数据来源优先级：代理端数据包识别 > 子服桥接 > 客户端 Mod**（`cache.yml` 中 `source` 字段标记，展示时默认取代理识别结果，防止子服误判）。
- **子服桥接仍是可选增强**：装了桥的子服会上报更完整的结构化数据（中文名、lore、附魔、NBT 摘要），与代理识别共存，代理优先。
- **自动探测与回退**：PacketEvents 初始化失败时自动回退到反射访问 Velocity 内部类的数据包识别；两者都不可用时降级到子服桥/客户端 Mod 上报，不影响其它功能。
- 缓存落盘限流（最多每 5 秒一次）+ 关闭时兜底保存，避免大量 YAML 写盘卡顿。

### 2. 进入提示隔离（默认关闭，支持白名单/黑名单）
`config.yml` → `join-notification`：

```yaml
join-notification:
  enabled: false
  mode: whitelist   # whitelist = 只播报 servers 列出的子服；blacklist = 除 servers 列出外全部播报
  servers: []       # 例如 ["survival", "minigame"]
```

开启后，玩家**首次进入代理**或**转服进入播报范围内子服**时才播报加入提示；登录服/大厅等范围外子服不播报。离开提示也只在玩家曾被播报过加入提示时播报。

- `mode: whitelist`（默认）：只有 `servers` 列表中列出的子服播报（适合子服较少的服务器）。
- `mode: blacklist`：`servers` 列表中列出的子服**不**播报，其余子服全部播报（适合子服很多时，只需列出登录服/大厅等不想播报的子服即可，避免配置一长串列表）。

### 3. 聊天框自动放行（默认关闭）
`config.yml` → `chat-input`：

```yaml
chat-input:
  enabled: false
  servers: []        # 留空 = 所有已配置子服
  max-length: 0      # 大于 0 时，字符数 <= 该值的消息直接放行（如搜索词、数量）
  patterns: []       # 正则列表，任一命中即放行，例如 ["^/shop .*", "购买"]
```

开启后，在**指定子服**内命中规则的聊天框输入会**原样放行到当前子服**（粘液科技搜索、箱子商店购买等子服插件可以正常收到输入），不再进入 PnChat 全服聊天，玩家无需再输入 `#`。**子服无需安装任何额外插件。**

> 请按子服插件实际需要谨慎配置，规则过宽可能导致短消息不再进入全服聊天。

### 4. 聊天字数限制
`config.yml` → `chat.max-length`（默认 256，按字符数，0 = 不限制）。拥有 `pnchat.chat.bypass.length` 权限可绕过。对全服聊天与私聊同时生效。

### 5. 配置不再乱括号、不丢注释
- **不再自动重写用户配置文件**：Configurate 4.2.0 的 YAML 读取不保留注释，因此改为“只读取 + 内存合并默认值”，用户文件始终保持原样（含注释与格式）。
- 新配置文件写出（如 `cache.yml`、`player.yml`）使用 BLOCK 节点风格 + 2 空格缩进，不再出现 flow 风格的一堆 `{}` 括号。
- 删除配置文件并重启可重新生成带注释的默认配置。

### 6. 聊天框全服玩家 TAB 补全
- **1.13+ 客户端**：使用 Velocity `Player.setCustomChatCompletions` 推送全服在线玩家名（连接时 + 每 30 秒刷新，最多 1000 个）。
- **≤1.12.2 客户端**：使用 `TabCompleteEvent` 追加（该事件仅对旧版客户端触发）。
- 可在 `chat.tab-complete-all-servers` 关闭。

### 7. 修复物品展示/加入退出失效、新增屏蔽指令
- **插件消息协议加版本号（同时兼容旧版）**：新版 pnchat 消息第一个字节为协议版本号（2）；**旧版无版本字节的消息（旧 AuthMe 用原始 boolean、旧版桥/客户端 Mod 用 Base64 旧格式）也会被兼容解析**——旧版聊天登录识别插件的 `AUTH_STATUS`、旧版桥的 `ITEM`、旧版客户端 Mod 的 `ITEM_CLIENT` 均按旧格式解析并正常处理，不再拒绝、不再产生 `EOFException`/WARN 刷屏。请尽量把所有子服端的 PnChatBridge 更新到同一版本以获取更完整数据。
- **桥接通道自动降级**：1.12 及以下 Bukkit 不允许通道名含冒号，桥会自动回退到 `PnChat` 旧版通道；代理端同时注册 `pnchat:main` 与 `PnChat` 两个通道。
- **cache.yml 不再生成空文件**：没有物品数据时不再写盘，不再出现 `items: null/{}`。
- **加入/离开/转服提示修复**：离开提示在退出事件中改用最后一次记录的服务器名（不再受 `getCurrentServer()` 已为空影响）；转服提示与加入/退出一样遵循 `join-notification.servers` 隔离；跳过时会输出 WARN 日志便于排查（例如子服未在 server.yml 配置、不在隔离列表）。
- **屏蔽指令（保存于 player.yml，一级命令）**：
  - `/ignore <玩家名>`（别名 `/ign`）—— 屏蔽/解除屏蔽某玩家的全服聊天与私聊
  - `/ignoreserver <子服名>` —— 屏蔽/解除屏蔽某子服的全部全服聊天
  - `/ignorelist`（别名 `/il`）—— 查看当前屏蔽列表
  - 兼容入口：`/pnchat ignore|ignoreserver|ignorelist` 仍然可用。
  - 被屏蔽后：对方的公开聊天不会显示给你、私聊会被拦截（对方会收到“对方屏蔽了你”提示）、@提醒也不会弹出。
  - 数据保存在 `plugins/pnchat/player.yml` 的 `ignored-players` / `ignored-servers` 节点。

### 8. 代理端数据包识别（内嵌 PacketEvents，无需子服插件）
- **原理**：直接在 Velocity 代理端监听客户端与子服之间的协议包，识别玩家当前手持物品并写入展示缓存。子服**无需安装 PnChatBridge**，解决子服环境受限（无法装插件、模组混合端等）的问题。
- **内嵌 PacketEvents（1.4.0 核心）**：代理 JAR 直接 shade 打包 PacketEvents 2.13.0（`com.github.retrooper:packetevents-velocity` 及依赖），启动时 `VelocityPacketEventsBuilder.build(...)` 创建实例并注册监听，**代理端无需额外安装 PacketEvents 插件**。物品栏内容更新（`Window Items` / `Set Slot` / `Set Player Inventory`，代理 → 客户端方向）与热栏切换（双向 `Held Item Change`）由 PacketEvents 统一注入并解析，兼容 1.7 – 26.x。
- **自动探测与降级**：PacketEvents 初始化失败时回退到反射访问 Velocity 内部类的旧方案；仍不可用则仅依赖子服桥/客户端 Mod 上报。启动日志会明确显示当前使用的识别方式。
- **debug 日志**：`config.yml` 顶部 `debug: true`（或运行时 `/pnchat debug on|off|status`，权限 `pnchat.command.debug`）可输出数据包识别详细日志（收到哪些包、解析到的物品、异常堆栈）。
- **精度说明**：数据包识别通常能提供物品**注册键/数量/NBT 摘要**；物品中文名/lore 依赖 `item.yml` 映射与 NBT display 数据。装了 PnChatBridge 的子服会用桥上报更完整的数据，但展示默认优先代理识别结果。
- **配置**（默认开启）：
```yaml
item-detection:
  packet-sniffer:
    enabled: true
```

## 配置说明

首次启动会在 `plugins/pnchat/` 生成以下文件（已存在则不覆盖）：

| 文件 | 用途 |
| --- | --- |
| `config.yml` | 主配置：功能开关、聊天冷却/字数、直接发送、进入提示隔离、聊天框自动放行、@/URL、敏感词/隐私、反刷屏、AuthMe、物品展示、日志 |
| `server.yml` | 子服显示名、default-sends、default-chats |
| `chat.yml` | 各子服聊天格式、私聊格式、是否允许物品展示 |
| `message.yml` | 所有提示文案 |
| `item.yml` | 物品/附魔中文名映射（可自行扩展模组物品名） |
| `cache.yml` | 物品展示缓存（自动维护） |
| `player.yml` | 禁言、称号、聊天接收模式、屏蔽列表（自动维护） |

### 核心配置项

```yaml
features:
  chat: true
  private-message: true
  mention: true
  url: true
  item-showcase: true
  join-message: true
  quit-message: true
  transfer-message: true

debug: false                # 调试日志（/pnchat debug 可运行时切换）

chat:
  cooldown-ms: 1500
  max-length: 256          # 聊天字数限制（0 = 不限制）
  tab-complete-all-servers: true
  item-token: "[i]"
  allow-color-codes: false

item-showcase:
  max-age-ms: 5000         # 缓存新鲜度
  request-timeout-ms: 750  # 请求最新物品的最长等待
  view-seconds: 120        # 缓存有效期
  cleanup-interval-seconds: 300
  clear-cache-on-start: true
```

## 命令与权限

| 命令 | 说明 | 权限 |
| --- | --- | --- |
| `/pnchat m <消息>` | 全服广播 | `pnchat.command.admin` |
| `/pnchat t <fadeIn> <stay> <fadeOut> <标题> [副标题]` | 全服 Title | `pnchat.command.admin` |
| `/pnchat p <称号>` / `/pnchat rp` | 设置/移除自己的称号 | `pnchat.command.title` |
| `/ignore`（别名 `/ign`） | 屏蔽/解除屏蔽某玩家（聊天+私聊） | 无 |
| `/ignoreserver <子服>` | 屏蔽/解除屏蔽某子服聊天 | 无 |
| `/ignorelist`（别名 `/il`） | 查看屏蔽列表 | 无 |
| `/pnchat debug [on|off|status]` | 开启/关闭/查看调试日志 | `pnchat.command.debug` |
| `/pnchat reload` | 重载配置 | `pnchat.command.reload` |
| `/msg <玩家> <消息>`（别名 tell/w/m/whisper） | 跨服私聊 | 无（默认允许） |
| `/r <消息>`（别名 reply） | 回复最近私聊对象 | 无 |
| `/send <消息>` | 把消息发送到当前子服（不进入全服聊天） | 无 |
| `/sends [true|false]` | 切换“直接发送模式” | 无 |
| `/chats <only|all>` | 聊天接收模式 | 无 |
| `/banchat <玩家>` | 切换禁言 | `pnchat.command.banchat` |

> `/pnchat ignore|ignoreserver|ignorelist` 仍作为兼容入口保留，功能与一级命令相同。

其他权限：

- `pnchat.cooldown.bypass` —— 无视聊天冷却
- `pnchat.chat.bypass.length` —— 无视聊天字数限制

## 物品展示协议

通道：`pnchat:main`（1.13+ 子服）与 `PnChat`（1.12 及以下子服）。所有消息使用 DataOutputStream 二进制，UTF-8，**第一个字节为协议版本号（2）**。

- 桥 → 代理：`version + "ITEM" + uuid + name + ItemPayload`
- 客户端 Mod → 代理：`version + "ITEM_CLIENT" + ItemPayload`
- 代理 → 桥：`version + "HELD_ITEM" + uuid`
- `ItemPayload` 字段：版本号、typeKey（注册键，模组物品保留非 minecraft 命名空间）、displayName、amount、durability、maxDurability、lore 数组、附魔数组（key/level）、NBT 摘要、modded 标记。所有文本有长度截断，单条消息不超过 30KB。

## 已知限制

1. **1.19.1+ 签名聊天**：Velocity 3.x 无法在代理端取消或修改签名聊天（`ChatResult.denied()`/`message()` 会导致 `A plugin tried to cancel a signed chat message` 踢人）。若你的客户端主要是 1.19.1+，请安装 [SignedVelocity](https://hangar.papermc.io/4drian3d/SignedVelocity)，或在子服关闭 `enforce-secure-profile`。
2. **`/send` 与 `#` 前缀在 1.19.1+ 同样受签名聊天影响**（`spoofChatInput` 发送的未签名消息可能被后端拒绝）。1.19.1+ 建议改用 `chat-input` 自动放行 + SignedVelocity。
3. **物品展示依赖子服桥**：只有子服也放入本 JAR（作为 Bukkit 桥）或客户端 Mod 上报时才能展示完整物品信息；纯代理端无桥时只能显示“没有可展示的物品数据”。
4. **模组物品显示名**：若模组物品没有自定义显示名，会回退到 `item.yml` 映射或注册键的人性化文本；可在 `item.yml` 中补充模组物品名。
5. **NBT 摘要是尽力而为**：跨版本 NMS 反射失败时 NBT 为空，不影响其余字段。
6. **桥接插件心跳间隔为 5 秒**：切换物品后最迟 5 秒内代理端缓存会更新；玩家发送 `[i]` 时会主动向桥请求最新数据（750ms 内）。
