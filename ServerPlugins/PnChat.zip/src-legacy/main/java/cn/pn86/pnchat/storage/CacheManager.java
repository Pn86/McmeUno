package cn.pn86.pnchat.storage;

import cn.pn86.pnchat.config.ConfigManager;
import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CacheManager {
    private final Path file;
    private final Logger logger;
    private final ConfigManager configs;
    private final Map<String, ItemSnapshot> items = new ConcurrentHashMap<>();

    public CacheManager(Path dataDirectory, Logger logger, ConfigManager configs) {
        this.file = dataDirectory.resolve("cache.yml");
        this.logger = logger;
        this.configs = configs;
    }

    public void load() {
        items.clear();
        if (!Files.exists(file)) {
            save();
            return;
        }
        try {
            ConfigurationNode root = YamlConfigurationLoader.builder().path(file).build().load();
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("items").childrenMap().entrySet()) {
                ConfigurationNode node = entry.getValue();
                String id = String.valueOf(entry.getKey());
                items.put(id, new ItemSnapshot(
                        id,
                        UUID.fromString(node.node("owner").getString(new UUID(0, 0).toString())),
                        node.node("owner-name").getString("Unknown"),
                        node.node("server").getString("unknown"),
                        node.node("display-name").getString("Unknown Item"),
                        node.node("material").getString("minecraft:stone"),
                        node.node("amount").getInt(1),
                        node.node("nbt").getString(""),
                        node.node("created-at").getLong(System.currentTimeMillis())
                ));
            }
        } catch (Exception e) {
            logger.warn("Unable to load cache.yml", e);
        }
    }

    public void save() {
        try {
            ConfigurationNode root = YamlConfigurationLoader.builder().path(file).build().createNode();
            ConfigurationNode itemRoot = root.node("items");
            for (ItemSnapshot item : items.values()) {
                ConfigurationNode node = itemRoot.node(item.id());
                node.node("owner").set(item.owner().toString());
                node.node("owner-name").set(item.ownerName());
                node.node("server").set(item.server());
                node.node("display-name").set(item.displayName());
                node.node("material").set(item.material());
                node.node("amount").set(item.amount());
                node.node("nbt").set(item.nbt());
                node.node("created-at").set(item.createdAt());
            }
            YamlConfigurationLoader.builder().path(file).build().save(root);
        } catch (Exception e) {
            logger.warn("Unable to save cache.yml", e);
        }
    }

    public ItemSnapshot put(UUID owner, String ownerName, String server, String displayName, String material, int amount, String nbt) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        ItemSnapshot item = new ItemSnapshot(id, owner, ownerName, server, displayName, material, Math.max(1, amount), nbt, System.currentTimeMillis());
        items.put(id, item);
        save();
        return item;
    }

    public Optional<ItemSnapshot> latest(UUID owner, String server) {
        return items.values().stream()
                .filter(item -> item.owner().equals(owner) && item.server().equalsIgnoreCase(server))
                .filter(item -> !isExpired(item))
                .max((a, b) -> Long.compare(a.createdAt(), b.createdAt()));
    }

    public Optional<ItemSnapshot> get(String id) {
        return Optional.ofNullable(items.get(id)).filter(item -> !isExpired(item));
    }

    public void cleanExpired() {
        items.values().removeIf(this::isExpired);
    }

    public void clearAndSave() {
        items.clear();
        save();
    }

    private boolean isExpired(ItemSnapshot item) {
        return System.currentTimeMillis() - item.createdAt() > configs.itemViewMillis();
    }
}
