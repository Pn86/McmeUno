package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;

public final class ConnectionListener {
    private final ChatService chat;

    public ConnectionListener(ChatService chat) {
        this.chat = chat;
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        chat.broadcastQuit(event.getPlayer());
        chat.clearSession(event.getPlayer());
    }

    @Subscribe
    public void onServerConnected(ServerConnectedEvent event) {
        String to = event.getServer().getServerInfo().getName();
        chat.noteServer(event.getPlayer(), to);
        chat.applyDefaultServerChatMode(event.getPlayer());
        if (event.getPreviousServer().isEmpty()) {
            chat.broadcastJoin(event.getPlayer());
            return;
        }
        event.getPreviousServer().ifPresent(previous -> {
            String from = previous.getServerInfo().getName();
            if (!from.equalsIgnoreCase(to)) {
                chat.broadcastTransfer(event.getPlayer(), from, to);
            }
        });
    }
}
