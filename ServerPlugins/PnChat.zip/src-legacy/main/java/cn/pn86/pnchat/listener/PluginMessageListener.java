package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.PnChatPlugin;
import cn.pn86.pnchat.storage.CacheManager;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class PluginMessageListener {
    private final CacheManager cache;
    private final ChatService chat;

    public PluginMessageListener(CacheManager cache, ChatService chat) {
        this.cache = cache;
        this.chat = chat;
    }

    @Subscribe
    public void onPluginMessage(PluginMessageEvent event) {
        if (!event.getIdentifier().equals(PnChatPlugin.CHANNEL)) {
            return;
        }
        event.setResult(PluginMessageEvent.ForwardResult.handled());
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(event.getData()));
            String action = in.readUTF();
            if (event.getSource() instanceof ServerConnection connection) {
                handleServerItem(connection, action, in);
                return;
            }
            if (event.getSource() instanceof Player player) {
                handleClientItem(player, action, in);
            }
        } catch (Exception ignored) {
        }
    }

    private void handleServerItem(ServerConnection connection, String action, DataInputStream in) throws Exception {
        if ("PNCHATLOGS_HELLO".equalsIgnoreCase(action)) {
            sendLogsHandshake(connection);
            return;
        }
        if ("AUTH_STATUS".equalsIgnoreCase(action)) {
            UUID owner = UUID.fromString(in.readUTF());
            boolean authenticated = in.readBoolean();
            chat.updateAuthmeStatus(owner, authenticated);
            return;
        }
        if (!"ITEM".equalsIgnoreCase(action)) {
            return;
        }
        UUID owner = UUID.fromString(in.readUTF());
        String ownerName = in.readUTF();
        String displayName = in.readUTF();
        String material = in.readUTF();
        int amount = in.readInt();
        String nbt = readLargeString(in);
        String server = connection.getServer().getServerInfo().getName();
        cache.put(owner, ownerName, server, displayName, material, amount, nbt);
    }

    private void handleClientItem(Player player, String action, DataInputStream in) throws Exception {
        if (!"ITEM_CLIENT".equalsIgnoreCase(action)) {
            return;
        }
        String server = player.getCurrentServer()
                .map(connection -> connection.getServer().getServerInfo().getName())
                .orElse("unknown");
        if ("unknown".equalsIgnoreCase(server)) {
            return;
        }
        String displayName = in.readUTF();
        String material = in.readUTF();
        int amount = in.readInt();
        String nbt = readLargeString(in);
        cache.put(player.getUniqueId(), player.getUsername(), server, displayName, material, amount, nbt);
    }

    private void sendLogsHandshake(ServerConnection connection) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeUTF("PNCHATLOGS_DETECTED");
        out.writeUTF("PnChat");
        out.writeUTF("1.0.0");
        out.writeUTF(connection.getServer().getServerInfo().getName());
        connection.sendPluginMessage(PnChatPlugin.CHANNEL, bytes.toByteArray());
    }

    private String readLargeString(DataInputStream in) throws Exception {
        int length = in.readInt();
        if (length < 0 || length > 1_000_000) {
            throw new IllegalArgumentException("Invalid item payload length: " + length);
        }
        byte[] bytes = in.readNBytes(length);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
