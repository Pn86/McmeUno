package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;

public final class SendCommand implements SimpleCommand {
    private final ChatService chat;

    public SendCommand(ChatService chat) {
        this.chat = chat;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player player)) {
            invocation.source().sendMessage(chat.colored(chat.configs().prefixed("player-only")));
            return;
        }
        String[] args = invocation.arguments();
        if (args.length == 0) {
            player.sendMessage(chat.colored(chat.configs().prefixed("usage-send").replace("%command%", invocation.alias())));
            return;
        }
        chat.sendToCurrentServer(player, String.join(" ", args));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        return List.of();
    }
}
