package cn.pn86.pnchat.storage;

import java.util.UUID;

public record ItemSnapshot(
        String id,
        UUID owner,
        String ownerName,
        String server,
        String displayName,
        String material,
        int amount,
        String nbt,
        long createdAt
) {
}
