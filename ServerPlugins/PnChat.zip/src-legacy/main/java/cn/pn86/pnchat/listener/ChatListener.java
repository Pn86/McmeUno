package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.player.PlayerChatEvent;
import com.velocitypowered.api.event.player.TabCompleteEvent;

import java.util.Locale;

public final class ChatListener {
    private final ChatService chat;

    public ChatListener(ChatService chat) {
        this.chat = chat;
    }

    @Subscribe
    public void onChat(PlayerChatEvent event) {
        if (chat.consumeServerChatBypass(event.getPlayer(), event.getMessage())) {
            return;
        }
        if (chat.handleServerChatShortcut(event.getPlayer(), event.getMessage())) {
            event.setResult(PlayerChatEvent.ChatResult.denied());
            return;
        }
        if (!chat.shouldHandleChat(event.getPlayer())) {
            return;
        }
        event.setResult(PlayerChatEvent.ChatResult.denied());
        chat.handleChat(event.getPlayer(), event.getMessage());
    }

    @Subscribe
    public void onTabComplete(TabCompleteEvent event) {
        if (!chat.configs().isServerConfigured(chat.serverName(event.getPlayer()))) {
            return;
        }
        String partial = event.getPartialMessage();
        if (partial.startsWith("/")) {
            return;
        }
        String token = partial.substring(partial.lastIndexOf(' ') + 1).toLowerCase(Locale.ROOT);
        for (String name : chat.onlineNames()) {
            if ((token.isBlank() || name.toLowerCase(Locale.ROOT).startsWith(token))
                    && !event.getSuggestions().contains(name)) {
                event.getSuggestions().add(name);
            }
        }
    }
}
