package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.PnChatPlugin;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class PnChatCommand implements SimpleCommand {
    private final PnChatPlugin plugin;
    private final ChatService chat;

    public PnChatCommand(PnChatPlugin plugin, ChatService chat) {
        this.plugin = plugin;
        this.chat = chat;
    }

    @Override
    public void execute(Invocation invocation) {
        String alias = invocation.alias();
        String[] args = invocation.arguments();
        if ("pnchatview".equalsIgnoreCase(alias)) {
            if (!(invocation.source() instanceof Player player) || args.length == 0) {
                return;
            }
            chat.viewItem(player, args[0]);
            return;
        }
        if (args.length == 1 && "reload".equalsIgnoreCase(args[0])) {
            if (!invocation.source().hasPermission("pnchat.reload")) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("no-permission")));
                return;
            }
            plugin.reload();
            invocation.source().sendMessage(plugin.chat().colored(plugin.configs().prefixed("reload")));
            return;
        }
        if (args.length >= 2 && "m".equalsIgnoreCase(args[0])) {
            if (!invocation.source().hasPermission("pnchat.message")) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("no-permission")));
                return;
            }
            chat.broadcastRawMessage(String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
            invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("broadcast-message-sent")));
            return;
        }
        if (args.length >= 5 && "t".equalsIgnoreCase(args[0])) {
            if (!invocation.source().hasPermission("pnchat.title")) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("no-permission")));
                return;
            }
            Long fadeIn = parseTicks(args[1]);
            Long stay = parseTicks(args[2]);
            Long fadeOut = parseTicks(args[3]);
            if (fadeIn == null || stay == null || fadeOut == null) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("usage-pnchat-title")));
                return;
            }
            TitleContent content = parseTitleContent(String.join(" ", Arrays.copyOfRange(args, 4, args.length)));
            if (content.title().isBlank()) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("usage-pnchat-title")));
                return;
            }
            chat.broadcastTitle(content.title(), content.subtitle(), fadeIn, stay, fadeOut);
            invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("broadcast-title-sent")));
            return;
        }
        if (args.length >= 3 && "p".equalsIgnoreCase(args[0])) {
            if (!invocation.source().hasPermission("pnchat.player-title")) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("no-permission")));
                return;
            }
            Player target = chat.replyTargetName(args[1]).orElse(null);
            if (target == null) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("player-not-found")));
                return;
            }
            String title = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            chat.setTitle(target, title);
            invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("title-set")
                    .replace("%player%", target.getUsername())
                    .replace("%title%", title)));
            return;
        }
        if (args.length == 2 && "rp".equalsIgnoreCase(args[0])) {
            if (!invocation.source().hasPermission("pnchat.player-title")) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("no-permission")));
                return;
            }
            Player target = chat.replyTargetName(args[1]).orElse(null);
            if (target == null) {
                invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("player-not-found")));
                return;
            }
            chat.removeTitle(target);
            invocation.source().sendMessage(chat.colored(plugin.configs().prefixed("title-removed")
                    .replace("%player%", target.getUsername())));
            return;
        }
        invocation.source().sendMessage(chat.colored("&aPnChat &7v1.0.3 &8- &f/pnchat reload &7| &f/pnchat m <内容> &7| &f/pnchat t <出现> <持续> <消失> <Title> {Subtitle} &7| &f/pnchat p <玩家> <称号> &7| &f/pnchat rp <玩家>"));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length <= 1) {
            List<String> suggestions = new ArrayList<>();
            suggestions.add("reload");
            suggestions.add("m");
            suggestions.add("t");
            suggestions.add("p");
            suggestions.add("rp");
            return suggestions;
        }
        if (args.length == 2 && ("p".equalsIgnoreCase(args[0]) || "rp".equalsIgnoreCase(args[0]))) {
            return chat.onlineNames().stream().sorted(String.CASE_INSENSITIVE_ORDER).toList();
        }
        if (args.length == 2 && "t".equalsIgnoreCase(args[0])) {
            return List.of("10");
        }
        if (args.length == 3 && "t".equalsIgnoreCase(args[0])) {
            return List.of("70");
        }
        if (args.length == 4 && "t".equalsIgnoreCase(args[0])) {
            return List.of("20");
        }
        return List.of();
    }

    private Long parseTicks(String input) {
        try {
            long ticks = Long.parseLong(input);
            return ticks < 0 ? null : ticks;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private TitleContent parseTitleContent(String raw) {
        String trimmed = raw.trim();
        if (!trimmed.endsWith("}")) {
            return new TitleContent(trimmed, "");
        }
        int start = trimmed.lastIndexOf('{');
        if (start < 0) {
            return new TitleContent(trimmed, "");
        }
        String title = trimmed.substring(0, start).trim();
        String subtitle = trimmed.substring(start + 1, trimmed.length() - 1).trim();
        return new TitleContent(title, subtitle);
    }

    private record TitleContent(String title, String subtitle) {
    }
}
