package cn.pn86.pnchat.config;

import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public final class ConfigManager {
    private static final Map<String, String> DEFAULT_MESSAGES = Map.ofEntries(
            Map.entry("broadcast-message-sent", "&a已向全服聊天框发送消息。"),
            Map.entry("broadcast-title-sent", "&a已向全服发送 Title。"),
            Map.entry("usage-pnchat-title", "&c用法: /pnchat t <出现时间tick> <持续时间tick> <消失时间tick> <Title内容> {Subtitle内容}"),
            Map.entry("title-set", "&a已将 &f%player% &a的称号设置为: &r%title%"),
            Map.entry("title-removed", "&a已移除 &f%player% &a的称号。"),
            Map.entry("item-showcase-cooldown", "&c物品展示冷却中，请等待 &f%time%秒 &c后再试。"),
            Map.entry("authme-not-logged-in", "&c你还没有完成登录，无法使用 PnChat 聊天功能。"),
            Map.entry("target-not-logged-in", "&c目标玩家还没有完成登录，暂时无法接收 PnChat 私聊。"),
            Map.entry("spam-similar", "&c你两次发送的内容相似程度过高，无法发送。"),
            Map.entry("privacy-hidden", "[隐私信息]"),
            Map.entry("usage-chats", "&c用法: /chats <only|all>"),
            Map.entry("chats-only", "&a聊天接收模式已切换为 only，仅接收当前子服和提到你的公开消息。"),
            Map.entry("chats-all", "&a聊天接收模式已切换为 all，接收所有子服的公开消息。")
    );

    private final Path dataDirectory;
    private final Logger logger;
    private ConfigurationNode config;
    private ConfigurationNode servers;
    private ConfigurationNode chat;
    private ConfigurationNode messages;
    private ConfigurationNode gui;
    private ConfigurationNode item;

    public ConfigManager(Path dataDirectory, Logger logger) {
        this.dataDirectory = dataDirectory;
        this.logger = logger;
    }

    public void load() {
        try {
            Files.createDirectories(dataDirectory);
            copyDefault("config.yml");
            copyDefault("server.yml");
            copyDefault("chat.yml");
            copyDefault("message.yml");
            copyDefault("gui.yml");
            copyDefault("item.yml");
            copyDefault("cache.yml");
            copyDefault("player.yml");
            repairConfig("config.yml");
            repairConfig("server.yml");
            repairConfig("chat.yml");
            repairConfig("message.yml");
            repairConfig("gui.yml");
            config = loadFile("config.yml");
            servers = loadFile("server.yml");
            chat = loadFile("chat.yml");
            messages = loadFile("message.yml");
            gui = loadFile("gui.yml");
            item = loadFile("item.yml");
        } catch (Exception e) {
            throw new IllegalStateException("Unable to load PnChat configuration", e);
        }
    }

    private ConfigurationNode loadFile(String file) throws Exception {
        return YamlConfigurationLoader.builder().path(dataDirectory.resolve(file)).build().load();
    }

    private void repairConfig(String file) throws Exception {
        Path target = dataDirectory.resolve(file);
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(file)) {
            if (input == null || !Files.exists(target)) {
                return;
            }
            YamlConfigurationLoader targetLoader = YamlConfigurationLoader.builder().path(target).build();
            ConfigurationNode current = targetLoader.load();
            ConfigurationNode defaults = YamlConfigurationLoader.builder()
                    .source(() -> new java.io.BufferedReader(new java.io.InputStreamReader(input, java.nio.charset.StandardCharsets.UTF_8)))
                    .build()
                    .load();
            if (mergeMissing(current, defaults)) {
                targetLoader.save(current);
            }
        }
    }

    private boolean mergeMissing(ConfigurationNode current, ConfigurationNode defaults) throws Exception {
        if (defaults.virtual()) {
            return false;
        }
        if (current.virtual()) {
            current.set(defaults.raw());
            return true;
        }
        boolean changed = false;
        for (Map.Entry<Object, ? extends ConfigurationNode> entry : defaults.childrenMap().entrySet()) {
            if (mergeMissing(current.node(entry.getKey()), entry.getValue())) {
                changed = true;
            }
        }
        if (current.childrenList().isEmpty() && !defaults.childrenList().isEmpty()) {
            current.set(defaults.raw());
            changed = true;
        }
        return changed;
    }

    private void copyDefault(String file) throws IOException {
        Path target = dataDirectory.resolve(file);
        if (Files.exists(target)) {
            return;
        }
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(file)) {
            if (input == null) {
                Files.createFile(target);
                return;
            }
            Files.copy(input, target);
        }
    }

    public boolean feature(String name) {
        return config.node("features", name).getBoolean(true);
    }

    public long chatCooldownMillis() {
        return config.node("chat", "cooldown-ms").getLong(1500L);
    }

    public String itemToken() {
        return config.node("chat", "item-token").getString("[i]");
    }

    public String directSendShortcutPrefix() {
        return config.node("direct-send", "shortcut-prefix").getString("#");
    }

    public String sendCommandName() {
        return config.node("direct-send", "send-command", "name").getString("send");
    }

    public List<String> sendCommandAliases() {
        return stringList(config.node("direct-send", "send-command", "aliases"));
    }

    public String sendsCommandName() {
        return config.node("direct-send", "sends-command", "name").getString("sends");
    }

    public List<String> sendsCommandAliases() {
        return stringList(config.node("direct-send", "sends-command", "aliases"));
    }

    public String directSendPlaceholder() {
        return config.node("direct-send", "placeholder").getString("%message%");
    }

    public boolean defaultSends(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        return node.childrenMap().isEmpty() ? false : node.node("default-sends").getBoolean(false);
    }

    public String defaultChats(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        String value = node.childrenMap().isEmpty() ? "all" : node.node("default-chats").getString("all");
        return "only".equalsIgnoreCase(value) ? "only" : "all";
    }

    public boolean allowColorCodes() {
        return config.node("chat", "allow-color-codes").getBoolean(false);
    }

    public long itemShowcaseCooldownMillis() {
        return config.node("item-showcase", "cooldown-ms").getLong(3000L);
    }

    public String itemChatDisplay() {
        return config.node("item-showcase", "chat-display").getString("&f[%item% &7x%amount%&f]");
    }

    public List<String> itemHoverFormat() {
        List<String> lines = new ArrayList<>();
        for (ConfigurationNode node : config.node("item-showcase", "hover-format").childrenList()) {
            String line = node.getString();
            if (line != null) {
                lines.add(line);
            }
        }
        if (lines.isEmpty()) {
            lines.add("&f%item%");
            lines.add("&7%material%");
            lines.add("&7数量: &f%amount%");
            lines.add("%lore%");
            lines.add("%enchants%");
        }
        return lines;
    }

    public long itemViewMillis() {
        return config.node("item-showcase", "view-seconds").getLong(120L) * 1000L;
    }

    public long cacheCleanupIntervalSeconds() {
        return config.node("item-showcase", "cleanup-interval-seconds").getLong(300L);
    }

    public boolean clearCacheOnStart() {
        return config.node("item-showcase", "clear-cache-on-start").getBoolean(true);
    }

    public String mentionFormat() {
        return config.node("mention", "format").getString("&3@&a%player%");
    }

    public String mentionSubtitle() {
        return config.node("mention", "subtitle").getString("&a%player% &f在聊天中@了你");
    }

    public String mentionSound() {
        return config.node("mention", "sound").getString("minecraft:block.note_block.pling");
    }

    public float mentionSoundVolume() {
        return (float) config.node("mention", "sound-volume").getDouble(1.0);
    }

    public float mentionSoundPitch() {
        return (float) config.node("mention", "sound-pitch").getDouble(1.2);
    }

    public String urlDisplay() {
        return config.node("url", "display").getString("&b[网站]");
    }

    public boolean urlUnderline() {
        return config.node("url", "underline").getBoolean(false);
    }

    public String urlHover() {
        return config.node("url", "hover").getString("&7点击访问: &f%url%");
    }

    public boolean sensitiveWordsEnabled() {
        return config.node("sensitive-words", "enabled").getBoolean(true);
    }

    public String sensitiveReplacement() {
        return config.node("sensitive-words", "replacement").getString("***");
    }

    public List<String> sensitiveWords() {
        return stringList(config.node("sensitive-words", "words"));
    }

    public String sensitiveIgnoreRegex() {
        return config.node("sensitive-words", "ignore-regex").getString("(?i)(?:&[0-9a-fk-orx]|§[0-9a-fk-orx]|\\s|[._,\\-+*~`|\\\\/])");
    }

    public boolean privacyEnabled() {
        return config.node("privacy", "enabled").getBoolean(true);
    }

    public String privacyReplacement() {
        return config.node("privacy", "replacement").getString(message("privacy-hidden"));
    }

    public List<PrivacyRule> privacyRules() {
        List<PrivacyRule> rules = new ArrayList<>();
        for (Map.Entry<Object, ? extends ConfigurationNode> entry : config.node("privacy", "rules").childrenMap().entrySet()) {
            ConfigurationNode node = entry.getValue();
            if (!node.node("enabled").getBoolean(true)) {
                continue;
            }
            String regex = node.node("regex").getString("");
            if (!regex.isBlank()) {
                rules.add(new PrivacyRule(String.valueOf(entry.getKey()), Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
            }
        }
        return rules;
    }

    public boolean antiSpamEnabled() {
        return config.node("anti-spam", "similarity", "enabled").getBoolean(true);
    }

    public double antiSpamSimilarityThreshold() {
        return config.node("anti-spam", "similarity", "threshold").getDouble(0.86);
    }

    public int antiSpamMinLength() {
        return config.node("anti-spam", "similarity", "min-length").getInt(6);
    }

    public long antiSpamRememberMillis() {
        return config.node("anti-spam", "similarity", "remember-seconds").getLong(60L) * 1000L;
    }

    public boolean authmeEnabled() {
        return config.node("authme", "enabled").getBoolean(false);
    }

    public boolean authmeBlockUnknown() {
        return config.node("authme", "block-unknown").getBoolean(true);
    }

    public boolean authmeBlockReceive() {
        return config.node("authme", "block-receive").getBoolean(true);
    }

    public boolean logPrivateMessage() {
        return config.node("logging", "private-message").getBoolean(true);
    }

    public boolean logChatMessage() {
        return config.node("logging", "chat").getBoolean(true);
    }

    public boolean chatLogApiEnabled() {
        return config.node("chat-log-api", "enabled").getBoolean(true);
    }

    public String serverName(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        if (!node.node("display").virtual()) {
            return node.node("display").getString(server);
        }
        return node.getString(server);
    }

    public boolean isServerConfigured(String server) {
        return !servers.node("servers", server.toLowerCase(Locale.ROOT)).virtual();
    }

    public boolean isChatServerConfigured(String server) {
        return !chat.node("servers", server.toLowerCase(Locale.ROOT)).virtual();
    }

    public String chatFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "chat-format")
                .getString(chat.node("default", "chat-format").getString("&8[%server%&8] &f%player%&7: %message%"));
    }

    public String privateSendFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "private-send-format")
                .getString(chat.node("default", "private-send-format").getString("&7你 -> &f%target%&7: &d%message%"));
    }

    public String privateReceiveFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "private-receive-format")
                .getString(chat.node("default", "private-receive-format").getString("&f%sender% &7-> 你&7: &d%message%"));
    }

    public boolean allowItemShowcase(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "allow-item-showcase")
                .getBoolean(chat.node("default", "allow-item-showcase").getBoolean(true));
    }

    public String guiTitle() {
        return gui.node("item-view", "title").getString("&8物品展示 - %player%");
    }

    public int guiSize() {
        int size = gui.node("item-view", "size").getInt(9);
        size = Math.max(9, Math.min(54, size));
        return size - (size % 9);
    }

    public int guiItemSlot() {
        return gui.node("item-view", "item-slot").getInt(4);
    }

    public boolean guiFillerEnabled() {
        return gui.node("item-view", "filler", "enabled").getBoolean(true);
    }

    public String guiFillerMaterial() {
        return gui.node("item-view", "filler", "material").getString("GRAY_STAINED_GLASS_PANE");
    }

    public String guiFillerName() {
        return gui.node("item-view", "filler", "name").getString(" ");
    }

    public String message(String key) {
        return messages.node(key).getString(DEFAULT_MESSAGES.getOrDefault(key, "&cMissing message: " + key));
    }

    public String itemName(String key) {
        if (key == null || key.isBlank()) {
            return "";
        }
        return item.node("items", key.toLowerCase(Locale.ROOT)).getString("");
    }

    public String enchantName(String key) {
        if (key == null || key.isBlank()) {
            return "";
        }
        return item.node("enchants", key.toLowerCase(Locale.ROOT)).getString("");
    }

    public String prefix() {
        return messages.node("prefix").getString("&8[&aPnChat&8] ");
    }

    public String prefixed(String key) {
        return prefix() + message(key);
    }

    public String applyPlaceholders(String input, Map<String, String> values) {
        String output = input == null ? "" : input;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            output = output.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        return output;
    }

    private List<String> stringList(ConfigurationNode parent) {
        List<String> values = new ArrayList<>();
        for (ConfigurationNode node : parent.childrenList()) {
            String value = node.getString();
            if (value != null && !value.isBlank()) {
                values.add(value);
            }
        }
        return values;
    }

    public record PrivacyRule(String name, Pattern pattern) {
    }
}
