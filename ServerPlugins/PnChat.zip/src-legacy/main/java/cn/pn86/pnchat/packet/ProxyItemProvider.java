package cn.pn86.pnchat.packet;

import com.velocitypowered.api.proxy.Player;

public interface ProxyItemProvider {
    boolean cacheCurrentItem(Player player);
}
