package cn.pn86.pnchat.storage;

import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Optional;

public final class PlayerStorage {
    private final Path file;
    private final Logger logger;
    private final Set<UUID> muted = new HashSet<>();
    private final Map<UUID, String> titles = new HashMap<>();
    private final Map<UUID, ChatMode> chatModes = new HashMap<>();

    public PlayerStorage(Path dataDirectory, Logger logger) {
        this.file = dataDirectory.resolve("player.yml");
        this.logger = logger;
    }

    public void load() {
        muted.clear();
        titles.clear();
        chatModes.clear();
        if (!Files.exists(file)) {
            save();
            return;
        }
        try {
            ConfigurationNode root = YamlConfigurationLoader.builder().path(file).build().load();
            for (ConfigurationNode node : root.node("muted").childrenList()) {
                muted.add(UUID.fromString(node.getString("")));
            }
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("titles").childrenMap().entrySet()) {
                String value = entry.getValue().getString("");
                if (value != null && !value.isBlank()) {
                    titles.put(UUID.fromString(String.valueOf(entry.getKey())), value);
                }
            }
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("chat-modes").childrenMap().entrySet()) {
                ChatMode.from(entry.getValue().getString(""))
                        .ifPresent(mode -> chatModes.put(UUID.fromString(String.valueOf(entry.getKey())), mode));
            }
        } catch (Exception e) {
            logger.warn("Unable to load player.yml", e);
        }
    }

    public boolean toggleMuted(UUID uuid) {
        boolean nowMuted;
        if (muted.contains(uuid)) {
            muted.remove(uuid);
            nowMuted = false;
        } else {
            muted.add(uuid);
            nowMuted = true;
        }
        save();
        return nowMuted;
    }

    public boolean isMuted(UUID uuid) {
        return muted.contains(uuid);
    }

    public void setTitle(UUID uuid, String title) {
        if (title == null || title.isBlank()) {
            titles.remove(uuid);
        } else {
            titles.put(uuid, title);
        }
        save();
    }

    public void removeTitle(UUID uuid) {
        titles.remove(uuid);
        save();
    }

    public String title(UUID uuid) {
        return titles.getOrDefault(uuid, "");
    }

    public Optional<ChatMode> chatMode(UUID uuid) {
        return Optional.ofNullable(chatModes.get(uuid));
    }

    public void setChatMode(UUID uuid, ChatMode mode) {
        chatModes.put(uuid, mode);
        save();
    }

    public void save() {
        try {
            ConfigurationNode root = YamlConfigurationLoader.builder().path(file).build().createNode();
            List<String> values = muted.stream().map(UUID::toString).toList();
            root.node("muted").setList(String.class, values);
            for (Map.Entry<UUID, String> entry : titles.entrySet()) {
                root.node("titles", entry.getKey().toString()).set(entry.getValue());
            }
            for (Map.Entry<UUID, ChatMode> entry : chatModes.entrySet()) {
                root.node("chat-modes", entry.getKey().toString()).set(entry.getValue().configValue());
            }
            YamlConfigurationLoader.builder().path(file).build().save(root);
        } catch (Exception e) {
            logger.warn("Unable to save player.yml", e);
        }
    }

    public enum ChatMode {
        ALL,
        ONLY;

        public String configValue() {
            return name().toLowerCase(java.util.Locale.ROOT);
        }

        public static Optional<ChatMode> from(String value) {
            if (value == null) {
                return Optional.empty();
            }
            return switch (value.trim().toLowerCase(java.util.Locale.ROOT)) {
                case "all" -> Optional.of(ALL);
                case "only" -> Optional.of(ONLY);
                default -> Optional.empty();
            };
        }
    }
}
