package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;

public final class SendSwitchCommand implements SimpleCommand {
    private final ChatService chat;

    public SendSwitchCommand(ChatService chat) {
        this.chat = chat;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player player)) {
            invocation.source().sendMessage(chat.colored(chat.configs().prefixed("player-only")));
            return;
        }
        String[] args = invocation.arguments();
        if (args.length != 1 || (!"true".equalsIgnoreCase(args[0]) && !"false".equalsIgnoreCase(args[0]))) {
            player.sendMessage(chat.colored(chat.configs().prefixed("usage-sends").replace("%command%", invocation.alias())));
            return;
        }
        boolean enabled = Boolean.parseBoolean(args[0]);
        chat.setServerChatLocked(player, enabled);
        player.sendMessage(chat.colored(chat.configs().prefixed(enabled ? "sends-on" : "sends-off")));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length <= 1) {
            return List.of("true", "false");
        }
        return List.of();
    }
}
