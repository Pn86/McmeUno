package cn.pn86.pnchat.util;

import cn.pn86.pnchat.storage.ItemSnapshot;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ItemTextFormatter {
    private static final Pattern JSON_TEXT = Pattern.compile("\\\\?\"(?:text|translate)\\\\?\"\\s*:\\s*\\\\?\"([^\"\\\\]*)");
    private static final Pattern JSON_TEXT_OBJECT = Pattern.compile("\\{([^{}]*?\"text\"\\s*:\\s*\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"[^{}]*?)}");
    private static final Pattern JSON_ROOT_TEXT = Pattern.compile("\"text\"\\s*:\\s*\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"");
    private static final Pattern LEGACY_DISPLAY_NAME = Pattern.compile("Name[:=]\"?((?:\\{.*?})|[^,}\\]]+)");
    private static final Pattern COMPONENT_CUSTOM_NAME = Pattern.compile("minecraft:custom_name[=:]((?:\\{.*?})|\".*?\"|[^,}\\]]+)");
    private static final Pattern COMPONENT_ITEM_NAME = Pattern.compile("minecraft:item_name[=:]((?:\\{.*?})|\".*?\"|[^,}\\]]+)");
    private static final Pattern LEGACY_LORE = Pattern.compile("Lore=List\\(\\[(.*?)]\\)");
    private static final Pattern QUOTED_TEXT = Pattern.compile("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"");
    private static final Pattern COMPONENT_CONTENT = Pattern.compile("content=\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"");
    private static final Pattern COMPONENT_OBJECT = Pattern.compile("TextComponentImpl\\{content=\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\".*?style=StyleImpl\\{(.*?)}, children=", Pattern.DOTALL);
    private static final Pattern JSON_STRING = Pattern.compile("String\\((\\{.*?})\\)");
    private static final Pattern NBT_STRING = Pattern.compile("String\\((.*?)\\)");
    private static final Pattern ENCHANT = Pattern.compile("(?:id|minecraft:id)[:=]\"?([a-z0-9_:.\\-]+)\"?.*?(?:lvl|level|minecraft:level)[:=]([0-9]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PACKET_EVENTS_ENCHANT = Pattern.compile("key=\"enchantment\\.minecraft\\.([a-z0-9_]+)\".*?\\}=([0-9]+)", Pattern.CASE_INSENSITIVE);

    private ItemTextFormatter() {
    }

    public static String displayName(String material, String rawData, Function<String, String> itemNames) {
        String raw = rawData == null ? "" : rawData;
        String decoded = customName(raw);
        if (!decoded.isBlank()) {
            return translateItemKey(decoded, itemNames);
        }
        String mapped = itemNames.apply(normalizeMaterial(material));
        return mapped == null || mapped.isBlank() ? normalizeMaterial(material) : mapped;
    }

    public static String hoverText(ItemSnapshot item, List<String> format, Function<String, String> itemNames, Function<String, String> enchantNames) {
        String name = displayName(item.material(), item.nbt(), itemNames);
        List<String> lore = lore(item.nbt());
        List<String> enchants = enchants(item.nbt(), enchantNames);
        List<String> lines = new ArrayList<>();
        for (String template : format) {
            if ("%lore%".equals(template)) {
                for (String line : lore) {
                    lines.add(hasLegacyStyle(line) ? line : "&5" + line);
                }
                continue;
            }
            if ("%enchants%".equals(template)) {
                for (String enchant : enchants) {
                    lines.add("&9" + enchant);
                }
                continue;
            }
            String rendered = template
                    .replace("%item%", name)
                    .replace("%material%", translatedMaterial(item.material(), itemNames))
                    .replace("%amount%", String.valueOf(item.amount()))
                    .replace("%owner%", item.ownerName());
            if (!rendered.isBlank()) {
                lines.add(rendered);
            }
        }
        return String.join("\n", lines);
    }

    public static String humanMaterial(String material) {
        String normalized = normalizeMaterial(material);
        int colon = normalized.indexOf(':');
        if (colon >= 0) {
            normalized = normalized.substring(colon + 1);
        }
        normalized = normalized.toLowerCase(Locale.ROOT).replace('-', '_');
        String[] parts = normalized.split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.length() == 0 ? "Unknown Item" : builder.toString();
    }

    private static List<String> lore(String rawData) {
        List<String> lore = new ArrayList<>();
        if (rawData == null || rawData.isBlank()) {
            return lore;
        }
        Set<String> seen = new LinkedHashSet<>();
        for (String body : loreBodies(rawData)) {
            for (String line : decodeLoreBody(body)) {
                String normalized = normalizeRenderedText(line);
                if (!normalized.isBlank() && seen.add(normalized)) {
                    lore.add(line);
                }
            }
        }
        return lore;
    }

    private static List<String> decodeLoreBody(String body) {
        List<String> lore = new ArrayList<>();
        Matcher jsonString = JSON_STRING.matcher(body);
        while (jsonString.find()) {
            String line = decodeJsonText(jsonString.group(1));
            if (!line.isBlank()) {
                lore.add(line);
            }
        }
        if (lore.isEmpty()) {
            Matcher nbtString = NBT_STRING.matcher(body);
            while (nbtString.find()) {
                String line = decodeText(nbtString.group(1));
                if (!line.isBlank()) {
                    lore.add(line);
                }
            }
        }
        if (lore.isEmpty()) {
            Matcher content = COMPONENT_OBJECT.matcher(body);
            StringBuilder current = new StringBuilder();
            while (content.find()) {
                String text = unescape(content.group(1));
                String styledText = styleCodesFromComponent(content.group(2)) + text;
                if (!text.isBlank()) {
                    current.append(styledText);
                } else if (current.length() > 0) {
                    lore.add(current.toString());
                    current.setLength(0);
                }
            }
            if (current.length() > 0) {
                lore.add(current.toString());
            }
        }
        if (lore.isEmpty()) {
            Matcher quoted = QUOTED_TEXT.matcher(body);
            while (quoted.find()) {
                String text = decodeText(quoted.group(1));
                if (!text.isBlank() && !text.contains(":")) {
                    lore.add(text);
                }
            }
        }
        return lore;
    }

    private static List<String> loreBodies(String raw) {
        List<String> bodies = new ArrayList<>();
        Matcher legacy = LEGACY_LORE.matcher(raw);
        while (legacy.find()) {
            bodies.add(legacy.group(1));
        }
        String marker = "ItemLore{lines=[";
        int from = 0;
        while (true) {
            int at = raw.indexOf(marker, from);
            if (at < 0) {
                break;
            }
            int start = at + marker.length();
            int end = matchingBracket(raw, start - 1);
            if (end > start) {
                bodies.add(raw.substring(start, end));
            }
            from = start;
        }
        return bodies;
    }

    private static int matchingBracket(String text, int openIndex) {
        int depth = 0;
        boolean inString = false;
        boolean escaped = false;
        for (int i = openIndex; i < text.length(); i++) {
            char c = text.charAt(i);
            if (escaped) {
                escaped = false;
                continue;
            }
            if (c == '\\') {
                escaped = true;
                continue;
            }
            if (c == '"') {
                inString = !inString;
                continue;
            }
            if (inString) {
                continue;
            }
            if (c == '[') {
                depth++;
            } else if (c == ']') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static List<String> enchants(String rawData, Function<String, String> enchantNames) {
        List<String> enchants = new ArrayList<>();
        if (rawData == null || rawData.isBlank()) {
            return enchants;
        }
        Set<String> seen = new LinkedHashSet<>();
        Matcher matcher = ENCHANT.matcher(rawData);
        while (matcher.find()) {
            String key = normalizeMaterial(matcher.group(1));
            if (key.startsWith("enchantment.minecraft.")) {
                key = "minecraft:" + key.substring("enchantment.minecraft.".length());
            }
            String level = matcher.group(2);
            if (!seen.add(key + ":" + level)) {
                continue;
            }
            String name = enchantNames.apply(key);
            enchants.add((name == null || name.isBlank() ? humanMaterial(key) : name) + " " + roman(level));
        }
        Matcher packetEvents = PACKET_EVENTS_ENCHANT.matcher(rawData);
        while (packetEvents.find()) {
            String key = "minecraft:" + packetEvents.group(1);
            String level = packetEvents.group(2);
            if (!seen.add(key + ":" + level)) {
                continue;
            }
            String name = enchantNames.apply(key);
            enchants.add((name == null || name.isBlank() ? humanMaterial(key) : name) + " " + roman(level));
        }
        return enchants;
    }

    private static String firstMatch(String raw, Pattern... patterns) {
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(raw);
            if (matcher.find()) {
                return matcher.group(1);
            }
        }
        return "";
    }

    private static String decodeText(String raw) {
        if (raw == null || raw.isBlank()) {
            return "";
        }
        raw = stripNbtString(raw);
        Matcher json = JSON_TEXT.matcher(raw);
        if (json.find()) {
            return unescape(json.group(1));
        }
        return stripQuotes(raw);
    }

    private static String customName(String raw) {
        String legacy = displayNameJson(raw);
        if (!legacy.isBlank()) {
            return legacy;
        }
        String component = componentText(raw, "minecraft:custom_name");
        if (!component.isBlank()) {
            return component;
        }
        String itemName = componentText(raw, "minecraft:item_name");
        if (!itemName.isBlank()) {
            return itemName;
        }
        String name = firstMatch(raw, COMPONENT_CUSTOM_NAME, COMPONENT_ITEM_NAME, LEGACY_DISPLAY_NAME);
        return decodeText(name);
    }

    private static String displayNameJson(String raw) {
        int nameAt = raw.indexOf("Name=String(");
        if (nameAt < 0) {
            return "";
        }
        int start = raw.indexOf('{', nameAt);
        if (start < 0) {
            return "";
        }
        int end = matchingBrace(raw, start);
        if (end <= start) {
            return "";
        }
        return decodeJsonText(raw.substring(start, end + 1));
    }

    private static String componentText(String raw, String key) {
        int keyAt = raw.indexOf(key);
        if (keyAt < 0) {
            return "";
        }
        int nextComponent = raw.indexOf("StaticComponentType[", keyAt + key.length());
        String segment = nextComponent > keyAt ? raw.substring(keyAt, nextComponent) : raw.substring(keyAt);
        Matcher component = COMPONENT_OBJECT.matcher(segment);
        StringBuilder builder = new StringBuilder();
        while (component.find()) {
            String text = unescape(component.group(1));
            if (!text.isBlank()) {
                builder.append(styleCodesFromComponent(component.group(2))).append(text);
            }
        }
        if (builder.length() > 0) {
            return builder.toString();
        }
        Matcher content = COMPONENT_CONTENT.matcher(segment);
        while (content.find()) {
            builder.append(unescape(content.group(1)));
        }
        if (builder.length() > 0) {
            return builder.toString();
        }
        Matcher json = JSON_TEXT.matcher(segment);
        while (json.find()) {
            builder.append(unescape(json.group(1)));
        }
        return builder.toString();
    }

    private static String decodeJsonText(String json) {
        Matcher object = JSON_TEXT_OBJECT.matcher(json);
        StringBuilder builder = new StringBuilder();
        while (object.find()) {
            String part = unescape(object.group(2));
            if (!part.startsWith("item.minecraft.") && !part.startsWith("block.minecraft.")) {
                builder.append(styleCodesFromJsonObject(object.group(1))).append(part);
            }
        }
        if (builder.length() > 0) {
            return builder.toString();
        }
        Matcher text = JSON_ROOT_TEXT.matcher(json);
        while (text.find()) {
            String part = unescape(text.group(1));
            if (!part.startsWith("item.minecraft.") && !part.startsWith("block.minecraft.")) {
                builder.append(part);
            }
        }
        return builder.toString();
    }

    private static boolean hasLegacyStyle(String text) {
        return text.matches(".*&[0-9a-fk-orA-FK-ORx].*");
    }

    private static String styleCodesFromJsonObject(String object) {
        StringBuilder style = new StringBuilder();
        String color = jsonStringValue(object, "color");
        if (!color.isBlank()) {
            style.append(colorCode(color));
        }
        if (jsonBooleanValue(object, "obfuscated")) {
            style.append("&k");
        }
        if (jsonBooleanValue(object, "bold")) {
            style.append("&l");
        }
        if (jsonBooleanValue(object, "strikethrough")) {
            style.append("&m");
        }
        if (jsonBooleanValue(object, "underlined")) {
            style.append("&n");
        }
        if (jsonBooleanValue(object, "italic")) {
            style.append("&o");
        }
        return style.toString();
    }

    private static String styleCodesFromComponent(String styleText) {
        StringBuilder style = new StringBuilder();
        Matcher color = Pattern.compile("color=NamedTextColor\\{name=\"([^\"]+)\"").matcher(styleText);
        if (color.find()) {
            style.append(colorCode(color.group(1)));
        }
        appendComponentFlag(style, styleText, "obfuscated", "&k");
        appendComponentFlag(style, styleText, "bold", "&l");
        appendComponentFlag(style, styleText, "strikethrough", "&m");
        appendComponentFlag(style, styleText, "underlined", "&n");
        appendComponentFlag(style, styleText, "italic", "&o");
        return style.toString();
    }

    private static void appendComponentFlag(StringBuilder builder, String styleText, String key, String code) {
        if (styleText.contains(key + "=true")) {
            builder.append(code);
        }
    }

    private static String jsonStringValue(String object, String key) {
        Matcher matcher = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"([^\"]+)\"").matcher(object);
        return matcher.find() ? matcher.group(1) : "";
    }

    private static boolean jsonBooleanValue(String object, String key) {
        Matcher matcher = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*true").matcher(object);
        return matcher.find();
    }

    private static String colorCode(String color) {
        return switch (color.toLowerCase(Locale.ROOT)) {
            case "black" -> "&0";
            case "dark_blue" -> "&1";
            case "dark_green" -> "&2";
            case "dark_aqua" -> "&3";
            case "dark_red" -> "&4";
            case "dark_purple" -> "&5";
            case "gold" -> "&6";
            case "gray" -> "&7";
            case "dark_gray" -> "&8";
            case "blue" -> "&9";
            case "green" -> "&a";
            case "aqua" -> "&b";
            case "red" -> "&c";
            case "light_purple" -> "&d";
            case "yellow" -> "&e";
            case "white" -> "&f";
            default -> color.startsWith("#") && color.length() == 7 ? "&" + color : "";
        };
    }

    private static int matchingBrace(String text, int start) {
        int depth = 0;
        boolean inString = false;
        boolean escaped = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (escaped) {
                escaped = false;
                continue;
            }
            if (c == '\\') {
                escaped = true;
                continue;
            }
            if (c == '"') {
                inString = !inString;
                continue;
            }
            if (inString) {
                continue;
            }
            if (c == '{') {
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static String translateItemKey(String value, Function<String, String> itemNames) {
        if (value.startsWith("item.minecraft.")) {
            String key = "minecraft:" + value.substring("item.minecraft.".length());
            String mapped = itemNames.apply(key);
            return mapped == null || mapped.isBlank() ? key : mapped;
        }
        if (value.startsWith("block.minecraft.")) {
            String key = "minecraft:" + value.substring("block.minecraft.".length());
            String mapped = itemNames.apply(key);
            return mapped == null || mapped.isBlank() ? key : mapped;
        }
        return value;
    }

    private static String translatedMaterial(String material, Function<String, String> itemNames) {
        String normalized = normalizeMaterial(material);
        String mapped = itemNames.apply(normalized);
        return mapped == null || mapped.isBlank() ? normalized : mapped;
    }

    private static String stripQuotes(String input) {
        String value = stripNbtString(unescape(input.trim()));
        if (value.startsWith("'") && value.endsWith("'") && value.length() > 1) {
            return value.substring(1, value.length() - 1);
        }
        if (value.startsWith("\"") && value.endsWith("\"") && value.length() > 1) {
            return value.substring(1, value.length() - 1);
        }
        return value;
    }

    private static String stripNbtString(String input) {
        String value = input == null ? "" : input.trim();
        while (value.startsWith("String(") && value.endsWith(")") && value.length() > "String()".length()) {
            value = value.substring("String(".length(), value.length() - 1).trim();
        }
        return value;
    }

    private static String normalizeRenderedText(String input) {
        return input.replaceAll("(?i)&(?:#[0-9a-f]{6}|[0-9a-fk-orx])", "").trim();
    }

    private static String normalizeMaterial(String material) {
        if (material == null || material.isBlank()) {
            return "unknown";
        }
        String value = material.trim();
        if (value.startsWith("ItemTypes.")) {
            value = value.substring("ItemTypes.".length());
        }
        return value.toLowerCase(Locale.ROOT);
    }

    private static String unescape(String text) {
        return text.replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\u00a7", "&")
                .replace("§", "&");
    }

    private static String roman(String value) {
        try {
            return switch (Integer.parseInt(value)) {
                case 1 -> "I";
                case 2 -> "II";
                case 3 -> "III";
                case 4 -> "IV";
                case 5 -> "V";
                case 6 -> "VI";
                case 7 -> "VII";
                case 8 -> "VIII";
                case 9 -> "IX";
                case 10 -> "X";
                default -> value;
            };
        } catch (NumberFormatException ignored) {
            return value;
        }
    }
}
