package cn.pn86.pnchat.packet;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.util.ItemTextFormatter;
import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetSlot;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowItems;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PacketEventsItemTracker implements ProxyItemProvider {
    private final ChatService chat;
    private final ProxyServer proxy;
    private final Logger logger;
    private final Map<UUID, Integer> heldSlots = new ConcurrentHashMap<>();
    private final Map<UUID, Object[]> hotbars = new ConcurrentHashMap<>();

    public PacketEventsItemTracker(ChatService chat, ProxyServer proxy, Logger logger) {
        this.chat = chat;
        this.proxy = proxy;
        this.logger = logger;
    }

    public void register() {
        PacketEvents.getAPI().getEventManager().registerListener(new Listener());
        logger.info("PnChat 已启用 PacketEvents 代理端物品监听。");
    }

    private final class Listener extends PacketListenerAbstract {
        private Listener() {
            super(PacketListenerPriority.NORMAL);
        }

        @Override
        public void onPacketSend(PacketSendEvent event) {
            try {
                Player player = resolvePlayer(event.getPlayer());
                if (player == null) {
                    return;
                }
                if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
                    handleSetSlot(player, new WrapperPlayServerSetSlot(event));
                    return;
                }
                if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
                    handleWindowItems(player, new WrapperPlayServerWindowItems(event));
                }
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void onPacketReceive(PacketReceiveEvent event) {
            try {
                Player player = resolvePlayer(event.getPlayer());
                if (player == null) {
                    return;
                }
                if (event.getPacketType() == PacketType.Play.Client.HELD_ITEM_CHANGE) {
                    WrapperPlayClientHeldItemChange wrapper = new WrapperPlayClientHeldItemChange(event);
                    int slot = wrapper.getSlot();
                    if (slot >= 0 && slot <= 8) {
                        heldSlots.put(player.getUniqueId(), slot);
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private void handleSetSlot(Player player, WrapperPlayServerSetSlot wrapper) {
        int windowId = wrapper.getWindowId();
        int slot = wrapper.getSlot();
        if (windowId != 0 || slot < 36 || slot > 44) {
            return;
        }
        int hotbarSlot = slot - 36;
        hotbar(player)[hotbarSlot] = wrapper.getItem();
    }

    private void handleWindowItems(Player player, WrapperPlayServerWindowItems wrapper) {
        if (wrapper.getWindowId() != 0) {
            return;
        }
        Object items = wrapper.getItems();
        Object[] hotbar = hotbar(player);
        int size = itemCount(items);
        for (int slot = 36; slot <= 44 && slot < size; slot++) {
            hotbar[slot - 36] = itemAt(items, slot);
        }
    }

    private Object[] hotbar(Player player) {
        return hotbars.computeIfAbsent(player.getUniqueId(), ignored -> new Object[9]);
    }

    @Override
    public boolean cacheCurrentItem(Player player) {
        int slot = heldSlots.getOrDefault(player.getUniqueId(), 0);
        Object item = hotbar(player)[slot];
        if (isEmpty(item)) {
            return false;
        }
        String material = material(item);
        int amount = amount(item);
        String rawData = rawData(item);
        String displayName = ItemTextFormatter.displayName(material, rawData, chat.configs()::itemName);
        chat.cacheProxyItem(player, displayName, material, amount, rawData);
        return true;
    }

    private boolean isEmpty(Object item) {
        if (item == null) {
            return true;
        }
        String material = material(item).toLowerCase();
        return amount(item) <= 0 || material.contains("air");
    }

    private int amount(Object item) {
        Object value = invoke(item, "getAmount");
        if (value instanceof Number number) {
            return number.intValue();
        }
        return 1;
    }

    private String material(Object item) {
        Object type = invoke(item, "getType");
        if (type == null) {
            return "unknown";
        }
        Object name = invoke(type, "getName");
        if (name != null) {
            return String.valueOf(name);
        }
        Object key = invoke(type, "getKey");
        if (key != null) {
            return String.valueOf(key);
        }
        return String.valueOf(type);
    }

    private String rawData(Object item) {
        Object nbt = invoke(item, "getNBT");
        if (nbt == null) {
            nbt = invoke(item, "getNbt");
        }
        Object components = invoke(item, "getComponents");
        if (components == null) {
            components = invoke(item, "getDataComponents");
        }
        return "item=" + item + ";components=" + components + ";nbt=" + nbt;
    }

    private Object invoke(Object target, String method) {
        if (target == null) {
            return null;
        }
        try {
            Method declared = target.getClass().getMethod(method);
            declared.setAccessible(true);
            return declared.invoke(target);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private Player resolvePlayer(Object packetPlayer) {
        if (packetPlayer instanceof Player player) {
            return player;
        }
        Object uuid = invoke(packetPlayer, "getUUID");
        if (!(uuid instanceof UUID)) {
            uuid = invoke(packetPlayer, "getUuid");
        }
        if (uuid instanceof UUID playerId) {
            return proxy.getPlayer(playerId).orElse(null);
        }
        return null;
    }

    private int itemCount(Object items) {
        if (items == null) {
            return 0;
        }
        if (items instanceof java.util.Collection<?> collection) {
            return collection.size();
        }
        if (items.getClass().isArray()) {
            return java.lang.reflect.Array.getLength(items);
        }
        return 0;
    }

    private Object itemAt(Object items, int index) {
        if (items instanceof java.util.List<?> list) {
            return list.get(index);
        }
        if (items != null && items.getClass().isArray()) {
            return java.lang.reflect.Array.get(items, index);
        }
        return null;
    }
}
