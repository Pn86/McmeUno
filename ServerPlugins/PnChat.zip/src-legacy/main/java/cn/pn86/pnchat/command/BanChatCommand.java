package cn.pn86.pnchat.command;

import cn.pn86.pnchat.PnChatPlugin;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public final class BanChatCommand implements SimpleCommand {
    private final PnChatPlugin plugin;

    public BanChatCommand(PnChatPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!invocation.source().hasPermission("pnchat.banchat")) {
            invocation.source().sendMessage(plugin.chat().colored(plugin.configs().prefixed("no-permission")));
            return;
        }
        String[] args = invocation.arguments();
        if (args.length != 1) {
            invocation.source().sendMessage(plugin.chat().colored(plugin.configs().prefixed("usage-banchat")));
            return;
        }
        Optional<Player> target = plugin.chat().replyTargetName(args[0]);
        if (target.isEmpty()) {
            invocation.source().sendMessage(plugin.chat().colored(plugin.configs().prefixed("player-not-found")));
            return;
        }
        boolean nowMuted = plugin.players().toggleMuted(target.get().getUniqueId());
        String key = nowMuted ? "mute-on" : "mute-off";
        String message = plugin.configs().applyPlaceholders(plugin.configs().prefixed(key), Map.of("player", target.get().getUsername()));
        invocation.source().sendMessage(plugin.chat().colored(message));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length <= 1) {
            return plugin.chat().onlineNames().stream().collect(Collectors.toList());
        }
        return List.of();
    }
}
