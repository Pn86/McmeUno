package cn.pn86.pnchat;

import cn.pn86.pnchat.config.ConfigManager;
import cn.pn86.pnchat.packet.ProxyItemProvider;
import cn.pn86.pnchat.storage.CacheManager;
import cn.pn86.pnchat.storage.ItemSnapshot;
import cn.pn86.pnchat.storage.PlayerStorage;
import cn.pn86.pnchat.util.ItemTextFormatter;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.title.Title;
import org.slf4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class ChatService {
    private static final Pattern URL_PATTERN = Pattern.compile("(?i)\\b((?:https?://)?(?:[a-z0-9-]+\\.)+[a-z]{2,}(?:/[^\\s]*)?)");
    private static final Pattern COLOR_CODE_PATTERN = Pattern.compile("(?i)(?:&[0-9a-fk-orx]|§[0-9a-fk-orx])");

    private final Object plugin;
    private final ProxyServer proxy;
    private final Logger logger;
    private ConfigManager configs;
    private CacheManager cache;
    private PlayerStorage players;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> itemShowcaseCooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> quitMessages = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastServers = new ConcurrentHashMap<>();
    private final Map<UUID, LastMessage> lastMessages = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> authmeAuthenticated = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> replies = new ConcurrentHashMap<>();
    private final Map<UUID, String> serverChatBypass = new ConcurrentHashMap<>();
    private final Set<UUID> serverChatLocked = ConcurrentHashMap.newKeySet();
    private ProxyItemProvider proxyItemProvider;

    public ChatService(Object plugin, ProxyServer proxy, Logger logger, ConfigManager configs, CacheManager cache, PlayerStorage players) {
        this.plugin = plugin;
        this.proxy = proxy;
        this.logger = logger;
        this.configs = configs;
        this.cache = cache;
        this.players = players;
    }

    public void update(ConfigManager configs, CacheManager cache, PlayerStorage players) {
        this.configs = configs;
        this.cache = cache;
        this.players = players;
    }

    public void setProxyItemProvider(ProxyItemProvider proxyItemProvider) {
        this.proxyItemProvider = proxyItemProvider;
    }

    public void handleChat(Player sender, String message) {
        String server = serverName(sender);
        if (!configs.isServerConfigured(server) || !configs.isChatServerConfigured(server)) {
            return;
        }
        if (!canUsePnChat(sender)) {
            sender.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        if (players.isMuted(sender.getUniqueId())) {
            sender.sendMessage(colored(configs.prefixed("muted")));
            return;
        }
        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(sender.getUniqueId(), 0L);
        if (now - last < configs.chatCooldownMillis() && !sender.hasPermission("pnchat.cooldown.bypass")) {
            sender.sendMessage(colored(configs.prefixed("cooldown")));
            return;
        }
        cooldowns.put(sender.getUniqueId(), now);

        String filteredMessage = prepareOutgoingMessage(sender, message);
        if (filteredMessage == null) {
            return;
        }
        boolean itemShowcaseRequested = containsItemToken(filteredMessage)
                && configs.feature("item-showcase")
                && configs.allowItemShowcase(server);
        if (itemShowcaseRequested && !checkItemShowcaseCooldown(sender, now)) {
            return;
        }
        if (itemShowcaseRequested && proxyItemProvider != null) {
            proxyItemProvider.cacheCurrentItem(sender);
        }
        if (shouldRefreshHeldItem(sender, server, filteredMessage)) {
            requestHeldItem(sender);
            proxy.getScheduler()
                    .buildTask(plugin, () -> broadcastChat(sender, server, filteredMessage))
                    .delay(250, java.util.concurrent.TimeUnit.MILLISECONDS)
                    .schedule();
            return;
        }
        broadcastChat(sender, server, filteredMessage);
    }

    private void broadcastChat(Player sender, String server, String filteredMessage) {
        if (proxy.getPlayer(sender.getUniqueId()).isEmpty()) {
            return;
        }
        String displayServer = configs.serverName(server);
        Map<String, String> placeholders = placeholders(sender, server);
        placeholders.put("server", displayServer);
        String format = configs.applyPlaceholders(configs.chatFormat(server), placeholders);
        Component content = buildFormattedChat(sender, server, format, filteredMessage);
        Set<UUID> mentionedPlayers = mentionedPlayerIds(sender, filteredMessage);
        sendPublicChat(content, server, mentionedPlayers);
        logChat(sender, server, filteredMessage);
        forwardChatLog("CHAT", sender.getUniqueId(), sender.getUsername(), server, "", "", filteredMessage);
        notifyMentions(sender, mentionedPlayers);
    }

    public void sendPrivate(Player sender, Player target, String message) {
        if (!configs.feature("private-message")) {
            return;
        }
        String senderServer = serverName(sender);
        String targetServer = serverName(target);
        if (!configs.isServerConfigured(senderServer)
                || !configs.isServerConfigured(targetServer)
                || !configs.isChatServerConfigured(senderServer)) {
            sender.sendMessage(colored(configs.prefixed("server-not-configured")));
            return;
        }
        if (!canUsePnChat(sender)) {
            sender.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        if (!canReceivePnChat(target)) {
            sender.sendMessage(colored(configs.prefixed("target-not-logged-in")));
            return;
        }
        String filteredMessage = prepareOutgoingMessage(sender, message);
        if (filteredMessage == null) {
            return;
        }
        Map<String, String> senderValues = placeholders(sender, senderServer);
        senderValues.put("target", target.getUsername());
        senderValues.put("target_title", players.title(target.getUniqueId()));
        Map<String, String> targetValues = placeholders(sender, targetServer);
        targetValues.put("sender", sender.getUsername());
        targetValues.put("sender_title", players.title(sender.getUniqueId()));

        sender.sendMessage(buildPrivateMessage(configs.applyPlaceholders(configs.privateSendFormat(senderServer), senderValues), filteredMessage));
        target.sendMessage(buildPrivateMessage(configs.applyPlaceholders(configs.privateReceiveFormat(targetServer), targetValues), filteredMessage));
        replies.put(sender.getUniqueId(), target.getUniqueId());
        replies.put(target.getUniqueId(), sender.getUniqueId());

        if (configs.logPrivateMessage()) {
            logger.info("[PM] {} -> {}: {}", sender.getUsername(), target.getUsername(), filteredMessage);
        }
        forwardChatLog("PRIVATE", sender.getUniqueId(), sender.getUsername(), senderServer, target.getUniqueId().toString(), target.getUsername(), filteredMessage);
    }

    public Optional<Player> replyTarget(Player player) {
        return Optional.ofNullable(replies.get(player.getUniqueId())).flatMap(proxy::getPlayer);
    }

    public Optional<Player> replyTargetName(String name) {
        return proxy.getPlayer(name);
    }

    public Set<String> onlineNames() {
        return proxy.getAllPlayers().stream().map(Player::getUsername).collect(Collectors.toSet());
    }

    public ConfigManager configs() {
        return configs;
    }

    public boolean isChatEnabled() {
        return configs.feature("chat");
    }

    public boolean shouldHandleChat(Player player) {
        String server = serverName(player);
        return isChatEnabled() && configs.isServerConfigured(server) && configs.isChatServerConfigured(server);
    }

    public void broadcastJoin(Player player) {
        if (!configs.feature("join-message")) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            return;
        }
        Map<String, String> values = placeholders(player, server);
        values.put("player", player.getUsername());
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("join"), values)));
    }

    public void broadcastQuit(Player player) {
        if (!configs.feature("quit-message")) {
            return;
        }
        long now = System.currentTimeMillis();
        Long last = quitMessages.put(player.getUniqueId(), now);
        if (last != null && now - last < 2000L) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            return;
        }
        Map<String, String> values = placeholders(player, server);
        values.put("player", player.getUsername());
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("quit"), values)));
    }

    public void broadcastTransfer(Player player, String from, String to) {
        if (!configs.feature("transfer-message")) {
            return;
        }
        if (!configs.isServerConfigured(from) || !configs.isServerConfigured(to)) {
            return;
        }
        Map<String, String> values = placeholders(player, to);
        values.put("player", player.getUsername());
        values.put("from", configs.serverName(from));
        values.put("to", configs.serverName(to));
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("transfer"), values)));
    }

    public void broadcastRawMessage(String message) {
        sendProxyMessage(colored(message));
    }

    public void broadcastTitle(String title, String subtitle, long fadeInTicks, long stayTicks, long fadeOutTicks) {
        Title.Times times = Title.Times.times(
                Duration.ofMillis(Math.max(0, fadeInTicks) * 50L),
                Duration.ofMillis(Math.max(0, stayTicks) * 50L),
                Duration.ofMillis(Math.max(0, fadeOutTicks) * 50L)
        );
        Title builtTitle = Title.title(
                colored(title),
                colored(subtitle == null ? "" : subtitle),
                times
        );
        for (Player player : proxy.getAllPlayers()) {
            if (configs.isServerConfigured(serverName(player)) && canReceivePnChat(player)) {
                player.showTitle(builtTitle);
            }
        }
    }

    public void setTitle(Player player, String title) {
        players.setTitle(player.getUniqueId(), title);
    }

    public void removeTitle(Player player) {
        players.removeTitle(player.getUniqueId());
    }

    public void setChatMode(Player player, PlayerStorage.ChatMode mode) {
        players.setChatMode(player.getUniqueId(), mode);
    }

    public void noteServer(Player player, String server) {
        lastServers.put(player.getUniqueId(), server.toLowerCase(Locale.ROOT));
    }

    public void applyDefaultServerChatMode(Player player) {
        setServerChatLocked(player, configs.defaultSends(serverName(player)));
    }

    public void updateAuthmeStatus(UUID uuid, boolean authenticated) {
        authmeAuthenticated.put(uuid, authenticated);
    }

    public void viewItem(Player player, String id) {
        Optional<ItemSnapshot> optional = cache.get(id);
        if (optional.isEmpty()) {
            player.sendMessage(colored(configs.prefixed("item-expired")));
            return;
        }
        ItemSnapshot item = optional.get();
        String current = serverName(player);
        if (!item.server().equalsIgnoreCase(current)) {
            player.sendMessage(colored(configs.prefixed("item-different-server")));
            return;
        }
        // Legacy command compatibility only; chat item showcases use hover and do not send detail messages.
    }

    public void cacheProxyItem(Player player, String displayName, String material, int amount, String rawData) {
        if (amount <= 0) {
            return;
        }
        cache.put(player.getUniqueId(), player.getUsername(), serverName(player), displayName, material, amount, rawData);
    }

    public void sendToCurrentServer(Player player, String message) {
        if (!canUsePnChat(player)) {
            player.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        String rendered = configs.directSendPlaceholder().replace("%message%", message).replace("{message}", message);
        serverChatBypass.put(player.getUniqueId(), rendered);
        player.spoofChatInput(rendered);
        proxy.getScheduler()
                .buildTask(plugin, () -> serverChatBypass.remove(player.getUniqueId(), rendered))
                .delay(2, java.util.concurrent.TimeUnit.SECONDS)
                .schedule();
    }

    public boolean consumeServerChatBypass(Player player, String message) {
        return serverChatBypass.remove(player.getUniqueId(), message);
    }

    public boolean handleServerChatShortcut(Player player, String message) {
        String prefix = configs.directSendShortcutPrefix();
        if (prefix != null && !prefix.isEmpty() && message.startsWith(prefix)) {
            String directMessage = message.length() > prefix.length() ? message.substring(prefix.length()) : "";
            if (!directMessage.isBlank()) {
                sendToCurrentServer(player, directMessage);
            }
            return true;
        }
        if (serverChatLocked.contains(player.getUniqueId())) {
            sendToCurrentServer(player, message);
            return true;
        }
        return false;
    }

    public void setServerChatLocked(Player player, boolean locked) {
        if (locked) {
            serverChatLocked.add(player.getUniqueId());
        } else {
            serverChatLocked.remove(player.getUniqueId());
        }
    }

    public void clearSession(Player player) {
        UUID uuid = player.getUniqueId();
        serverChatLocked.remove(uuid);
        serverChatBypass.remove(uuid);
        cooldowns.remove(uuid);
        itemShowcaseCooldowns.remove(uuid);
        lastServers.remove(uuid);
        lastMessages.remove(uuid);
        authmeAuthenticated.remove(uuid);
        replies.remove(uuid);
        replies.values().removeIf(uuid::equals);
    }

    public Component colored(String text) {
        return PnChatPlugin.LEGACY.deserialize(text == null ? "" : text);
    }

    public String serverName(Player player) {
        return player.getCurrentServer()
                .map(ServerConnection::getServer)
                .map(com.velocitypowered.api.proxy.server.RegisteredServer::getServerInfo)
                .map(info -> info.getName().toLowerCase(Locale.ROOT))
                .orElseGet(() -> lastServers.getOrDefault(player.getUniqueId(), "unknown"));
    }

    private Component buildFormattedChat(Player sender, String server, String format, String message) {
        int index = format.indexOf("%message%");
        if (index < 0) {
            return colored(format).append(buildMessage(sender, server, message));
        }
        Component before = colored(format.substring(0, index));
        Component after = colored(format.substring(index + "%message%".length()));
        return before.append(buildMessage(sender, server, message)).append(after);
    }

    private Component buildPrivateMessage(String format, String message) {
        int index = format.indexOf("%message%");
        if (index < 0) {
            return colored(format).append(plain(message));
        }
        Component before = colored(format.substring(0, index));
        Component after = colored(format.substring(index + "%message%".length()));
        return before.append(plain(message)).append(after);
    }

    private Component buildMessage(Player sender, String server, String message) {
        Component result = Component.empty();
        String token = configs.itemToken();
        int position = 0;
        while (!token.isEmpty()) {
            int tokenIndex = message.indexOf(token, position);
            if (tokenIndex < 0) {
                break;
            }
            result = result.append(buildTextWithLinksAndMentions(message.substring(position, tokenIndex)));
            result = result.append(buildItemComponent(sender, server));
            position = tokenIndex + token.length();
        }
        result = result.append(buildTextWithLinksAndMentions(message.substring(position)));
        return result;
    }

    private Component buildItemComponent(Player sender, String server) {
        if (!configs.feature("item-showcase")) {
            return colored(configs.message("item-disabled"));
        }
        if (!configs.allowItemShowcase(server)) {
            return colored(configs.message("item-disabled"));
        }
        Optional<ItemSnapshot> optional = cache.latest(sender.getUniqueId(), server);
        if (optional.isEmpty()) {
            return colored(configs.message("item-no-data"));
        }
        ItemSnapshot item = optional.get();
        Component hover = colored(ItemTextFormatter.hoverText(item, configs.itemHoverFormat(), configs::itemName, configs::enchantName));
        String display = configs.itemChatDisplay()
                .replace("%item%", item.displayName())
                .replace("%amount%", String.valueOf(item.amount()))
                .replace("%material%", item.material())
                .replace("%player%", item.ownerName());
        return colored(display)
                .hoverEvent(HoverEvent.showText(hover));
    }

    private Component buildTextWithLinksAndMentions(String text) {
        Component result = Component.empty();
        if (!configs.feature("url")) {
            return buildMentions(text);
        }
        int cursor = 0;
        Matcher matcher = URL_PATTERN.matcher(text);
        while (matcher.find()) {
            result = result.append(buildMentions(text.substring(cursor, matcher.start())));
            String raw = matcher.group(1);
            String url = normalizeUrl(raw);
            Component link = colored(configs.urlDisplay())
                    .clickEvent(ClickEvent.openUrl(url))
                    .hoverEvent(HoverEvent.showText(colored(configs.urlHover().replace("%url%", url))));
            if (configs.urlUnderline()) {
                link = link.decorate(net.kyori.adventure.text.format.TextDecoration.UNDERLINED);
            }
            result = result.append(link);
            cursor = matcher.end();
        }
        return result.append(buildMentions(text.substring(cursor)));
    }

    private Component buildMentions(String text) {
        if (!configs.feature("mention") || text.isEmpty()) {
            return plain(text);
        }
        Component result = Component.empty();
        int cursor = 0;
        String lower = text.toLowerCase(Locale.ROOT);
        Set<String> names = proxy.getAllPlayers().stream().map(Player::getUsername).collect(Collectors.toSet());
        while (cursor < text.length()) {
            String matched = null;
            int matchedAt = text.length();
            for (String name : names) {
                int at = lower.indexOf(name.toLowerCase(Locale.ROOT), cursor);
                if (at >= 0 && at < matchedAt) {
                    matchedAt = at;
                    matched = name;
                }
            }
            if (matched == null) {
                result = result.append(plain(text.substring(cursor)));
                break;
            }
            result = result.append(plain(text.substring(cursor, matchedAt)));
            String originalName = text.substring(matchedAt, matchedAt + matched.length());
            result = result.append(colored(configs.mentionFormat().replace("%player%", originalName)));
            cursor = matchedAt + matched.length();
        }
        return result;
    }

    private Set<UUID> mentionedPlayerIds(Player sender, String message) {
        if (!configs.feature("mention")) {
            return Set.of();
        }
        String lower = message.toLowerCase(Locale.ROOT);
        return proxy.getAllPlayers().stream()
                .filter(player -> !player.getUniqueId().equals(sender.getUniqueId()))
                .filter(player -> lower.contains(player.getUsername().toLowerCase(Locale.ROOT)))
                .map(Player::getUniqueId)
                .collect(Collectors.toSet());
    }

    private void notifyMentions(Player sender, Set<UUID> mentionedPlayers) {
        for (Player player : proxy.getAllPlayers()) {
            if (!mentionedPlayers.contains(player.getUniqueId())) {
                continue;
            }
            if (!configs.isServerConfigured(serverName(player))) {
                continue;
            }
            if (!canReceivePnChat(player)) {
                continue;
            }
            String subtitle = configs.mentionSubtitle().replace("%player%", sender.getUsername());
            player.showTitle(Title.title(
                    Component.empty(),
                    colored(subtitle),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1800), Duration.ofMillis(400))
            ));
            player.playSound(Sound.sound(Key.key(configs.mentionSound()), Sound.Source.PLAYER, configs.mentionSoundVolume(), configs.mentionSoundPitch()));
        }
    }

    private Map<String, String> placeholders(Player player, String server) {
        Map<String, String> values = new HashMap<>();
        values.put("player", player.getUsername());
        values.put("title", players.title(player.getUniqueId()));
        values.put("server", configs.serverName(server));
        values.put("online", String.valueOf(proxy.getPlayerCount()));
        for (com.velocitypowered.api.proxy.server.RegisteredServer registered : proxy.getAllServers()) {
            String name = registered.getServerInfo().getName();
            long count = proxy.getAllPlayers().stream()
                    .filter(p -> serverName(p).equalsIgnoreCase(name))
                    .count();
            values.put("online_" + name, String.valueOf(count));
        }
        return values;
    }

    private boolean sendBridgeMessage(Player viewer, String action, ItemSnapshot item) {
        Optional<ServerConnection> current = viewer.getCurrentServer();
        if (current.isEmpty()) {
            return false;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeUTF(action);
            out.writeUTF(viewer.getUniqueId().toString());
            out.writeUTF(item.id());
            out.writeUTF(item.displayName());
            out.writeUTF(item.material());
            out.writeInt(item.amount());
            writeLargeString(out, item.nbt());
            return current.get().sendPluginMessage(PnChatPlugin.CHANNEL, bytes.toByteArray());
        } catch (IOException e) {
            return false;
        }
    }

    private boolean requestHeldItem(Player player) {
        Optional<ServerConnection> current = player.getCurrentServer();
        if (current.isEmpty()) {
            return false;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeUTF("HELD_ITEM");
            out.writeUTF(player.getUniqueId().toString());
            return current.get().sendPluginMessage(PnChatPlugin.CHANNEL, bytes.toByteArray());
        } catch (IOException e) {
            return false;
        }
    }

    private boolean shouldRefreshHeldItem(Player sender, String server, String message) {
        return containsItemToken(message)
                && configs.feature("item-showcase")
                && configs.allowItemShowcase(server)
                && cache.latest(sender.getUniqueId(), server).isEmpty();
    }

    private boolean checkItemShowcaseCooldown(Player sender, long now) {
        long cooldown = configs.itemShowcaseCooldownMillis();
        if (cooldown <= 0) {
            return true;
        }
        long last = itemShowcaseCooldowns.getOrDefault(sender.getUniqueId(), 0L);
        long remaining = cooldown - (now - last);
        if (remaining > 0L) {
            sender.sendMessage(colored(configs.prefixed("item-showcase-cooldown")
                    .replace("%time%", String.format(Locale.ROOT, "%.1f", remaining / 1000.0))));
            return false;
        }
        itemShowcaseCooldowns.put(sender.getUniqueId(), now);
        return true;
    }

    private boolean containsItemToken(String message) {
        String token = configs.itemToken();
        return token != null
                && !token.isEmpty()
                && message.contains(token);
    }

    private void writeLargeString(DataOutputStream out, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(bytes.length);
        out.write(bytes);
    }

    private void logChat(Player sender, String server, String message) {
        if (configs.logChatMessage()) {
            logger.info("[Chat/{}] {}: {}", server, sender.getUsername(), message);
        }
    }

    private void forwardChatLog(String type, UUID senderId, String senderName, String server, String targetId, String targetName, String message) {
        if (!configs.chatLogApiEnabled()) {
            return;
        }
        if (!configs.isServerConfigured(server)) {
            return;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeUTF("PRIVATE".equalsIgnoreCase(type) ? "PRIVATE_LOG" : "CHAT_LOG");
            out.writeUTF(type);
            out.writeUTF(senderId.toString());
            out.writeUTF(senderName);
            out.writeUTF(server);
            out.writeUTF(configs.serverName(server));
            out.writeUTF(targetId == null ? "" : targetId);
            out.writeUTF(targetName == null ? "" : targetName);
            writeLargeString(out, message);
            byte[] payload = bytes.toByteArray();
            Set<String> sentServers = ConcurrentHashMap.newKeySet();
            for (Player player : proxy.getAllPlayers()) {
                String current = serverName(player);
                if (!configs.isServerConfigured(current) || !sentServers.add(current)) {
                    continue;
                }
                player.getCurrentServer().ifPresent(connection -> connection.sendPluginMessage(PnChatPlugin.CHANNEL, payload));
            }
        } catch (IOException e) {
            logger.warn("Unable to forward PnChat chat log to backend servers.", e);
        }
    }

    private Component plain(String text) {
        if (configs.allowColorCodes()) {
            return colored(text);
        }
        return Component.text(text);
    }

    private void sendProxyMessage(Component message) {
        for (Player player : proxy.getAllPlayers()) {
            if (configs.isServerConfigured(serverName(player)) && canReceivePnChat(player)) {
                player.sendMessage(message);
            }
        }
    }

    private void sendPublicChat(Component message, String senderServer, Set<UUID> mentionedPlayers) {
        for (Player player : proxy.getAllPlayers()) {
            String receiverServer = serverName(player);
            if (!configs.isServerConfigured(receiverServer) || !canReceivePnChat(player)) {
                continue;
            }
            PlayerStorage.ChatMode mode = players.chatMode(player.getUniqueId())
                    .orElseGet(() -> PlayerStorage.ChatMode.from(configs.defaultChats(receiverServer))
                            .orElse(PlayerStorage.ChatMode.ALL));
            if (mode == PlayerStorage.ChatMode.ALL
                    || receiverServer.equalsIgnoreCase(senderServer)
                    || mentionedPlayers.contains(player.getUniqueId())) {
                player.sendMessage(message);
            }
        }
    }

    private String prepareOutgoingMessage(Player sender, String message) {
        String filtered = hidePrivacy(message);
        filtered = filterSensitiveWords(filtered);
        if (isTooSimilar(sender, filtered)) {
            sender.sendMessage(colored(configs.prefixed("spam-similar")));
            return null;
        }
        rememberMessage(sender, filtered);
        return filtered;
    }

    private boolean canUsePnChat(Player player) {
        if (!configs.authmeEnabled()) {
            return true;
        }
        Boolean authenticated = authmeAuthenticated.get(player.getUniqueId());
        return authenticated != null ? authenticated : !configs.authmeBlockUnknown();
    }

    private boolean canReceivePnChat(Player player) {
        return !configs.authmeBlockReceive() || canUsePnChat(player);
    }

    private String hidePrivacy(String message) {
        if (!configs.privacyEnabled()) {
            return message;
        }
        String filtered = message;
        for (ConfigManager.PrivacyRule rule : configs.privacyRules()) {
            filtered = rule.pattern().matcher(filtered).replaceAll(Matcher.quoteReplacement(configs.privacyReplacement()));
        }
        return filtered;
    }

    private String filterSensitiveWords(String message) {
        if (!configs.sensitiveWordsEnabled()) {
            return message;
        }
        String filtered = message;
        for (String word : configs.sensitiveWords()) {
            filtered = replaceObfuscatedWord(filtered, word, configs.sensitiveReplacement());
        }
        return filtered;
    }

    private String replaceObfuscatedWord(String input, String word, String replacement) {
        NormalizedText normalizedInput = normalizeForModeration(input);
        String normalizedWord = normalizeForModeration(word).text();
        if (normalizedWord.isBlank()) {
            return input;
        }
        StringBuilder output = new StringBuilder(input);
        String lowerInput = normalizedInput.text().toLowerCase(Locale.ROOT);
        String lowerWord = normalizedWord.toLowerCase(Locale.ROOT);
        int from = 0;
        int offset = 0;
        while (true) {
            int at = lowerInput.indexOf(lowerWord, from);
            if (at < 0) {
                break;
            }
            int originalStart = normalizedInput.indexes().get(at) + offset;
            int originalEnd = normalizedInput.indexes().get(at + lowerWord.length() - 1) + 1 + offset;
            output.replace(originalStart, originalEnd, replacement);
            offset += replacement.length() - (originalEnd - originalStart);
            from = at + lowerWord.length();
        }
        return output.toString();
    }

    private boolean isTooSimilar(Player sender, String message) {
        if (!configs.antiSpamEnabled()) {
            return false;
        }
        String normalized = normalizeForModeration(message).text().toLowerCase(Locale.ROOT);
        if (normalized.length() < configs.antiSpamMinLength()) {
            return false;
        }
        LastMessage last = lastMessages.get(sender.getUniqueId());
        if (last == null || System.currentTimeMillis() - last.time() > configs.antiSpamRememberMillis()) {
            return false;
        }
        return similarity(last.normalized(), normalized) >= configs.antiSpamSimilarityThreshold();
    }

    private void rememberMessage(Player sender, String message) {
        String normalized = normalizeForModeration(message).text().toLowerCase(Locale.ROOT);
        if (normalized.length() >= configs.antiSpamMinLength()) {
            lastMessages.put(sender.getUniqueId(), new LastMessage(normalized, System.currentTimeMillis()));
        }
    }

    private double similarity(String left, String right) {
        int max = Math.max(left.length(), right.length());
        if (max == 0) {
            return 1.0;
        }
        return 1.0 - (levenshtein(left, right) / (double) max);
    }

    private int levenshtein(String left, String right) {
        int[] previous = new int[right.length() + 1];
        int[] current = new int[right.length() + 1];
        for (int j = 0; j <= right.length(); j++) {
            previous[j] = j;
        }
        for (int i = 1; i <= left.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= right.length(); j++) {
                int cost = left.charAt(i - 1) == right.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[right.length()];
    }

    private NormalizedText normalizeForModeration(String input) {
        Pattern ignored;
        try {
            ignored = Pattern.compile(configs.sensitiveIgnoreRegex(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        } catch (Exception ignoredError) {
            ignored = Pattern.compile("(?i)(?:&[0-9a-fk-orx]|§[0-9a-fk-orx]|\\s|[._,\\-+*~`|\\\\/])", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        }
        StringBuilder text = new StringBuilder();
        java.util.List<Integer> indexes = new java.util.ArrayList<>();
        for (int i = 0; i < input.length(); ) {
            Matcher matcher = ignored.matcher(input);
            matcher.region(i, input.length());
            if (matcher.lookingAt()) {
                i = matcher.end();
                continue;
            }
            int codePoint = input.codePointAt(i);
            text.appendCodePoint(codePoint);
            indexes.add(i);
            i += Character.charCount(codePoint);
        }
        return new NormalizedText(COLOR_CODE_PATTERN.matcher(text.toString()).replaceAll(""), indexes);
    }

    private String normalizeUrl(String raw) {
        String compact = raw.replaceAll("\\s*[,.]\\s*", ".").replaceAll("\\s+", ".");
        return compact.toLowerCase(Locale.ROOT).startsWith("http") ? compact : "https://" + compact;
    }

    private record LastMessage(String normalized, long time) {
    }

    private record NormalizedText(String text, java.util.List<Integer> indexes) {
    }
}
