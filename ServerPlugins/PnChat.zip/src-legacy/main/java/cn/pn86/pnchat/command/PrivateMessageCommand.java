package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public final class PrivateMessageCommand implements SimpleCommand {
    private final ChatService chat;
    private final boolean reply;

    public PrivateMessageCommand(ChatService chat, boolean reply) {
        this.chat = chat;
        this.reply = reply;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player sender)) {
            invocation.source().sendMessage(chat.colored(chat.configs().prefixed("player-only")));
            return;
        }
        String[] args = invocation.arguments();
        if (reply) {
            if (args.length < 1) {
                sender.sendMessage(chat.colored(chat.configs().prefixed("usage-msg")));
                return;
            }
            Optional<Player> target = chat.replyTarget(sender);
            if (target.isEmpty()) {
                sender.sendMessage(chat.colored(chat.configs().prefixed("reply-empty")));
                return;
            }
            chat.sendPrivate(sender, target.get(), String.join(" ", args));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(chat.colored(chat.configs().prefixed("usage-msg")));
            return;
        }
        Optional<Player> target = chat.replyTargetName(args[0]);
        if (target.isEmpty()) {
            sender.sendMessage(chat.colored(chat.configs().prefixed("player-not-found")));
            return;
        }
        String[] messageArgs = new String[args.length - 1];
        System.arraycopy(args, 1, messageArgs, 0, messageArgs.length);
        chat.sendPrivate(sender, target.get(), String.join(" ", messageArgs));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (!reply && invocation.arguments().length <= 1) {
            return chat.onlineNames().stream().collect(Collectors.toList());
        }
        return List.of();
    }
}
