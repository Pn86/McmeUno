package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.storage.PlayerStorage.ChatMode;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;

public final class ChatModeCommand implements SimpleCommand {
    private final ChatService chat;

    public ChatModeCommand(ChatService chat) {
        this.chat = chat;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player player)) {
            invocation.source().sendMessage(chat.colored(chat.configs().prefixed("player-only")));
            return;
        }
        String[] args = invocation.arguments();
        if (args.length != 1) {
            player.sendMessage(chat.colored(chat.configs().prefixed("usage-chats")));
            return;
        }
        ChatMode.from(args[0]).ifPresentOrElse(mode -> {
            chat.setChatMode(player, mode);
            player.sendMessage(chat.colored(chat.configs().prefixed(
                    mode == ChatMode.ONLY ? "chats-only" : "chats-all"
            )));
        }, () -> player.sendMessage(chat.colored(chat.configs().prefixed("usage-chats"))));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length <= 1) {
            String input = invocation.arguments().length == 0 ? "" : invocation.arguments()[0].toLowerCase();
            return List.of("only", "all").stream().filter(value -> value.startsWith(input)).toList();
        }
        return List.of();
    }
}
