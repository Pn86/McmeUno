package cn.pn86.pnchat;

import cn.pn86.pnchat.command.BanChatCommand;
import cn.pn86.pnchat.command.ChatModeCommand;
import cn.pn86.pnchat.command.PnChatCommand;
import cn.pn86.pnchat.command.PrivateMessageCommand;
import cn.pn86.pnchat.command.SendCommand;
import cn.pn86.pnchat.command.SendSwitchCommand;
import cn.pn86.pnchat.config.ConfigManager;
import cn.pn86.pnchat.listener.ChatListener;
import cn.pn86.pnchat.listener.ConnectionListener;
import cn.pn86.pnchat.listener.PluginMessageListener;
import cn.pn86.pnchat.packet.ProxyItemProvider;
import cn.pn86.pnchat.storage.CacheManager;
import cn.pn86.pnchat.storage.PlayerStorage;
import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.slf4j.Logger;

import java.lang.reflect.Constructor;
import java.nio.file.Path;
import java.util.List;

@Plugin(
        id = "pnchat",
        name = "PnChat",
        version = "1.0.3",
        authors = {"Pn86"},
        dependencies = {
                @Dependency(id = "packetevents", optional = true)
        }
)
public final class PnChatPlugin {
    public static final MinecraftChannelIdentifier CHANNEL = MinecraftChannelIdentifier.from("pnchat:main");
    public static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;
    private ConfigManager configManager;
    private CacheManager cacheManager;
    private PlayerStorage playerStorage;
    private ChatService chatService;

    @Inject
    public PnChatPlugin(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory) {
        this.proxy = proxy;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        reload(true);
        proxy.getChannelRegistrar().register(CHANNEL);
        proxy.getEventManager().register(this, new ChatListener(chatService));
        proxy.getEventManager().register(this, new ConnectionListener(chatService));
        proxy.getEventManager().register(this, new PluginMessageListener(cacheManager, chatService));

        CommandMeta pnChatMeta = proxy.getCommandManager().metaBuilder("pnchat").build();
        proxy.getCommandManager().register(pnChatMeta, new PnChatCommand(this, chatService));
        proxy.getCommandManager().register(proxy.getCommandManager().metaBuilder("pnchatview").build(), new PnChatCommand(this, chatService));
        proxy.getCommandManager().register(proxy.getCommandManager().metaBuilder("banchat").build(), new BanChatCommand(this));
        proxy.getCommandManager().register(
                proxy.getCommandManager().metaBuilder("msg").aliases("tell", "w", "m", "whisper").build(),
                new PrivateMessageCommand(chatService, false)
        );
        proxy.getCommandManager().register(
                proxy.getCommandManager().metaBuilder("r").aliases("reply").build(),
                new PrivateMessageCommand(chatService, true)
        );
        proxy.getCommandManager().register(commandMeta(configManager.sendCommandName(), configManager.sendCommandAliases()), new SendCommand(chatService));
        proxy.getCommandManager().register(commandMeta(configManager.sendsCommandName(), configManager.sendsCommandAliases()), new SendSwitchCommand(chatService));
        proxy.getCommandManager().register(proxy.getCommandManager().metaBuilder("chats").build(), new ChatModeCommand(chatService));
        registerPacketEventsTracker();
        scheduleCleanup();
        logger.info("欢迎使用PnChat，作者Pn86(QQ3999389202)，插件已加载成功！");
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (cacheManager != null) {
            cacheManager.cleanExpired();
            cacheManager.save();
        }
    }

    public void reload() {
        reload(false);
    }

    private void reload(boolean startup) {
        this.configManager = new ConfigManager(dataDirectory, logger);
        this.configManager.load();
        this.cacheManager = new CacheManager(dataDirectory, logger, configManager);
        this.cacheManager.load();
        if (startup && configManager.clearCacheOnStart()) {
            this.cacheManager.clearAndSave();
        } else {
            this.cacheManager.cleanExpired();
        }
        this.playerStorage = new PlayerStorage(dataDirectory, logger);
        this.playerStorage.load();
        if (this.chatService == null) {
            this.chatService = new ChatService(this, proxy, logger, configManager, cacheManager, playerStorage);
        } else {
            this.chatService.update(configManager, cacheManager, playerStorage);
        }
    }

    private void scheduleCleanup() {
        long interval = Math.max(30L, configManager.cacheCleanupIntervalSeconds());
        proxy.getScheduler()
                .buildTask(this, () -> {
                    cacheManager.cleanExpired();
                    cacheManager.save();
                })
                .repeat(interval, java.util.concurrent.TimeUnit.SECONDS)
                .schedule();
    }

    private void registerPacketEventsTracker() {
        try {
            Class.forName("com.github.retrooper.packetevents.PacketEvents");
            Class<?> trackerClass = Class.forName("cn.pn86.pnchat.packet.PacketEventsItemTracker");
            Constructor<?> constructor = trackerClass.getConstructor(ChatService.class, ProxyServer.class, Logger.class);
            Object tracker = constructor.newInstance(chatService, proxy, logger);
            trackerClass.getMethod("register").invoke(tracker);
            chatService.setProxyItemProvider((ProxyItemProvider) tracker);
        } catch (ClassNotFoundException ignored) {
            logger.info("未检测到 PacketEvents，PnChat 将无法使用代理端背包包监听物品展示。");
        } catch (Exception e) {
            logger.warn("PnChat 初始化 PacketEvents 物品监听失败。", e);
        }
    }

    private CommandMeta commandMeta(String name, List<String> aliases) {
        CommandMeta.Builder builder = proxy.getCommandManager().metaBuilder(name);
        if (!aliases.isEmpty()) {
            builder.aliases(aliases.toArray(String[]::new));
        }
        return builder.build();
    }

    public ConfigManager configs() {
        return configManager;
    }

    public PlayerStorage players() {
        return playerStorage;
    }

    public ChatService chat() {
        return chatService;
    }
}
