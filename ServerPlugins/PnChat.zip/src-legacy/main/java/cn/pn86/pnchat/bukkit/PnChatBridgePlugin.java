package cn.pn86.pnchat.bukkit;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

public final class PnChatBridgePlugin extends JavaPlugin implements Listener, PluginMessageListener {
    private static final String CHANNEL = "pnchat:main";
    private FileConfiguration gui;

    @Override
    public void onEnable() {
        loadGui();
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getMessenger().registerOutgoingPluginChannel(this, CHANNEL);
        Bukkit.getMessenger().registerIncomingPluginChannel(this, CHANNEL, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::sendHeldItem), 40L, 100L);
    }

    @Override
    public void onDisable() {
        Bukkit.getMessenger().unregisterOutgoingPluginChannel(this, CHANNEL);
        Bukkit.getMessenger().unregisterIncomingPluginChannel(this, CHANNEL, this);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> sendHeldItem(event.getPlayer()), 20L);
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> sendHeldItem(event.getPlayer()), 1L);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ItemViewHolder) {
            event.setCancelled(true);
            return;
        }
        if (event.getWhoClicked() instanceof Player player) {
            Bukkit.getScheduler().runTaskLater(this, () -> sendHeldItem(player), 1L);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ItemViewHolder) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!CHANNEL.equals(channel)) {
            return;
        }
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
            String action = in.readUTF();
            if ("HELD_ITEM".equalsIgnoreCase(action)) {
                Player target = Bukkit.getPlayer(UUID.fromString(in.readUTF()));
                if (target != null) {
                    sendHeldItem(target);
                }
                return;
            }
            if (!"VIEW".equalsIgnoreCase(action)) {
                return;
            }
            UUID viewerId = UUID.fromString(in.readUTF());
            String id = in.readUTF();
            String displayName = in.readUTF();
            String material = in.readUTF();
            int amount = in.readInt();
            String encodedItem = readLargeString(in);
            Player viewer = Bukkit.getPlayer(viewerId);
            if (viewer == null) {
                return;
            }
            ItemStack item = decodeItem(encodedItem);
            int size = guiSize();
            ItemViewHolder holder = new ItemViewHolder();
            Inventory inventory = Bukkit.createInventory(holder, size, guiTitle(viewer, id, displayName, material, amount));
            holder.setInventory(inventory);
            if (gui.getBoolean("item-view.filler.enabled", true)) {
                ItemStack filler = fillerItem();
                for (int slot = 0; slot < inventory.getSize(); slot++) {
                    inventory.setItem(slot, filler);
                }
            }
            int slot = Math.max(0, Math.min(inventory.getSize() - 1, gui.getInt("item-view.item-slot", 4)));
            inventory.setItem(slot, item);
            viewer.openInventory(inventory);
        } catch (Exception ignored) {
        }
    }

    private void sendHeldItem(Player player) {
        if (!player.isOnline()) {
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR || item.getAmount() <= 0) {
            return;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeUTF("ITEM");
            out.writeUTF(player.getUniqueId().toString());
            out.writeUTF(player.getName());
            out.writeUTF(displayName(item));
            out.writeUTF(item.getType().getKey().toString());
            out.writeInt(item.getAmount());
            writeLargeString(out, encodeItem(item));
            player.sendPluginMessage(this, CHANNEL, bytes.toByteArray());
        } catch (Exception ignored) {
        }
    }

    private String displayName(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return meta.getDisplayName();
        }
        NamespacedKey key = item.getType().getKey();
        return key.getKey();
    }

    private String encodeItem(ItemStack item) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream out = new BukkitObjectOutputStream(bytes)) {
            out.writeObject(item);
        }
        return Base64.getEncoder().encodeToString(bytes.toByteArray());
    }

    private ItemStack decodeItem(String encoded) throws Exception {
        byte[] bytes = Base64.getDecoder().decode(encoded.getBytes(StandardCharsets.UTF_8));
        try (BukkitObjectInputStream in = new BukkitObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object object = in.readObject();
            return object instanceof ItemStack item ? item : new ItemStack(Material.STONE);
        }
    }

    private void writeLargeString(DataOutputStream out, String value) throws Exception {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(bytes.length);
        out.write(bytes);
    }

    private String readLargeString(DataInputStream in) throws Exception {
        int length = in.readInt();
        if (length < 0 || length > 1_000_000) {
            throw new IllegalArgumentException("Invalid item payload length: " + length);
        }
        byte[] bytes = in.readNBytes(length);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private void loadGui() {
        File file = new File(getDataFolder(), "gui.yml");
        if (!file.exists()) {
            saveResource("gui.yml", false);
        }
        gui = YamlConfiguration.loadConfiguration(file);
    }

    private int guiSize() {
        int size = Math.max(9, Math.min(54, gui.getInt("item-view.size", 9)));
        return size - (size % 9);
    }

    private String guiTitle(Player viewer, String id, String item, String material, int amount) {
        String title = gui.getString("item-view.title", "&8物品展示 - %player%");
        title = title.replace("%player%", viewer.getName())
                .replace("%id%", id)
                .replace("%item%", item)
                .replace("%material%", material)
                .replace("%amount%", String.valueOf(amount));
        return color(title);
    }

    private ItemStack fillerItem() {
        Material material = Material.matchMaterial(gui.getString("item-view.filler.material", "GRAY_STAINED_GLASS_PANE"));
        if (material == null) {
            material = Material.GRAY_STAINED_GLASS_PANE;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(gui.getString("item-view.filler.name", " ")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private static final class ItemViewHolder implements InventoryHolder {
        private Inventory inventory;

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
