package cn.pn86.pnchat.config;

import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.NodeStyle;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public final class ConfigManager {
    private static final Map<String, String> DEFAULT_MESSAGES = new HashMap<>();
    static {
        DEFAULT_MESSAGES.put("broadcast-message-sent", "&a已向全服聊天框发送消息。");
        DEFAULT_MESSAGES.put("broadcast-title-sent", "&a已向全服发送 Title。");
        DEFAULT_MESSAGES.put("usage-pnchat-title", "&c用法: /pnchat t <出现时间tick> <持续时间tick> <消失时间tick> <Title内容> {Subtitle内容}");
        DEFAULT_MESSAGES.put("title-set", "&a已将 &f%player% &a的称号设置为: &r%title%");
        DEFAULT_MESSAGES.put("title-removed", "&a已移除 &f%player% &a的称号。");
        DEFAULT_MESSAGES.put("item-showcase-cooldown", "&c物品展示冷却中，请等待 &f%time%秒 &c后再试。");
        DEFAULT_MESSAGES.put("authme-not-logged-in", "&c你还没有完成登录，无法使用 PnChat 聊天功能。");
        DEFAULT_MESSAGES.put("target-not-logged-in", "&c目标玩家还没有完成登录，暂时无法接收 PnChat 私聊。");
        DEFAULT_MESSAGES.put("spam-similar", "&c你两次发送的内容相似程度过高，无法发送。");
        DEFAULT_MESSAGES.put("privacy-hidden", "[隐私信息]");
        DEFAULT_MESSAGES.put("usage-chats", "&c用法: /chats <only|all>");
        DEFAULT_MESSAGES.put("chats-only", "&a聊天接收模式已切换为 only，仅接收当前子服和提到你的公开消息。");
        DEFAULT_MESSAGES.put("chats-all", "&a聊天接收模式已切换为 all，接收所有子服的公开消息。");
        DEFAULT_MESSAGES.put("message-too-long", "&c消息过长，最多 &f%max% &c个字符。");
        DEFAULT_MESSAGES.put("self-pm", "&c不能给自己发送私聊消息。");
        DEFAULT_MESSAGES.put("usage-ignore", "&c用法: /ignore <玩家名>（或 /pnchat ignore <玩家名>）");
        DEFAULT_MESSAGES.put("usage-ignore-server", "&c用法: /ignoreserver <子服名>（或 /pnchat ignoreserver <子服名>）");
        DEFAULT_MESSAGES.put("ignore-player-on", "&a已屏蔽 &f%player%&a 的聊天与私聊消息。");
        DEFAULT_MESSAGES.put("ignore-player-off", "&a已解除屏蔽 &f%player%&a。");
        DEFAULT_MESSAGES.put("ignore-server-on", "&a已屏蔽子服 &f%server%&a 的聊天消息。");
        DEFAULT_MESSAGES.put("ignore-server-off", "&a已解除屏蔽子服 &f%server%&a。");
        DEFAULT_MESSAGES.put("ignore-list", "&7你屏蔽的玩家: &f%players%");
        DEFAULT_MESSAGES.put("ignore-list-server", "&7你屏蔽的子服: &f%servers%");
        DEFAULT_MESSAGES.put("ignored-by-target", "&c对方屏蔽了你，无法发送私聊。");
        DEFAULT_MESSAGES.put("you-ignored-target", "&c你已经屏蔽了对方，无法发送私聊。");
        DEFAULT_MESSAGES.put("ignore-self", "&c不能屏蔽自己。");
    }

    private static final String DEFAULT_SENSITIVE_IGNORE =
            "(?i)(?:&[0-9a-fk-orx]|§[0-9a-fk-orx]|\\s|[._,\\-+*~`|\\\\/])";

    private final Path dataDirectory;
    private final Logger logger;
    private ConfigurationNode config;
    private ConfigurationNode servers;
    private ConfigurationNode chat;
    private ConfigurationNode messages;
    private ConfigurationNode item;

    private Pattern sensitiveIgnorePattern;
    private List<PrivacyRule> privacyRulesCache;
    private List<Pattern> chatInputPatternsCache;

    public ConfigManager(Path dataDirectory, Logger logger) {
        this.dataDirectory = dataDirectory;
        this.logger = logger;
    }

    /**
     * 创建一个统一的 YAML 加载器：BLOCK 节点风格 + 2 空格缩进，
     * 避免写出 flow 风格的括号 YAML。
     */
    public static YamlConfigurationLoader loader(Path path) {
        return YamlConfigurationLoader.builder()
                .path(path)
                .nodeStyle(NodeStyle.BLOCK)
                .indent(2)
                .build();
    }

    public void load() {
        try {
            Files.createDirectories(dataDirectory);
            copyDefault("config.yml");
            copyDefault("server.yml");
            copyDefault("chat.yml");
            copyDefault("message.yml");
            copyDefault("item.yml");
            copyDefault("cache.yml");
            copyDefault("player.yml");
            // 只做内存合并，绝不重写用户已有的配置文件（保留注释与格式）
            config = loadMerged("config.yml");
            servers = loadFile("server.yml");
            chat = loadFile("chat.yml");
            messages = loadMerged("message.yml");
            item = loadFile("item.yml");
            // 重载后重新编译正则缓存
            sensitiveIgnorePattern = null;
            privacyRulesCache = null;
            chatInputPatternsCache = null;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to load PnChat configuration", e);
        }
    }

    private ConfigurationNode loadFile(String file) throws Exception {
        return loader(dataDirectory.resolve(file)).load();
    }

    /**
     * 读取用户文件，并把默认资源中缺失的键在内存中补全（不写回文件）。
     */
    private ConfigurationNode loadMerged(String file) throws Exception {
        ConfigurationNode current = loadFile(file);
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(file)) {
            if (input == null) {
                return current;
            }
            ConfigurationNode defaults = YamlConfigurationLoader.builder()
                    .source(() -> new java.io.BufferedReader(new java.io.InputStreamReader(input, java.nio.charset.StandardCharsets.UTF_8)))
                    .build()
                    .load();
            mergeMissing(current, defaults);
        }
        return current;
    }

    private void mergeMissing(ConfigurationNode current, ConfigurationNode defaults) throws Exception {
        if (defaults.virtual()) {
            return;
        }
        for (Map.Entry<Object, ? extends ConfigurationNode> entry : defaults.childrenMap().entrySet()) {
            ConfigurationNode child = current.node(entry.getKey());
            ConfigurationNode defaultChild = entry.getValue();
            if (child.virtual()) {
                child.set(defaultChild.raw());
            } else if (!defaultChild.isMap() || !child.isMap()) {
                // 类型不一致时保留用户值
            } else {
                mergeMissing(child, defaultChild);
            }
        }
    }

    private void copyDefault(String file) throws IOException {
        Path target = dataDirectory.resolve(file);
        if (Files.exists(target)) {
            return;
        }
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(file)) {
            if (input == null) {
                Files.createFile(target);
                return;
            }
            Files.copy(input, target);
        }
    }

    public boolean feature(String name) {
        return config.node("features", name).getBoolean(true);
    }

    public long chatCooldownMillis() {
        return config.node("chat", "cooldown-ms").getLong(1500L);
    }

    public int chatMaxLength() {
        return config.node("chat", "max-length").getInt(256);
    }

    public boolean tabCompleteAllServers() {
        return config.node("chat", "tab-complete-all-servers").getBoolean(true);
    }

    public String itemToken() {
        return config.node("chat", "item-token").getString("[i]");
    }

    public String directSendShortcutPrefix() {
        return config.node("direct-send", "shortcut-prefix").getString("#");
    }

    public String sendCommandName() {
        return config.node("direct-send", "send-command", "name").getString("send");
    }

    public List<String> sendCommandAliases() {
        return stringList(config.node("direct-send", "send-command", "aliases"));
    }

    public String sendsCommandName() {
        return config.node("direct-send", "sends-command", "name").getString("sends");
    }

    public List<String> sendsCommandAliases() {
        return stringList(config.node("direct-send", "sends-command", "aliases"));
    }

    public String directSendPlaceholder() {
        return config.node("direct-send", "placeholder").getString("%message%");
    }

    public boolean defaultSends(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        return node.childrenMap().isEmpty() ? false : node.node("default-sends").getBoolean(false);
    }

    public String defaultChats(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        String value = node.childrenMap().isEmpty() ? "all" : node.node("default-chats").getString("all");
        return "only".equalsIgnoreCase(value) ? "only" : "all";
    }

    public boolean allowColorCodes() {
        return config.node("chat", "allow-color-codes").getBoolean(false);
    }

    public boolean joinNotificationEnabled() {
        return config.node("join-notification", "enabled").getBoolean(false);
    }

    public enum JoinNotificationMode { WHITELIST, BLACKLIST }

    /** 返回 join-notification.mode：whitelist（默认，只播报列出的子服）或 blacklist（除列出外全部播报）。 */
    public JoinNotificationMode joinNotificationMode() {
        String mode = config.node("join-notification", "mode").getString("whitelist");
        return "blacklist".equalsIgnoreCase(mode) ? JoinNotificationMode.BLACKLIST : JoinNotificationMode.WHITELIST;
    }

    public Set<String> joinNotificationServers() {
        return lowerCaseSet(config.node("join-notification", "servers"));
    }

    /** 该子服是否需要播报加入/转服提示（按白/黑名单模式判断）。 */
    public boolean isJoinNotificationServer(String server) {
        boolean listed = joinNotificationServers().contains(server.toLowerCase(Locale.ROOT));
        return joinNotificationMode() == JoinNotificationMode.BLACKLIST ? !listed : listed;
    }

    /** 代理端数据包识别开关（默认开启；不可用时自动降级）。 */
    public boolean packetSnifferEnabled() {
        return config.node("item-detection", "packet-sniffer", "enabled").getBoolean(true);
    }

    /** 全局 debug 开关（默认关闭；开启后输出数据包识别/协议解析详细日志与异常堆栈）。 */
    public boolean debugEnabled() {
        return config.node("debug").getBoolean(false);
    }

    public boolean chatInputEnabled() {
        return config.node("chat-input", "enabled").getBoolean(false);
    }

    public Set<String> chatInputServers() {
        return lowerCaseSet(config.node("chat-input", "servers"));
    }

    public int chatInputMaxLength() {
        return config.node("chat-input", "max-length").getInt(0);
    }

    public List<Pattern> chatInputPatterns() {
        if (chatInputPatternsCache == null) {
            List<Pattern> patterns = new ArrayList<>();
            for (ConfigurationNode node : config.node("chat-input", "patterns").childrenList()) {
                String regex = node.getString("");
                if (regex != null && !regex.isEmpty()) {
                    try {
                        patterns.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
                    } catch (Exception e) {
                        logger.warn("chat-input.patterns 中的正则无效，已跳过: {}", regex);
                    }
                }
            }
            chatInputPatternsCache = patterns;
        }
        return chatInputPatternsCache;
    }

    public long itemShowcaseCooldownMillis() {
        return config.node("item-showcase", "cooldown-ms").getLong(3000L);
    }

    public String itemChatDisplay() {
        return config.node("item-showcase", "chat-display").getString("&f[%item% &7x%amount%&f]");
    }

    public List<String> itemHoverFormat() {
        List<String> lines = new ArrayList<>();
        for (ConfigurationNode node : config.node("item-showcase", "hover-format").childrenList()) {
            String line = node.getString();
            if (line != null) {
                lines.add(line);
            }
        }
        if (lines.isEmpty()) {
            lines.add("&f%item%");
            lines.add("&7%material%");
            lines.add("&7数量: &f%amount%");
            lines.add("&7耐久: &f%durability%");
            lines.add("%lore%");
            lines.add("%enchants%");
            lines.add("%nbt%");
        }
        return lines;
    }

    public long itemViewMillis() {
        return config.node("item-showcase", "view-seconds").getLong(120L) * 1000L;
    }

    public long itemMaxAgeMillis() {
        return config.node("item-showcase", "max-age-ms").getLong(5000L);
    }

    public long itemRequestTimeoutMillis() {
        return config.node("item-showcase", "request-timeout-ms").getLong(750L);
    }

    public long cacheCleanupIntervalSeconds() {
        return config.node("item-showcase", "cleanup-interval-seconds").getLong(300L);
    }

    public boolean clearCacheOnStart() {
        return config.node("item-showcase", "clear-cache-on-start").getBoolean(true);
    }

    public String mentionFormat() {
        return config.node("mention", "format").getString("&3@&a%player%");
    }

    public String mentionSubtitle() {
        return config.node("mention", "subtitle").getString("&a%player% &f在聊天中@了你");
    }

    public String mentionSound() {
        return config.node("mention", "sound").getString("minecraft:block.note_block.pling");
    }

    public float mentionSoundVolume() {
        return (float) config.node("mention", "sound-volume").getDouble(1.0);
    }

    public float mentionSoundPitch() {
        return (float) config.node("mention", "sound-pitch").getDouble(1.2);
    }

    public String urlDisplay() {
        return config.node("url", "display").getString("&b[网站]");
    }

    public boolean urlUnderline() {
        return config.node("url", "underline").getBoolean(false);
    }

    public String urlHover() {
        return config.node("url", "hover").getString("&7点击访问: &f%url%");
    }

    public boolean sensitiveWordsEnabled() {
        return config.node("sensitive-words", "enabled").getBoolean(true);
    }

    public String sensitiveReplacement() {
        return config.node("sensitive-words", "replacement").getString("***");
    }

    public List<String> sensitiveWords() {
        return stringList(config.node("sensitive-words", "words"));
    }

    public Pattern sensitiveIgnorePattern() {
        if (sensitiveIgnorePattern == null) {
            String regex = config.node("sensitive-words", "ignore-regex").getString(DEFAULT_SENSITIVE_IGNORE);
            try {
                sensitiveIgnorePattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            } catch (Exception e) {
                logger.warn("sensitive-words.ignore-regex 无效，使用默认值。");
                sensitiveIgnorePattern = Pattern.compile(DEFAULT_SENSITIVE_IGNORE, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            }
        }
        return sensitiveIgnorePattern;
    }

    public boolean privacyEnabled() {
        return config.node("privacy", "enabled").getBoolean(true);
    }

    public String privacyReplacement() {
        return config.node("privacy", "replacement").getString(message("privacy-hidden"));
    }

    public List<PrivacyRule> privacyRules() {
        if (privacyRulesCache == null) {
            List<PrivacyRule> rules = new ArrayList<>();
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : config.node("privacy", "rules").childrenMap().entrySet()) {
                ConfigurationNode node = entry.getValue();
                if (!node.node("enabled").getBoolean(true)) {
                    continue;
                }
                String regex = node.node("regex").getString("");
                if (regex != null && !regex.isEmpty()) {
                    try {
                        rules.add(new PrivacyRule(String.valueOf(entry.getKey()),
                                Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
                    } catch (Exception e) {
                        logger.warn("privacy.rules.{} 的正则无效，已跳过。", entry.getKey());
                    }
                }
            }
            privacyRulesCache = rules;
        }
        return privacyRulesCache;
    }

    public boolean antiSpamEnabled() {
        return config.node("anti-spam", "similarity", "enabled").getBoolean(true);
    }

    public double antiSpamSimilarityThreshold() {
        return config.node("anti-spam", "similarity", "threshold").getDouble(0.86);
    }

    public int antiSpamMinLength() {
        return config.node("anti-spam", "similarity", "min-length").getInt(6);
    }

    public long antiSpamRememberMillis() {
        return config.node("anti-spam", "similarity", "remember-seconds").getLong(60L) * 1000L;
    }

    public boolean authmeEnabled() {
        return config.node("authme", "enabled").getBoolean(false);
    }

    public boolean authmeBlockUnknown() {
        return config.node("authme", "block-unknown").getBoolean(true);
    }

    public boolean authmeBlockReceive() {
        return config.node("authme", "block-receive").getBoolean(true);
    }

    public boolean logPrivateMessage() {
        return config.node("logging", "private-message").getBoolean(true);
    }

    public boolean logChatMessage() {
        return config.node("logging", "chat").getBoolean(true);
    }

    public boolean chatLogApiEnabled() {
        return config.node("chat-log-api", "enabled").getBoolean(true);
    }

    public String serverName(String server) {
        ConfigurationNode node = servers.node("servers", server.toLowerCase(Locale.ROOT));
        if (!node.node("display").virtual()) {
            return node.node("display").getString(server);
        }
        return node.getString(server);
    }

    public boolean isServerConfigured(String server) {
        return !servers.node("servers", server.toLowerCase(Locale.ROOT)).virtual();
    }

    /** 返回 server.yml 中已配置的子服名（小写）。 */
    public List<String> configuredServerNames() {
        List<String> names = new ArrayList<>();
        for (Map.Entry<Object, ? extends ConfigurationNode> entry : servers.node("servers").childrenMap().entrySet()) {
            names.add(String.valueOf(entry.getKey()).toLowerCase(Locale.ROOT));
        }
        return names;
    }

    public boolean isChatServerConfigured(String server) {
        return !chat.node("servers", server.toLowerCase(Locale.ROOT)).virtual();
    }

    public String chatFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "chat-format")
                .getString(chat.node("default", "chat-format").getString("&8[%server%&8] &f%player%&7: %message%"));
    }

    public String privateSendFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "private-send-format")
                .getString(chat.node("default", "private-send-format").getString("&7你 -> &f%target%&7: &d%message%"));
    }

    public String privateReceiveFormat(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "private-receive-format")
                .getString(chat.node("default", "private-receive-format").getString("&f%sender% &7-> 你&7: &d%message%"));
    }

    public boolean allowItemShowcase(String server) {
        return chat.node("servers", server.toLowerCase(Locale.ROOT), "allow-item-showcase")
                .getBoolean(chat.node("default", "allow-item-showcase").getBoolean(true));
    }

    public String message(String key) {
        return messages.node(key).getString(DEFAULT_MESSAGES.getOrDefault(key, "&cMissing message: " + key));
    }

    public String itemName(String key) {
        if (key == null || key.isEmpty()) {
            return "";
        }
        return item.node("items", key.toLowerCase(Locale.ROOT)).getString("");
    }

    public String enchantName(String key) {
        if (key == null || key.isEmpty()) {
            return "";
        }
        return item.node("enchants", key.toLowerCase(Locale.ROOT)).getString("");
    }

    public String prefix() {
        return messages.node("prefix").getString("&8[&aPnChat&8] ");
    }

    public String prefixed(String key) {
        return prefix() + message(key);
    }

    public String applyPlaceholders(String input, Map<String, String> values) {
        String output = input == null ? "" : input;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            output = output.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        return output;
    }

    private List<String> stringList(ConfigurationNode parent) {
        List<String> values = new ArrayList<>();
        for (ConfigurationNode node : parent.childrenList()) {
            String value = node.getString();
            if (value != null && !value.isEmpty()) {
                values.add(value);
            }
        }
        return values;
    }

    private Set<String> lowerCaseSet(ConfigurationNode parent) {
        Set<String> values = new HashSet<>();
        for (ConfigurationNode node : parent.childrenList()) {
            String value = node.getString();
            if (value != null && !value.isEmpty()) {
                values.add(value.toLowerCase(Locale.ROOT));
            }
        }
        return values;
    }

    public record PrivacyRule(String name, Pattern pattern) {
    }
}
