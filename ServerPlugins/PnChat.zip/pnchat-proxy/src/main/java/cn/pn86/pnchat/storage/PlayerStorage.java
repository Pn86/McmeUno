package cn.pn86.pnchat.storage;

import cn.pn86.pnchat.config.ConfigManager;
import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerStorage {
    private final Path file;
    private final Logger logger;
    private final Map<UUID, Boolean> muted = new ConcurrentHashMap<>();
    private final Map<UUID, String> titles = new ConcurrentHashMap<>();
    private final Map<UUID, ChatMode> chatModes = new ConcurrentHashMap<>();
    private final Map<UUID, Set<UUID>> ignoredPlayers = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> ignoredServers = new ConcurrentHashMap<>();

    public PlayerStorage(Path dataDirectory, Logger logger) {
        this.file = dataDirectory.resolve("player.yml");
        this.logger = logger;
    }

    public void load() {
        muted.clear();
        titles.clear();
        chatModes.clear();
        ignoredPlayers.clear();
        ignoredServers.clear();
        if (!Files.exists(file)) {
            return;
        }
        try {
            ConfigurationNode root = ConfigManager.loader(file).load();
            for (ConfigurationNode node : root.node("muted").childrenList()) {
                muted.put(UUID.fromString(node.getString("")), Boolean.TRUE);
            }
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("titles").childrenMap().entrySet()) {
                String value = entry.getValue().getString("");
                if (value != null && !value.isEmpty()) {
                    titles.put(UUID.fromString(String.valueOf(entry.getKey())), value);
                }
            }
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("chat-modes").childrenMap().entrySet()) {
                ChatMode.from(entry.getValue().getString(""))
                        .ifPresent(mode -> chatModes.put(UUID.fromString(String.valueOf(entry.getKey())), mode));
            }
            // 屏蔽的玩家：ignored-players -> {ignorerUuid: [ignoredUuid, ...]}
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("ignored-players").childrenMap().entrySet()) {
                try {
                    UUID ignorer = UUID.fromString(String.valueOf(entry.getKey()));
                    Set<UUID> set = new HashSet<>();
                    for (ConfigurationNode node : entry.getValue().childrenList()) {
                        try {
                            set.add(UUID.fromString(node.getString("")));
                        } catch (Exception ignored) {
                        }
                    }
                    if (!set.isEmpty()) {
                        ignoredPlayers.put(ignorer, set);
                    }
                } catch (Exception ignored) {
                }
            }
            // 屏蔽的子服：ignored-servers -> {ignorerUuid: [server, ...]}
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("ignored-servers").childrenMap().entrySet()) {
                try {
                    UUID ignorer = UUID.fromString(String.valueOf(entry.getKey()));
                    Set<String> set = new HashSet<>();
                    for (ConfigurationNode node : entry.getValue().childrenList()) {
                        String value = node.getString("");
                        if (value != null && !value.isEmpty()) {
                            set.add(value.toLowerCase(Locale.ROOT));
                        }
                    }
                    if (!set.isEmpty()) {
                        ignoredServers.put(ignorer, set);
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            logger.warn("Unable to load player.yml", e);
        }
    }

    public boolean toggleMuted(UUID uuid) {
        boolean nowMuted;
        if (Boolean.TRUE.equals(muted.remove(uuid))) {
            nowMuted = false;
        } else {
            muted.put(uuid, Boolean.TRUE);
            nowMuted = true;
        }
        save();
        return nowMuted;
    }

    public boolean isMuted(UUID uuid) {
        return Boolean.TRUE.equals(muted.get(uuid));
    }

    public void setTitle(UUID uuid, String title) {
        if (title == null || title.isEmpty()) {
            titles.remove(uuid);
        } else {
            titles.put(uuid, title);
        }
        save();
    }

    public void removeTitle(UUID uuid) {
        titles.remove(uuid);
        save();
    }

    public String title(UUID uuid) {
        String title = titles.get(uuid);
        return title == null ? "" : title;
    }

    public Optional<ChatMode> chatMode(UUID uuid) {
        return Optional.ofNullable(chatModes.get(uuid));
    }

    public void setChatMode(UUID uuid, ChatMode mode) {
        chatModes.put(uuid, mode);
        save();
    }

    /** 切换屏蔽某个玩家。返回 true 表示已屏蔽，false 表示已解除屏蔽。 */
    public boolean toggleIgnoredPlayer(UUID ignorer, UUID ignored) {
        Set<UUID> set = ignoredPlayers.computeIfAbsent(ignorer, k -> ConcurrentHashMap.newKeySet());
        boolean added;
        if (set.remove(ignored)) {
            added = false;
        } else {
            set.add(ignored);
            added = true;
        }
        if (set.isEmpty()) {
            ignoredPlayers.remove(ignorer);
        }
        save();
        return added;
    }

    public boolean isIgnoringPlayer(UUID ignorer, UUID ignored) {
        Set<UUID> set = ignoredPlayers.get(ignorer);
        return set != null && set.contains(ignored);
    }

    /** 切换屏蔽某个子服。返回 true 表示已屏蔽，false 表示已解除屏蔽。 */
    public boolean toggleIgnoredServer(UUID ignorer, String server) {
        String lower = server == null ? "" : server.toLowerCase(Locale.ROOT);
        Set<String> set = ignoredServers.computeIfAbsent(ignorer, k -> ConcurrentHashMap.newKeySet());
        boolean added;
        if (set.remove(lower)) {
            added = false;
        } else {
            set.add(lower);
            added = true;
        }
        if (set.isEmpty()) {
            ignoredServers.remove(ignorer);
        }
        save();
        return added;
    }

    public boolean isIgnoringServer(UUID ignorer, String server) {
        if (server == null) {
            return false;
        }
        Set<String> set = ignoredServers.get(ignorer);
        return set != null && set.contains(server.toLowerCase(Locale.ROOT));
    }

    public Set<UUID> ignoredPlayers(UUID ignorer) {
        Set<UUID> set = ignoredPlayers.get(ignorer);
        return set == null ? Collections.emptySet() : Collections.unmodifiableSet(set);
    }

    public Set<String> ignoredServers(UUID ignorer) {
        Set<String> set = ignoredServers.get(ignorer);
        return set == null ? Collections.emptySet() : Collections.unmodifiableSet(set);
    }

    public void save() {
        try {
            ConfigurationNode root = ConfigManager.loader(file).createNode();
            for (UUID uuid : muted.keySet()) {
                root.node("muted").appendListNode().set(uuid.toString());
            }
            for (Map.Entry<UUID, String> entry : titles.entrySet()) {
                root.node("titles", entry.getKey().toString()).set(entry.getValue());
            }
            for (Map.Entry<UUID, ChatMode> entry : chatModes.entrySet()) {
                root.node("chat-modes", entry.getKey().toString()).set(entry.getValue().configValue());
            }
            for (Map.Entry<UUID, Set<UUID>> entry : ignoredPlayers.entrySet()) {
                ConfigurationNode node = root.node("ignored-players", entry.getKey().toString());
                for (UUID ignored : entry.getValue()) {
                    node.appendListNode().set(ignored.toString());
                }
            }
            for (Map.Entry<UUID, Set<String>> entry : ignoredServers.entrySet()) {
                ConfigurationNode node = root.node("ignored-servers", entry.getKey().toString());
                for (String server : entry.getValue()) {
                    node.appendListNode().set(server);
                }
            }
            ConfigManager.loader(file).save(root);
        } catch (Exception e) {
            logger.warn("Unable to save player.yml", e);
        }
    }

    public enum ChatMode {
        ALL,
        ONLY;

        public String configValue() {
            return name().toLowerCase(Locale.ROOT);
        }

        public static Optional<ChatMode> from(String value) {
            if (value == null) {
                return Optional.empty();
            }
            switch (value.trim().toLowerCase(Locale.ROOT)) {
                case "all":
                    return Optional.of(ALL);
                case "only":
                    return Optional.of(ONLY);
                default:
                    return Optional.empty();
            }
        }
    }
}
