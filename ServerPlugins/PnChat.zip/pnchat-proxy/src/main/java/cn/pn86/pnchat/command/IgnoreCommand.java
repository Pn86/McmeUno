package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 一级屏蔽命令：/ignore、/ignoreserver、/ignorelist（数据保存于 player.yml）。
 *
 * <p>同时保留 /pnchat ignore|ignoreserver|ignorelist 子命令作为兼容入口；
 * 本类中的静态方法同时被一级命令与 /pnchat 子命令复用。</p>
 *
 * <ul>
 *     <li>/ignore &lt;玩家名&gt; —— 屏蔽/解除屏蔽某玩家的聊天与私聊消息</li>
 *     <li>/ignoreserver &lt;子服名&gt; —— 屏蔽/解除屏蔽某子服的全部聊天消息</li>
 *     <li>/ignorelist —— 查看当前屏蔽列表</li>
 * </ul>
 */
public final class IgnoreCommand implements SimpleCommand {

    public enum Kind { PLAYER, SERVER, LIST }

    private final ChatService chatService;
    private final ProxyServer proxy;
    private final Kind kind;

    public IgnoreCommand(ChatService chatService, ProxyServer proxy, Kind kind) {
        this.chatService = chatService;
        this.proxy = proxy;
        this.kind = kind;
    }

    @Override
    public void execute(Invocation invocation) {
        switch (kind) {
            case PLAYER:
                executePlayer(chatService, proxy, invocation.source(), invocation.arguments());
                break;
            case SERVER:
                executeServer(chatService, invocation.source(), invocation.arguments());
                break;
            case LIST:
                executeList(chatService, proxy, invocation.source());
                break;
        }
    }

    /**
     * 切换屏蔽某玩家。args 为“玩家名”参数数组（不含命令名）。
     */
    public static void executePlayer(ChatService chatService, ProxyServer proxy, CommandSource source, String[] args) {
        if (!(source instanceof Player)) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        if (args.length < 1) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-ignore")));
            return;
        }
        Player self = (Player) source;
        Optional<Player> target = chatService.replyTargetName(args[0]);
        if (target.isEmpty()) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("player-not-found")));
            return;
        }
        Player ignored = target.get();
        if (ignored.getUniqueId().equals(self.getUniqueId())) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("ignore-self")));
            return;
        }
        boolean added = chatService.toggleIgnorePlayer(self, ignored.getUniqueId());
        String key = added ? "ignore-player-on" : "ignore-player-off";
        source.sendMessage(chatService.colored(chatService.configs().prefixed(key)
                .replace("%player%", ignored.getUsername())));
    }

    /**
     * 切换屏蔽某子服。args 为“子服名”参数数组（不含命令名）。
     */
    public static void executeServer(ChatService chatService, CommandSource source, String[] args) {
        if (!(source instanceof Player)) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        if (args.length < 1) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-ignore-server")));
            return;
        }
        Player self = (Player) source;
        String server = args[0].toLowerCase(Locale.ROOT);
        if (!chatService.configs().isServerConfigured(server)) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("server-not-configured")));
            return;
        }
        boolean added = chatService.toggleIgnoreServer(self, server);
        String key = added ? "ignore-server-on" : "ignore-server-off";
        source.sendMessage(chatService.colored(chatService.configs().prefixed(key)
                .replace("%server%", chatService.configs().serverName(server))));
    }

    /**
     * 查看当前屏蔽列表。
     */
    public static void executeList(ChatService chatService, ProxyServer proxy, CommandSource source) {
        if (!(source instanceof Player)) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        Player self = (Player) source;
        Set<UUID> ignoredPlayers = chatService.ignoredPlayers(self);
        Set<String> ignoredServers = chatService.ignoredServers(self);
        String playerNames = ignoredPlayers.stream()
                .map(uuid -> proxy.getPlayer(uuid).map(Player::getUsername).orElse(uuid.toString().substring(0, 8)))
                .sorted()
                .collect(Collectors.joining(", "));
        if (playerNames.isEmpty()) {
            playerNames = "无";
        }
        String serverNames = ignoredServers.stream()
                .map(server -> chatService.configs().serverName(server))
                .sorted()
                .collect(Collectors.joining(", "));
        if (serverNames.isEmpty()) {
            serverNames = "无";
        }
        source.sendMessage(chatService.colored(chatService.configs().prefixed("ignore-list")
                .replace("%players%", playerNames)));
        source.sendMessage(chatService.colored(chatService.configs().prefixed("ignore-list-server")
                .replace("%servers%", serverNames)));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length == 1) {
            if (kind == Kind.PLAYER) {
                return chatService.onlineNames().stream().sorted().toList();
            }
            if (kind == Kind.SERVER) {
                return chatService.configs().configuredServerNames().stream().sorted().toList();
            }
        }
        return List.of();
    }
}
