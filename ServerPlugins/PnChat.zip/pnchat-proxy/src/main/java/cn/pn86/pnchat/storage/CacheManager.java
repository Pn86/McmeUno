package cn.pn86.pnchat.storage;

import cn.pn86.pnchat.config.ConfigManager;
import org.slf4j.Logger;
import org.spongepowered.configurate.ConfigurationNode;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 物品展示缓存。写入采用限流落盘（最多每 5 秒一次）+ 关闭时兜底保存，
 * 避免每个玩家的物品上报都触发全量 YAML 写盘。
 */
public final class CacheManager {
    private static final long SAVE_THROTTLE_MILLIS = 5000L;
    private static final int MAX_CACHE_SIZE = 500;

    private final Path file;
    private final Logger logger;
    private final ConfigManager configs;
    private final Map<String, ItemSnapshot> items = new ConcurrentHashMap<>();
    private final AtomicBoolean dirty = new AtomicBoolean(false);
    private volatile long lastSave = 0L;

    public CacheManager(Path dataDirectory, Logger logger, ConfigManager configs) {
        this.file = dataDirectory.resolve("cache.yml");
        this.logger = logger;
        this.configs = configs;
    }

    public void load() {
        items.clear();
        if (!Files.exists(file)) {
            return;
        }
        try {
            ConfigurationNode root = ConfigManager.loader(file).load();
            for (Map.Entry<Object, ? extends ConfigurationNode> entry : root.node("items").childrenMap().entrySet()) {
                ConfigurationNode node = entry.getValue();
                String id = String.valueOf(entry.getKey());
                ItemSnapshot snapshot = readSnapshot(id, node);
                if (snapshot != null) {
                    items.put(id, snapshot);
                }
            }
        } catch (Exception e) {
            logger.warn("Unable to load cache.yml", e);
        }
    }

    public void save() {
        if (items.isEmpty()) {
            // 没有任何物品时不需要写盘（避免生成空的 cache.yml）
            dirty.set(false);
            return;
        }
        if (!dirty.get()) {
            // 没有变化时不重复写盘
            return;
        }
        try {
            ConfigurationNode root = ConfigManager.loader(file).createNode();
            ConfigurationNode itemRoot = root.node("items");
            for (ItemSnapshot item : items.values()) {
                ConfigurationNode node = itemRoot.node(item.id());
                node.node("owner").set(item.owner().toString());
                node.node("owner-name").set(item.ownerName());
                node.node("server").set(item.server());
                node.node("type-key").set(item.typeKey());
                node.node("display-name").set(item.displayName());
                node.node("amount").set(item.amount());
                node.node("durability").set(item.durability());
                node.node("max-durability").set(item.maxDurability());
                node.node("modded").set(item.modded());
                ConfigurationNode loreRoot = node.node("lore");
                for (String line : item.lore()) {
                    loreRoot.appendListNode().set(line);
                }
                ConfigurationNode enchantRoot = node.node("enchants");
                for (ItemSnapshot.Enchant enchant : item.enchants()) {
                    ConfigurationNode enchantNode = enchantRoot.appendListNode();
                    enchantNode.node("key").set(enchant.key());
                    enchantNode.node("level").set(enchant.level());
                }
                node.node("nbt").set(item.nbt());
                node.node("created-at").set(item.createdAt());
                node.node("source").set(item.source());
            }
            ConfigManager.loader(file).save(root);
            dirty.set(false);
            lastSave = System.currentTimeMillis();
        } catch (Exception e) {
            logger.warn("Unable to save cache.yml", e);
        }
    }

    public ItemSnapshot put(ItemSnapshot item) {
        items.put(item.id(), item);
        dirty.set(true);
        evictIfNeeded();
        long now = System.currentTimeMillis();
        if (now - lastSave >= SAVE_THROTTLE_MILLIS) {
            save();
        }
        return item;
    }

    public Optional<ItemSnapshot> latest(UUID owner, String server) {
        return items.values().stream()
                .filter(item -> item.owner().equals(owner) && item.server().equalsIgnoreCase(server))
                .filter(item -> !isExpired(item))
                .max(Comparator.comparingInt((ItemSnapshot item) -> sourceRank(item.source()))
                        .thenComparing(ItemSnapshot::createdAt));
    }

    /** 最近 maxAgeMillis 毫秒内更新的手持物品数据 */
    public Optional<ItemSnapshot> latestFresh(UUID owner, String server, long maxAgeMillis) {
        long now = System.currentTimeMillis();
        return items.values().stream()
                .filter(item -> item.owner().equals(owner) && item.server().equalsIgnoreCase(server))
                .filter(item -> now - item.createdAt() <= maxAgeMillis)
                .filter(item -> !isExpired(item))
                .max(Comparator.comparingInt((ItemSnapshot item) -> sourceRank(item.source()))
                        .thenComparing(ItemSnapshot::createdAt));
    }

    /** 来源优先级：proxy（代理端识别）> bridge（子服上报）> client（客户端 Mod）。 */
    private static int sourceRank(String source) {
        if ("proxy".equalsIgnoreCase(source)) {
            return 2;
        }
        if ("client".equalsIgnoreCase(source)) {
            return 0;
        }
        return 1;
    }

    public Optional<ItemSnapshot> get(String id) {
        return Optional.ofNullable(items.get(id)).filter(item -> !isExpired(item));
    }

    public void cleanExpired() {
        items.values().removeIf(this::isExpired);
    }

    public void clearAndSave() {
        items.clear();
        dirty.set(true);
        save();
    }

    private void evictIfNeeded() {
        if (items.size() <= MAX_CACHE_SIZE) {
            return;
        }
        items.values().stream()
                .sorted(Comparator.comparingLong(ItemSnapshot::createdAt))
                .limit(items.size() - MAX_CACHE_SIZE)
                .forEach(item -> items.remove(item.id()));
    }

    private boolean isExpired(ItemSnapshot item) {
        return System.currentTimeMillis() - item.createdAt() > configs.itemViewMillis();
    }

    private ItemSnapshot readSnapshot(String id, ConfigurationNode node) {
        try {
            UUID owner = UUID.fromString(node.node("owner").getString(new UUID(0, 0).toString()));
            String ownerName = node.node("owner-name").getString("Unknown");
            String server = node.node("server").getString("unknown");
            String typeKey = node.node("type-key").getString(node.node("material").getString("minecraft:stone"));
            String displayName = node.node("display-name").getString("");
            int amount = node.node("amount").getInt(1);
            int durability = node.node("durability").getInt(0);
            int maxDurability = node.node("max-durability").getInt(0);
            boolean modded = node.node("modded").getBoolean(false);
            java.util.List<String> lore = new java.util.ArrayList<>();
            for (ConfigurationNode loreNode : node.node("lore").childrenList()) {
                lore.add(loreNode.getString(""));
            }
            java.util.List<ItemSnapshot.Enchant> enchants = new java.util.ArrayList<>();
            for (ConfigurationNode enchantNode : node.node("enchants").childrenList()) {
                enchants.add(new ItemSnapshot.Enchant(
                        enchantNode.node("key").getString(""),
                        enchantNode.node("level").getInt(0)
                ));
            }
            String nbt = node.node("nbt").getString("");
            long createdAt = node.node("created-at").getLong(System.currentTimeMillis());
            String source = node.node("source").getString("bridge");
            return new ItemSnapshot(id, owner, ownerName, server, typeKey, displayName, amount,
                    durability, maxDurability, lore, enchants, nbt, modded, createdAt, source);
        } catch (Exception e) {
            return null;
        }
    }
}
