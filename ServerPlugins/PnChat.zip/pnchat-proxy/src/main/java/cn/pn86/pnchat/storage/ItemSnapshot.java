package cn.pn86.pnchat.storage;

import cn.pn86.pnchat.protocol.ItemPayload;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * 代理端缓存的物品展示快照（结构化数据）。
 *
 * <p>source 标记数据来源：proxy（代理端数据包识别）/ bridge（子服桥接上报）/
 * client（客户端 Mod 上报）。展示时默认优先使用代理端识别到的数据（防止子服误判）。</p>
 */
public record ItemSnapshot(
        String id,
        UUID owner,
        String ownerName,
        String server,
        String typeKey,
        String displayName,
        int amount,
        int durability,
        int maxDurability,
        List<String> lore,
        List<Enchant> enchants,
        String nbt,
        boolean modded,
        long createdAt,
        String source
) {

    public ItemSnapshot {
        lore = lore == null ? Collections.emptyList() : List.copyOf(lore);
        enchants = enchants == null ? Collections.emptyList() : List.copyOf(enchants);
        if (source == null || source.isEmpty()) {
            source = "bridge";
        }
    }

    /** 旧调用点兼容：默认 source=bridge（子服桥接上报）。 */
    public ItemSnapshot(String id, UUID owner, String ownerName, String server, String typeKey,
                        String displayName, int amount, int durability, int maxDurability,
                        List<String> lore, List<Enchant> enchants, String nbt, boolean modded, long createdAt) {
        this(id, owner, ownerName, server, typeKey, displayName, amount, durability, maxDurability,
                lore, enchants, nbt, modded, createdAt, "bridge");
    }

    public static ItemSnapshot fromPayload(String id, UUID owner, String ownerName, String server, ItemPayload payload) {
        List<String> lore = payload.lore == null ? Collections.emptyList() : new ArrayList<>(payload.lore);
        List<Enchant> enchants = new ArrayList<>();
        if (payload.enchantments != null) {
            for (ItemPayload.Enchant enchant : payload.enchantments) {
                enchants.add(new Enchant(enchant.key, enchant.level));
            }
        }
        return new ItemSnapshot(
                id,
                owner,
                ownerName,
                server,
                payload.typeKey == null ? "" : payload.typeKey,
                payload.displayName == null ? "" : payload.displayName,
                payload.amount,
                payload.durability,
                payload.maxDurability,
                lore,
                enchants,
                payload.nbt == null ? "" : payload.nbt,
                payload.modded,
                System.currentTimeMillis()
        );
    }

    public record Enchant(String key, int level) {
    }
}
