package cn.pn86.pnchat.packet;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * 极简反射工具：按候选字段名/方法名读取，全部失败返回 null。
 *
 * <p>用于代理端数据包识别（{@link ProxyItemTracker}）。所有对 Velocity 内部类与
 * Netty 的访问都通过反射完成，编译期不依赖任何内部类型；运行期探测失败时安全降级，
 * 不会影响 PnChat 其它功能。</p>
 */
public final class ReflectionUtil {

    private ReflectionUtil() {
    }

    /** 尝试加载类，失败返回 null。 */
    public static Class<?> tryClass(String name) {
        try {
            return Class.forName(name);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 按候选字段名读取字段值，全部失败返回 null。 */
    public static Object getField(Object target, String... names) {
        if (target == null) {
            return null;
        }
        Class<?> type = target instanceof Class ? (Class<?>) target : target.getClass();
        Object instance = target instanceof Class ? null : target;
        for (String name : names) {
            try {
                Field field = findField(type, name);
                if (field == null) {
                    continue;
                }
                field.setAccessible(true);
                return field.get(instance);
            } catch (Throwable ignored) {
                // 尝试下一个候选
            }
        }
        return null;
    }

    /** 设置字段值（尽力而为，失败忽略）。 */
    public static void setField(Object target, String name, Object value) {
        if (target == null) {
            return;
        }
        try {
            Field field = findField(target.getClass(), name);
            if (field == null) {
                return;
            }
            field.setAccessible(true);
            field.set(target, value);
        } catch (Throwable ignored) {
            // 忽略
        }
    }

    /** 调用方法（优先精确参数类型，失败按参数个数宽松匹配），失败返回 null。 */
    public static Object call(Object target, String name, Class<?>[] paramTypes, Object... args) {
        if (target == null) {
            return null;
        }
        try {
            Method method = findMethod(target.getClass(), name, paramTypes, args == null ? 0 : args.length);
            if (method == null) {
                return null;
            }
            method.setAccessible(true);
            return method.invoke(target, args);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 读取静态常量（如协议常量）。 */
    public static Object getStatic(String className, String fieldName) {
        Class<?> type = tryClass(className);
        if (type == null) {
            return null;
        }
        try {
            Field field = type.getDeclaredField(fieldName);
            field.setAccessible(true);
            if (!Modifier.isStatic(field.getModifiers())) {
                return null;
            }
            return field.get(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    private static Method findMethod(Class<?> type, String name, Class<?>[] paramTypes, int argCount) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            // 优先精确参数类型
            if (paramTypes != null) {
                try {
                    return current.getDeclaredMethod(name, paramTypes);
                } catch (NoSuchMethodException ignored) {
                    // 继续宽松匹配
                }
            }
            // 宽松匹配：同名 + 参数个数（用于接口参数类型有差异的场景，如 ChannelHandler）
            for (Method method : current.getDeclaredMethods()) {
                if (method.getName().equals(name) && method.getParameterCount() == argCount) {
                    return method;
                }
            }
            current = current.getSuperclass();
        }
        return null;
    }
}
