package cn.pn86.pnchat.packet;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.proxy.Player;
import org.slf4j.Logger;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 代理端数据包识别器（实验性）：监听 Velocity 内部协议包（Set Slot / Window Items /
 * Held Item Change），在代理端直接识别玩家手持物品，子服无需安装 PnChatBridge。
 *
 * <p>实现说明：</p>
 * <ul>
 *     <li>Velocity 公开 API 没有数据包访问能力，因此本组件通过反射访问
 *         {@code com.velocitypowered.proxy.*} 内部类，并在玩家连接的 Netty pipeline 中
 *         注入一个监听 handler（用 {@link Proxy} 动态代理实现，编译期不依赖 Netty）。</li>
 *     <li><b>双向监听</b>：客户端连接 pipeline 中，inbound 是客户端发给代理的包
 *         （Serverbound，如切换热栏的 HeldItemChange）；outbound 是代理发给客户端的包
 *         （Clientbound，如 Set Slot / Window Items / HeldItemChange 同步）。物品栏内容
 *         更新在 Clientbound 方向，因此 handler 同时实现 ChannelInboundHandler 与
 *         ChannelOutboundHandler。</li>
 *     <li>启动时先探测内部类是否存在：探测失败会输出 WARN 并禁用本组件，物品展示自动
 *         回退到子服插件（PnChatBridge）或客户端 Mod 上报，不影响其它功能。</li>
 *     <li>所有字段均按候选名读取；包类型用 {@code isInstance} 或简单类名匹配双保险，
 *         读取失败只跳过该包，不会抛异常。</li>
 * </ul>
 */
public final class ProxyItemTracker {

    private static final String CONNECTED_PLAYER = "com.velocitypowered.proxy.connection.client.ConnectedPlayer";
    private static final String CLIENT_CONNECTION = "com.velocitypowered.proxy.connection.client.ClientConnection";
    private static final String SET_SLOT_PACKET = "com.velocitypowered.proxy.protocol.packet.SetPlayerInventorySlot";
    private static final String WINDOW_ITEMS_PACKET = "com.velocitypowered.proxy.protocol.packet.WindowItemsPacket";
    private static final String HELD_ITEM_PACKET = "com.velocitypowered.proxy.protocol.packet.HeldItemChangePacket";
    private static final String ITEM_STACK = "com.velocitypowered.proxy.protocol.item.ItemStack";
    private static final String CHANNEL_INBOUND_HANDLER = "io.netty.channel.ChannelInboundHandler";
    private static final String CHANNEL_OUTBOUND_HANDLER = "io.netty.channel.ChannelOutboundHandler";
    private static final String HANDLER_NAME = "pnchat-packet-sniffer";

    private final ChatService chatService;
    private final Logger logger;

    private volatile boolean available = false;
    private Class<?> connectedPlayerClass;
    private Class<?> clientConnectionClass;
    private Class<?> setSlotClass;
    private Class<?> windowItemsClass;
    private Class<?> heldItemClass;
    private Class<?> itemStackClass;
    private Class<?> channelInboundHandlerClass;
    private Class<?> channelOutboundHandlerClass;

    /** 玩家当前选中的快捷栏槽位（0-8），用于决定 36-44 号物品栏槽位是否为主手。 */
    private final Map<UUID, Integer> selectedSlots = new ConcurrentHashMap<>();

    public ProxyItemTracker(ChatService chatService, Logger logger) {
        this.chatService = chatService;
        this.logger = logger;
    }

    /** 探测 Velocity 内部类，返回是否可用。 */
    public boolean probe() {
        connectedPlayerClass = ReflectionUtil.tryClass(CONNECTED_PLAYER);
        clientConnectionClass = ReflectionUtil.tryClass(CLIENT_CONNECTION);
        setSlotClass = ReflectionUtil.tryClass(SET_SLOT_PACKET);
        windowItemsClass = ReflectionUtil.tryClass(WINDOW_ITEMS_PACKET);
        heldItemClass = ReflectionUtil.tryClass(HELD_ITEM_PACKET);
        itemStackClass = ReflectionUtil.tryClass(ITEM_STACK);
        channelInboundHandlerClass = ReflectionUtil.tryClass(CHANNEL_INBOUND_HANDLER);
        channelOutboundHandlerClass = ReflectionUtil.tryClass(CHANNEL_OUTBOUND_HANDLER);

        available = connectedPlayerClass != null
                && clientConnectionClass != null
                && channelInboundHandlerClass != null
                && channelOutboundHandlerClass != null
                && (setSlotClass != null || windowItemsClass != null || heldItemClass != null);
        if (available) {
            logger.info("[PnChat] 代理端数据包识别已启用（无需子服插件）：已探测到 Velocity 内部协议类。");
        } else {
            logger.warn("[PnChat] 未探测到当前 Velocity 版本可用的内部协议类（"
                    + "ConnectedPlayer={}, ClientConnection={}, SetSlot={}, WindowItems={}, HeldItem={}, ItemStack={}），"
                    + "代理端数据包识别已禁用；物品展示将使用子服插件/客户端 Mod 上报（如果有），不影响其它功能。",
                    connectedPlayerClass != null, clientConnectionClass != null,
                    setSlotClass != null, windowItemsClass != null,
                    heldItemClass != null, itemStackClass != null);
        }
        return available;
    }

    public boolean isAvailable() {
        return available;
    }

    /** 玩家连接子服后调用：尝试注入数据包监听。 */
    public void onPlayerConnected(Player player) {
        if (!available) {
            return;
        }
        try {
            Object connection = ReflectionUtil.getField(player, "connection");
            if (connection == null || !clientConnectionClass.isInstance(connection)) {
                logger.debug("玩家 {} 无 ClientConnection（跳过注入）。", player.getUsername());
                return;
            }
            Object channel = ReflectionUtil.getField(connection, "channel");
            if (channel == null) {
                logger.debug("玩家 {} 无 channel（跳过注入）。", player.getUsername());
                return;
            }
            Object eventLoop = ReflectionUtil.call(channel, "eventLoop", null);
            if (eventLoop != null) {
                Runnable task = () -> installHandler(channel, player);
                ReflectionUtil.call(eventLoop, "execute", new Class<?>[]{Runnable.class}, task);
            } else {
                installHandler(channel, player);
            }
        } catch (Exception e) {
            logger.warn("为玩家 {} 注入数据包识别失败（已自动降级）: {}", player.getUsername(), e.toString());
        }
    }

    /** 玩家断开时清理状态。 */
    public void onPlayerDisconnected(Player player) {
        selectedSlots.remove(player.getUniqueId());
    }

    private void installHandler(Object channel, Player player) {
        try {
            Object pipeline = ReflectionUtil.call(channel, "pipeline", null);
            if (pipeline == null) {
                return;
            }
            if (ReflectionUtil.call(pipeline, "get", new Class<?>[]{String.class}, HANDLER_NAME) != null) {
                return;
            }
            Object handler = createSnifferHandler(player);
            if (handler == null) {
                return;
            }
            String before = null;
            Object names = ReflectionUtil.call(pipeline, "names", null);
            if (names instanceof List<?> list) {
                for (Object nameObj : list) {
                    String name = String.valueOf(nameObj);
                    Object context = ReflectionUtil.call(pipeline, "context", new Class<?>[]{String.class}, name);
                    Object existing = context == null ? null : ReflectionUtil.call(context, "handler", null);
                    if (existing != null && clientConnectionClass.isInstance(existing)) {
                        before = name;
                        break;
                    }
                }
            }
            boolean added;
            if (before != null) {
                added = ReflectionUtil.call(pipeline, "addBefore",
                        new Class<?>[]{String.class, String.class, channelInboundHandlerClass},
                        before, HANDLER_NAME, handler) != null;
            } else {
                added = ReflectionUtil.call(pipeline, "addLast",
                        new Class<?>[]{String.class, channelInboundHandlerClass},
                        HANDLER_NAME, handler) != null;
            }
            if (added) {
                logger.info("[PnChat] 已为玩家 {} 安装数据包识别监听（inbound+outbound）。", player.getUsername());
            }
        } catch (Exception e) {
            logger.warn("安装数据包识别监听失败（已自动降级）: {}", e.toString());
        }
    }

    /**
     * 用 JDK 动态代理实现 Netty ChannelInboundHandler + ChannelOutboundHandler
     * （零编译期 Netty 依赖）。
     *
     * <p>inbound 方向（channelRead）捕获客户端发来的 Serverbound 包（切换热栏）；<br>
     * outbound 方向（write）捕获代理发给客户端的 Clientbound 包（Set Slot / Window Items /
     * HeldItemChange 同步）。</p>
     */
    private Object createSnifferHandler(Player player) {
        try {
            InvocationHandler invocation = (proxy, method, args) -> {
                String name = method.getName();
                if ("channelRead".equals(name)) {
                    if (args != null && args.length == 2 && args[1] != null) {
                        inspectInbound(args[1], player);
                        forward(ctxOf(args), "fireChannelRead", args[1]);
                    }
                    return null;
                }
                if ("write".equals(name)) {
                    if (args != null && args.length == 3 && args[1] != null) {
                        inspectOutbound(args[1], player);
                        // 必须继续传递，否则包不会发送
                        forwardWrite(ctxOf(args), args[1], args[2]);
                    }
                    return null;
                }
                if ("flush".equals(name)) {
                    forward(ctxOf(args), "flush", null);
                    return null;
                }
                // outbound 生命周期事件（bind/connect/disconnect/close/deregister/read）
                // 直接转发到 ctx 同名方法，保证连接正常。
                switch (name) {
                    case "bind":
                    case "connect":
                    case "disconnect":
                    case "close":
                    case "deregister":
                    case "read":
                        forward(ctxOf(args), name, args != null && args.length > 1 ? args[1] : null);
                        return null;
                    default:
                        // fallthrough to inbound forwarding below
                }
                // 转发其余入站事件，保证 Velocity 连接流程正常
                switch (name) {
                    case "channelActive":
                        forward(ctxOf(args), "fireChannelActive", null);
                        return null;
                    case "channelInactive":
                        forward(ctxOf(args), "fireChannelInactive", null);
                        return null;
                    case "channelReadComplete":
                        forward(ctxOf(args), "fireChannelReadComplete", null);
                        return null;
                    case "channelRegistered":
                        forward(ctxOf(args), "fireChannelRegistered", null);
                        return null;
                    case "channelUnregistered":
                        forward(ctxOf(args), "fireChannelUnregistered", null);
                        return null;
                    case "channelWritabilityChanged":
                        forward(ctxOf(args), "fireChannelWritabilityChanged", null);
                        return null;
                    case "userEventTriggered":
                        forward(ctxOf(args), "fireUserEventTriggered", args.length > 1 ? args[1] : null);
                        return null;
                    case "exceptionCaught":
                        forward(ctxOf(args), "fireExceptionCaught", args.length > 1 ? args[1] : null);
                        return null;
                    case "handlerAdded":
                    case "handlerRemoved":
                        return null;
                    default:
                        return defaultValue(method.getReturnType());
                }
            };
            return Proxy.newProxyInstance(
                    channelInboundHandlerClass.getClassLoader(),
                    new Class<?>[]{channelInboundHandlerClass, channelOutboundHandlerClass},
                    invocation);
        } catch (Exception e) {
            logger.warn("创建数据包识别监听失败（已自动降级）: {}", e.toString());
            return null;
        }
    }

    private Object ctxOf(Object[] args) {
        return args != null && args.length > 0 ? args[0] : null;
    }

    private void forward(Object ctx, String fireName, Object arg) {
        if (ctx == null) {
            return;
        }
        try {
            if (arg == null) {
                ReflectionUtil.call(ctx, fireName, null);
            } else {
                // Netty fire* 方法参数类型固定为 Object，必须用 Object.class 查找，
                // 不能用具象类型（否则 getDeclaredMethod 匹配不到）。
                ReflectionUtil.call(ctx, fireName, new Class<?>[]{Object.class}, arg);
            }
        } catch (Throwable ignored) {
            // 转发失败不应中断
        }
    }

    /** 转发 outbound write：ctx.write(msg, promise)。 */
    private void forwardWrite(Object ctx, Object msg, Object promise) {
        if (ctx == null) {
            return;
        }
        try {
            if (promise != null) {
                ReflectionUtil.call(ctx, "write", null, msg, promise);
            } else {
                ReflectionUtil.call(ctx, "write", new Class<?>[]{Object.class}, msg);
            }
        } catch (Throwable ignored) {
            // 转发失败不应中断
        }
    }

    private Object defaultValue(Class<?> returnType) {
        if (returnType == boolean.class) {
            return false;
        }
        if (returnType == int.class) {
            return 0;
        }
        if (returnType == long.class) {
            return 0L;
        }
        if (returnType == double.class) {
            return 0.0d;
        }
        if (returnType == float.class) {
            return 0.0f;
        }
        if (returnType == short.class) {
            return (short) 0;
        }
        if (returnType == byte.class) {
            return (byte) 0;
        }
        if (returnType == char.class) {
            return '\0';
        }
        return null;
    }

    /** inbound：客户端发给代理的包（Serverbound）。目前关注切换热栏。 */
    private void inspectInbound(Object packet, Player player) {
        if (isPacket(packet, heldItemClass, "HeldItemChange")) {
            Object slot = ReflectionUtil.getField(packet, "slot", "selectedSlot");
            if (slot instanceof Number number) {
                selectedSlots.put(player.getUniqueId(), number.intValue());
            }
        }
    }

    /** outbound：代理发给客户端的包（Clientbound）。物品栏内容更新在这里。 */
    private void inspectOutbound(Object packet, Player player) {
        UUID uuid = player.getUniqueId();
        if (isPacket(packet, heldItemClass, "HeldItemChange")) {
            Object slot = ReflectionUtil.getField(packet, "slot", "selectedSlot");
            if (slot instanceof Number number) {
                selectedSlots.put(uuid, number.intValue());
            }
            return;
        }
        if (isPacket(packet, setSlotClass, "SetPlayerInventorySlot")) {
            Object slotObj = ReflectionUtil.getField(packet, "slot");
            Object stack = ReflectionUtil.getField(packet, "itemStack", "item", "stack");
            if (slotObj instanceof Number number) {
                int slot = number.intValue();
                int selected = selectedSlots.getOrDefault(uuid, 0);
                if (slot >= 36 && slot <= 44 && slot == 36 + selected) {
                    handleStack(stack, player);
                }
            }
            return;
        }
        if (isPacket(packet, windowItemsClass, "WindowItems")) {
            Object itemsObj = ReflectionUtil.getField(packet, "items", "itemStacks", "slots");
            if (itemsObj instanceof List<?> items && items.size() > 36) {
                int selected = selectedSlots.getOrDefault(uuid, 0);
                int index = 36 + selected;
                if (index >= 0 && index < items.size()) {
                    handleStack(items.get(index), player);
                }
            }
        }
    }

    /** 包类型判断：优先 isInstance，失败用简单类名匹配（跨版本类名差异兜底）。 */
    private boolean isPacket(Object packet, Class<?> clazz, String simpleName) {
        if (packet == null) {
            return false;
        }
        if (clazz != null && clazz.isInstance(packet)) {
            return true;
        }
        String name = packet.getClass().getSimpleName();
        return name != null && name.contains(simpleName);
    }

    private void handleStack(Object stack, Player player) {
        if (stack == null) {
            return;
        }
        if (itemStackClass != null && !itemStackClass.isInstance(stack)) {
            // 不是 ItemStack 类型，可能是空槽位（null 或特殊对象）
            String name = stack.getClass().getSimpleName();
            if (name == null || !name.contains("ItemStack")) {
                return;
            }
        }
        try {
            Object countObj = ReflectionUtil.getField(stack, "count", "itemCount", "amount");
            int count = countObj instanceof Number number ? number.intValue() : 1;
            if (count <= 0) {
                return;
            }
            Object idObj = ReflectionUtil.getField(stack, "itemId", "id", "type", "typeKey");
            String typeKey = idObj == null ? "" : String.valueOf(idObj);
            Object nbtObj = ReflectionUtil.getField(stack, "nbt", "components", "tag", "data");
            String nbtSummary = nbtObj == null ? "" : String.valueOf(nbtObj);
            if (nbtSummary.length() > 1000) {
                nbtSummary = nbtSummary.substring(0, 1000);
            }
            chatService.cachePacketItem(player, typeKey, count, nbtSummary);
        } catch (Exception e) {
            logger.debug("解析手持物品失败（忽略该包）: {}", e.toString());
        }
    }
}
