package cn.pn86.pnchat;

import cn.pn86.pnchat.command.BanChatCommand;
import cn.pn86.pnchat.command.ChatModeCommand;
import cn.pn86.pnchat.command.IgnoreCommand;
import cn.pn86.pnchat.command.PnChatCommand;
import cn.pn86.pnchat.command.PrivateMessageCommand;
import cn.pn86.pnchat.command.SendCommand;
import cn.pn86.pnchat.command.SendSwitchCommand;
import cn.pn86.pnchat.config.ConfigManager;
import cn.pn86.pnchat.listener.ChatListener;
import cn.pn86.pnchat.listener.ConnectionListener;
import cn.pn86.pnchat.listener.PluginMessageListener;
import cn.pn86.pnchat.packet.PnChatPacketListener;
import cn.pn86.pnchat.packet.ProxyItemTracker;
import cn.pn86.pnchat.protocol.PnChatProtocol;
import cn.pn86.pnchat.storage.CacheManager;
import cn.pn86.pnchat.storage.PlayerStorage;
import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.PacketEventsAPI;
import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.PluginContainer;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import io.github.retrooper.packetevents.velocity.factory.VelocityPacketEventsBuilder;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.slf4j.Logger;

import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

@Plugin(
        id = "pnchat",
        name = "PnChat",
        version = "1.4.0",
        description = "跨服聊天、私聊、物品展示、@提醒、敏感词过滤、聊天框自动放行",
        authors = {"Pn86"}
)
public final class PnChatPlugin {

    public static final MinecraftChannelIdentifier CHANNEL =
            MinecraftChannelIdentifier.create("pnchat", "main");
    /** 旧版（1.12 及以下）子服使用的插件消息通道 */
    public static final LegacyChannelIdentifier LEGACY_CHANNEL =
            new LegacyChannelIdentifier(PnChatProtocol.CHANNEL_LEGACY);
    public static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder()
                    .character('&')
                    .hexColors()
                    .build();

    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;
    private final PluginContainer container;

    private ConfigManager configs;
    private CacheManager cache;
    private PlayerStorage players;
    private ChatService chatService;

    /** 内嵌 PacketEvents（无需代理额外安装插件） */
    private PacketEventsAPI<PluginContainer> packetEventsApi;
    private PnChatPacketListener packetListener;
    private boolean packetEventsActive = false;

    /** 反射回退的数据包识别（仅在 PacketEvents 初始化失败时启用） */
    private ProxyItemTracker itemTracker;

    /** 运行时 debug 开关（可通过 /pnchat debug 切换） */
    private volatile boolean debugMode = false;

    @Inject
    public PnChatPlugin(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory, PluginContainer container) {
        this.proxy = proxy;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
        this.container = container;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        configs = new ConfigManager(dataDirectory, logger);
        configs.load();
        cache = new CacheManager(dataDirectory, logger, configs);
        cache.load();
        if (configs.clearCacheOnStart()) {
            cache.clearAndSave();
        }
        players = new PlayerStorage(dataDirectory, logger);
        players.load();
        debugMode = configs.debugEnabled();

        chatService = new ChatService(this, proxy, logger, configs, cache, players);

        // 代理端数据包识别（无需子服插件）：优先内嵌 PacketEvents，失败回退反射方案
        initPacketDetection();

        proxy.getChannelRegistrar().register(CHANNEL);
        proxy.getChannelRegistrar().register(LEGACY_CHANNEL);
        proxy.getEventManager().register(this, new ChatListener(chatService, configs));
        proxy.getEventManager().register(this, new ConnectionListener(chatService, itemTracker, packetListener));
        proxy.getEventManager().register(this, new PluginMessageListener(chatService, logger));

        registerCommands();

        // 周期推送全服玩家名到 1.13+ 客户端的聊天框补全
        proxy.getScheduler().buildTask(this, this::refreshAllTabCompletions)
                .repeat(30, TimeUnit.SECONDS)
                .schedule();

        // 周期清理过期物品缓存
        long cleanupSeconds = Math.max(30L, configs.cacheCleanupIntervalSeconds());
        proxy.getScheduler().buildTask(this, cache::cleanExpired)
                .repeat(cleanupSeconds, TimeUnit.SECONDS)
                .schedule();

        logger.info("PnChat 1.4.0 已启用。物品数据来源优先级：代理端数据包识别 > 子服桥接 > 客户端 Mod。");
    }

    private void initPacketDetection() {
        if (!configs.packetSnifferEnabled()) {
            logger.info("[PnChat] item-detection.packet-sniffer.enabled=false，代理端数据包识别已关闭。");
            return;
        }
        // 1) 优先内嵌 PacketEvents（成熟库，负责 Netty 注入与协议解析）
        try {
            PacketEventsAPI<PluginContainer> api =
                    VelocityPacketEventsBuilder.build(proxy, container, logger, dataDirectory);
            PacketEvents.setAPI(api);
            api.load();
            api.init();
            packetEventsApi = api;
            packetEventsActive = true;
            packetListener = new PnChatPacketListener(chatService, configs, logger);
            api.getEventManager().registerListener(packetListener,
                    com.github.retrooper.packetevents.event.PacketListenerPriority.NORMAL);
            logger.info("[PnChat] 内嵌 PacketEvents 已启用（代理端数据包识别，无需子服插件、无需额外安装插件）。");
            return;
        } catch (Throwable t) {
            logger.warn("[PnChat] PacketEvents 初始化失败，回退到反射数据包识别/子服上报。原因: {}",
                    t.toString(), t);
        }
        // 2) 回退：反射访问 Velocity 内部类
        itemTracker = new ProxyItemTracker(chatService, logger);
        if (configs.packetSnifferEnabled()) {
            itemTracker.probe();
        }
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (cache != null) {
            cache.save();
        }
        if (players != null) {
            players.save();
        }
        if (packetEventsActive && packetEventsApi != null) {
            try {
                packetEventsApi.terminate();
            } catch (Throwable ignored) {
                // 关闭时忽略终止异常
            }
            try {
                VelocityPacketEventsBuilder.clearBuildCache();
            } catch (Throwable ignored) {
            }
        }
        logger.info("PnChat 已关闭。");
    }

    public void reload() {
        configs.load();
        cache = new CacheManager(dataDirectory, logger, configs);
        cache.load();
        if (configs.clearCacheOnStart()) {
            cache.clearAndSave();
        }
        players.load();
        chatService.update(configs, cache, players);
        debugMode = configs.debugEnabled();
        logger.info("PnChat 配置已重载。");
    }

    public void setDebug(boolean enabled) {
        this.debugMode = enabled;
    }

    public boolean isDebug() {
        return debugMode;
    }

    private void registerCommands() {
        proxy.getCommandManager().register("pnchat", new PnChatCommand(this, proxy, logger, chatService));
        proxy.getCommandManager().register("msg", new PrivateMessageCommand(chatService),
                "tell", "w", "m", "whisper");
        proxy.getCommandManager().register("r", new PrivateMessageCommand.ReplyCommand(chatService), "reply");
        proxy.getCommandManager().register(configs.sendCommandName(), new SendCommand(chatService),
                configs.sendCommandAliases().toArray(new String[0]));
        proxy.getCommandManager().register(configs.sendsCommandName(), new SendSwitchCommand(chatService),
                configs.sendsCommandAliases().toArray(new String[0]));
        proxy.getCommandManager().register("banchat", new BanChatCommand(chatService));
        proxy.getCommandManager().register("chats", new ChatModeCommand(chatService), "chatmode");
        // 一级屏蔽命令（/pnchat ignore|ignoreserver|ignorelist 仍作为兼容入口保留）
        proxy.getCommandManager().register("ignore", new IgnoreCommand(chatService, proxy, IgnoreCommand.Kind.PLAYER), "ign");
        proxy.getCommandManager().register("ignoreserver", new IgnoreCommand(chatService, proxy, IgnoreCommand.Kind.SERVER));
        proxy.getCommandManager().register("ignorelist", new IgnoreCommand(chatService, proxy, IgnoreCommand.Kind.LIST), "il");
    }

    public void refreshAllTabCompletions() {
        for (Player player : proxy.getAllPlayers()) {
            chatService.refreshTabCompletions(player);
        }
    }

    public ChatService chatService() {
        return chatService;
    }

    public ConfigManager configs() {
        return configs;
    }

    public CacheManager cache() {
        return cache;
    }

    public PlayerStorage players() {
        return players;
    }

    public Logger logger() {
        return logger;
    }

    public ProxyServer proxy() {
        return proxy;
    }

    public ProxyItemTracker itemTracker() {
        return itemTracker;
    }

    public PnChatPacketListener packetListener() {
        return packetListener;
    }

    public boolean packetEventsActive() {
        return packetEventsActive;
    }

    public Path dataDirectory() {
        return dataDirectory;
    }
}
