package cn.pn86.pnchat.packet;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.config.ConfigManager;
import com.github.retrooper.packetevents.event.PacketListener;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.item.ItemStack;
import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetPlayerInventory;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetSlot;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowItems;
import com.velocitypowered.api.proxy.Player;
import org.slf4j.Logger;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 基于内嵌 PacketEvents 的代理端数据包监听：识别玩家手持物品并写入展示缓存。
 *
 * <ul>
 *     <li>inbound（{@link PacketReceiveEvent}）：客户端切换热栏 {@code HELD_ITEM_CHANGE}，记录选中槽位；</li>
 *     <li>outbound（{@link PacketSendEvent}）：子服发给客户端的物品栏更新
 *         {@code WINDOW_ITEMS} / {@code SET_SLOT} / {@code SET_PLAYER_INVENTORY} / {@code HELD_ITEM_CHANGE}，
 *         解析主手槽位（36 + 选中槽）的物品栈并写入缓存。</li>
 * </ul>
 *
 * <p>所有解析都包在 try-catch 中，任何失败只输出 debug 日志，不影响协议流。</p>
 */
public final class PnChatPacketListener implements PacketListener {

    private final ChatService chatService;
    private final ConfigManager configs;
    private final Logger logger;

    /** 玩家当前选中的快捷栏槽位（0-8）。 */
    private final Map<UUID, Integer> selectedSlots = new ConcurrentHashMap<>();

    public PnChatPacketListener(ChatService chatService, ConfigManager configs, Logger logger) {
        this.chatService = chatService;
        this.configs = configs;
        this.logger = logger;
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        if (event.getPacketType() != PacketType.Play.Client.HELD_ITEM_CHANGE) {
            return;
        }
        Player player = playerOf(event.getPlayer());
        if (player == null) {
            return;
        }
        try {
            WrapperPlayClientHeldItemChange wrapper = new WrapperPlayClientHeldItemChange(event);
            selectedSlots.put(player.getUniqueId(), wrapper.getSlot());
            debug("玩家 {} 切换热栏到槽位 {}", player.getUsername(), wrapper.getSlot());
        } catch (Exception e) {
            debugWarn("解析客户端热栏切换失败（{}）", e);
        }
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        Player player = playerOf(event.getPlayer());
        if (player == null) {
            return;
        }
        if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
            try {
                WrapperPlayServerWindowItems wrapper = new WrapperPlayServerWindowItems(event);
                handleWindowItems(player, wrapper.getItems());
            } catch (Exception e) {
                debugWarn("解析 WINDOW_ITEMS 失败（{}）", e);
            }
        } else if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
            try {
                WrapperPlayServerSetSlot wrapper = new WrapperPlayServerSetSlot(event);
                int slot = wrapper.getSlot();
                int selected = selectedSlots.getOrDefault(player.getUniqueId(), 0);
                if (isHotbarSlot(slot, selected)) {
                    handleStack(player, wrapper.getItem());
                }
            } catch (Exception e) {
                debugWarn("解析 SET_SLOT 失败（{}）", e);
            }
        } else if (event.getPacketType() == PacketType.Play.Server.SET_PLAYER_INVENTORY) {
            try {
                WrapperPlayServerSetPlayerInventory wrapper = new WrapperPlayServerSetPlayerInventory(event);
                int slot = wrapper.getSlot();
                int selected = selectedSlots.getOrDefault(player.getUniqueId(), 0);
                if (isHotbarSlot(slot, selected)) {
                    handleStack(player, wrapper.getStack());
                }
            } catch (Exception e) {
                debugWarn("解析 SET_PLAYER_INVENTORY 失败（{}）", e);
            }
        } else if (event.getPacketType() == PacketType.Play.Server.HELD_ITEM_CHANGE) {
            try {
                WrapperPlayServerHeldItemChange wrapper = new WrapperPlayServerHeldItemChange(event);
                selectedSlots.put(player.getUniqueId(), wrapper.getSlot());
            } catch (Exception e) {
                debugWarn("解析服务端热栏同步失败（{}）", e);
            }
        }
    }

    /** 清空某玩家的热栏状态（断开时调用）。 */
    public void onPlayerDisconnected(Player player) {
        selectedSlots.remove(player.getUniqueId());
    }

    private void handleWindowItems(Player player, List<ItemStack> items) {
        if (items == null || items.size() <= 36) {
            return;
        }
        int selected = selectedSlots.getOrDefault(player.getUniqueId(), 0);
        int index = 36 + selected;
        if (index >= 0 && index < items.size()) {
            handleStack(player, items.get(index));
        }
    }

    private boolean isHotbarSlot(int slot, int selected) {
        // 玩家主物品栏槽位 36-44，当前手持 = 36 + 选中槽
        return slot >= 36 && slot <= 44 && slot == 36 + selected;
    }

    private void handleStack(Player player, ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return;
        }
        try {
            String typeKey = stack.getType().getName().toString();
            int amount = stack.getAmount();
            String nbt = describeNbt(stack);
            chatService.cachePacketItem(player, typeKey, amount, nbt);
            debug("代理识别手持物品：{} {} x{}（{}/{}）", player.getUsername(), typeKey, amount,
                    player.getCurrentServer().map(s -> s.getServerInfo().getName()).orElse("?"),
                    player.getUniqueId());
        } catch (Exception e) {
            debugWarn("解析手持物品失败（{}）", e);
        }
    }

    private String describeNbt(ItemStack stack) {
        try {
            NBTCompound nbt = stack.getOrCreateTag();
            if (nbt != null) {
                String value = nbt.toString();
                if (value.length() > 1000) {
                    value = value.substring(0, 1000);
                }
                return value;
            }
        } catch (Throwable ignored) {
            // NBT 摘要为尽力而为
        }
        return "";
    }

    @SuppressWarnings("unchecked")
    private Player playerOf(Object player) {
        return (Player) player;
    }

    private void debug(String format, Object... args) {
        if (configs.debugEnabled()) {
            logger.info("[PnChat-DEBUG] " + format, args);
        }
    }

    private void debugWarn(String format, Object... args) {
        if (configs.debugEnabled()) {
            logger.warn("[PnChat-DEBUG] " + format, args);
        }
    }
}
