package cn.pn86.pnchat.util;

import cn.pn86.pnchat.storage.ItemSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;

/**
 * 物品展示文本格式化器。
 *
 * <p>v2 版本不再解析 NBT/toString 文本，而是直接使用桥接端上报的结构化数据
 * （显示名、lore、附魔、注册键、NBT 摘要），因此能正确展示新版物品与模组物品。</p>
 */
public final class ItemTextFormatter {

    private ItemTextFormatter() {
    }

    public static String hoverText(ItemSnapshot item, List<String> format,
                                   Function<String, String> itemNames, Function<String, String> enchantNames) {
        String name = displayName(item, itemNames);
        List<String> lines = new ArrayList<>();
        for (String template : format) {
            if ("%lore%".equals(template)) {
                for (String line : item.lore()) {
                    String text = normalizeLegacy(line);
                    if (!text.isEmpty()) {
                        lines.add(hasLegacyStyle(text) ? text : "&5" + text);
                    }
                }
                continue;
            }
            if ("%enchants%".equals(template)) {
                for (String enchant : formatEnchants(item, enchantNames)) {
                    lines.add("&9" + enchant);
                }
                continue;
            }
            if ("%nbt%".equals(template)) {
                if (item.nbt() != null && !item.nbt().isEmpty()) {
                    lines.add("&8" + item.nbt());
                }
                continue;
            }
            String rendered = template
                    .replace("%item%", name)
                    .replace("%material%", material(item, itemNames))
                    .replace("%amount%", String.valueOf(item.amount()))
                    .replace("%durability%", durabilityText(item))
                    .replace("%owner%", item.ownerName());
            if (rendered != null && !rendered.isEmpty()) {
                lines.add(rendered);
            }
        }
        return String.join("\n", lines);
    }

    private static String displayName(ItemSnapshot item, Function<String, String> itemNames) {
        String custom = normalizeLegacy(item.displayName());
        if (!custom.isEmpty()) {
            return custom;
        }
        String mapped = itemNames.apply(normalizeMaterial(item.typeKey()));
        if (mapped != null && !mapped.isEmpty()) {
            return mapped;
        }
        return humanMaterial(item.typeKey());
    }

    private static String material(ItemSnapshot item, Function<String, String> itemNames) {
        String mapped = itemNames.apply(normalizeMaterial(item.typeKey()));
        if (mapped != null && !mapped.isEmpty()) {
            return mapped;
        }
        return humanMaterial(item.typeKey());
    }

    private static String durabilityText(ItemSnapshot item) {
        if (item.maxDurability() > 0) {
            return (item.maxDurability() - item.durability()) + "/" + item.maxDurability();
        }
        if (item.durability() > 0) {
            return String.valueOf(item.durability());
        }
        return "";
    }

    private static List<String> formatEnchants(ItemSnapshot item, Function<String, String> enchantNames) {
        List<String> result = new ArrayList<>();
        for (ItemSnapshot.Enchant enchant : item.enchants()) {
            String key = normalizeMaterial(enchant.key());
            if (key.isEmpty() || "unknown".equals(key)) {
                continue;
            }
            String name = enchantNames.apply(key);
            if (name == null || name.isEmpty()) {
                name = humanMaterial(key);
            }
            result.add(name + " " + roman(enchant.level()));
        }
        return result;
    }

    /** 人类可读材质名：minecraft:diamond_sword -> Diamond Sword */
    public static String humanMaterial(String material) {
        String normalized = normalizeMaterial(material);
        int colon = normalized.indexOf(':');
        if (colon >= 0) {
            normalized = normalized.substring(colon + 1);
        }
        String[] parts = normalized.split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.length() == 0 ? "Unknown Item" : builder.toString();
    }

    /** 把服务端 legacy 文本中的 § 颜色码统一成 & 码，便于 PnChat 的 Legacy 序列化器渲染 */
    private static String normalizeLegacy(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        return text.replace('\u00a7', '&');
    }

    private static boolean hasLegacyStyle(String text) {
        return text.matches(".*&[0-9a-fk-orA-FK-ORx].*");
    }

    private static String normalizeMaterial(String material) {
        if (material == null || material.isEmpty()) {
            return "unknown";
        }
        String value = material.trim();
        if (value.startsWith("ItemTypes.")) {
            value = value.substring("ItemTypes.".length());
        }
        return value.toLowerCase(Locale.ROOT);
    }

    private static String roman(int value) {
        if (value <= 0) {
            return String.valueOf(value);
        }
        int[] values = {10, 9, 5, 4, 1};
        String[] symbols = {"X", "IX", "V", "IV", "I"};
        StringBuilder builder = new StringBuilder();
        int remaining = value;
        for (int i = 0; i < values.length && remaining > 0; i++) {
            while (remaining >= values[i]) {
                builder.append(symbols[i]);
                remaining -= values[i];
            }
        }
        return builder.toString();
    }
}
