package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.config.ConfigManager;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.player.PlayerChatEvent;
import com.velocitypowered.api.proxy.Player;

/**
 * 聊天事件监听器。
 *
 * <p>决定每条聊天消息的去向：</p>
 * <ul>
 *     <li>/send 命令伪造的本地消息：放行到当前子服（allowed）</li>
 *     <li>聊天框自动放行检测命中（粘液科技搜索等）：原样放行（allowed）</li>
 *     <li>直接发送模式（/sends 锁定 或 配置 default-sends）：放行到当前子服（allowed）</li>
 *     <li># 前缀：去掉前缀后放行到当前子服（message）</li>
 *     <li>其余：由 PnChat 作为全服聊天广播，并拒绝后端重复显示（denied）</li>
 * </ul>
 *
 * <p>注意：1.19.1+ 客户端存在聊天签名机制，denied 会触发 Velocity 的
 * “A plugin tried to cancel a signed chat message”踢人。解决方法是安装
 * SignedVelocity（https://hangar.papermc.io/4drian3d/SignedVelocity）。</p>
 */
public final class ChatListener {

    private final ChatService chatService;
    private final ConfigManager configs;

    public ChatListener(ChatService chatService, ConfigManager configs) {
        this.chatService = chatService;
        this.configs = configs;
    }

    @Subscribe
    public void onChat(PlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();

        if (!chatService.shouldHandleChat(player)) {
            // 该子服未接入 PnChat 聊天，交给后端服务器自行处理
            return;
        }

        // /send 命令伪造的本地消息，原样放行到当前子服
        if (chatService.consumeServerChatBypass(player, message)) {
            event.setResult(PlayerChatEvent.ChatResult.allowed());
            return;
        }

        // 聊天框自动放行检测（粘液科技搜索、箱子商店等子服插件）
        if (chatService.shouldAutoPassChat(player, message)) {
            event.setResult(PlayerChatEvent.ChatResult.allowed());
            return;
        }

        // 直接发送模式：锁定为本地聊天，放行到当前子服
        if (chatService.isServerChatLocked(player)) {
            event.setResult(PlayerChatEvent.ChatResult.allowed());
            return;
        }

        // # 前缀：去掉前缀后放行到当前子服
        String prefix = configs.directSendShortcutPrefix();
        if (prefix != null && !prefix.isEmpty() && message.startsWith(prefix)) {
            String stripped = message.substring(prefix.length());
            if (!stripped.isEmpty()) {
                event.setResult(PlayerChatEvent.ChatResult.message(stripped));
                return;
            }
            // 只有 # 一个字符时按普通消息处理
        }

        // 全局 PnChat 聊天
        chatService.handleChat(player, message);
        event.setResult(PlayerChatEvent.ChatResult.denied());
    }
}
