package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.protocol.ItemPayload;
import cn.pn86.pnchat.protocol.PnChatProtocol;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.util.Locale;
import java.util.UUID;

/**
 * 插件消息监听器：处理子服桥上报的物品数据、客户端 Mod 上报的物品数据、AuthMe 登录状态。
 *
 * <p>协议（DataOutputStream / DataInputStream，UTF-8）：</p>
 * <ul>
 *     <li>新协议：第一个字节 = {@link PnChatProtocol#MESSAGE_PROTOCOL_VERSION}，然后才是 action</li>
 *     <li>ITEM：version + "ITEM" + uuid + name + ItemPayload（桥端上报）</li>
 *     <li>ITEM_CLIENT：version + "ITEM_CLIENT" + ItemPayload（客户端 Mod 上报）</li>
 *     <li>AUTH_STATUS：version + "AUTH_STATUS" + uuid + "true"/"false"</li>
 * </ul>
 *
 * <p>兼容旧协议（无版本字节，旧版 PnChat 子服插件/旧版桥发送）：</p>
 * <ul>
 *     <li>AUTH_STATUS：action + uuid + boolean（聊天登录识别插件）</li>
 *     <li>ITEM：action + uuid + ownerName + displayName + material + amount + nbt</li>
 *     <li>ITEM_CLIENT：action + displayName + material + amount + nbt</li>
 * </ul>
 * 旧版消息不再被拒绝，避免旧版聊天登录识别插件（AuthMe 状态上报）失效。
 *
 * <p>兼容两个通道：1.13+ 子服使用 {@code pnchat:main}，1.12 及以下子服使用 {@code PnChat}。</p>
 */
public final class PluginMessageListener {

    private final ChatService chatService;
    private final Logger logger;

    public PluginMessageListener(ChatService chatService, Logger logger) {
        this.chatService = chatService;
        this.logger = logger;
    }

    @Subscribe
    public void onPluginMessage(PluginMessageEvent event) {
        String id = event.getIdentifier().getId();
        if (!PnChatProtocol.CHANNEL.equals(id) && !PnChatProtocol.CHANNEL_LEGACY.equals(id)) {
            return;
        }
        // 消费该通道消息，不再转发
        event.setResult(PluginMessageEvent.ForwardResult.handled());
        byte[] data = event.getData();
        String source = describeSource(event);
        if (data == null || data.length == 0) {
            logger.warn("收到空的 PnChat 插件消息（来自 {}）。", source);
            return;
        }
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
            int first = in.readUnsignedByte();
            if (first == PnChatProtocol.MESSAGE_PROTOCOL_VERSION) {
                // 新协议：version + action + ...
                String action = in.readUTF();
                handleAction(event, action, in, true);
            } else {
                // 旧协议：无版本字节，从开头重新按旧格式解析（首字节是 action 的 UTF 长度高字节）
                DataInputStream legacy = new DataInputStream(new ByteArrayInputStream(data));
                String action = legacy.readUTF();
                handleAction(event, action, legacy, false);
            }
        } catch (EOFException e) {
            logger.warn("收到截断的 PnChat 插件消息（len={}, 来自 {}）：数据不完整，已忽略。",
                    data.length, source);
        } catch (Exception e) {
            logger.warn("处理 PnChat 插件消息失败（来自 {}，len={}）: {}", source, data.length, e.toString());
        }
    }

    private void handleAction(PluginMessageEvent event, String action, DataInputStream in, boolean newProtocol) throws Exception {
        switch (action) {
            case PnChatProtocol.ACTION_ITEM: {
                UUID owner = UUID.fromString(in.readUTF());
                String ownerName = in.readUTF();
                String server = sourceServer(event);
                if (newProtocol) {
                    ItemPayload payload = ItemPayload.read(in);
                    if (payload != null) {
                        chatService.cacheServerItem(owner, ownerName, server, payload);
                    }
                } else {
                    // 旧版桥格式：displayName + material + amount + nbt(长度前缀)
                    String displayName = in.readUTF();
                    String material = in.readUTF();
                    int amount = in.readInt();
                    String nbt = readLargeString(in);
                    chatService.cacheServerItemLegacy(owner, ownerName, server, displayName, material, amount, nbt);
                }
                break;
            }
            case PnChatProtocol.ACTION_ITEM_CLIENT: {
                if (!(event.getSource() instanceof Player)) {
                    break;
                }
                Player player = (Player) event.getSource();
                if (newProtocol) {
                    ItemPayload payload = ItemPayload.read(in);
                    if (payload != null) {
                        chatService.cacheClientItem(player, payload);
                    }
                } else {
                    String displayName = in.readUTF();
                    String material = in.readUTF();
                    int amount = in.readInt();
                    String nbt = readLargeString(in);
                    chatService.cacheClientItemLegacy(player, displayName, material, amount, nbt);
                }
                break;
            }
            case PnChatProtocol.ACTION_AUTH_STATUS: {
                UUID uuid = UUID.fromString(in.readUTF());
                boolean authenticated;
                if (newProtocol) {
                    authenticated = Boolean.parseBoolean(in.readUTF());
                } else {
                    authenticated = in.readBoolean();
                }
                chatService.updateAuthmeStatus(uuid, authenticated);
                break;
            }
            default:
                logger.warn("收到未知的 PnChat 插件消息: {}（来自 {}）", action, describeSource(event));
        }
    }

    private String readLargeString(DataInputStream in) throws Exception {
        int length = in.readInt();
        if (length < 0 || length > 1_000_000) {
            throw new IllegalArgumentException("Invalid item payload length: " + length);
        }
        byte[] bytes = new byte[length];
        in.readFully(bytes);
        return new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
    }

    private String describeSource(PluginMessageEvent event) {
        if (event.getSource() instanceof ServerConnection) {
            return "子服 " + ((ServerConnection) event.getSource()).getServerInfo().getName();
        }
        if (event.getSource() instanceof Player) {
            return "玩家 " + ((Player) event.getSource()).getUsername();
        }
        return String.valueOf(event.getSource());
    }

    private String sourceServer(PluginMessageEvent event) {
        if (event.getSource() instanceof ServerConnection) {
            return ((ServerConnection) event.getSource()).getServerInfo().getName()
                    .toLowerCase(Locale.ROOT);
        }
        if (event.getSource() instanceof Player) {
            return chatService.serverName((Player) event.getSource());
        }
        return "unknown";
    }
}
