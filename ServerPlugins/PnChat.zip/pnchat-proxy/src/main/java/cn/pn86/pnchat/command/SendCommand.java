package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

/**
 * /send <消息>：把消息作为本地聊天发送到当前子服（不进入 PnChat 全服聊天）。
 */
public final class SendCommand implements SimpleCommand {

    private final ChatService chatService;

    public SendCommand(ChatService chatService) {
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player)) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        Player player = (Player) invocation.source();
        String[] args = invocation.arguments();
        if (args.length < 1) {
            player.sendMessage(chatService.colored(chatService.configs().prefixed("usage-send")
                    .replace("%command%", invocation.alias())));
            return;
        }
        String message = String.join(" ", args);
        chatService.sendToCurrentServer(player, message);
    }
}
