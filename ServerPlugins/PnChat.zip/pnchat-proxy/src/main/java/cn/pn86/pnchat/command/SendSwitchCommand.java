package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.Locale;

/**
 * /sends <true|false>：切换“直接发送模式”。
 * 开启后，聊天框输入的消息默认发送到当前子服，不再进入 PnChat 全服聊天。
 */
public final class SendSwitchCommand implements SimpleCommand {

    private final ChatService chatService;

    public SendSwitchCommand(ChatService chatService) {
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player)) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        Player player = (Player) invocation.source();
        String[] args = invocation.arguments();
        boolean locked;
        if (args.length == 0) {
            locked = !chatService.isServerChatLocked(player);
        } else {
            String value = args[0].toLowerCase(Locale.ROOT);
            if ("true".equals(value) || "on".equals(value) || "1".equals(value)) {
                locked = true;
            } else if ("false".equals(value) || "off".equals(value) || "0".equals(value)) {
                locked = false;
            } else {
                player.sendMessage(chatService.colored(chatService.configs().prefixed("usage-sends")
                        .replace("%command%", invocation.alias())));
                return;
            }
        }
        chatService.setServerChatLocked(player, locked);
        player.sendMessage(chatService.colored(chatService.configs().prefixed(locked ? "sends-on" : "sends-off")));
    }
}
