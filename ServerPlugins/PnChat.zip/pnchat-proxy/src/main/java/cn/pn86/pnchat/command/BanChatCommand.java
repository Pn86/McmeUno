package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.Optional;

/**
 * /banchat <玩家名>：切换禁言状态（按 UUID 持久化）。
 */
public final class BanChatCommand implements SimpleCommand {

    private final ChatService chatService;

    public BanChatCommand(ChatService chatService) {
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!invocation.source().hasPermission("pnchat.command.banchat")) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("no-permission")));
            return;
        }
        String[] args = invocation.arguments();
        if (args.length < 1) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("usage-banchat")));
            return;
        }
        Optional<Player> target = chatService.replyTargetName(args[0]);
        if (target.isEmpty()) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-not-found")));
            return;
        }
        Player player = target.get();
        boolean nowMuted = chatService.players().toggleMuted(player.getUniqueId());
        String key = nowMuted ? "mute-on" : "mute-off";
        invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed(key)
                .replace("%player%", player.getUsername())));
    }
}
