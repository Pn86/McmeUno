package cn.pn86.pnchat;

import cn.pn86.pnchat.config.ConfigManager;
import cn.pn86.pnchat.protocol.ItemPayload;
import cn.pn86.pnchat.protocol.PnChatProtocol;
import cn.pn86.pnchat.storage.CacheManager;
import cn.pn86.pnchat.storage.ItemSnapshot;
import cn.pn86.pnchat.storage.PlayerStorage;
import cn.pn86.pnchat.util.ItemTextFormatter;
import com.velocitypowered.api.network.ProtocolVersion;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.title.Title;
import org.slf4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class ChatService {
    private static final Pattern URL_PATTERN = Pattern.compile("(?i)\\b((?:https?://)?(?:[a-z0-9-]+\\.)+[a-z]{2,}(?:/[^\\s]*)?)");
    private static final Pattern COLOR_CODE_PATTERN = Pattern.compile("(?i)(?:&[0-9a-fk-orx]|§[0-9a-fk-orx])");
    private static final long ITEM_POLL_INTERVAL_MILLIS = 25L;

    private final Object plugin;
    private final ProxyServer proxy;
    private final Logger logger;
    private ConfigManager configs;
    private CacheManager cache;
    private PlayerStorage players;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> itemShowcaseCooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> quitMessages = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastServers = new ConcurrentHashMap<>();
    private final Map<UUID, LastMessage> lastMessages = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> authmeAuthenticated = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> replies = new ConcurrentHashMap<>();
    private final Map<UUID, String> serverChatBypass = new ConcurrentHashMap<>();
    private final Set<UUID> serverChatLocked = ConcurrentHashMap.newKeySet();
    private final Set<UUID> announcedJoins = ConcurrentHashMap.newKeySet();

    public ChatService(Object plugin, ProxyServer proxy, Logger logger, ConfigManager configs, CacheManager cache, PlayerStorage players) {
        this.plugin = plugin;
        this.proxy = proxy;
        this.logger = logger;
        this.configs = configs;
        this.cache = cache;
        this.players = players;
    }

    public void update(ConfigManager configs, CacheManager cache, PlayerStorage players) {
        this.configs = configs;
        this.cache = cache;
        this.players = players;
    }

    public void handleChat(Player sender, String message) {
        String server = serverName(sender);
        if (!configs.isServerConfigured(server) || !configs.isChatServerConfigured(server)) {
            return;
        }
        if (!canUsePnChat(sender)) {
            sender.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        if (players.isMuted(sender.getUniqueId())) {
            sender.sendMessage(colored(configs.prefixed("muted")));
            return;
        }
        if (!checkChatLength(sender, message)) {
            return;
        }
        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(sender.getUniqueId(), 0L);
        if (now - last < configs.chatCooldownMillis() && !sender.hasPermission("pnchat.cooldown.bypass")) {
            sender.sendMessage(colored(configs.prefixed("cooldown")));
            return;
        }
        cooldowns.put(sender.getUniqueId(), now);

        String filteredMessage = prepareOutgoingMessage(sender, message);
        if (filteredMessage == null) {
            return;
        }
        boolean itemShowcaseRequested = containsItemToken(filteredMessage)
                && configs.feature("item-showcase")
                && configs.allowItemShowcase(server);
        if (itemShowcaseRequested && !checkItemShowcaseCooldown(sender, now)) {
            return;
        }
        if (itemShowcaseRequested) {
            broadcastChatAfterItem(sender, server, filteredMessage);
            return;
        }
        broadcastChat(sender, server, filteredMessage);
    }

    private void broadcastChat(Player sender, String server, String filteredMessage) {
        if (proxy.getPlayer(sender.getUniqueId()).isEmpty()) {
            return;
        }
        String displayServer = configs.serverName(server);
        Map<String, String> placeholders = placeholders(sender, server);
        placeholders.put("server", displayServer);
        String format = configs.applyPlaceholders(configs.chatFormat(server), placeholders);
        Component content = buildFormattedChat(sender, server, format, filteredMessage);
        Set<UUID> mentionedPlayers = mentionedPlayerIds(sender, filteredMessage);
        sendPublicChat(content, server, sender.getUniqueId(), mentionedPlayers);
        logChat(sender, server, filteredMessage);
        forwardChatLog("CHAT", sender.getUniqueId(), sender.getUsername(), server, "", "", filteredMessage);
        notifyMentions(sender, mentionedPlayers);
    }

    /**
     * 物品展示消息：缓存数据新鲜（max-age-ms 内）时立即广播；否则向子服桥请求一次最新
     * 手持物品，最多等待 request-timeout-ms（每 25ms 轮询一次），超时后按现有缓存广播。
     * 不再使用固定 250ms 延迟。
     */
    private void broadcastChatAfterItem(Player sender, String server, String message) {
        if (cache.latestFresh(sender.getUniqueId(), server, configs.itemMaxAgeMillis()).isPresent()) {
            broadcastChat(sender, server, message);
            return;
        }
        requestHeldItem(sender);
        long deadline = System.currentTimeMillis() + configs.itemRequestTimeoutMillis();
        pollItemThenBroadcast(sender, server, message, deadline);
    }

    private void pollItemThenBroadcast(Player sender, String server, String message, long deadline) {
        if (cache.latestFresh(sender.getUniqueId(), server, configs.itemMaxAgeMillis()).isPresent()
                || System.currentTimeMillis() >= deadline) {
            broadcastChat(sender, server, message);
            return;
        }
        proxy.getScheduler()
                .buildTask(plugin, () -> pollItemThenBroadcast(sender, server, message, deadline))
                .delay(ITEM_POLL_INTERVAL_MILLIS, TimeUnit.MILLISECONDS)
                .schedule();
    }

    public void sendPrivate(Player sender, Player target, String message) {
        if (!configs.feature("private-message")) {
            return;
        }
        if (sender.getUniqueId().equals(target.getUniqueId())) {
            sender.sendMessage(colored(configs.prefixed("self-pm")));
            return;
        }
        String senderServer = serverName(sender);
        String targetServer = serverName(target);
        if (!configs.isServerConfigured(senderServer)
                || !configs.isServerConfigured(targetServer)
                || !configs.isChatServerConfigured(senderServer)) {
            sender.sendMessage(colored(configs.prefixed("server-not-configured")));
            return;
        }
        if (!canUsePnChat(sender)) {
            sender.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        if (!canReceivePnChat(target)) {
            sender.sendMessage(colored(configs.prefixed("target-not-logged-in")));
            return;
        }
        // 屏蔽检测
        if (players.isIgnoringPlayer(target.getUniqueId(), sender.getUniqueId())) {
            sender.sendMessage(colored(configs.prefixed("ignored-by-target")));
            return;
        }
        if (players.isIgnoringPlayer(sender.getUniqueId(), target.getUniqueId())) {
            sender.sendMessage(colored(configs.prefixed("you-ignored-target")));
            return;
        }
        if (!checkChatLength(sender, message)) {
            return;
        }
        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(sender.getUniqueId(), 0L);
        if (now - last < configs.chatCooldownMillis() && !sender.hasPermission("pnchat.cooldown.bypass")) {
            sender.sendMessage(colored(configs.prefixed("cooldown")));
            return;
        }
        cooldowns.put(sender.getUniqueId(), now);

        String filteredMessage = prepareOutgoingMessage(sender, message);
        if (filteredMessage == null) {
            return;
        }
        Map<String, String> senderValues = placeholders(sender, senderServer);
        senderValues.put("target", target.getUsername());
        senderValues.put("target_title", players.title(target.getUniqueId()));
        Map<String, String> targetValues = placeholders(sender, targetServer);
        targetValues.put("sender", sender.getUsername());
        targetValues.put("sender_title", players.title(sender.getUniqueId()));

        sender.sendMessage(buildPrivateMessage(configs.applyPlaceholders(configs.privateSendFormat(senderServer), senderValues), filteredMessage));
        target.sendMessage(buildPrivateMessage(configs.applyPlaceholders(configs.privateReceiveFormat(targetServer), targetValues), filteredMessage));
        replies.put(sender.getUniqueId(), target.getUniqueId());
        replies.put(target.getUniqueId(), sender.getUniqueId());

        if (configs.logPrivateMessage()) {
            logger.info("[PM] {} -> {}: {}", sender.getUsername(), target.getUsername(), filteredMessage);
        }
        forwardChatLog("PRIVATE", sender.getUniqueId(), sender.getUsername(), senderServer, target.getUniqueId().toString(), target.getUsername(), filteredMessage);
    }

    public Optional<Player> replyTarget(Player player) {
        return Optional.ofNullable(replies.get(player.getUniqueId())).flatMap(proxy::getPlayer);
    }

    public Optional<Player> replyTargetName(String name) {
        return proxy.getPlayer(name);
    }

    public Set<String> onlineNames() {
        return proxy.getAllPlayers().stream().map(Player::getUsername).collect(Collectors.toSet());
    }

    public ConfigManager configs() {
        return configs;
    }

    public PlayerStorage players() {
        return players;
    }

    public boolean isChatEnabled() {
        return configs.feature("chat");
    }

    public boolean shouldHandleChat(Player player) {
        String server = serverName(player);
        return isChatEnabled() && configs.isServerConfigured(server) && configs.isChatServerConfigured(server);
    }

    public void broadcastJoin(Player player) {
        if (!configs.feature("join-message")) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            logger.warn("PnChat 加入提示被跳过：玩家 {} 所在子服 {} 未在 server.yml 中配置。", player.getUsername(), server);
            return;
        }
        if (configs.joinNotificationEnabled()) {
            if (!configs.isJoinNotificationServer(server)) {
                logger.warn("PnChat 加入提示被跳过：子服 {} 不在 join-notification 播报范围（mode={}）。",
                        server, configs.joinNotificationMode());
                return;
            }
            if (!announcedJoins.add(player.getUniqueId())) {
                return;
            }
        }
        Map<String, String> values = placeholders(player, server);
        values.put("player", player.getUsername());
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("join"), values)));
    }

    public void broadcastQuit(Player player) {
        if (!configs.feature("quit-message")) {
            return;
        }
        if (configs.joinNotificationEnabled() && !announcedJoins.contains(player.getUniqueId())) {
            return;
        }
        long now = System.currentTimeMillis();
        Long last = quitMessages.put(player.getUniqueId(), now);
        if (last != null && now - last < 2000L) {
            return;
        }
        // DisconnectEvent 时 getCurrentServer() 可能已经为空，使用最后一次记录的服务器
        String server = lastServers.getOrDefault(player.getUniqueId(), "unknown");
        if (!configs.isServerConfigured(server)) {
            logger.warn("PnChat 离开提示被跳过：玩家 {} 最后所在子服 {} 未在 server.yml 中配置。", player.getUsername(), server);
            return;
        }
        Map<String, String> values = placeholders(player, server);
        values.put("player", player.getUsername());
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("quit"), values)));
    }

    public void broadcastTransfer(Player player, String from, String to) {
        if (!configs.feature("transfer-message")) {
            return;
        }
        if (!configs.isServerConfigured(from) || !configs.isServerConfigured(to)) {
            return;
        }
        Map<String, String> values = placeholders(player, to);
        values.put("player", player.getUsername());
        values.put("from", configs.serverName(from));
        values.put("to", configs.serverName(to));
        sendProxyMessage(colored(configs.applyPlaceholders(configs.message("transfer"), values)));
    }

    public boolean joinNotificationGated() {
        return configs.joinNotificationEnabled();
    }

    public Set<String> joinNotificationServers() {
        return configs.joinNotificationServers();
    }

    /** 该子服是否需要播报加入/转服提示（按 join-notification 白/黑名单模式判断）。 */
    public boolean isJoinNotificationServer(String server) {
        return configs.isJoinNotificationServer(server);
    }

    public boolean isJoinAnnounced(Player player) {
        return announcedJoins.contains(player.getUniqueId());
    }

    public void broadcastRawMessage(String message) {
        sendProxyMessage(colored(message));
    }

    public void broadcastTitle(String title, String subtitle, long fadeInTicks, long stayTicks, long fadeOutTicks) {
        Title.Times times = Title.Times.times(
                Duration.ofMillis(Math.max(0, fadeInTicks) * 50L),
                Duration.ofMillis(Math.max(0, stayTicks) * 50L),
                Duration.ofMillis(Math.max(0, fadeOutTicks) * 50L)
        );
        Title builtTitle = Title.title(
                colored(title),
                colored(subtitle == null ? "" : subtitle),
                times
        );
        for (Player player : proxy.getAllPlayers()) {
            if (configs.isServerConfigured(serverName(player)) && canReceivePnChat(player)) {
                player.showTitle(builtTitle);
            }
        }
    }

    public void setTitle(Player player, String title) {
        players.setTitle(player.getUniqueId(), title);
    }

    public void removeTitle(Player player) {
        players.removeTitle(player.getUniqueId());
    }

    public void setChatMode(Player player, PlayerStorage.ChatMode mode) {
        players.setChatMode(player.getUniqueId(), mode);
    }

    public void noteServer(Player player, String server) {
        lastServers.put(player.getUniqueId(), server.toLowerCase(Locale.ROOT));
    }

    /** 返回玩家上一次所在子服（尚未记录时返回 "unknown"） */
    public String lastServerName(Player player) {
        return lastServers.getOrDefault(player.getUniqueId(), "unknown");
    }

    public void applyDefaultServerChatMode(Player player) {
        setServerChatLocked(player, configs.defaultSends(serverName(player)));
    }

    public void updateAuthmeStatus(UUID uuid, boolean authenticated) {
        authmeAuthenticated.put(uuid, authenticated);
    }

    public void cacheServerItem(UUID owner, String ownerName, String server, ItemPayload payload) {
        if (payload == null || payload.amount <= 0) {
            return;
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        cache.put(ItemSnapshot.fromPayload(id, owner, ownerName, server, payload));
    }

    /**
     * 旧版桥上报的条目（无协议版本字节的旧格式 ITEM）。
     * 旧格式只有 displayName / material / amount / nbt，缺少结构化 lore 与附魔。
     */
    public void cacheServerItemLegacy(UUID owner, String ownerName, String server,
                                      String displayName, String material, int amount, String nbt) {
        if (amount <= 0) {
            return;
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        cache.put(new ItemSnapshot(id, owner, ownerName, server,
                material == null ? "" : material,
                displayName == null ? "" : displayName,
                amount, 0, 0,
                List.of(), List.of(),
                nbt == null ? "" : nbt,
                false,
                System.currentTimeMillis()));
    }

    /**
     * 代理端数据包识别写入的条目（无需子服插件）。数据来自 Velocity 内部协议包，
     * 通常只能可靠提供物品注册键/数量/NBT 摘要，展示名与 lore 为空。
     */
    public void cachePacketItem(Player player, String typeKey, int amount, String nbtSummary) {
        if (amount <= 0) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            return;
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        cache.put(new ItemSnapshot(id, player.getUniqueId(), player.getUsername(), server,
                typeKey == null ? "" : typeKey, "", amount, 0, 0,
                List.of(), List.of(), nbtSummary == null ? "" : nbtSummary, false,
                System.currentTimeMillis(), "proxy"));
    }

    public void cacheClientItem(Player player, ItemPayload payload) {
        if (payload == null || payload.amount <= 0) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            return;
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        cache.put(ItemSnapshot.fromPayload(id, player.getUniqueId(), player.getUsername(), server, payload));
    }

    /** 旧版客户端 Mod 上报的条目（无协议版本字节的旧格式 ITEM_CLIENT）。 */
    public void cacheClientItemLegacy(Player player, String displayName, String material,
                                      int amount, String nbt) {
        if (amount <= 0) {
            return;
        }
        String server = serverName(player);
        if (!configs.isServerConfigured(server)) {
            return;
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        cache.put(new ItemSnapshot(id, player.getUniqueId(), player.getUsername(), server,
                material == null ? "" : material,
                displayName == null ? "" : displayName,
                amount, 0, 0,
                List.of(), List.of(),
                nbt == null ? "" : nbt,
                false,
                System.currentTimeMillis()));
    }

    public void sendToCurrentServer(Player player, String message) {
        if (!canUsePnChat(player)) {
            player.sendMessage(colored(configs.prefixed("authme-not-logged-in")));
            return;
        }
        String rendered = configs.directSendPlaceholder().replace("%message%", message).replace("{message}", message);
        serverChatBypass.put(player.getUniqueId(), rendered);
        player.spoofChatInput(rendered);
        proxy.getScheduler()
                .buildTask(plugin, () -> serverChatBypass.remove(player.getUniqueId(), rendered))
                .delay(2, TimeUnit.SECONDS)
                .schedule();
    }

    public boolean consumeServerChatBypass(Player player, String message) {
        return serverChatBypass.remove(player.getUniqueId(), message);
    }

    public boolean isServerChatLocked(Player player) {
        return serverChatLocked.contains(player.getUniqueId());
    }

    public void setServerChatLocked(Player player, boolean locked) {
        if (locked) {
            serverChatLocked.add(player.getUniqueId());
        } else {
            serverChatLocked.remove(player.getUniqueId());
        }
    }

    /**
     * 聊天框自动放行检测：命中任一规则的消息原样放行到当前子服（不进入 PnChat 全服聊天）。
     */
    public boolean shouldAutoPassChat(Player player, String message) {
        if (!configs.chatInputEnabled()) {
            return false;
        }
        String server = serverName(player);
        Set<String> servers = configs.chatInputServers();
        if (!servers.isEmpty() && !servers.contains(server)) {
            return false;
        }
        int maxLength = configs.chatInputMaxLength();
        if (maxLength > 0 && message.codePointCount(0, message.length()) <= maxLength) {
            return true;
        }
        for (Pattern pattern : configs.chatInputPatterns()) {
            if (pattern.matcher(message).find()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 1.13+ 客户端：把全服在线玩家名推送给客户端作为聊天框自定义补全。
     */
    public void refreshTabCompletions(Player player) {
        if (!configs.tabCompleteAllServers()) {
            return;
        }
        if (player.getProtocolVersion().noLessThan(ProtocolVersion.MINECRAFT_1_13)) {
            Set<String> names = onlineNames();
            if (names.size() > 1000) {
                names = names.stream().limit(1000).collect(Collectors.toSet());
            }
            player.setCustomChatCompletions(names);
        }
    }

    public void clearSession(Player player) {
        UUID uuid = player.getUniqueId();
        serverChatLocked.remove(uuid);
        serverChatBypass.remove(uuid);
        cooldowns.remove(uuid);
        itemShowcaseCooldowns.remove(uuid);
        lastServers.remove(uuid);
        lastMessages.remove(uuid);
        authmeAuthenticated.remove(uuid);
        replies.remove(uuid);
        replies.values().removeIf(uuid::equals);
        announcedJoins.remove(uuid);
    }

    /** 切换屏蔽玩家。返回 true 表示已屏蔽。 */
    public boolean toggleIgnorePlayer(Player player, UUID ignored) {
        return players.toggleIgnoredPlayer(player.getUniqueId(), ignored);
    }

    /** 切换屏蔽子服。返回 true 表示已屏蔽。 */
    public boolean toggleIgnoreServer(Player player, String server) {
        return players.toggleIgnoredServer(player.getUniqueId(), server);
    }

    public Set<UUID> ignoredPlayers(Player player) {
        return players.ignoredPlayers(player.getUniqueId());
    }

    public Set<String> ignoredServers(Player player) {
        return players.ignoredServers(player.getUniqueId());
    }

    public Component colored(String text) {
        return PnChatPlugin.LEGACY.deserialize(text == null ? "" : text);
    }

    public String serverName(Player player) {
        return player.getCurrentServer()
                .map(ServerConnection::getServer)
                .map(com.velocitypowered.api.proxy.server.RegisteredServer::getServerInfo)
                .map(info -> info.getName().toLowerCase(Locale.ROOT))
                .orElseGet(() -> lastServers.getOrDefault(player.getUniqueId(), "unknown"));
    }

    private boolean checkChatLength(Player sender, String message) {
        int max = configs.chatMaxLength();
        if (max <= 0 || sender.hasPermission("pnchat.chat.bypass.length")) {
            return true;
        }
        if (message.codePointCount(0, message.length()) > max) {
            sender.sendMessage(colored(configs.prefixed("message-too-long").replace("%max%", String.valueOf(max))));
            return false;
        }
        return true;
    }

    private Component buildFormattedChat(Player sender, String server, String format, String message) {
        int index = format.indexOf("%message%");
        if (index < 0) {
            return colored(format).append(buildMessage(sender, server, message));
        }
        Component before = colored(format.substring(0, index));
        Component after = colored(format.substring(index + "%message%".length()));
        return before.append(buildMessage(sender, server, message)).append(after);
    }

    private Component buildPrivateMessage(String format, String message) {
        int index = format.indexOf("%message%");
        if (index < 0) {
            return colored(format).append(plain(message));
        }
        Component before = colored(format.substring(0, index));
        Component after = colored(format.substring(index + "%message%".length()));
        return before.append(plain(message)).append(after);
    }

    private Component buildMessage(Player sender, String server, String message) {
        Component result = Component.empty();
        String token = configs.itemToken();
        int position = 0;
        while (!token.isEmpty()) {
            int tokenIndex = message.indexOf(token, position);
            if (tokenIndex < 0) {
                break;
            }
            result = result.append(buildTextWithLinksAndMentions(message.substring(position, tokenIndex)));
            result = result.append(buildItemComponent(sender, server));
            position = tokenIndex + token.length();
        }
        result = result.append(buildTextWithLinksAndMentions(message.substring(position)));
        return result;
    }

    private Component buildItemComponent(Player sender, String server) {
        if (!configs.feature("item-showcase")) {
            return colored(configs.message("item-disabled"));
        }
        if (!configs.allowItemShowcase(server)) {
            return colored(configs.message("item-disabled"));
        }
        Optional<ItemSnapshot> optional = cache.latest(sender.getUniqueId(), server);
        if (optional.isEmpty()) {
            return colored(configs.message("item-no-data"));
        }
        ItemSnapshot item = optional.get();
        Component hover = colored(ItemTextFormatter.hoverText(item, configs.itemHoverFormat(), configs::itemName, configs::enchantName));
        String itemName = item.displayName() != null && !item.displayName().isEmpty()
                ? item.displayName()
                : ItemTextFormatter.humanMaterial(item.typeKey());
        String display = configs.itemChatDisplay()
                .replace("%item%", itemName)
                .replace("%amount%", String.valueOf(item.amount()))
                .replace("%material%", item.typeKey())
                .replace("%player%", item.ownerName());
        return colored(display)
                .hoverEvent(HoverEvent.showText(hover));
    }

    private Component buildTextWithLinksAndMentions(String text) {
        Component result = Component.empty();
        if (!configs.feature("url")) {
            return buildMentions(text);
        }
        int cursor = 0;
        Matcher matcher = URL_PATTERN.matcher(text);
        while (matcher.find()) {
            result = result.append(buildMentions(text.substring(cursor, matcher.start())));
            String raw = matcher.group(1);
            String url = normalizeUrl(raw);
            Component link = colored(configs.urlDisplay())
                    .clickEvent(ClickEvent.openUrl(url))
                    .hoverEvent(HoverEvent.showText(colored(configs.urlHover().replace("%url%", url))));
            if (configs.urlUnderline()) {
                link = link.decorate(net.kyori.adventure.text.format.TextDecoration.UNDERLINED);
            }
            result = result.append(link);
            cursor = matcher.end();
        }
        return result.append(buildMentions(text.substring(cursor)));
    }

    private Component buildMentions(String text) {
        if (!configs.feature("mention") || text.isEmpty()) {
            return plain(text);
        }
        Component result = Component.empty();
        int cursor = 0;
        String lower = text.toLowerCase(Locale.ROOT);
        Set<String> names = proxy.getAllPlayers().stream().map(Player::getUsername).collect(Collectors.toSet());
        while (cursor < text.length()) {
            String matched = null;
            int matchedAt = -1;
            for (String name : names) {
                if (name.isEmpty()) {
                    continue;
                }
                String lowerName = name.toLowerCase(Locale.ROOT);
                int at = lower.indexOf(lowerName, cursor);
                while (at >= 0) {
                    if (isWholeWordMatch(text, at, name.length())) {
                        if (matchedAt < 0 || at < matchedAt) {
                            matchedAt = at;
                            matched = name;
                        }
                        break;
                    }
                    at = lower.indexOf(lowerName, at + 1);
                }
            }
            if (matched == null) {
                result = result.append(plain(text.substring(cursor)));
                break;
            }
            result = result.append(plain(text.substring(cursor, matchedAt)));
            String originalName = text.substring(matchedAt, matchedAt + matched.length());
            result = result.append(colored(configs.mentionFormat().replace("%player%", originalName)));
            cursor = matchedAt + matched.length();
        }
        return result;
    }

    private Set<UUID> mentionedPlayerIds(Player sender, String message) {
        if (!configs.feature("mention")) {
            return Set.of();
        }
        Set<UUID> result = new HashSet<>();
        for (Player player : proxy.getAllPlayers()) {
            if (player.getUniqueId().equals(sender.getUniqueId())) {
                continue;
            }
            String name = player.getUsername();
            if (name.isEmpty()) {
                continue;
            }
            String lower = message.toLowerCase(Locale.ROOT);
            String lowerName = name.toLowerCase(Locale.ROOT);
            int at = lower.indexOf(lowerName);
            while (at >= 0) {
                if (isWholeWordMatch(message, at, name.length())) {
                    result.add(player.getUniqueId());
                    break;
                }
                at = lower.indexOf(lowerName, at + 1);
            }
        }
        return result;
    }

    /**
     * 判断从 start 开始的 word 是否作为一个完整的“单词”出现（避免 www.Steve.com 之类误匹配）。
     */
    private boolean isWholeWordMatch(String text, int start, int wordLength) {
        int end = start + wordLength;
        if (start > 0 && isNameChar(text.charAt(start - 1))) {
            return false;
        }
        return end >= text.length() || !isNameChar(text.charAt(end));
    }

    private boolean isNameChar(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_';
    }

    private void notifyMentions(Player sender, Set<UUID> mentionedPlayers) {
        for (Player player : proxy.getAllPlayers()) {
            if (!mentionedPlayers.contains(player.getUniqueId())) {
                continue;
            }
            if (!configs.isServerConfigured(serverName(player))) {
                continue;
            }
            if (!canReceivePnChat(player)) {
                continue;
            }
            // 被提及者屏蔽了发送者则不提示
            if (players.isIgnoringPlayer(player.getUniqueId(), sender.getUniqueId())) {
                continue;
            }
            String subtitle = configs.mentionSubtitle().replace("%player%", sender.getUsername());
            player.showTitle(Title.title(
                    Component.empty(),
                    colored(subtitle),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1800), Duration.ofMillis(400))
            ));
            player.playSound(Sound.sound(Key.key(configs.mentionSound()), Sound.Source.PLAYER, configs.mentionSoundVolume(), configs.mentionSoundPitch()));
        }
    }

    private Map<String, String> placeholders(Player player, String server) {
        Map<String, String> values = new HashMap<>();
        values.put("player", player.getUsername());
        values.put("title", players.title(player.getUniqueId()));
        values.put("server", configs.serverName(server));
        values.put("online", String.valueOf(proxy.getPlayerCount()));
        for (com.velocitypowered.api.proxy.server.RegisteredServer registered : proxy.getAllServers()) {
            String name = registered.getServerInfo().getName();
            long count = proxy.getAllPlayers().stream()
                    .filter(p -> serverName(p).equalsIgnoreCase(name))
                    .count();
            values.put("online_" + name, String.valueOf(count));
        }
        return values;
    }

    private boolean requestHeldItem(Player player) {
        Optional<ServerConnection> current = player.getCurrentServer();
        if (current.isEmpty()) {
            return false;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeByte(PnChatProtocol.MESSAGE_PROTOCOL_VERSION);
            out.writeUTF(PnChatProtocol.ACTION_HELD_ITEM);
            out.writeUTF(player.getUniqueId().toString());
            byte[] payload = bytes.toByteArray();
            boolean sent = current.get().sendPluginMessage(PnChatPlugin.CHANNEL, payload);
            // 兼容 1.12 及以下使用旧版通道的子服
            if (current.get().sendPluginMessage(PnChatPlugin.LEGACY_CHANNEL, payload)) {
                sent = true;
            }
            return sent;
        } catch (IOException e) {
            return false;
        }
    }

    private boolean checkItemShowcaseCooldown(Player sender, long now) {
        long cooldown = configs.itemShowcaseCooldownMillis();
        if (cooldown <= 0) {
            return true;
        }
        long last = itemShowcaseCooldowns.getOrDefault(sender.getUniqueId(), 0L);
        long remaining = cooldown - (now - last);
        if (remaining > 0L) {
            sender.sendMessage(colored(configs.prefixed("item-showcase-cooldown")
                    .replace("%time%", String.format(Locale.ROOT, "%.1f", remaining / 1000.0))));
            return false;
        }
        itemShowcaseCooldowns.put(sender.getUniqueId(), now);
        return true;
    }

    private boolean containsItemToken(String message) {
        String token = configs.itemToken();
        return token != null
                && !token.isEmpty()
                && message.contains(token);
    }

    private void writeLargeString(DataOutputStream out, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(bytes.length);
        out.write(bytes);
    }

    private void logChat(Player sender, String server, String message) {
        if (configs.logChatMessage()) {
            logger.info("[Chat/{}] {}: {}", server, sender.getUsername(), message);
        }
    }

    private void forwardChatLog(String type, UUID senderId, String senderName, String server, String targetId, String targetName, String message) {
        if (!configs.chatLogApiEnabled()) {
            return;
        }
        if (!configs.isServerConfigured(server)) {
            return;
        }
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeByte(PnChatProtocol.MESSAGE_PROTOCOL_VERSION);
            out.writeUTF("PRIVATE".equalsIgnoreCase(type) ? PnChatProtocol.ACTION_PRIVATE_LOG : PnChatProtocol.ACTION_CHAT_LOG);
            out.writeUTF(type);
            out.writeUTF(senderId.toString());
            out.writeUTF(senderName);
            out.writeUTF(server);
            out.writeUTF(configs.serverName(server));
            out.writeUTF(targetId == null ? "" : targetId);
            out.writeUTF(targetName == null ? "" : targetName);
            writeLargeString(out, message);
            byte[] payload = bytes.toByteArray();
            Set<String> sentServers = ConcurrentHashMap.newKeySet();
            for (Player player : proxy.getAllPlayers()) {
                String current = serverName(player);
                if (!configs.isServerConfigured(current) || !sentServers.add(current)) {
                    continue;
                }
                player.getCurrentServer().ifPresent(connection -> {
                    connection.sendPluginMessage(PnChatPlugin.CHANNEL, payload);
                    connection.sendPluginMessage(PnChatPlugin.LEGACY_CHANNEL, payload);
                });
            }
        } catch (IOException e) {
            logger.warn("Unable to forward PnChat chat log to backend servers.", e);
        }
    }

    private Component plain(String text) {
        if (configs.allowColorCodes()) {
            return colored(text);
        }
        return Component.text(text);
    }

    private void sendProxyMessage(Component message) {
        for (Player player : proxy.getAllPlayers()) {
            if (configs.isServerConfigured(serverName(player)) && canReceivePnChat(player)) {
                player.sendMessage(message);
            }
        }
    }

    private void sendPublicChat(Component message, String senderServer, UUID senderId, Set<UUID> mentionedPlayers) {
        for (Player player : proxy.getAllPlayers()) {
            String receiverServer = serverName(player);
            if (!configs.isServerConfigured(receiverServer) || !canReceivePnChat(player)) {
                continue;
            }
            // 屏蔽检测：被屏蔽的玩家 / 被屏蔽的子服
            if (players.isIgnoringPlayer(player.getUniqueId(), senderId)
                    || players.isIgnoringServer(player.getUniqueId(), senderServer)) {
                continue;
            }
            PlayerStorage.ChatMode mode = players.chatMode(player.getUniqueId())
                    .orElseGet(() -> PlayerStorage.ChatMode.from(configs.defaultChats(receiverServer))
                            .orElse(PlayerStorage.ChatMode.ALL));
            if (mode == PlayerStorage.ChatMode.ALL
                    || receiverServer.equalsIgnoreCase(senderServer)
                    || mentionedPlayers.contains(player.getUniqueId())) {
                player.sendMessage(message);
            }
        }
    }

    private String prepareOutgoingMessage(Player sender, String message) {
        String filtered = hidePrivacy(message);
        filtered = filterSensitiveWords(filtered);
        if (isTooSimilar(sender, filtered)) {
            sender.sendMessage(colored(configs.prefixed("spam-similar")));
            return null;
        }
        rememberMessage(sender, filtered);
        return filtered;
    }

    private boolean canUsePnChat(Player player) {
        if (!configs.authmeEnabled()) {
            return true;
        }
        Boolean authenticated = authmeAuthenticated.get(player.getUniqueId());
        return authenticated != null ? authenticated : !configs.authmeBlockUnknown();
    }

    private boolean canReceivePnChat(Player player) {
        return !configs.authmeBlockReceive() || canUsePnChat(player);
    }

    private String hidePrivacy(String message) {
        if (!configs.privacyEnabled()) {
            return message;
        }
        String filtered = message;
        for (ConfigManager.PrivacyRule rule : configs.privacyRules()) {
            filtered = rule.pattern().matcher(filtered).replaceAll(Matcher.quoteReplacement(configs.privacyReplacement()));
        }
        return filtered;
    }

    private String filterSensitiveWords(String message) {
        if (!configs.sensitiveWordsEnabled()) {
            return message;
        }
        String filtered = message;
        for (String word : configs.sensitiveWords()) {
            filtered = replaceObfuscatedWord(filtered, word, configs.sensitiveReplacement());
        }
        return filtered;
    }

    private String replaceObfuscatedWord(String input, String word, String replacement) {
        NormalizedText normalizedInput = normalizeForModeration(input);
        String normalizedWord = normalizeForModeration(word).text();
        if (normalizedWord.isEmpty()) {
            return input;
        }
        StringBuilder output = new StringBuilder(input);
        String lowerInput = normalizedInput.text().toLowerCase(Locale.ROOT);
        String lowerWord = normalizedWord.toLowerCase(Locale.ROOT);
        int from = 0;
        int offset = 0;
        while (true) {
            int at = lowerInput.indexOf(lowerWord, from);
            if (at < 0) {
                break;
            }
            int originalStart = normalizedInput.indexes().get(at) + offset;
            int originalEnd = normalizedInput.indexes().get(at + lowerWord.length() - 1) + 1 + offset;
            output.replace(originalStart, originalEnd, replacement);
            offset += replacement.length() - (originalEnd - originalStart);
            from = at + lowerWord.length();
        }
        return output.toString();
    }

    private boolean isTooSimilar(Player sender, String message) {
        if (!configs.antiSpamEnabled()) {
            return false;
        }
        String normalized = normalizeForModeration(message).text().toLowerCase(Locale.ROOT);
        if (normalized.length() < configs.antiSpamMinLength()) {
            return false;
        }
        LastMessage last = lastMessages.get(sender.getUniqueId());
        if (last == null || System.currentTimeMillis() - last.time() > configs.antiSpamRememberMillis()) {
            return false;
        }
        return similarity(last.normalized(), normalized) >= configs.antiSpamSimilarityThreshold();
    }

    private void rememberMessage(Player sender, String message) {
        String normalized = normalizeForModeration(message).text().toLowerCase(Locale.ROOT);
        if (normalized.length() >= configs.antiSpamMinLength()) {
            lastMessages.put(sender.getUniqueId(), new LastMessage(normalized, System.currentTimeMillis()));
        }
    }

    private double similarity(String left, String right) {
        int max = Math.max(left.length(), right.length());
        if (max == 0) {
            return 1.0;
        }
        return 1.0 - (levenshtein(left, right) / (double) max);
    }

    private int levenshtein(String left, String right) {
        int[] previous = new int[right.length() + 1];
        int[] current = new int[right.length() + 1];
        for (int j = 0; j <= right.length(); j++) {
            previous[j] = j;
        }
        for (int i = 1; i <= left.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= right.length(); j++) {
                int cost = left.charAt(i - 1) == right.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[right.length()];
    }

    private NormalizedText normalizeForModeration(String input) {
        Pattern ignored = configs.sensitiveIgnorePattern();
        StringBuilder text = new StringBuilder();
        List<Integer> indexes = new ArrayList<>();
        for (int i = 0; i < input.length(); ) {
            Matcher matcher = ignored.matcher(input);
            matcher.region(i, input.length());
            if (matcher.lookingAt()) {
                i = matcher.end();
                continue;
            }
            int codePoint = input.codePointAt(i);
            text.appendCodePoint(codePoint);
            indexes.add(i);
            i += Character.charCount(codePoint);
        }
        return new NormalizedText(COLOR_CODE_PATTERN.matcher(text.toString()).replaceAll(""), indexes);
    }

    private String normalizeUrl(String raw) {
        String compact = raw.replaceAll("\\s*[,.]\\s*", ".").replaceAll("\\s+", ".");
        return compact.toLowerCase(Locale.ROOT).startsWith("http") ? compact : "https://" + compact;
    }

    private record LastMessage(String normalized, long time) {
    }

    private record NormalizedText(String text, List<Integer> indexes) {
    }
}
