package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;
import java.util.Optional;

/**
 * /msg、/tell、/w、/m、/whisper 跨服私聊，以及 /r、/reply 回复。
 */
public final class PrivateMessageCommand implements SimpleCommand {

    private final ChatService chatService;

    public PrivateMessageCommand(ChatService chatService) {
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player)) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        Player sender = (Player) invocation.source();
        String[] args = invocation.arguments();
        if (args.length < 2) {
            sender.sendMessage(chatService.colored(chatService.configs().prefixed("usage-msg")));
            return;
        }
        Optional<Player> target = chatService.replyTargetName(args[0]);
        if (target.isEmpty()) {
            sender.sendMessage(chatService.colored(chatService.configs().prefixed("player-not-found")));
            return;
        }
        String message = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        chatService.sendPrivate(sender, target.get(), message);
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length == 0) {
            return chatService.onlineNames().stream().sorted().toList();
        }
        return List.of();
    }

    /**
     * /r、/reply 回复最近私聊对象。
     */
    public static final class ReplyCommand implements SimpleCommand {

        private final ChatService chatService;

        public ReplyCommand(ChatService chatService) {
            this.chatService = chatService;
        }

        @Override
        public void execute(Invocation invocation) {
            if (!(invocation.source() instanceof Player)) {
                invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
                return;
            }
            Player sender = (Player) invocation.source();
            String[] args = invocation.arguments();
            if (args.length < 1) {
                sender.sendMessage(chatService.colored(chatService.configs().prefixed("usage-msg")));
                return;
            }
            Optional<Player> target = chatService.replyTarget(sender);
            if (target.isEmpty()) {
                sender.sendMessage(chatService.colored(chatService.configs().prefixed("reply-empty")));
                return;
            }
            String message = String.join(" ", args);
            chatService.sendPrivate(sender, target.get(), message);
        }
    }
}
