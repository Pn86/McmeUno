package cn.pn86.pnchat.listener;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.packet.PnChatPacketListener;
import cn.pn86.pnchat.packet.ProxyItemTracker;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.proxy.Player;

import java.util.Locale;

/**
 * 连接与转服监听器。
 *
 * <p>负责：加入提示（含登录服/大厅隔离）、转服提示、离开提示、玩家所在子服记录、
 * 直接发送模式默认值、聊天框 TAB 补全推送。</p>
 *
 * <p>隔离规则（join-notification.enabled=true 时）：</p>
 * <ul>
 *     <li>玩家首次进入代理：只有进入 join-notification 播报范围内的子服才播报加入提示；</li>
 *     <li>转服：只有目标子服在播报范围内才播报（首次进入播报范围子服按加入提示处理，后续按转服提示）；</li>
 *     <li>离开：只有玩家曾被播报过加入提示才播报离开提示。</li>
 *     <li>mode=whitelist：只有 servers 列表中列出的子服播报；mode=blacklist：列表中列出的子服不播报，其余全部播报。</li>
 * </ul>
 */
public final class ConnectionListener {

    private final ChatService chatService;
    private final ProxyItemTracker itemTracker;
    private final PnChatPacketListener packetListener;

    public ConnectionListener(ChatService chatService, ProxyItemTracker itemTracker, PnChatPacketListener packetListener) {
        this.chatService = chatService;
        this.itemTracker = itemTracker;
        this.packetListener = packetListener;
    }

    @Subscribe
    public void onPostLogin(PostLoginEvent event) {
        chatService.refreshTabCompletions(event.getPlayer());
    }

    @Subscribe
    public void onServerConnected(ServerConnectedEvent event) {
        Player player = event.getPlayer();
        String from = chatService.lastServerName(player);
        String to = event.getServer().getServerInfo().getName().toLowerCase(Locale.ROOT);
        chatService.noteServer(player, to);
        chatService.applyDefaultServerChatMode(player);
        // 反射回退模式才需要逐玩家注入；PacketEvents 模式为全局监听
        if (itemTracker != null) {
            itemTracker.onPlayerConnected(player);
        }

        if (from.equalsIgnoreCase("unknown") || from.isEmpty()) {
            // 首次进入代理：加入提示（内部会按“提示子服”配置隔离）
            chatService.broadcastJoin(player);
        } else if (!from.equalsIgnoreCase(to)) {
            // 转服：与加入/退出一样遵循隔离配置
            if (chatService.joinNotificationGated()) {
                if (chatService.isJoinNotificationServer(to)) {
                    if (!chatService.isJoinAnnounced(player)) {
                        chatService.broadcastJoin(player);
                    } else {
                        chatService.broadcastTransfer(player, from, to);
                    }
                }
                // 目标子服不在播报范围内 -> 不播报转服提示（隔离）
            } else {
                chatService.broadcastTransfer(player, from, to);
            }
        }
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        Player player = event.getPlayer();
        if (itemTracker != null) {
            itemTracker.onPlayerDisconnected(player);
        }
        if (packetListener != null) {
            packetListener.onPlayerDisconnected(player);
        }
        chatService.broadcastQuit(player);
        chatService.clearSession(player);
    }
}
