package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.storage.PlayerStorage;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;

import java.util.List;
import java.util.Locale;

/**
 * /chats <only|all>：切换聊天接收模式。
 */
public final class ChatModeCommand implements SimpleCommand {

    private final ChatService chatService;

    public ChatModeCommand(ChatService chatService) {
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player)) {
            invocation.source().sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
            return;
        }
        Player player = (Player) invocation.source();
        String[] args = invocation.arguments();
        if (args.length < 1) {
            player.sendMessage(chatService.colored(chatService.configs().prefixed("usage-chats")));
            return;
        }
        String value = args[0].toLowerCase(Locale.ROOT);
        PlayerStorage.ChatMode mode;
        if ("only".equals(value) || "o".equals(value)) {
            mode = PlayerStorage.ChatMode.ONLY;
        } else if ("all".equals(value) || "a".equals(value)) {
            mode = PlayerStorage.ChatMode.ALL;
        } else {
            player.sendMessage(chatService.colored(chatService.configs().prefixed("usage-chats")));
            return;
        }
        chatService.setChatMode(player, mode);
        player.sendMessage(chatService.colored(chatService.configs().prefixed(mode == PlayerStorage.ChatMode.ONLY ? "chats-only" : "chats-all")));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length == 0) {
            return List.of("only", "all");
        }
        return List.of();
    }
}
