package cn.pn86.pnchat.command;

import cn.pn86.pnchat.ChatService;
import cn.pn86.pnchat.PnChatPlugin;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * /pnchat 主命令：管理广播、Title、称号、配置重载。
 *
 * <p>屏蔽功能已独立为一级命令（/ignore、/ignoreserver、/ignorelist），
 * 这里仍保留 /pnchat ignore|ignoreserver|ignorelist 作为兼容入口。</p>
 */
public final class PnChatCommand implements SimpleCommand {

    private final PnChatPlugin plugin;
    private final ProxyServer proxy;
    private final Logger logger;
    private final ChatService chatService;

    public PnChatCommand(PnChatPlugin plugin, ProxyServer proxy, Logger logger, ChatService chatService) {
        this.plugin = plugin;
        this.proxy = proxy;
        this.logger = logger;
        this.chatService = chatService;
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        String[] args = invocation.arguments();
        if (args.length == 0) {
            sendHelp(source);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "m":
            case "broadcast":
                requirePermission(source, "pnchat.command.admin", () -> {
                    if (args.length < 2) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-pnchat-title")));
                        return;
                    }
                    String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                    chatService.broadcastRawMessage(message);
                    source.sendMessage(chatService.colored(chatService.configs().prefixed("broadcast-message-sent")));
                });
                break;
            case "t":
            case "title":
                requirePermission(source, "pnchat.command.admin", () -> {
                    if (args.length < 5) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-pnchat-title")));
                        return;
                    }
                    try {
                        long fadeIn = Long.parseLong(args[1]);
                        long stay = Long.parseLong(args[2]);
                        long fadeOut = Long.parseLong(args[3]);
                        String title = args[4];
                        String subtitle = args.length > 5 ? args[5] : "";
                        chatService.broadcastTitle(title, subtitle, fadeIn, stay, fadeOut);
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("broadcast-title-sent")));
                    } catch (NumberFormatException e) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-pnchat-title")));
                    }
                });
                break;
            case "p":
            case "settitle":
                requirePermission(source, "pnchat.command.title", () -> {
                    if (!(source instanceof Player)) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
                        return;
                    }
                    if (args.length < 2) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("usage-pnchat-title")));
                        return;
                    }
                    String title = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                    chatService.setTitle((Player) source, title);
                    source.sendMessage(chatService.colored(chatService.configs().prefixed("title-set")
                            .replace("%player%", ((Player) source).getUsername())
                            .replace("%title%", title)));
                });
                break;
            case "rp":
            case "removetitle":
                requirePermission(source, "pnchat.command.title", () -> {
                    if (!(source instanceof Player)) {
                        source.sendMessage(chatService.colored(chatService.configs().prefixed("player-only")));
                        return;
                    }
                    chatService.removeTitle((Player) source);
                    source.sendMessage(chatService.colored(chatService.configs().prefixed("title-removed")));
                });
                break;
            case "ignore":
                // 兼容入口：一级命令为 /ignore
                IgnoreCommand.executePlayer(chatService, proxy, source, Arrays.copyOfRange(args, 1, args.length));
                break;
            case "ignoreserver":
                // 兼容入口：一级命令为 /ignoreserver
                IgnoreCommand.executeServer(chatService, source, Arrays.copyOfRange(args, 1, args.length));
                break;
            case "ignorelist":
                // 兼容入口：一级命令为 /ignorelist
                IgnoreCommand.executeList(chatService, proxy, source);
                break;
            case "reload":
                requirePermission(source, "pnchat.command.reload", () -> {
                    plugin.reload();
                    source.sendMessage(chatService.colored(chatService.configs().prefixed("reload")));
                });
                break;
            case "debug":
                requirePermission(source, "pnchat.command.debug", () -> handleDebug(source, args));
                break;
            default:
                sendHelp(source);
        }
    }

    private void handleDebug(CommandSource source, String[] args) {
        boolean enabled;
        if (args.length >= 2 && "on".equalsIgnoreCase(args[1])) {
            enabled = true;
        } else if (args.length >= 2 && "off".equalsIgnoreCase(args[1])) {
            enabled = false;
        } else if (args.length >= 2 && ("status".equalsIgnoreCase(args[1]) || "info".equalsIgnoreCase(args[1]))) {
            source.sendMessage(Component.text("§8[§aPnChat§8] §fDebug: "
                    + (plugin.isDebug() ? "§a开启" : "§c关闭")
                    + " §7| PacketEvents: " + (plugin.packetEventsActive() ? "§a启用" : "§c未启用/回退")
                    + " §7| 配置 debug: " + plugin.configs().debugEnabled()));
            return;
        } else {
            enabled = !plugin.isDebug();
        }
        plugin.setDebug(enabled);
        source.sendMessage(Component.text("§8[§aPnChat§8] §fDebug 模式已"
                + (enabled ? "§a开启" : "§c关闭")
                + "§f。开启后会输出数据包识别/协议解析详细日志与异常堆栈（config.yml 中 debug: true 可持久开启）。"));
    }

    private void sendHelp(CommandSource source) {
        source.sendMessage(Component.text("§8[§aPnChat§8] §fPnChat v1.4.0"));
        source.sendMessage(Component.text("§7/pnchat m <消息> §f- 全服广播"));
        source.sendMessage(Component.text("§7/pnchat t <fadeIn> <stay> <fadeOut> <标题> [副标题] §f- 全服 Title"));
        source.sendMessage(Component.text("§7/pnchat p <称号> / rp §f- 设置/移除自己的称号"));
        source.sendMessage(Component.text("§7/ignore <玩家名> §f- 屏蔽/解除屏蔽某玩家"));
        source.sendMessage(Component.text("§7/ignoreserver <子服名> §f- 屏蔽/解除屏蔽某子服聊天"));
        source.sendMessage(Component.text("§7/ignorelist §f- 查看屏蔽列表"));
        source.sendMessage(Component.text("§7/pnchat debug [on|off|status] §f- 开启/关闭/查看调试日志"));
        source.sendMessage(Component.text("§7/pnchat reload §f- 重载配置"));
    }

    private void requirePermission(CommandSource source, String permission, Runnable action) {
        if (!source.hasPermission(permission)) {
            source.sendMessage(chatService.colored(chatService.configs().prefixed("no-permission")));
            return;
        }
        action.run();
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length <= 1) {
            return List.of("m", "t", "p", "rp", "ignore", "ignoreserver", "ignorelist", "debug", "reload");
        }
        if ("ignore".equalsIgnoreCase(args[0]) && args.length == 2) {
            return chatService.onlineNames().stream().sorted().toList();
        }
        if ("ignoreserver".equalsIgnoreCase(args[0]) && args.length == 2) {
            return chatService.configs().configuredServerNames().stream().sorted().toList();
        }
        return List.of();
    }
}
