public class JavaVersion {
    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        System.out.println("java.home=" + System.getProperty("java.home"));
        System.out.println("javac.spec=" + System.getProperty("java.specification.version"));
    }
}
