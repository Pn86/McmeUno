package cn.pn86.pnserverssend.command;

import cn.pn86.pnserverssend.PnServersSend;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;

public final class AdminCommand implements CommandExecutor, TabCompleter {
    private final PnServersSend plugin;

    public AdminCommand(PnServersSend plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("pnserverssend.admin")) {
            send(sender, "no-permission", Map.of());
            return true;
        }
        if (args.length != 1 || !args[0].equalsIgnoreCase("reload")) {
            send(sender, "usage-pnss", Map.of());
            return true;
        }
        try {
            plugin.loadSettings();
            send(sender, "reloaded", Map.of());
        } catch (Exception exception) {
            plugin.getLogger().severe("配置重载失败: " + exception.getMessage());
            send(sender, "reload-failed", Map.of("reason", String.valueOf(exception.getMessage())));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("pnserverssend.admin")) return List.of();
        if (args.length == 1 && "reload".startsWith(args[0].toLowerCase())) return List.of("reload");
        return List.of();
    }

    private void send(CommandSender sender, String key, Map<String, String> placeholders) {
        Player player = sender instanceof Player p ? p : null;
        Component message = plugin.display().parse(player, plugin.settings().message(key), placeholders);
        sender.sendMessage(message);
    }
}
