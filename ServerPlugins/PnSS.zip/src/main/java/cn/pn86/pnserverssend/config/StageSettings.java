package cn.pn86.pnserverssend.config;

public record StageSettings(
        String title,
        String subtitle,
        int durationTicks,
        int fadeInTicks,
        int stayTicks,
        int fadeOutTicks,
        SoundSettings sound
) {}
