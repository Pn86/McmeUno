package cn.pn86.pnserverssend;

import cn.pn86.pnserverssend.command.AdminCommand;
import cn.pn86.pnserverssend.command.ServerTpCommand;
import cn.pn86.pnserverssend.config.PluginSettings;
import cn.pn86.pnserverssend.display.DisplayController;
import cn.pn86.pnserverssend.queue.SessionManager;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class PnServersSend extends JavaPlugin implements Listener {
    private PluginSettings settings;
    private DisplayController display;
    private SessionManager sessions;
    private String registeredChannel;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            loadSettings();
        } catch (Exception exception) {
            getLogger().severe("无法加载 config.yml: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        display = new DisplayController(this);
        sessions = new SessionManager(this);
        registerProxyChannel(settings.proxyChannel());
        registerCommands();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("PnServersSend " + getPluginMeta().getVersion() + " 已启用，将通过代理动态查询服务器列表。");
    }

    @Override
    public void onDisable() {
        if (sessions != null) sessions.shutdown();
        unregisterProxyChannel();
    }

    public void loadSettings() throws Exception {
        File configFile = new File(getDataFolder(), "config.yml");
        PluginSettings loaded = PluginSettings.load(configFile);
        String oldChannel = settings == null ? null : settings.proxyChannel();
        settings = loaded;
        if (sessions != null && (oldChannel == null || !oldChannel.equals(loaded.proxyChannel()))) {
            registerProxyChannel(loaded.proxyChannel());
        }
    }

    private void registerProxyChannel(String channel) {
        unregisterProxyChannel();
        getServer().getMessenger().registerOutgoingPluginChannel(this, channel);
        getServer().getMessenger().registerIncomingPluginChannel(this, channel, sessions);
        registeredChannel = channel;
    }

    private void unregisterProxyChannel() {
        if (registeredChannel == null) return;
        getServer().getMessenger().unregisterOutgoingPluginChannel(this, registeredChannel);
        getServer().getMessenger().unregisterIncomingPluginChannel(this, registeredChannel, sessions);
        registeredChannel = null;
    }

    private void registerCommands() {
        PluginCommand serverTp = requireCommand("servertp");
        ServerTpCommand serverTpHandler = new ServerTpCommand(this);
        serverTp.setExecutor(serverTpHandler);
        serverTp.setTabCompleter(serverTpHandler);

        PluginCommand pnss = requireCommand("pnss");
        AdminCommand adminHandler = new AdminCommand(this);
        pnss.setExecutor(adminHandler);
        pnss.setTabCompleter(adminHandler);
    }

    private PluginCommand requireCommand(String name) {
        PluginCommand command = getCommand(name);
        if (command == null) throw new IllegalStateException("plugin.yml 缺少命令: " + name);
        return command;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        sessions.cancel(event.getPlayer(), "", false);
    }

    public PluginSettings settings() { return settings; }
    public DisplayController display() { return display; }
    public SessionManager sessions() { return sessions; }
}
