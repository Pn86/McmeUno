package cn.pn86.pnserverssend.display;

import cn.pn86.pnserverssend.PnServersSend;
import cn.pn86.pnserverssend.config.SoundSettings;
import cn.pn86.pnserverssend.config.StageSettings;
import cn.pn86.pnserverssend.queue.TransferSession;
import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Map;

public final class DisplayController {
    private final PnServersSend plugin;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.builder()
            .character('&')
            .hexCharacter('#')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    public DisplayController(PnServersSend plugin) {
        this.plugin = plugin;
    }

    public void start(TransferSession session, String stageName) {
        session.setStage(stageName);
        render(session, true);
    }

    public void render(TransferSession session, boolean playSound) {
        StageSettings stage = plugin.settings().stage(session.stage());
        if (stage == null || !session.player().isOnline()) return;
        Map<String, String> placeholders = plugin.sessions().placeholders(session);
        Component title = parse(session.player(), stage.title(), placeholders);
        Component subtitle = parse(session.player(), stage.subtitle(), placeholders);
        Title.Times times = Title.Times.times(
                ticks(stage.fadeInTicks()),
                ticks(stage.stayTicks()),
                ticks(stage.fadeOutTicks())
        );
        session.player().showTitle(Title.title(title, subtitle, times));
        if (playSound) playSound(session.player(), stage.sound());
    }

    /**
     * 解析显示文本：先替换插件自定义变量 {player} {server} {position} {total} {reason}，
     * 若服务器已安装 PlaceholderAPI 且存在玩家上下文，再解析 PAPI 占位符 %xxx%。
     */
    public Component parse(Player player, String text, Map<String, String> placeholders) {
        String resolved = text == null ? "" : text;
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            resolved = resolved.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        if (player != null && placeholderApiAvailable()) {
            resolved = PlaceholderAPI.setPlaceholders(player, resolved);
        }
        return legacy.deserialize(resolved);
    }

    public void stopAnimation(TransferSession session) {
        // 1.2.0 起不再创建文本动画任务；保留该方法以统一清理流程。
    }

    private boolean placeholderApiAvailable() {
        return plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null;
    }

    private void playSound(Player player, SoundSettings sound) {
        if (!sound.enabled()) return;
        try {
            player.playSound(player.getLocation(), sound.name(), SoundCategory.MASTER, sound.volume(), sound.pitch());
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("无法播放音效 " + sound.name() + ": " + exception.getMessage());
        }
    }

    private static Duration ticks(int ticks) {
        return Duration.ofMillis(ticks * 50L);
    }
}
