package cn.pn86.pnserverssend.config;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PluginSettings {
    private final YamlConfiguration yaml;
    private final String proxyChannel;
    private final long proxyResponseTimeoutTicks;
    private final long releaseIntervalTicks;
    private final int maxQueueSize;
    private final long enterDelayTicks;
    private final Map<String, StageSettings> stages;

    private PluginSettings(YamlConfiguration yaml) {
        this.yaml = yaml;
        proxyChannel = nonBlank(yaml.getString("proxy.channel"), "BungeeCord");
        proxyResponseTimeoutTicks = Math.max(1L, yaml.getLong("detection.proxy-response-timeout-ticks", 60L));
        releaseIntervalTicks = Math.max(1L, yaml.getLong("queue.release-interval-seconds", 5L) * 20L);
        maxQueueSize = Math.max(0, yaml.getInt("queue.max-size-per-server", 0));
        enterDelayTicks = Math.max(0L, yaml.getLong("queue.enter-delay-seconds", 2L) * 20L);
        stages = Collections.unmodifiableMap(loadStages(yaml));
    }

    public static PluginSettings load(File file) throws Exception {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.load(file);
        return new PluginSettings(yaml);
    }

    private static Map<String, StageSettings> loadStages(YamlConfiguration yaml) {
        Map<String, StageSettings> result = new LinkedHashMap<>();
        for (String name : List.of("detecting", "queue", "entering", "failure", "cancelled")) {
            String root = "display." + name;
            String title = yaml.getString(root + ".title", "");
            String subtitle = yaml.getString(root + ".subtitle", "");
            int duration = Math.max(1, yaml.getInt(root + ".duration-ticks", 80));
            int fadeIn = Math.max(0, yaml.getInt(root + ".fade-in-ticks", 0));
            int stay = Math.max(1, yaml.getInt(root + ".stay-ticks", 70));
            int fadeOut = Math.max(0, yaml.getInt(root + ".fade-out-ticks", 0));
            SoundSettings sound = new SoundSettings(
                    yaml.getBoolean(root + ".sound.enabled", false),
                    nonBlank(yaml.getString(root + ".sound.name"), "minecraft:block.note_block.hat"),
                    (float) yaml.getDouble(root + ".sound.volume", 1.0),
                    (float) yaml.getDouble(root + ".sound.pitch", 1.0)
            );
            result.put(name, new StageSettings(title, subtitle, duration, fadeIn, stay, fadeOut, sound));
        }
        return result;
    }

    private static String nonBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    public String proxyChannel() { return proxyChannel; }
    public long proxyResponseTimeoutTicks() { return proxyResponseTimeoutTicks; }
    public long releaseIntervalTicks() { return releaseIntervalTicks; }
    public int maxQueueSize() { return maxQueueSize; }
    public long enterDelayTicks() { return enterDelayTicks; }
    public StageSettings stage(String name) { return stages.get(name); }
    public String message(String key) { return yaml.getString("messages." + key, "&cMissing message: " + key); }
    public String failureReason(String key) {
        String fallback = switch (key) {
            case "proxy-timeout" -> "代理未响应服务器检测请求";
            case "invalid-response" -> "服务器检测返回了无效响应";
            case "server-not-found" -> "代理中不存在服务器 {server}";
            case "send-failed" -> "无法向代理发送连接请求：{detail}";
            case "plugin-disabled" -> "插件已卸载";
            default -> key;
        };
        return yaml.getString("failure-reasons." + key, fallback);
    }
}
