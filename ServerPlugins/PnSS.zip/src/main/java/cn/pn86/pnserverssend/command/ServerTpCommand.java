package cn.pn86.pnserverssend.command;

import cn.pn86.pnserverssend.PnServersSend;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ServerTpCommand implements CommandExecutor, TabCompleter {
    private final PnServersSend plugin;

    public ServerTpCommand(PnServersSend plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            send(sender, "player-only", Map.of());
            return true;
        }
        if (!player.hasPermission("pnserverssend.use")) {
            send(player, "no-permission", Map.of());
            return true;
        }
        if (args.length != 1) {
            send(player, "usage-servertp", Map.of());
            return true;
        }
        if (plugin.sessions().hasSession(player)) {
            send(player, "already-processing", Map.of());
            return true;
        }
        plugin.sessions().begin(player, args[0]);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("pnserverssend.use")) return List.of();
        if (args.length != 1) return List.of();
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        plugin.sessions().cachedServers().forEach(server -> {
            if (server.toLowerCase(Locale.ROOT).startsWith(prefix)) result.add(server);
        });
        return result;
    }

    private void send(CommandSender sender, String key, Map<String, String> values) {
        Map<String, String> placeholders = new LinkedHashMap<>(values);
        placeholders.putIfAbsent("player", sender.getName());
        Player player = sender instanceof Player p ? p : null;
        Component message = plugin.display().parse(player, plugin.settings().message(key), placeholders);
        sender.sendMessage(message);
    }
}
