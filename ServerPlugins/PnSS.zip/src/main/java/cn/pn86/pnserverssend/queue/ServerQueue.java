package cn.pn86.pnserverssend.queue;

import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.UUID;

final class ServerQueue {
    private final Deque<UUID> players = new ArrayDeque<>();
    private BukkitTask releaseTask;

    void add(UUID playerId) { players.addLast(playerId); }
    UUID poll() { return players.pollFirst(); }
    boolean remove(UUID playerId) { return players.remove(playerId); }
    int size() { return players.size(); }
    boolean isEmpty() { return players.isEmpty(); }
    int position(UUID playerId) { return new ArrayList<>(players).indexOf(playerId) + 1; }
    List<UUID> snapshot() { return List.copyOf(players); }
    BukkitTask releaseTask() { return releaseTask; }
    void setReleaseTask(BukkitTask releaseTask) { this.releaseTask = releaseTask; }
}
