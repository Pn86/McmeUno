package cn.pn86.pnserverssend.queue;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Locale;
import java.util.UUID;

public final class TransferSession {
    private final UUID token = UUID.randomUUID();
    private final Player player;
    private final String requestedServer;
    private String proxyServerName;
    private String stage = "detecting";
    private String reason = "";
    private BukkitTask delayedTask;
    private DetectionPhase detectionPhase = DetectionPhase.SERVER_LIST;

    public TransferSession(Player player, String requestedServer) {
        this.player = player;
        this.requestedServer = requestedServer;
        this.proxyServerName = requestedServer;
    }

    public UUID token() { return token; }
    public Player player() { return player; }
    public String serverId() { return proxyServerName.toLowerCase(Locale.ROOT); }
    public String requestedServer() { return requestedServer; }
    public String proxyServerName() { return proxyServerName; }
    public void setProxyServerName(String proxyServerName) { this.proxyServerName = proxyServerName; }
    public String stage() { return stage; }
    public void setStage(String stage) { this.stage = stage; }
    public String reason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public BukkitTask delayedTask() { return delayedTask; }
    public void setDelayedTask(BukkitTask delayedTask) { this.delayedTask = delayedTask; }
    public DetectionPhase detectionPhase() { return detectionPhase; }
    public void setDetectionPhase(DetectionPhase detectionPhase) { this.detectionPhase = detectionPhase; }

    public enum DetectionPhase {
        SERVER_LIST,
        SERVER_COUNT,
        COMPLETE
    }
}
