package cn.pn86.pnserverssend.queue;

import cn.pn86.pnserverssend.PnServersSend;
import cn.pn86.pnserverssend.config.StageSettings;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class SessionManager implements PluginMessageListener {
    private final PnServersSend plugin;
    private final Map<UUID, TransferSession> sessions = new HashMap<>();
    private final Map<String, ServerQueue> queues = new HashMap<>();
    private final Set<String> cachedServers = new LinkedHashSet<>();

    public SessionManager(PnServersSend plugin) {
        this.plugin = plugin;
    }

    public boolean hasSession(Player player) {
        return sessions.containsKey(player.getUniqueId());
    }

    public boolean isCurrent(TransferSession session) {
        TransferSession current = sessions.get(session.player().getUniqueId());
        return current != null && current.token().equals(session.token());
    }

    public List<String> cachedServers() {
        return List.copyOf(cachedServers);
    }

    public void begin(Player player, String requestedServer) {
        TransferSession session = new TransferSession(player, requestedServer);
        sessions.put(player.getUniqueId(), session);
        plugin.display().start(session, "detecting");

        try {
            sendProxyMessage(player, "GetServers", null);
            scheduleProxyTimeout(session);
        } catch (IOException | RuntimeException exception) {
            fail(session, localizedReason(session, "send-failed", safeDetail(exception)));
        }
    }

    @Override
    public void onPluginMessageReceived(@NotNull String channel, @NotNull Player player, byte @NotNull [] message) {
        if (!channel.equalsIgnoreCase(plugin.settings().proxyChannel())) return;

        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(message))) {
            TransferSession session = sessions.get(player.getUniqueId());
            if (session == null || !isCurrent(session) || !"detecting".equals(session.stage())) return;
            String subchannel = input.readUTF();
            if ("GetServers".equals(subchannel)) {
                handleServerList(session, input.readUTF());
            } else if ("PlayerCount".equals(subchannel)) {
                handlePlayerCount(session, input);
            }
        } catch (IOException | RuntimeException exception) {
            TransferSession session = sessions.get(player.getUniqueId());
            if (session != null && isCurrent(session) && "detecting".equals(session.stage())) {
                fail(session, localizedReason(session, "invalid-response", safeDetail(exception)));
            }
        }
    }

    private void handleServerList(TransferSession session, String rawServers) throws IOException {
        if (session.detectionPhase() != TransferSession.DetectionPhase.SERVER_LIST) return;
        List<String> proxyServers = parseServerList(rawServers);
        cachedServers.clear();
        cachedServers.addAll(proxyServers);

        String matched = proxyServers.stream()
                .filter(name -> name.equalsIgnoreCase(session.requestedServer()))
                .findFirst()
                .orElse(null);
        if (matched == null) {
            fail(session, localizedReason(session, "server-not-found", ""));
            return;
        }

        cancelDelayedTask(session);
        session.setProxyServerName(matched);
        session.setDetectionPhase(TransferSession.DetectionPhase.SERVER_COUNT);
        sendProxyMessage(session.player(), "PlayerCount", matched);
        scheduleProxyTimeout(session);
    }

    /**
     * 代理返回目标服务器的在线人数，说明该服务器已注册在代理中且代理可与其通信。
     * 以代理视角判定可用性，不再直连目标服务器执行网络 Ping，因此跨机器、防火墙、
     * NAT 环境下也能正常检测并转服。
     */
    private void handlePlayerCount(TransferSession session, DataInputStream input) throws IOException {
        if (session.detectionPhase() != TransferSession.DetectionPhase.SERVER_COUNT) return;
        String serverName = input.readUTF();
        int playerCount = input.readInt();
        if (!serverName.equalsIgnoreCase(session.proxyServerName())) return;
        if (playerCount < 0) {
            fail(session, localizedReason(session, "server-not-found", ""));
            return;
        }
        cancelDelayedTask(session);
        session.setDetectionPhase(TransferSession.DetectionPhase.COMPLETE);
        enqueue(session);
    }

    private void scheduleProxyTimeout(TransferSession session) {
        cancelDelayedTask(session);
        BukkitTask timeout = plugin.getServer().getScheduler().runTaskLater(
                plugin,
                () -> {
                    if (isCurrent(session) && "detecting".equals(session.stage())) {
                        fail(session, localizedReason(session, "proxy-timeout", ""));
                    }
                },
                plugin.settings().proxyResponseTimeoutTicks()
        );
        session.setDelayedTask(timeout);
    }

    private List<String> parseServerList(String raw) {
        List<String> result = new ArrayList<>();
        for (String part : raw.split(",")) {
            String name = part.trim();
            if (!name.isEmpty()) result.add(name);
        }
        return result;
    }

    private void enqueue(TransferSession session) {
        ServerQueue queue = queues.computeIfAbsent(session.serverId(), ignored -> new ServerQueue());
        int maxSize = plugin.settings().maxQueueSize();
        if (maxSize > 0 && queue.size() >= maxSize) {
            fail(session, plainMessage("queue-full", session));
            return;
        }
        queue.add(session.player().getUniqueId());
        plugin.display().start(session, "queue");
        refreshQueue(session.serverId());
        scheduleRelease(session.serverId(), queue);
    }

    private void scheduleRelease(String serverId, ServerQueue queue) {
        if (queue.releaseTask() != null || queue.isEmpty()) return;
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(
                plugin,
                () -> {
                    queue.setReleaseTask(null);
                    releaseNext(serverId, queue);
                    if (!queue.isEmpty()) scheduleRelease(serverId, queue);
                },
                plugin.settings().releaseIntervalTicks()
        );
        queue.setReleaseTask(task);
    }

    private void releaseNext(String serverId, ServerQueue queue) {
        TransferSession selected = null;
        while (!queue.isEmpty() && selected == null) {
            UUID playerId = queue.poll();
            TransferSession candidate = sessions.get(playerId);
            if (candidate != null && isCurrent(candidate) && candidate.player().isOnline()) selected = candidate;
        }
        refreshQueue(serverId);
        if (selected == null) return;

        TransferSession session = selected;
        plugin.display().start(session, "entering");
        BukkitTask delayed = plugin.getServer().getScheduler().runTaskLater(
                plugin,
                () -> connect(session),
                plugin.settings().enterDelayTicks()
        );
        session.setDelayedTask(delayed);
    }

    private void connect(TransferSession session) {
        if (!isCurrent(session) || !session.player().isOnline()) return;
        try {
            sendProxyMessage(session.player(), "Connect", session.proxyServerName());
            BukkitTask cleanup = plugin.getServer().getScheduler().runTaskLater(plugin, () -> finish(session, false), 60L);
            session.setDelayedTask(cleanup);
        } catch (IOException | RuntimeException exception) {
            fail(session, localizedReason(session, "send-failed", safeDetail(exception)));
        }
    }

    private void sendProxyMessage(Player player, String subchannel, String argument) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream output = new DataOutputStream(bytes)) {
            output.writeUTF(subchannel);
            if (argument != null) output.writeUTF(argument);
        }
        player.sendPluginMessage(plugin, plugin.settings().proxyChannel(), bytes.toByteArray());
    }

    public void fail(TransferSession session, String reason) {
        if (!isCurrent(session)) return;
        cancelDelayedTask(session);
        removeFromQueue(session);
        session.setReason(reason);
        plugin.display().start(session, "failure");
        StageSettings stage = plugin.settings().stage("failure");
        BukkitTask cleanup = plugin.getServer().getScheduler().runTaskLater(
                plugin,
                () -> finish(session, false),
                stage == null ? 80L : stage.durationTicks()
        );
        session.setDelayedTask(cleanup);
    }

    public void cancel(Player player, String reason, boolean showCancelled) {
        TransferSession session = sessions.get(player.getUniqueId());
        if (session == null) return;
        cancelDelayedTask(session);
        removeFromQueue(session);
        if (showCancelled && player.isOnline()) {
            session.setReason(reason);
            plugin.display().start(session, "cancelled");
            StageSettings stage = plugin.settings().stage("cancelled");
            BukkitTask cleanup = plugin.getServer().getScheduler().runTaskLater(
                    plugin,
                    () -> finish(session, false),
                    stage == null ? 60L : stage.durationTicks()
            );
            session.setDelayedTask(cleanup);
        } else {
            finish(session, false);
        }
    }

    public void finish(TransferSession session, boolean clearTitle) {
        if (!isCurrent(session)) return;
        removeFromQueue(session);
        plugin.display().stopAnimation(session);
        cancelDelayedTask(session);
        sessions.remove(session.player().getUniqueId());
        if (clearTitle && session.player().isOnline()) session.player().clearTitle();
    }

    public void shutdown() {
        String reason = plugin.settings().failureReason("plugin-disabled");
        for (TransferSession session : sessions.values().toArray(TransferSession[]::new)) {
            session.setReason(reason);
            finish(session, true);
        }
        for (ServerQueue queue : queues.values()) {
            if (queue.releaseTask() != null) queue.releaseTask().cancel();
        }
        queues.clear();
        cachedServers.clear();
    }

    private void cancelDelayedTask(TransferSession session) {
        BukkitTask delayed = session.delayedTask();
        if (delayed != null) {
            delayed.cancel();
            session.setDelayedTask(null);
        }
    }

    private void removeFromQueue(TransferSession session) {
        ServerQueue queue = queues.get(session.serverId());
        if (queue == null) return;
        if (queue.remove(session.player().getUniqueId())) refreshQueue(session.serverId());
        if (queue.isEmpty() && queue.releaseTask() != null) {
            queue.releaseTask().cancel();
            queue.setReleaseTask(null);
        }
    }

    private void refreshQueue(String serverId) {
        ServerQueue queue = queues.get(serverId);
        if (queue == null) return;
        for (UUID playerId : queue.snapshot()) {
            TransferSession session = sessions.get(playerId);
            if (session != null && "queue".equals(session.stage())) plugin.display().render(session, false);
        }
    }

    public Map<String, String> placeholders(TransferSession session) {
        Map<String, String> values = new LinkedHashMap<>();
        ServerQueue queue = queues.get(session.serverId());
        values.put("player", session.player().getName());
        values.put("server", session.proxyServerName());
        values.put("position", queue == null ? "0" : String.valueOf(queue.position(session.player().getUniqueId())));
        values.put("total", queue == null ? "0" : String.valueOf(queue.size()));
        values.put("reason", session.reason());
        return values;
    }

    private String localizedReason(TransferSession session, String key, String detail) {
        return plugin.settings().failureReason(key)
                .replace("{server}", session.requestedServer())
                .replace("{detail}", detail == null ? "" : detail);
    }

    private String plainMessage(String key, TransferSession session) {
        String message = plugin.settings().message(key);
        for (Map.Entry<String, String> entry : placeholders(session).entrySet()) {
            message = message.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return message;
    }

    private static String safeDetail(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }
}
