package cn.pn86.pnserverssend.config;

public record SoundSettings(
        boolean enabled,
        String name,
        float volume,
        float pitch
) {}
