package dev.craftwizard.paperplugin;

import org.bukkit.plugin.java.JavaPlugin;

public final class PaperPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("PaperPlugin enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("PaperPlugin disabled.");
    }
}
